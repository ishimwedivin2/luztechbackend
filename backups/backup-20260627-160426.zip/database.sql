--
-- PostgreSQL database dump
--

-- Dumped from database version 17.1
-- Dumped by pg_dump version 17.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.procurement_orders DROP CONSTRAINT IF EXISTS fkthjya06tx4ktno1tw72q1vogf;
ALTER TABLE IF EXISTS ONLY public.support_messages DROP CONSTRAINT IF EXISTS fkt3x5f2qc7d89medr0xxslx982;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fksjfs85qf6vmcurlx43cnc16gy;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS fksf8xqne4s20910sgk48jvyx4u;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS fksaok720gsu4u2wrgbk10b5n8d;
ALTER TABLE IF EXISTS ONLY public.shipments DROP CONSTRAINT IF EXISTS fkrnt4wht95lxxplspltrg9681s;
ALTER TABLE IF EXISTS ONLY public.satisfaction_surveys DROP CONSTRAINT IF EXISTS fkrivxx8qmqpjxdli4nwquxol58;
ALTER TABLE IF EXISTS ONLY public.wishlist_items DROP CONSTRAINT IF EXISTS fkqxj7lncd242b59fb78rqegyxj;
ALTER TABLE IF EXISTS ONLY public.product_images DROP CONSTRAINT IF EXISTS fkqnq71xsohugpqwf3c9gxmsuy;
ALTER TABLE IF EXISTS ONLY public.customer_metrics DROP CONSTRAINT IF EXISTS fkqj2ewu7pf91h6a56jvd05l6s;
ALTER TABLE IF EXISTS ONLY public.order_tracking_events DROP CONSTRAINT IF EXISTS fkpiysrnkv9a30xirabwtyd0poj;
ALTER TABLE IF EXISTS ONLY public.cart_items DROP CONSTRAINT IF EXISTS fkpcttvuq4mxppo8sxggjtn5i2c;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS fkog2rp4qthbtt2lfyhfo32lsw9;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS fkocimc7dtr037rh4ls4l95nlfi;
ALTER TABLE IF EXISTS ONLY public.support_tickets DROP CONSTRAINT IF EXISTS fko9o82krkf7cg9ic4r5froc83v;
ALTER TABLE IF EXISTS ONLY public.payment_transactions DROP CONSTRAINT IF EXISTS fknsous9qyrjv5ss8que6o6617;
ALTER TABLE IF EXISTS ONLY public.wishlist_items DROP CONSTRAINT IF EXISTS fkmmj2k1i459yu449k3h1vx5abp;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fkmb88e3a35geg9rxiefr1qma88;
ALTER TABLE IF EXISTS ONLY public.mfa_otps DROP CONSTRAINT IF EXISTS fkm4pfhtf6c4ov8if1v97yfrpy;
ALTER TABLE IF EXISTS ONLY public.fulfillment_orders DROP CONSTRAINT IF EXISTS fklqmme8l6wu2wdx6m5pdg5kvc6;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS fkk3ndxg5xp6v7wd4gjyusp15gq;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS fkhfh9dx7w3ubf1co1vdev94g3f;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS fkh8ciramu9cc9q3qcqiv4ue8a6;
ALTER TABLE IF EXISTS ONLY public.communication_logs DROP CONSTRAINT IF EXISTS fkgk9474pf5rnu0c37mekk9gap9;
ALTER TABLE IF EXISTS ONLY public.chat_messages DROP CONSTRAINT IF EXISTS fkgiqeap8ays4lf684x7m0r2729;
ALTER TABLE IF EXISTS ONLY public.support_messages DROP CONSTRAINT IF EXISTS fkejv4umpsfsqv4amvnjrmni3xi;
ALTER TABLE IF EXISTS ONLY public.procurement_orders DROP CONSTRAINT IF EXISTS fkbvdwa0a0j4xip16ocu2twj4bk;
ALTER TABLE IF EXISTS ONLY public.return_requests DROP CONSTRAINT IF EXISTS fkbski88d6kewx0cbj5pk7nes01;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS fkbioxgbv59vetrxe0ejfubep1w;
ALTER TABLE IF EXISTS ONLY public.carts DROP CONSTRAINT IF EXISTS fkb5o626f86h46m4s7ms6ginnop;
ALTER TABLE IF EXISTS ONLY public.chat_sessions DROP CONSTRAINT IF EXISTS fkao4yreakip07aurht94h7lo6r;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS fk9y21adhxn0ayjhfocscqox7bh;
ALTER TABLE IF EXISTS ONLY public.customer_profiles DROP CONSTRAINT IF EXISTS fk9u9qbkn57pxecpxjstd68deti;
ALTER TABLE IF EXISTS ONLY public.fulfillment_orders DROP CONSTRAINT IF EXISTS fk9r0ufkesaxvhurv9q8fch75ka;
ALTER TABLE IF EXISTS ONLY public.customer_profiles DROP CONSTRAINT IF EXISTS fk9b8jyctrw1rowxsyiwmvh3gae;
ALTER TABLE IF EXISTS ONLY public.feedbacks DROP CONSTRAINT IF EXISTS fk8kw5agn6ypgg4lkjrbc54wk0c;
ALTER TABLE IF EXISTS ONLY public.communication_logs DROP CONSTRAINT IF EXISTS fk81wbm56ml5kl04lda12gxhrxs;
ALTER TABLE IF EXISTS ONLY public.chat_sessions DROP CONSTRAINT IF EXISTS fk6acn2awn3clx0yvpn8htd70be;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS fk5u9vbactm63h16y9fj00t798f;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS fk5cyj7v7fvm60i2ubciqfo2wxm;
ALTER TABLE IF EXISTS ONLY public.product_reviews DROP CONSTRAINT IF EXISTS fk58i39bhws2hss3tbcvdmrm60f;
ALTER TABLE IF EXISTS ONLY public.chat_messages DROP CONSTRAINT IF EXISTS fk3cpkdtwdxndrjhrx3gt9q5ux9;
ALTER TABLE IF EXISTS ONLY public.product_reviews DROP CONSTRAINT IF EXISTS fk35kxxqe2g9r4mww80w9e3tnw9;
ALTER TABLE IF EXISTS ONLY public.support_tickets DROP CONSTRAINT IF EXISTS fk1tmbsselat6ceyejefrvdeis9;
ALTER TABLE IF EXISTS ONLY public.cart_items DROP CONSTRAINT IF EXISTS fk1re40cjegsfvw58xrkdp6bac6;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS fk1lih5y2npsf8u5o3vhdb9y0os;
ALTER TABLE IF EXISTS ONLY public.wishlist_items DROP CONSTRAINT IF EXISTS wishlist_items_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS ukt8o6pivur7nn124jehx7cygw5;
ALTER TABLE IF EXISTS ONLY public.fulfillment_orders DROP CONSTRAINT IF EXISTS ukrkhys3qm94etm6t863ifw77t0;
ALTER TABLE IF EXISTS ONLY public.satisfaction_surveys DROP CONSTRAINT IF EXISTS ukpv41e93d5s8qmc9eq8ws0hawj;
ALTER TABLE IF EXISTS ONLY public.inventory_items DROP CONSTRAINT IF EXISTS ukp0mih1lkha7t38jh46r3uu0eg;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS ukofx66keruapi6vyqpv6f2or37;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS uknthkiu7pgmnqnu86i2jyoe2v7;
ALTER TABLE IF EXISTS ONLY public.fulfillment_orders DROP CONSTRAINT IF EXISTS ukng3qc69pwbil0dalh7vkmueod;
ALTER TABLE IF EXISTS ONLY public.return_requests DROP CONSTRAINT IF EXISTS ukmlyu5yxuty6xy4bndr5rrnfr0;
ALTER TABLE IF EXISTS ONLY public.customer_profiles DROP CONSTRAINT IF EXISTS ukjoftwv6r96fq3bdnu7q00hq1w;
ALTER TABLE IF EXISTS ONLY public.mfa_otps DROP CONSTRAINT IF EXISTS ukicfpxf4f0hvk8up1epwolbe29;
ALTER TABLE IF EXISTS ONLY public.customer_metrics DROP CONSTRAINT IF EXISTS ukhuf800pbo311daueruwtpgd4w;
ALTER TABLE IF EXISTS ONLY public.shipments DROP CONSTRAINT IF EXISTS ukhrhy2yghr8dampg1jtecuekvp;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS ukghpmfn23vmxfu3spu3lfg4r2d;
ALTER TABLE IF EXISTS ONLY public.coupons DROP CONSTRAINT IF EXISTS ukeplt0kkm9yf2of2lnx6c1oy9b;
ALTER TABLE IF EXISTS ONLY public.customer_segments DROP CONSTRAINT IF EXISTS uk9v933bm211015c3i1vh4qg1iq;
ALTER TABLE IF EXISTS ONLY public.system_configurations DROP CONSTRAINT IF EXISTS uk867jsfttn43kaegq3c6c24b7r;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS uk7tdcd6ab5wsgoudnvj7xf1b7l;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS uk71lqwbwtklmljk3qlsugr1mig;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS uk6dotkott2kjsp8vw4d0m25fb7;
ALTER TABLE IF EXISTS ONLY public.carts DROP CONSTRAINT IF EXISTS uk64t7ox312pqal3p7fg9o503c2;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS uk61hq67yr3nuuwvx80rbr95r4s;
ALTER TABLE IF EXISTS ONLY public.tax_records DROP CONSTRAINT IF EXISTS tax_records_pkey;
ALTER TABLE IF EXISTS ONLY public.system_configurations DROP CONSTRAINT IF EXISTS system_configurations_pkey;
ALTER TABLE IF EXISTS ONLY public.system_backups DROP CONSTRAINT IF EXISTS system_backups_pkey;
ALTER TABLE IF EXISTS ONLY public.support_tickets DROP CONSTRAINT IF EXISTS support_tickets_pkey;
ALTER TABLE IF EXISTS ONLY public.support_messages DROP CONSTRAINT IF EXISTS support_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.suppliers DROP CONSTRAINT IF EXISTS suppliers_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_pkey;
ALTER TABLE IF EXISTS ONLY public.shipments DROP CONSTRAINT IF EXISTS shipments_pkey;
ALTER TABLE IF EXISTS ONLY public.security_settings DROP CONSTRAINT IF EXISTS security_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.satisfaction_surveys DROP CONSTRAINT IF EXISTS satisfaction_surveys_pkey;
ALTER TABLE IF EXISTS ONLY public.sales_reports DROP CONSTRAINT IF EXISTS sales_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.revenues DROP CONSTRAINT IF EXISTS revenues_pkey;
ALTER TABLE IF EXISTS ONLY public.return_requests DROP CONSTRAINT IF EXISTS return_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_pkey;
ALTER TABLE IF EXISTS ONLY public.product_reviews DROP CONSTRAINT IF EXISTS product_reviews_pkey;
ALTER TABLE IF EXISTS ONLY public.product_images DROP CONSTRAINT IF EXISTS product_images_pkey;
ALTER TABLE IF EXISTS ONLY public.procurement_orders DROP CONSTRAINT IF EXISTS procurement_orders_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_transactions DROP CONSTRAINT IF EXISTS payment_transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS password_reset_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_pkey;
ALTER TABLE IF EXISTS ONLY public.order_tracking_events DROP CONSTRAINT IF EXISTS order_tracking_events_pkey;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.mfa_otps DROP CONSTRAINT IF EXISTS mfa_otps_pkey;
ALTER TABLE IF EXISTS ONLY public.login_attempts DROP CONSTRAINT IF EXISTS login_attempts_pkey;
ALTER TABLE IF EXISTS ONLY public.kpi_records DROP CONSTRAINT IF EXISTS kpi_records_pkey;
ALTER TABLE IF EXISTS ONLY public.inventory_items DROP CONSTRAINT IF EXISTS inventory_items_pkey;
ALTER TABLE IF EXISTS ONLY public.fulfillment_orders DROP CONSTRAINT IF EXISTS fulfillment_orders_pkey;
ALTER TABLE IF EXISTS ONLY public.financial_reports DROP CONSTRAINT IF EXISTS financial_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.feedbacks DROP CONSTRAINT IF EXISTS feedbacks_pkey;
ALTER TABLE IF EXISTS ONLY public.faq_articles DROP CONSTRAINT IF EXISTS faq_articles_pkey;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_pkey;
ALTER TABLE IF EXISTS ONLY public.discounts DROP CONSTRAINT IF EXISTS discounts_pkey;
ALTER TABLE IF EXISTS ONLY public.customer_segments DROP CONSTRAINT IF EXISTS customer_segments_pkey;
ALTER TABLE IF EXISTS ONLY public.customer_profiles DROP CONSTRAINT IF EXISTS customer_profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.customer_metrics DROP CONSTRAINT IF EXISTS customer_metrics_pkey;
ALTER TABLE IF EXISTS ONLY public.coupons DROP CONSTRAINT IF EXISTS coupons_pkey;
ALTER TABLE IF EXISTS ONLY public.communication_logs DROP CONSTRAINT IF EXISTS communication_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.chat_sessions DROP CONSTRAINT IF EXISTS chat_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.chat_messages DROP CONSTRAINT IF EXISTS chat_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.carts DROP CONSTRAINT IF EXISTS carts_pkey;
ALTER TABLE IF EXISTS ONLY public.cart_items DROP CONSTRAINT IF EXISTS cart_items_pkey;
ALTER TABLE IF EXISTS ONLY public.banners DROP CONSTRAINT IF EXISTS banners_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
DROP TABLE IF EXISTS public.wishlist_items;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.tax_records;
DROP TABLE IF EXISTS public.system_configurations;
DROP TABLE IF EXISTS public.system_backups;
DROP TABLE IF EXISTS public.support_tickets;
DROP TABLE IF EXISTS public.support_messages;
DROP TABLE IF EXISTS public.suppliers;
DROP TABLE IF EXISTS public.stock_movements;
DROP TABLE IF EXISTS public.shipments;
DROP TABLE IF EXISTS public.security_settings;
DROP TABLE IF EXISTS public.satisfaction_surveys;
DROP TABLE IF EXISTS public.sales_reports;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.revenues;
DROP TABLE IF EXISTS public.return_requests;
DROP TABLE IF EXISTS public.refresh_tokens;
DROP TABLE IF EXISTS public.products;
DROP TABLE IF EXISTS public.product_reviews;
DROP TABLE IF EXISTS public.product_images;
DROP TABLE IF EXISTS public.procurement_orders;
DROP TABLE IF EXISTS public.payment_transactions;
DROP TABLE IF EXISTS public.password_reset_tokens;
DROP TABLE IF EXISTS public.orders;
DROP TABLE IF EXISTS public.order_tracking_events;
DROP TABLE IF EXISTS public.order_items;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.mfa_otps;
DROP TABLE IF EXISTS public.login_attempts;
DROP TABLE IF EXISTS public.kpi_records;
DROP TABLE IF EXISTS public.inventory_items;
DROP TABLE IF EXISTS public.fulfillment_orders;
DROP TABLE IF EXISTS public.financial_reports;
DROP TABLE IF EXISTS public.feedbacks;
DROP TABLE IF EXISTS public.faq_articles;
DROP TABLE IF EXISTS public.expenses;
DROP TABLE IF EXISTS public.discounts;
DROP TABLE IF EXISTS public.customer_segments;
DROP TABLE IF EXISTS public.customer_profiles;
DROP TABLE IF EXISTS public.customer_metrics;
DROP TABLE IF EXISTS public.coupons;
DROP TABLE IF EXISTS public.communication_logs;
DROP TABLE IF EXISTS public.chat_sessions;
DROP TABLE IF EXISTS public.chat_messages;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.carts;
DROP TABLE IF EXISTS public.cart_items;
DROP TABLE IF EXISTS public.banners;
DROP TABLE IF EXISTS public.audit_logs;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    action character varying(255) NOT NULL,
    details character varying(255),
    ip_address character varying(255) NOT NULL,
    resource character varying(255) NOT NULL,
    status character varying(255),
    "timestamp" timestamp(6) without time zone,
    user_email character varying(255)
);


--
-- Name: banners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.banners (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    active boolean NOT NULL,
    button_text character varying(255),
    display_order integer,
    image_url character varying(255),
    link_url character varying(255),
    product_id uuid,
    subtitle text,
    tag_label character varying(255),
    title character varying(255) NOT NULL
);


--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_items (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    quantity integer NOT NULL,
    cart_id uuid NOT NULL,
    product_id uuid NOT NULL
);


--
-- Name: carts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carts (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    user_id uuid NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    description character varying(255),
    name character varying(255) NOT NULL,
    parent_id uuid
);


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_messages (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    message text NOT NULL,
    sender_id uuid NOT NULL,
    session_id uuid NOT NULL
);


--
-- Name: chat_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_sessions (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    status character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    agent_id uuid,
    customer_id uuid NOT NULL
);


--
-- Name: communication_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_logs (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    channel character varying(255) NOT NULL,
    notes text,
    outcome character varying(255),
    reference_id character varying(255),
    reference_type character varying(255),
    subject character varying(255) NOT NULL,
    customer_id uuid NOT NULL,
    handled_by_id uuid
);


--
-- Name: coupons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coupons (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    active boolean NOT NULL,
    amount numeric(38,2) NOT NULL,
    code character varying(255) NOT NULL,
    current_usage integer,
    expiry_date timestamp(6) without time zone,
    minimum_order_amount numeric(38,2),
    type character varying(255) NOT NULL,
    usage_limit integer
);


--
-- Name: customer_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_metrics (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    average_order_value numeric(38,2),
    engagement_score integer,
    return_rate_percentage integer,
    customer_id uuid NOT NULL
);


--
-- Name: customer_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_profiles (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    last_purchase_date date,
    total_purchases integer,
    total_spent numeric(38,2),
    customer_id uuid NOT NULL,
    segment_id uuid
);


--
-- Name: customer_segments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_segments (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    description character varying(255),
    name character varying(255) NOT NULL
);


--
-- Name: discounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discounts (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    active boolean NOT NULL,
    description character varying(255) NOT NULL,
    discount_percentage numeric(38,2) NOT NULL,
    end_date timestamp(6) without time zone,
    name character varying(255) NOT NULL,
    start_date timestamp(6) without time zone
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    amount numeric(38,2) NOT NULL,
    category character varying(255) NOT NULL,
    description character varying(255),
    expense_date date NOT NULL,
    status character varying(255) NOT NULL
);


--
-- Name: faq_articles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.faq_articles (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    answer text NOT NULL,
    category character varying(255) NOT NULL,
    published boolean NOT NULL,
    question character varying(255) NOT NULL
);


--
-- Name: feedbacks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedbacks (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    category character varying(255),
    comments text,
    rating integer NOT NULL,
    reference_id character varying(255),
    customer_id uuid NOT NULL
);


--
-- Name: financial_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_reports (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    generated_date date,
    net_profit numeric(38,2) NOT NULL,
    report_period character varying(255) NOT NULL,
    total_expenses numeric(38,2) NOT NULL,
    total_revenue numeric(38,2) NOT NULL
);


--
-- Name: fulfillment_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fulfillment_orders (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    completed_at timestamp(6) without time zone,
    dispatched_at timestamp(6) without time zone,
    packed_at timestamp(6) without time zone,
    picked_at timestamp(6) without time zone,
    status character varying(255) NOT NULL,
    order_id uuid NOT NULL,
    shipment_id uuid
);


--
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_items (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    location character varying(255) NOT NULL,
    low_stock_threshold integer NOT NULL,
    product_name character varying(255) NOT NULL,
    quantity integer NOT NULL,
    sku character varying(255) NOT NULL
);


--
-- Name: kpi_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kpi_records (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    description character varying(255),
    metric_name character varying(255) NOT NULL,
    metric_value numeric(38,2) NOT NULL,
    record_date date NOT NULL
);


--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_attempts (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    email character varying(255) NOT NULL,
    failure_reason character varying(255),
    ip_address character varying(255) NOT NULL,
    success boolean NOT NULL
);


--
-- Name: mfa_otps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mfa_otps (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    code_hash character varying(255) NOT NULL,
    expiry_date timestamp(6) with time zone NOT NULL,
    mfa_token character varying(255) NOT NULL,
    used boolean NOT NULL,
    user_id uuid NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    message text NOT NULL,
    read boolean NOT NULL,
    related_id character varying(255),
    title character varying(255) NOT NULL,
    type character varying(255),
    user_id uuid NOT NULL
);


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    quantity integer NOT NULL,
    sub_total numeric(38,2) NOT NULL,
    unit_price numeric(38,2) NOT NULL,
    order_id uuid NOT NULL,
    product_id uuid NOT NULL
);


--
-- Name: order_tracking_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_tracking_events (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    note text,
    status character varying(255) NOT NULL,
    order_id uuid NOT NULL,
    CONSTRAINT order_tracking_events_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'CREATED'::character varying, 'PAID'::character varying, 'PROCESSING'::character varying, 'SHIPPED'::character varying, 'DELIVERED'::character varying, 'CANCELLED'::character varying, 'RETURN_REQUESTED'::character varying, 'RETURNED'::character varying, 'REFUNDED'::character varying])::text[])))
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    billing_address character varying(255),
    coupon_code character varying(255),
    discount_amount numeric(38,2),
    order_channel character varying(255) NOT NULL,
    order_number character varying(255) NOT NULL,
    payment_method character varying(255),
    payment_reference character varying(255),
    shipping_address character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    sub_total_amount numeric(38,2),
    tax_amount numeric(38,2),
    tax_rate numeric(38,2),
    total_amount numeric(38,2) NOT NULL,
    cashier_id uuid,
    customer_id uuid,
    CONSTRAINT orders_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'CREATED'::character varying, 'PAID'::character varying, 'PROCESSING'::character varying, 'SHIPPED'::character varying, 'DELIVERED'::character varying, 'CANCELLED'::character varying, 'RETURN_REQUESTED'::character varying, 'RETURNED'::character varying, 'REFUNDED'::character varying])::text[])))
);


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    expiry_date timestamp(6) with time zone NOT NULL,
    token character varying(255) NOT NULL,
    used boolean NOT NULL,
    user_id uuid NOT NULL
);


--
-- Name: payment_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_transactions (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    amount numeric(38,2) NOT NULL,
    payment_reference character varying(255),
    provider character varying(255) NOT NULL,
    reconciled_at timestamp(6) without time zone,
    reconciliation_notes text,
    reconciliation_status character varying(255),
    status character varying(255) NOT NULL,
    transaction_type character varying(255) NOT NULL,
    order_id uuid NOT NULL
);


--
-- Name: procurement_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.procurement_orders (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    expected_delivery_date date,
    quantity_ordered integer NOT NULL,
    quantity_received integer,
    status character varying(255) NOT NULL,
    total_cost numeric(38,2),
    inventory_item_id uuid NOT NULL,
    supplier_id uuid NOT NULL
);


--
-- Name: product_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_images (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    alt_text character varying(255) NOT NULL,
    is_primary boolean NOT NULL,
    url character varying(255) NOT NULL,
    product_id uuid NOT NULL
);


--
-- Name: product_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_reviews (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    comment text,
    rating integer NOT NULL,
    verified_purchase boolean NOT NULL,
    product_id uuid NOT NULL,
    user_id uuid NOT NULL
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    average_rating numeric(3,2),
    description text,
    featured boolean NOT NULL,
    name character varying(255) NOT NULL,
    price numeric(38,2) NOT NULL,
    sku character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    category_id uuid,
    discount_id uuid,
    inventory_item_id uuid,
    CONSTRAINT products_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'DRAFT'::character varying, 'ARCHIVED'::character varying])::text[])))
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    expiry_date timestamp(6) with time zone NOT NULL,
    revoked boolean NOT NULL,
    token character varying(255) NOT NULL,
    user_id uuid
);


--
-- Name: return_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.return_requests (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    admin_notes character varying(255),
    approved_at timestamp(6) without time zone,
    completed_at timestamp(6) without time zone,
    reason character varying(255) NOT NULL,
    refund_provider character varying(255),
    refund_reference character varying(255),
    refund_requested_at timestamp(6) without time zone,
    refund_status character varying(255),
    refunded_amount numeric(38,2),
    requested_amount numeric(38,2),
    status character varying(255) NOT NULL,
    order_id uuid NOT NULL
);


--
-- Name: revenues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.revenues (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    amount numeric(38,2) NOT NULL,
    reference_id character varying(255),
    revenue_date date NOT NULL,
    source character varying(255) NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    description character varying(255),
    name character varying(255) NOT NULL
);


--
-- Name: sales_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_reports (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    active_customers integer NOT NULL,
    report_date date NOT NULL,
    report_period character varying(255),
    total_orders integer NOT NULL,
    total_revenue numeric(38,2) NOT NULL
);


--
-- Name: satisfaction_surveys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.satisfaction_surveys (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    feedback text,
    rating integer NOT NULL,
    ticket_id uuid NOT NULL
);


--
-- Name: security_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_settings (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    lockout_duration_minutes integer NOT NULL,
    max_failed_login_attempts integer NOT NULL,
    mfa_required boolean NOT NULL,
    password_min_length integer NOT NULL,
    password_require_digit boolean NOT NULL,
    password_require_lowercase boolean NOT NULL,
    password_require_special_character boolean NOT NULL,
    password_require_uppercase boolean NOT NULL,
    session_timeout_minutes integer NOT NULL
);


--
-- Name: shipments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipments (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    actual_delivery_date timestamp(6) without time zone,
    carrier character varying(255) NOT NULL,
    estimated_delivery_date timestamp(6) without time zone,
    status character varying(255) NOT NULL,
    tracking_number character varying(255) NOT NULL,
    order_id uuid NOT NULL
);


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_movements (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    quantity integer NOT NULL,
    reason character varying(255),
    reference_id character varying(255),
    type character varying(255) NOT NULL,
    inventory_item_id uuid NOT NULL
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    active boolean NOT NULL,
    address character varying(255),
    contact_email character varying(255) NOT NULL,
    contact_phone character varying(255),
    name character varying(255) NOT NULL,
    notes text,
    performance_rating double precision
);


--
-- Name: support_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_messages (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    message text NOT NULL,
    sender_id uuid NOT NULL,
    ticket_id uuid NOT NULL
);


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_tickets (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    description text NOT NULL,
    priority character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    assigned_agent_id uuid,
    customer_id uuid NOT NULL
);


--
-- Name: system_backups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_backups (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    completed_at timestamp(6) without time zone,
    file_path character varying(255) NOT NULL,
    message character varying(255),
    name character varying(255) NOT NULL,
    restored_at timestamp(6) without time zone,
    size_bytes bigint NOT NULL,
    status character varying(255) NOT NULL
);


--
-- Name: system_configurations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_configurations (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    category character varying(255),
    config_key character varying(255) NOT NULL,
    config_value text,
    description character varying(255),
    sensitive boolean NOT NULL
);


--
-- Name: tax_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_records (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    amount numeric(38,2) NOT NULL,
    filing_date date NOT NULL,
    order_id uuid,
    order_number character varying(255),
    reference_id character varying(255),
    status character varying(255),
    tax_date date,
    tax_rate numeric(38,2),
    tax_type character varying(255) NOT NULL,
    taxable_amount numeric(38,2)
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role_id uuid NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    address character varying(255),
    email character varying(255) NOT NULL,
    email_verified boolean NOT NULL,
    enabled boolean NOT NULL,
    first_name character varying(255) NOT NULL,
    force_password_change boolean NOT NULL,
    last_login_date timestamp(6) without time zone,
    last_name character varying(255) NOT NULL,
    locked boolean NOT NULL,
    password character varying(255),
    phone_number character varying(255)
);


--
-- Name: wishlist_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wishlist_items (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    product_id uuid NOT NULL,
    user_id uuid NOT NULL
);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, created_at, created_by, updated_at, updated_by, action, details, ip_address, resource, status, "timestamp", user_email) FROM stdin;
bc3af0d6-6c6c-45a9-9adf-1a477f815a2d	2026-06-27 15:39:37.334073	\N	2026-06-27 15:39:37.334073	\N	GET	status=101, durationMs=79, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/ws	SUCCESS	2026-06-27 15:39:37.330006	anonymousUser
6ba32d62-3d39-49b2-9461-2a719ff78387	2026-06-27 15:39:42.720532	\N	2026-06-27 15:39:42.720532	\N	GET	status=101, durationMs=0, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/ws	SUCCESS	2026-06-27 15:39:42.720533	anonymousUser
0caf07ad-3e61-4102-ad00-c46471ed292c	2026-06-27 15:40:03.851161	\N	2026-06-27 15:40:03.851161	\N	GET	status=500, durationMs=812, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	FAILURE	2026-06-27 15:40:03.841587	ishimwedivin2@gmail.com
10aa25c2-58f6-4958-8286-96ead0786cad	2026-06-27 15:40:04.484343	\N	2026-06-27 15:40:04.484343	\N	GET	status=200, durationMs=595, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 15:40:04.484344	ishimwedivin2@gmail.com
eff6f076-8fd5-49e0-b4c1-1fa9a32948d1	2026-06-27 15:40:04.596259	\N	2026-06-27 15:40:04.596259	\N	GET	status=200, durationMs=76, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 15:40:04.594781	ishimwedivin2@gmail.com
5708046d-3e81-4999-af19-58d9a6cc9abe	2026-06-27 15:40:04.710716	\N	2026-06-27 15:40:04.710716	\N	GET	status=200, durationMs=47, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-06-27 15:40:04.708708	ishimwedivin2@gmail.com
05a2155a-e830-4cbe-ab11-8362500a2351	2026-06-27 15:40:04.911951	\N	2026-06-27 15:40:04.911951	\N	getAllOrders	\N	0:0:0:0:0:0:0:1	com.luztechnology.order.controller.OrderController	SUCCESS	2026-06-27 15:40:04.910849	ishimwedivin2@gmail.com
61b95553-0807-4822-8581-921c4f00e29b	2026-06-27 15:40:04.921577	\N	2026-06-27 15:40:04.921577	\N	GET	status=200, durationMs=54, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/orders	SUCCESS	2026-06-27 15:40:04.920189	ishimwedivin2@gmail.com
99de3115-4146-4e16-9f73-0a08b5e142b1	2026-06-27 15:40:05.028735	\N	2026-06-27 15:40:05.028735	\N	GET	status=200, durationMs=33, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/analytics/revenue/monthly	SUCCESS	2026-06-27 15:40:05.0267	ishimwedivin2@gmail.com
85c79daa-1d9b-4da5-b946-257e84d6f1c8	2026-06-27 15:40:05.04206	\N	2026-06-27 15:40:05.04206	\N	GET	status=200, durationMs=64, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/analytics/revenue	SUCCESS	2026-06-27 15:40:05.038681	ishimwedivin2@gmail.com
8f8f1938-58aa-4fe1-ad00-3eb58b5f693f	2026-06-27 15:40:05.137382	\N	2026-06-27 15:40:05.137382	\N	GET	status=200, durationMs=255, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/tickets	SUCCESS	2026-06-27 15:40:05.135641	ishimwedivin2@gmail.com
0743c897-cc0a-4bd8-8d1a-0ff7ffcbb4b1	2026-06-27 15:40:05.173392	\N	2026-06-27 15:40:05.173392	\N	GET	status=200, durationMs=298, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/returns	SUCCESS	2026-06-27 15:40:05.172396	ishimwedivin2@gmail.com
c5f2f16d-c07e-4f5b-9128-8d1dc8a15766	2026-06-27 15:40:05.308103	\N	2026-06-27 15:40:05.308103	\N	GET	status=200, durationMs=333, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/analytics/dashboard/kpis	SUCCESS	2026-06-27 15:40:05.302865	ishimwedivin2@gmail.com
c627570b-7e4f-4936-bc3a-b574a7f6b897	2026-06-27 15:40:18.546029	\N	2026-06-27 15:40:18.546029	\N	GET	status=200, durationMs=38, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/discounts	SUCCESS	2026-06-27 15:40:18.544109	ishimwedivin2@gmail.com
ac4ea3dc-9154-4c0d-a3b6-65540d30e373	2026-06-27 15:40:18.629029	\N	2026-06-27 15:40:18.629029	\N	GET	status=200, durationMs=109, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:40:18.626787	ishimwedivin2@gmail.com
a5ed0dc1-ff27-4d63-afb3-8f2d6392b0f5	2026-06-27 15:40:18.675322	\N	2026-06-27 15:40:18.675322	\N	GET	status=200, durationMs=165, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-06-27 15:40:18.674037	ishimwedivin2@gmail.com
3decb8a4-28d3-44f1-8752-078a8602c39c	2026-06-27 15:40:21.648919	\N	2026-06-27 15:40:21.648919	\N	GET	status=200, durationMs=29, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:40:21.64892	ishimwedivin2@gmail.com
1d1802bf-5714-4c45-aff0-9f3e209d5167	2026-06-27 15:41:40.809382	\N	2026-06-27 15:41:40.809382	\N	POST	status=200, durationMs=1187, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:41:40.809383	ishimwedivin2@gmail.com
2d0917a8-715f-4bd5-996f-84905d15eed2	2026-06-27 15:43:03.624555	\N	2026-06-27 15:43:03.624555	\N	POST	status=200, durationMs=1498, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/upload	SUCCESS	2026-06-27 15:43:03.620678	ishimwedivin2@gmail.com
04758220-5a80-404c-8963-6797218640ec	2026-06-27 15:43:04.031659	\N	2026-06-27 15:43:04.031659	\N	GET	status=200, durationMs=30, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/discounts	SUCCESS	2026-06-27 15:43:04.029744	ishimwedivin2@gmail.com
dbef482f-732e-44cb-8a9d-cc97cfc7dc60	2026-06-27 15:43:04.051334	\N	2026-06-27 15:43:04.051334	\N	GET	status=200, durationMs=34, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:43:04.04662	ishimwedivin2@gmail.com
5a69e0b2-4d89-4ed6-8d4c-c318a55507a5	2026-06-27 15:43:04.340813	\N	2026-06-27 15:43:04.340813	\N	GET	status=200, durationMs=336, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-06-27 15:43:04.333844	ishimwedivin2@gmail.com
820e7b6a-f35b-427b-9a68-0e0ccca829a6	2026-06-27 15:43:32.184247	\N	2026-06-27 15:43:32.184247	\N	GET	status=200, durationMs=275, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:43:32.147238	ishimwedivin2@gmail.com
89149f0d-7b89-407e-939a-78afcc41fc7a	2026-06-27 15:46:01.598022	\N	2026-06-27 15:46:01.598022	\N	POST	status=200, durationMs=215, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:46:01.598022	ishimwedivin2@gmail.com
02d1a610-8e8b-47bd-bcf7-4a857e9cb516	2026-06-27 15:46:14.271601	\N	2026-06-27 15:46:14.271601	\N	POST	status=200, durationMs=219, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/upload	SUCCESS	2026-06-27 15:46:14.271601	ishimwedivin2@gmail.com
b54fe9ad-d8b8-4476-95cd-30b2e7ca4e46	2026-06-27 15:46:14.68492	\N	2026-06-27 15:46:14.685904	\N	GET	status=200, durationMs=17, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/discounts	SUCCESS	2026-06-27 15:46:14.678122	ishimwedivin2@gmail.com
62813651-b214-4d4e-a8f6-0d86c354e217	2026-06-27 15:46:14.709744	\N	2026-06-27 15:46:14.709744	\N	GET	status=200, durationMs=65, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:46:14.709744	ishimwedivin2@gmail.com
996267ef-ab2b-4f2d-8f76-c489bcd66b6f	2026-06-27 15:46:14.861445	\N	2026-06-27 15:46:14.867947	\N	GET	status=200, durationMs=202, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-06-27 15:46:14.861446	ishimwedivin2@gmail.com
8bae08c1-b44e-4614-a119-a92207cadf94	2026-06-27 15:49:49.131325	\N	2026-06-27 15:49:49.131325	\N	POST	status=200, durationMs=220, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners/upload	SUCCESS	2026-06-27 15:49:49.127902	ishimwedivin2@gmail.com
205cffb8-cdc4-40d5-8667-4f40e9ed114b	2026-06-27 15:49:51.600835	\N	2026-06-27 15:49:51.600835	\N	GET	status=200, durationMs=25, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-06-27 15:49:51.600835	ishimwedivin2@gmail.com
76d7b1a4-dc23-4178-b0d7-3ef7e596abb1	2026-06-27 15:49:51.908866	\N	2026-06-27 15:49:51.908866	\N	GET	status=200, durationMs=156, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-06-27 15:49:51.908867	ishimwedivin2@gmail.com
12f67061-5bbe-4e2f-a022-c70ccdbd68b8	2026-06-27 15:50:25.610821	\N	2026-06-27 15:50:25.610821	\N	GET	status=200, durationMs=65, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-06-27 15:50:25.609271	ishimwedivin2@gmail.com
4f9260d0-3e05-4b36-b681-0d4ef7d1949a	2026-06-27 15:50:25.735142	\N	2026-06-27 15:50:25.735142	\N	GET	status=200, durationMs=15, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/tickets	SUCCESS	2026-06-27 15:50:25.735142	ishimwedivin2@gmail.com
4742bee2-0d68-4e07-a0d5-af893a41aeb8	2026-06-27 15:50:28.107913	\N	2026-06-27 15:50:28.107913	\N	GET	status=200, durationMs=42, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/movements	SUCCESS	2026-06-27 15:50:28.099605	ishimwedivin2@gmail.com
efe1a251-3ba4-47c7-aaf4-511e431ec65f	2026-06-27 15:46:25.909235	\N	2026-06-27 15:46:25.909235	\N	GET	status=200, durationMs=131, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners/all	SUCCESS	2026-06-27 15:46:25.909235	ishimwedivin2@gmail.com
0d32ee85-1321-4e5f-962f-4356af58ac54	2026-06-27 15:48:29.707861	\N	2026-06-27 15:48:29.707861	\N	GET	status=200, durationMs=48, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners/all	SUCCESS	2026-06-27 15:48:29.706364	ishimwedivin2@gmail.com
b299166a-6408-4948-94b1-426b170e7d2e	2026-06-27 15:49:51.396018	\N	2026-06-27 15:49:51.396018	\N	GET	status=500, durationMs=92, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	FAILURE	2026-06-27 15:49:51.395016	ishimwedivin2@gmail.com
9397e033-ed39-4d8b-9ffc-f66b15afe6a7	2026-06-27 15:49:51.468332	\N	2026-06-27 15:49:51.468332	\N	GET	status=200, durationMs=43, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 15:49:51.467408	ishimwedivin2@gmail.com
ce56a487-2a4b-4cd3-a267-a043aec2f40f	2026-06-27 15:49:51.551342	\N	2026-06-27 15:49:51.551342	\N	GET	status=200, durationMs=59, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 15:49:51.551343	ishimwedivin2@gmail.com
5281be46-2362-4113-91ca-e7778b272562	2026-06-27 15:49:51.843885	\N	2026-06-27 15:49:51.843885	\N	GET	status=200, durationMs=72, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/featured	SUCCESS	2026-06-27 15:49:51.834868	ishimwedivin2@gmail.com
86fb8b5d-b4fa-4062-92c6-df5053aaef31	2026-06-27 15:49:52.027095	\N	2026-06-27 15:49:52.027095	\N	GET	status=500, durationMs=33, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/live-chat/sessions/my	FAILURE	2026-06-27 15:49:52.027095	ishimwedivin2@gmail.com
6d5af8ba-1323-4102-a670-12de79ba4ed8	2026-06-27 15:50:25.532996	\N	2026-06-27 15:50:25.532996	\N	GET	status=200, durationMs=7, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 15:50:25.52431	ishimwedivin2@gmail.com
2516c33b-a2df-4e07-adf8-8be08d66c43e	2026-06-27 15:50:25.743958	\N	2026-06-27 15:50:25.743958	\N	getAllOrders	\N	0:0:0:0:0:0:0:1	com.luztechnology.order.controller.OrderController	SUCCESS	2026-06-27 15:50:25.741975	ishimwedivin2@gmail.com
67246b69-59c0-4be9-8b0c-c5b1b301c402	2026-06-27 15:50:25.748398	\N	2026-06-27 15:50:25.748398	\N	GET	status=200, durationMs=30, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/orders	SUCCESS	2026-06-27 15:50:25.746879	ishimwedivin2@gmail.com
14e1f850-5a40-48b2-83bc-1505d6e4191a	2026-06-27 15:50:28.148448	\N	2026-06-27 15:50:28.148448	\N	GET	status=200, durationMs=94, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-06-27 15:50:28.140533	ishimwedivin2@gmail.com
a36aeda2-ee5b-4a78-a570-29fc16b64d5a	2026-06-27 15:50:58.033196	\N	2026-06-27 15:50:58.033196	\N	GET	status=200, durationMs=34, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-06-27 15:50:58.033196	ishimwedivin2@gmail.com
933f1513-749c-4dc4-85e3-91c8e313cb97	2026-06-27 15:48:29.216056	\N	2026-06-27 15:48:29.216056	\N	POST	status=200, durationMs=453, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners/upload	SUCCESS	2026-06-27 15:48:29.205349	ishimwedivin2@gmail.com
3c1468ef-f758-45e0-bf79-292b3e41bd1b	2026-06-27 15:49:49.527384	\N	2026-06-27 15:49:49.527384	\N	GET	status=200, durationMs=26, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners/all	SUCCESS	2026-06-27 15:49:49.524769	ishimwedivin2@gmail.com
f654c350-3edb-494e-84e6-0c91a6fdd23e	2026-06-27 15:49:51.676966	\N	2026-06-27 15:49:51.676966	\N	GET	status=200, durationMs=42, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:49:51.676966	ishimwedivin2@gmail.com
348a5026-29ca-4d5c-8a33-18c941224526	2026-06-27 15:49:51.818877	\N	2026-06-27 15:49:51.818877	\N	GET	status=200, durationMs=68, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners	SUCCESS	2026-06-27 15:49:51.816915	ishimwedivin2@gmail.com
9e6fda85-89a2-4344-984b-1f3c76671f89	2026-06-27 15:50:25.434987	\N	2026-06-27 15:50:25.434987	\N	GET	status=500, durationMs=15, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	FAILURE	2026-06-27 15:50:25.432705	ishimwedivin2@gmail.com
ec18f2c6-9422-482b-9750-8fbea311ca63	2026-06-27 15:50:25.495884	\N	2026-06-27 15:50:25.495884	\N	GET	status=200, durationMs=15, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 15:50:25.494458	ishimwedivin2@gmail.com
af9de83b-141d-48bc-bc64-af1dcd6ee421	2026-06-27 15:50:25.666575	\N	2026-06-27 15:50:25.666575	\N	GET	status=200, durationMs=11, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners/all	SUCCESS	2026-06-27 15:50:25.664127	ishimwedivin2@gmail.com
bab2d88f-2e46-4cb2-9ff9-3cdc584f876a	2026-06-27 15:50:25.75102	\N	2026-06-27 15:50:25.75102	\N	GET	status=200, durationMs=34, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/returns	SUCCESS	2026-06-27 15:50:25.751021	ishimwedivin2@gmail.com
090ca05c-7e2c-47b6-8323-09f084de40ff	2026-06-27 15:50:28.075595	\N	2026-06-27 15:50:28.075595	\N	GET	status=200, durationMs=7, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-06-27 15:50:28.065442	ishimwedivin2@gmail.com
3e3a21f1-7471-44e4-ac52-e8983dc1e2ad	2026-06-27 15:51:01.00966	\N	2026-06-27 15:51:01.00966	\N	GET	status=200, durationMs=12, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-06-27 15:51:01.009661	ishimwedivin2@gmail.com
81f359ac-bfe5-44bc-8483-82a28e90cb97	2026-06-27 15:51:57.027341	\N	2026-06-27 15:51:57.027341	\N	POST	status=200, durationMs=476, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-06-27 15:51:57.027341	ishimwedivin2@gmail.com
1908df63-c1af-4e7e-bbec-57d9eece8c5e	2026-06-27 15:51:57.426557	\N	2026-06-27 15:51:57.426557	\N	GET	status=200, durationMs=30, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-06-27 15:51:57.425359	ishimwedivin2@gmail.com
7c357e7f-8db4-4470-864f-209f6789ccfe	2026-06-27 15:52:01.076772	\N	2026-06-27 15:52:01.076772	\N	GET	status=200, durationMs=35, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/procurements	SUCCESS	2026-06-27 15:52:01.074403	ishimwedivin2@gmail.com
128c2033-50de-44bb-897f-eff233186085	2026-06-27 15:52:01.078818	\N	2026-06-27 15:52:01.078818	\N	GET	status=200, durationMs=37, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-06-27 15:52:01.076174	ishimwedivin2@gmail.com
64a847fc-54be-446c-9c77-04a4922b1f1e	2026-06-27 15:52:01.091191	\N	2026-06-27 15:52:01.091191	\N	GET	status=200, durationMs=48, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-06-27 15:52:01.086539	ishimwedivin2@gmail.com
54b387ac-f611-44bf-ae87-560d22fcf582	2026-06-27 15:52:04.344821	\N	2026-06-27 15:52:04.345794	\N	GET	status=200, durationMs=18, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-06-27 15:52:04.338778	ishimwedivin2@gmail.com
e64a0174-91d9-4709-8492-2afe14526218	2026-06-27 15:52:04.353293	\N	2026-06-27 15:52:04.353293	\N	GET	status=200, durationMs=31, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-06-27 15:52:04.351601	ishimwedivin2@gmail.com
4aa8f10b-7a60-4d24-b37f-67dad5aeef99	2026-06-27 15:53:02.579601	\N	2026-06-27 15:53:02.579601	\N	POST	status=200, durationMs=423, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/procurements	SUCCESS	2026-06-27 15:53:02.572244	ishimwedivin2@gmail.com
eec5095e-4181-4697-a72f-abbd6e790588	2026-06-27 15:53:02.943165	\N	2026-06-27 15:53:02.943165	\N	GET	status=200, durationMs=14, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-06-27 15:53:02.941768	ishimwedivin2@gmail.com
0cee70df-42cc-4620-9cb1-3260f827a988	2026-06-27 15:53:02.951754	\N	2026-06-27 15:53:02.951754	\N	GET	status=200, durationMs=21, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/procurements	SUCCESS	2026-06-27 15:53:02.948335	ishimwedivin2@gmail.com
863afb44-bb70-4285-a71e-a66ada37a320	2026-06-27 15:53:02.958672	\N	2026-06-27 15:53:02.958672	\N	GET	status=200, durationMs=21, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-06-27 15:53:02.958673	ishimwedivin2@gmail.com
91ef708b-e6e6-493c-a6a0-3277fc503da2	2026-06-27 15:53:07.067064	\N	2026-06-27 15:53:07.067064	\N	GET	status=200, durationMs=9, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-06-27 15:53:07.06383	ishimwedivin2@gmail.com
65798aef-ef03-43f1-9528-a49e5ad75cee	2026-06-27 15:53:07.070823	\N	2026-06-27 15:53:07.070823	\N	GET	status=200, durationMs=16, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications	SUCCESS	2026-06-27 15:53:07.070823	ishimwedivin2@gmail.com
d16b3b14-e942-4e39-acf7-275a7b594726	2026-06-27 15:53:10.480591	\N	2026-06-27 15:53:10.480591	\N	PATCH	status=500, durationMs=52, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/null/read	FAILURE	2026-06-27 15:53:10.480592	ishimwedivin2@gmail.com
e9281159-c8aa-4b6d-8053-d1cfff38cfb1	2026-06-27 15:53:18.153376	\N	2026-06-27 15:53:18.153376	\N	logoutUser	\N	0:0:0:0:0:0:0:1	com.luztechnology.auth.controller.AuthController	SUCCESS	2026-06-27 15:53:18.153376	ishimwedivin2@gmail.com
5c46394c-4615-4459-9c12-59210f09f979	2026-06-27 15:53:18.165678	\N	2026-06-27 15:53:18.165678	\N	POST	status=200, durationMs=44, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/auth/logout	SUCCESS	2026-06-27 15:53:18.163907	ishimwedivin2@gmail.com
9118199c-58ba-4748-9e5a-c6086a2294e2	2026-06-27 15:53:18.359462	\N	2026-06-27 15:53:18.359462	\N	GET	status=200, durationMs=20, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:53:18.359463	anonymousUser
d9aa7e11-59ec-46c0-86af-c205e69c8b91	2026-06-27 15:53:18.390868	\N	2026-06-27 15:53:18.390868	\N	GET	status=200, durationMs=11, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/featured	SUCCESS	2026-06-27 15:53:18.387823	anonymousUser
a1816d46-128c-4d6c-8b2d-b0ae829989e4	2026-06-27 15:54:09.646608	\N	2026-06-27 15:54:09.646608	\N	verifyMfa	\N	0:0:0:0:0:0:0:1	com.luztechnology.auth.controller.AuthController	SUCCESS	2026-06-27 15:54:09.646609	SYSTEM
ccc6d2dd-e44a-4e13-b44c-9616e9a54222	2026-06-27 15:54:09.650611	\N	2026-06-27 15:54:09.650611	\N	POST	status=200, durationMs=243, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/auth/mfa/verify	SUCCESS	2026-06-27 15:54:09.649608	anonymousUser
64d25ed7-d6b0-4dd0-b674-cfe1a0072a9e	2026-06-27 15:54:10.02958	\N	2026-06-27 15:54:10.02958	\N	GET	status=200, durationMs=75, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:54:10.024289	ishimdivin2019@gmail.com
ce9d8545-6b6b-4969-97d5-ec5cc4d7f539	2026-06-27 15:54:10.143449	\N	2026-06-27 15:54:10.143449	\N	GET	status=200, durationMs=16, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners	SUCCESS	2026-06-27 15:54:10.142334	ishimdivin2019@gmail.com
4ff4a767-0f10-43e9-bc85-e4f10379bb12	2026-06-27 15:54:21.569494	\N	2026-06-27 15:54:21.569494	\N	POST	status=200, durationMs=164, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart/items	SUCCESS	2026-06-27 15:54:21.568762	ishimdivin2019@gmail.com
1ca3201d-0976-4880-916d-0ee0382984a6	2026-06-27 15:54:21.755134	\N	2026-06-27 15:54:21.755134	\N	GET	status=200, durationMs=21, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 15:54:21.751477	ishimdivin2019@gmail.com
e7e77108-9a52-49f8-8a7a-a5e8df8b8ad3	2026-06-27 15:54:26.555248	\N	2026-06-27 15:54:26.555248	\N	GET	status=200, durationMs=10, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 15:54:26.554325	ishimdivin2019@gmail.com
7b2fda8d-7fd2-4025-ab5d-6b6f99478d8b	2026-06-27 15:54:29.894195	\N	2026-06-27 15:54:29.894195	\N	PATCH	status=200, durationMs=52, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart/items/3fe56847-f3e1-41f5-904d-374508a6e6c1	SUCCESS	2026-06-27 15:54:29.892263	ishimdivin2019@gmail.com
4ffe9ea8-8a5e-47a3-8eb5-96729d4ee823	2026-06-27 15:54:29.962575	\N	2026-06-27 15:54:29.962575	\N	GET	status=200, durationMs=19, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 15:54:29.962575	ishimdivin2019@gmail.com
95761933-c46d-4ea3-ac40-af0f799abcee	2026-06-27 15:54:35.696069	\N	2026-06-27 15:54:35.696069	\N	GET	status=200, durationMs=11, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 15:54:35.692136	ishimdivin2019@gmail.com
4608ab86-cda7-4ca6-a3c5-f6d3d612ccf8	2026-06-27 15:56:26.047754	\N	2026-06-27 15:56:26.047754	\N	GET	status=200, durationMs=53, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/featured	SUCCESS	2026-06-27 15:56:26.044416	anonymousUser
e57eae12-eac0-4225-a1e4-f177884461d0	2026-06-27 15:56:46.939456	\N	2026-06-27 15:56:46.939456	\N	authenticateUser	\N	0:0:0:0:0:0:0:1	com.luztechnology.auth.controller.AuthController	SUCCESS	2026-06-27 15:56:46.939457	SYSTEM
d8917b25-8ba8-4733-8404-ad768c751279	2026-06-27 15:56:46.957716	\N	2026-06-27 15:56:46.957716	\N	POST	status=200, durationMs=8197, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/auth/login	SUCCESS	2026-06-27 15:56:46.957717	ANONYMOUS
d6a741ef-b66b-43d9-8846-07484f3b20d1	2026-06-27 15:53:18.397319	\N	2026-06-27 15:53:18.397319	\N	GET	status=200, durationMs=15, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners	SUCCESS	2026-06-27 15:53:18.395742	anonymousUser
4f6bc888-d6cc-4cc0-8a01-eb6ff22ff00e	2026-06-27 15:54:09.806719	\N	2026-06-27 15:54:09.806719	\N	GET	status=200, durationMs=107, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 15:54:09.806719	ishimdivin2019@gmail.com
8fcb353f-bebc-40af-8f3e-6f491aeaae4b	2026-06-27 15:54:10.176451	\N	2026-06-27 15:54:10.176451	\N	GET	status=200, durationMs=60, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-06-27 15:54:10.176452	ishimdivin2019@gmail.com
3b60afcc-58b1-41ea-8a84-200e75503811	2026-06-27 15:54:21.796967	\N	2026-06-27 15:54:21.796967	\N	GET	status=200, durationMs=14, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 15:54:21.796967	ishimdivin2019@gmail.com
ebe76105-0986-4573-ac91-58974739ea5b	2026-06-27 15:54:26.649694	\N	2026-06-27 15:54:26.649694	\N	GET	status=200, durationMs=22, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/live-chat/sessions/my	SUCCESS	2026-06-27 15:54:26.648693	ishimdivin2019@gmail.com
5e30aca3-36d2-473b-94e9-034358a17a92	2026-06-27 15:54:29.989987	\N	2026-06-27 15:54:29.989987	\N	GET	status=200, durationMs=16, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 15:54:29.989988	ishimdivin2019@gmail.com
36634880-2ef4-465d-9d10-3ff93f3a0e78	2026-06-27 15:54:35.760787	\N	2026-06-27 15:54:35.760787	\N	GET	status=200, durationMs=12, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 15:54:35.760788	ishimdivin2019@gmail.com
f7e03ec0-5cbe-4692-b02c-53e40e049e90	2026-06-27 15:56:25.923349	\N	2026-06-27 15:56:25.923349	\N	GET	status=200, durationMs=88, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:56:25.884125	anonymousUser
b901ca82-befd-4d39-a285-54a883f70b6a	2026-06-27 15:56:26.031148	\N	2026-06-27 15:56:26.031148	\N	GET	status=200, durationMs=46, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners	SUCCESS	2026-06-27 15:56:26.026844	anonymousUser
403e01d8-d04c-444c-84cd-7441e644bc66	2026-06-27 15:53:18.423821	\N	2026-06-27 15:53:18.423821	\N	GET	status=200, durationMs=45, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-06-27 15:53:18.422841	anonymousUser
ffaa69dc-7535-4ff2-86e9-976abca959e8	2026-06-27 15:53:53.59429	\N	2026-06-27 15:53:53.59429	\N	authenticateUser	\N	0:0:0:0:0:0:0:1	com.luztechnology.auth.controller.AuthController	SUCCESS	2026-06-27 15:53:53.594291	SYSTEM
794419f7-0cf1-49d0-9dcf-71d001e7ba45	2026-06-27 15:53:53.611784	\N	2026-06-27 15:53:53.611784	\N	POST	status=200, durationMs=8467, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/auth/login	SUCCESS	2026-06-27 15:53:53.611785	ANONYMOUS
bba5cb72-1364-405b-bed1-38eab4c65bc6	2026-06-27 15:54:09.861867	\N	2026-06-27 15:54:09.861867	\N	GET	status=200, durationMs=13, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 15:54:09.857044	ishimdivin2019@gmail.com
43dcebf4-b4f2-4972-bce9-000eec0858d6	2026-06-27 15:54:09.91503	\N	2026-06-27 15:54:09.91503	\N	GET	status=200, durationMs=32, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 15:54:09.913218	ishimdivin2019@gmail.com
6f3d8ff7-b727-4e49-bf6d-a1f76217e09b	2026-06-27 15:54:10.13214	\N	2026-06-27 15:54:10.13214	\N	GET	status=200, durationMs=14, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/featured	SUCCESS	2026-06-27 15:54:10.130141	ishimdivin2019@gmail.com
f4480014-ba14-4dc7-9e41-ffa638b8aaaa	2026-06-27 15:54:10.247768	\N	2026-06-27 15:54:10.247768	\N	GET	status=200, durationMs=29, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/live-chat/sessions/my	SUCCESS	2026-06-27 15:54:10.244888	ishimdivin2019@gmail.com
be43f0d6-2ce7-4ae4-b075-f4b6175d5470	2026-06-27 15:54:21.657946	\N	2026-06-27 15:54:21.657946	\N	GET	status=200, durationMs=57, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 15:54:21.65389	ishimdivin2019@gmail.com
863cbb37-ef7a-45f7-94b7-e04590be5121	2026-06-27 15:54:26.501785	\N	2026-06-27 15:54:26.501785	\N	GET	status=200, durationMs=9, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 15:54:26.492617	ishimdivin2019@gmail.com
b24ae245-a7ef-4b7c-a1d9-1f3925fc38d4	2026-06-27 15:54:26.523922	\N	2026-06-27 15:54:26.523922	\N	GET	status=200, durationMs=17, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 15:54:26.523923	ishimdivin2019@gmail.com
21382681-7cd6-4817-9912-9330e728e98e	2026-06-27 15:54:26.605631	\N	2026-06-27 15:54:26.605631	\N	GET	status=200, durationMs=22, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 15:54:26.601664	ishimdivin2019@gmail.com
4fb359dd-9a37-417c-9a7e-0453520c738d	2026-06-27 15:54:29.929818	\N	2026-06-27 15:54:29.929818	\N	GET	status=200, durationMs=16, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 15:54:29.929818	ishimdivin2019@gmail.com
cc2c930f-7a10-4c86-a79e-77b6b1c45649	2026-06-27 15:54:30.01232	\N	2026-06-27 15:54:30.01232	\N	GET	status=200, durationMs=5, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 15:54:30.01132	ishimdivin2019@gmail.com
a1c4b097-d544-4238-9ec8-484332e4a084	2026-06-27 15:54:35.661961	\N	2026-06-27 15:54:35.661961	\N	GET	status=200, durationMs=34, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 15:54:35.661962	ishimdivin2019@gmail.com
a96c1c14-e269-4bc8-9f14-4627261099b8	2026-06-27 15:54:35.72235	\N	2026-06-27 15:54:35.72235	\N	GET	status=200, durationMs=0, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 15:54:35.710372	ishimdivin2019@gmail.com
e656dbc1-373c-47d4-ac59-96eb36cbf6e5	2026-06-27 15:54:35.809486	\N	2026-06-27 15:54:35.809486	\N	GET	status=200, durationMs=6, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/live-chat/sessions/my	SUCCESS	2026-06-27 15:54:35.808229	ishimdivin2019@gmail.com
cfb4754b-b0e2-4df3-9dd9-544a2e3036aa	2026-06-27 15:54:46.717636	\N	2026-06-27 15:54:46.717636	\N	POST	status=400, durationMs=306, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart/checkout	FAILURE	2026-06-27 15:54:46.717636	ishimdivin2019@gmail.com
7e35a615-1c47-466e-a7ee-e5db3d3c8490	2026-06-27 15:56:26.277739	\N	2026-06-27 15:56:26.278244	\N	GET	status=200, durationMs=294, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-06-27 15:56:26.275887	anonymousUser
24fe96bd-8452-412e-8513-fa4d315a228a	2026-06-27 15:56:26.476362	\N	2026-06-27 15:56:26.476362	\N	logoutUser	\N	0:0:0:0:0:0:0:1	com.luztechnology.auth.controller.AuthController	SUCCESS	2026-06-27 15:56:26.466142	ishimdivin2019@gmail.com
57e80ccd-854d-4df1-ac6e-9cd870064e6e	2026-06-27 15:56:26.499563	\N	2026-06-27 15:56:26.499563	\N	POST	status=200, durationMs=904, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/auth/logout	SUCCESS	2026-06-27 15:56:26.497556	ishimdivin2019@gmail.com
a96bdd38-d802-4c36-a308-1fd8950c150b	2026-06-27 15:57:34.15877	\N	2026-06-27 15:57:34.15877	\N	verifyMfa	\N	0:0:0:0:0:0:0:1	com.luztechnology.auth.controller.AuthController	SUCCESS	2026-06-27 15:57:34.157207	SYSTEM
4cb4773b-5e27-45e4-b28a-ee270109d80f	2026-06-27 15:57:34.214491	\N	2026-06-27 15:57:34.214491	\N	POST	status=200, durationMs=527, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/auth/mfa/verify	SUCCESS	2026-06-27 15:57:34.214492	anonymousUser
fc535f43-4c4d-42b0-8d8b-094506ca5174	2026-06-27 15:57:34.369861	\N	2026-06-27 15:57:34.369861	\N	GET	status=500, durationMs=78, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	FAILURE	2026-06-27 15:57:34.369862	ishimwedivin2@gmail.com
a765fc71-b89a-4159-8033-1473927155c3	2026-06-27 15:57:34.47828	\N	2026-06-27 15:57:34.47828	\N	GET	status=200, durationMs=35, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 15:57:34.47828	ishimwedivin2@gmail.com
33a7cfec-ac19-4d6b-ad77-89fb635a194f	2026-06-27 15:57:34.54546	\N	2026-06-27 15:57:34.54546	\N	GET	status=200, durationMs=36, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 15:57:34.544037	ishimwedivin2@gmail.com
9d0353e0-d1be-4659-a071-04bb850f3485	2026-06-27 15:57:34.610612	\N	2026-06-27 15:57:34.610612	\N	GET	status=200, durationMs=35, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-06-27 15:57:34.610613	ishimwedivin2@gmail.com
32abe1a6-a0a7-45c7-b418-f6f4791dc07d	2026-06-27 15:57:34.694572	\N	2026-06-27 15:57:34.694572	\N	GET	status=200, durationMs=35, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:57:34.694573	ishimwedivin2@gmail.com
c5e4603a-7ceb-4705-9939-902dd63f43a6	2026-06-27 15:57:34.832113	\N	2026-06-27 15:57:34.832113	\N	GET	status=200, durationMs=32, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/featured	SUCCESS	2026-06-27 15:57:34.829977	ishimwedivin2@gmail.com
5e65fb5a-f289-4662-8504-4cf8e751e67e	2026-06-27 15:57:39.264988	\N	2026-06-27 15:57:39.264988	\N	GET	status=200, durationMs=0, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 15:57:39.251444	ishimwedivin2@gmail.com
b76b3de7-063b-4a9d-b9a1-053e01c86e9a	2026-06-27 15:57:39.304152	\N	2026-06-27 15:57:39.304152	\N	GET	status=200, durationMs=34, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-06-27 15:57:39.303647	ishimwedivin2@gmail.com
1ef94460-5cee-484a-90ff-b0f7dbfc1a85	2026-06-27 15:57:39.411187	\N	2026-06-27 15:57:39.411187	\N	GET	status=200, durationMs=45, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-06-27 15:57:39.407004	ishimwedivin2@gmail.com
c00e60b1-120d-4aa3-8e82-95d2595202d1	2026-06-27 15:57:46.063208	\N	2026-06-27 15:57:46.063208	\N	GET	status=200, durationMs=14, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-06-27 15:57:46.054745	ishimwedivin2@gmail.com
84b05eac-71c8-4602-8218-6ec2726c578a	2026-06-27 15:58:06.333154	\N	2026-06-27 15:58:06.333154	\N	GET	status=200, durationMs=8, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-06-27 15:58:06.331144	ishimwedivin2@gmail.com
039ded9a-90b0-4cc1-b050-a2eebb34bd73	2026-06-27 15:58:12.374438	\N	2026-06-27 15:58:12.374438	\N	GET	status=200, durationMs=77, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/payments/reconciliation/transactions	SUCCESS	2026-06-27 15:58:12.370077	ishimwedivin2@gmail.com
c50b5c09-d0c8-4e91-87c2-37e11e1beced	2026-06-27 15:58:19.944308	\N	2026-06-27 15:58:19.944308	\N	GET	status=200, durationMs=55, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-06-27 15:58:19.944309	ishimwedivin2@gmail.com
7f5166d4-87c6-4d6b-a5b5-5f3f6b0e2f29	2026-06-27 15:58:27.055022	\N	2026-06-27 15:58:27.055022	\N	GET	status=200, durationMs=17, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-06-27 15:58:27.051986	ishimwedivin2@gmail.com
0220da54-5512-4e7d-8a9f-19451c183167	2026-06-27 15:58:31.793034	\N	2026-06-27 15:58:31.793034	\N	GET	status=200, durationMs=24, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/procurements	SUCCESS	2026-06-27 15:58:31.79253	ishimwedivin2@gmail.com
ffa29135-2ee0-432a-aa29-dea5e46d219b	2026-06-27 15:58:35.166907	\N	2026-06-27 15:58:35.166907	\N	GET	status=200, durationMs=12, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-06-27 15:58:35.165988	ishimwedivin2@gmail.com
add32017-3c16-4be1-b748-32b3bf8c48d1	2026-06-27 15:58:36.431775	\N	2026-06-27 15:58:36.431775	\N	GET	status=200, durationMs=27, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/movements	SUCCESS	2026-06-27 15:58:36.430536	ishimwedivin2@gmail.com
3a3cbd82-5989-47f2-a680-72c6730e96a5	2026-06-27 15:58:49.106833	\N	2026-06-27 15:58:49.106833	\N	GET	status=200, durationMs=12, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners	SUCCESS	2026-06-27 15:58:49.105889	anonymousUser
b85a2863-aaf5-44fd-b568-fc2fb2ffc318	2026-06-27 15:57:34.928208	\N	2026-06-27 15:57:34.928208	\N	GET	status=200, durationMs=137, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners	SUCCESS	2026-06-27 15:57:34.928209	ishimwedivin2@gmail.com
43c10c97-15a4-43df-acfa-5e1dc1570e89	2026-06-27 15:57:34.975395	\N	2026-06-27 15:57:34.975395	\N	GET	status=200, durationMs=146, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-06-27 15:57:34.975395	ishimwedivin2@gmail.com
41055f19-cb42-41ee-a3e9-1bbf3901eb23	2026-06-27 15:57:39.242674	\N	2026-06-27 15:57:39.242674	\N	GET	status=200, durationMs=9, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 15:57:39.242675	ishimwedivin2@gmail.com
47aefb92-23bb-4b7e-ba02-1edb3dc29aff	2026-06-27 15:57:39.402676	\N	2026-06-27 15:57:39.402676	\N	GET	status=200, durationMs=25, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-06-27 15:57:39.387108	ishimwedivin2@gmail.com
610136cd-4c4b-4f3f-a149-84426f5c4ec7	2026-06-27 15:57:39.528162	\N	2026-06-27 15:57:39.528162	\N	getAllOrders	\N	0:0:0:0:0:0:0:1	com.luztechnology.order.controller.OrderController	SUCCESS	2026-06-27 15:57:39.528163	ishimwedivin2@gmail.com
6a7d788c-e5a8-4c78-9661-2544627d6e50	2026-06-27 15:57:39.539334	\N	2026-06-27 15:57:39.539334	\N	GET	status=200, durationMs=31, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/orders	SUCCESS	2026-06-27 15:57:39.536166	ishimwedivin2@gmail.com
c2205970-51af-46c8-810d-16cbd320f4c6	2026-06-27 15:57:39.557674	\N	2026-06-27 15:57:39.557674	\N	GET	status=200, durationMs=35, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/returns	SUCCESS	2026-06-27 15:57:39.557674	ishimwedivin2@gmail.com
76478676-14a5-4ef8-8804-27510279f3b5	2026-06-27 15:57:46.086821	\N	2026-06-27 15:57:46.086821	\N	GET	status=200, durationMs=43, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/movements	SUCCESS	2026-06-27 15:57:46.083144	ishimwedivin2@gmail.com
2d7046bf-c5ab-4df2-a226-3850b549dbe7	2026-06-27 15:58:06.333154	\N	2026-06-27 15:58:06.333154	\N	GET	status=200, durationMs=12, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/procurements	SUCCESS	2026-06-27 15:58:06.333155	ishimwedivin2@gmail.com
bae50eb0-0b49-4dfc-a38e-9ad68dc9457c	2026-06-27 15:58:08.408535	\N	2026-06-27 15:58:08.408535	\N	getAllOrders	\N	0:0:0:0:0:0:0:1	com.luztechnology.order.controller.OrderController	SUCCESS	2026-06-27 15:58:08.408536	ishimwedivin2@gmail.com
151fe87e-1cd9-47c2-9480-de57befbe681	2026-06-27 15:58:08.412638	\N	2026-06-27 15:58:08.412638	\N	GET	status=200, durationMs=13, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/orders	SUCCESS	2026-06-27 15:58:08.411367	ishimwedivin2@gmail.com
972f4f1c-f28f-4532-8c05-ef11dfee29a1	2026-06-27 15:58:15.75013	\N	2026-06-27 15:58:15.75013	\N	GET	status=200, durationMs=14, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/discounts	SUCCESS	2026-06-27 15:58:15.74813	ishimwedivin2@gmail.com
4e4359f3-ee35-4816-8c94-e5720ca41c12	2026-06-27 15:58:15.774186	\N	2026-06-27 15:58:15.774186	\N	GET	status=200, durationMs=35, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-06-27 15:58:15.773681	ishimwedivin2@gmail.com
586b14a2-2a06-4be7-8af6-1ffe86149e33	2026-06-27 15:58:19.904275	\N	2026-06-27 15:58:19.904275	\N	GET	status=200, durationMs=14, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-06-27 15:58:19.903434	ishimwedivin2@gmail.com
313a961c-515a-4150-bd1e-e3bfc2a3d2f6	2026-06-27 15:58:25.092935	\N	2026-06-27 15:58:25.092935	\N	GET	status=200, durationMs=18, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-06-27 15:58:25.092241	ishimwedivin2@gmail.com
2c14789b-517b-4b10-94f2-be9a9876067c	2026-06-27 15:58:27.098964	\N	2026-06-27 15:58:27.098964	\N	GET	status=200, durationMs=51, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/procurements	SUCCESS	2026-06-27 15:58:27.098964	ishimwedivin2@gmail.com
955f6cbc-1853-4286-93a7-a9226c7d9ac0	2026-06-27 15:58:31.783007	\N	2026-06-27 15:58:31.783007	\N	GET	status=200, durationMs=9, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-06-27 15:58:31.777167	ishimwedivin2@gmail.com
50f24cb3-8ee8-4bc5-ad15-be9b4f503b03	2026-06-27 15:58:36.42092	\N	2026-06-27 15:58:36.42092	\N	GET	status=200, durationMs=17, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-06-27 15:58:36.420921	ishimwedivin2@gmail.com
dfca12e6-d3fa-4d69-b05c-82f9ffc08c85	2026-06-27 15:58:44.081838	\N	2026-06-27 15:58:44.081838	\N	GET	status=200, durationMs=18, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-06-27 15:58:44.08084	ishimwedivin2@gmail.com
676ff9ba-386b-4117-bf62-2438650eee72	2026-06-27 15:58:49.113963	\N	2026-06-27 15:58:49.113963	\N	GET	status=200, durationMs=18, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-06-27 15:58:49.113963	anonymousUser
f272ede6-b9ee-4d83-bd71-c9ed9d952551	2026-06-27 15:57:35.045088	\N	2026-06-27 15:57:35.045088	\N	GET	status=500, durationMs=6, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/live-chat/sessions/my	FAILURE	2026-06-27 15:57:35.043077	ishimwedivin2@gmail.com
b4c13f88-fe84-41f6-a226-b11c55091f38	2026-06-27 15:57:39.204403	\N	2026-06-27 15:57:39.204403	\N	GET	status=500, durationMs=5, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	FAILURE	2026-06-27 15:57:39.204403	ishimwedivin2@gmail.com
4591e2ba-f9da-456c-87fe-485753ccbfdd	2026-06-27 15:57:39.412621	\N	2026-06-27 15:57:39.412621	\N	GET	status=200, durationMs=48, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/procurements	SUCCESS	2026-06-27 15:57:39.407004	ishimwedivin2@gmail.com
616880f8-7b9e-4f7d-92a5-e00bd945da41	2026-06-27 15:57:39.544808	\N	2026-06-27 15:57:39.544808	\N	GET	status=200, durationMs=20, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/tickets	SUCCESS	2026-06-27 15:57:39.543867	ishimwedivin2@gmail.com
6dec51a7-4913-446a-94c1-a94250e5b586	2026-06-27 15:57:41.732847	\N	2026-06-27 15:57:41.732847	\N	GET	status=200, durationMs=7, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-06-27 15:57:41.727952	ishimwedivin2@gmail.com
5af4a30d-338b-4dfe-b4ed-a771c32aa5e4	2026-06-27 15:57:46.082637	\N	2026-06-27 15:57:46.082637	\N	GET	status=200, durationMs=37, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-06-27 15:57:46.08063	ishimwedivin2@gmail.com
64b15ac4-1d67-4934-8be9-12f7d8d6a0a7	2026-06-27 15:58:06.342326	\N	2026-06-27 15:58:06.342326	\N	GET	status=200, durationMs=21, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-06-27 15:58:06.342326	ishimwedivin2@gmail.com
af3e79a0-d4de-4815-b636-2821cbfd524e	2026-06-27 15:58:08.410171	\N	2026-06-27 15:58:08.410171	\N	getAllOrders	\N	0:0:0:0:0:0:0:1	com.luztechnology.order.controller.OrderController	SUCCESS	2026-06-27 15:58:08.408536	ishimwedivin2@gmail.com
6f17c01c-b0ec-49e4-a417-4ff742e6193b	2026-06-27 15:58:08.412638	\N	2026-06-27 15:58:08.412638	\N	GET	status=200, durationMs=14, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/orders	SUCCESS	2026-06-27 15:58:08.412638	ishimwedivin2@gmail.com
58e2fea6-c30f-42a9-a4db-ce207a69307c	2026-06-27 15:58:11.005676	\N	2026-06-27 15:58:11.005676	\N	getAllOrders	\N	0:0:0:0:0:0:0:1	com.luztechnology.order.controller.OrderController	SUCCESS	2026-06-27 15:58:11.005677	ishimwedivin2@gmail.com
02b15ecd-2b61-48d7-a0fa-a68b8a15f1d1	2026-06-27 15:58:11.011579	\N	2026-06-27 15:58:11.011579	\N	GET	status=200, durationMs=16, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/orders	SUCCESS	2026-06-27 15:58:11.009573	ishimwedivin2@gmail.com
2f2e4336-27d0-4dd7-9b6a-82b5ca375870	2026-06-27 15:58:12.419689	\N	2026-06-27 15:58:12.419689	\N	GET	status=200, durationMs=126, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/payments/reconciliation/summary	SUCCESS	2026-06-27 15:58:12.419689	ishimwedivin2@gmail.com
966d0e43-30d1-4725-aaae-e5787eac0c9e	2026-06-27 15:58:12.446579	\N	2026-06-27 15:58:12.446579	\N	GET	status=200, durationMs=2, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/payments/reconciliation/transactions	SUCCESS	2026-06-27 15:58:12.445578	ishimwedivin2@gmail.com
b43543ff-e4b1-40ce-88fa-c5ff459c3bc9	2026-06-27 15:58:15.76012	\N	2026-06-27 15:58:15.76012	\N	GET	status=200, durationMs=24, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:58:15.758927	ishimwedivin2@gmail.com
7613d900-ec04-4a77-b4ce-795d3292779b	2026-06-27 15:58:19.904275	\N	2026-06-27 15:58:19.904275	\N	GET	status=200, durationMs=11, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/movements	SUCCESS	2026-06-27 15:58:19.903434	ishimwedivin2@gmail.com
d67c2154-e1a5-4218-9d6c-7ff4eba0713d	2026-06-27 15:58:27.098964	\N	2026-06-27 15:58:27.098964	\N	GET	status=200, durationMs=83, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-06-27 15:58:27.096958	ishimwedivin2@gmail.com
86c1f16f-e995-4834-af3a-40522b5cda34	2026-06-27 15:58:31.440583	\N	2026-06-27 15:58:31.440583	\N	POST	status=200, durationMs=111, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/procurements/3ca9b26f-7f7b-4041-817c-d665d88881ed/receive	SUCCESS	2026-06-27 15:58:31.440584	ishimwedivin2@gmail.com
109f0428-213a-4630-a8b6-9147d3610cae	2026-06-27 15:58:31.809035	\N	2026-06-27 15:58:31.809035	\N	GET	status=200, durationMs=41, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-06-27 15:58:31.809036	ishimwedivin2@gmail.com
cab66d4d-0df1-44de-a1d1-868045ad5e9d	2026-06-27 15:58:36.417786	\N	2026-06-27 15:58:36.417786	\N	GET	status=200, durationMs=12, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-06-27 15:58:36.415057	ishimwedivin2@gmail.com
78baf04e-a266-49d3-80b0-6a6eb1129b20	2026-06-27 15:58:44.0766	\N	2026-06-27 15:58:44.0766	\N	GET	status=200, durationMs=16, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications	SUCCESS	2026-06-27 15:58:44.0766	ishimwedivin2@gmail.com
a7eb982c-08a6-4b90-99e5-7e36ef1cdcd9	2026-06-27 15:58:49.049544	\N	2026-06-27 15:58:49.049544	\N	logoutUser	\N	0:0:0:0:0:0:0:1	com.luztechnology.auth.controller.AuthController	SUCCESS	2026-06-27 15:58:49.049545	ishimwedivin2@gmail.com
da4c0795-52f0-4c81-8c96-e13921cdae82	2026-06-27 15:58:49.049544	\N	2026-06-27 15:58:49.049544	\N	POST	status=200, durationMs=13, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/auth/logout	SUCCESS	2026-06-27 15:58:49.049545	ishimwedivin2@gmail.com
6a4f96f9-132c-4e9f-825d-5ea1755f6cf6	2026-06-27 15:58:49.082398	\N	2026-06-27 15:58:49.082398	\N	GET	status=200, durationMs=9, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:58:49.082399	anonymousUser
e37a8c5f-2dad-4e40-9dde-a85a73a13c94	2026-06-27 15:58:49.1024	\N	2026-06-27 15:58:49.1024	\N	GET	status=200, durationMs=7, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/featured	SUCCESS	2026-06-27 15:58:49.1024	anonymousUser
50691070-ea76-4af8-a56f-6ea59bb45a05	2026-06-27 15:59:22.207048	\N	2026-06-27 15:59:22.207048	\N	authenticateUser	\N	0:0:0:0:0:0:0:1	com.luztechnology.auth.controller.AuthController	SUCCESS	2026-06-27 15:59:22.207049	SYSTEM
f7630d59-d6d0-44a1-87e7-209cad81d8c3	2026-06-27 15:59:22.213735	\N	2026-06-27 15:59:22.213735	\N	POST	status=200, durationMs=6792, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/auth/login	SUCCESS	2026-06-27 15:59:22.207049	ANONYMOUS
1e25b09c-3feb-47eb-8b71-0b1a312e61e5	2026-06-27 15:59:58.983213	\N	2026-06-27 15:59:58.983213	\N	verifyMfa	\N	0:0:0:0:0:0:0:1	com.luztechnology.auth.controller.AuthController	SUCCESS	2026-06-27 15:59:58.983214	SYSTEM
270f1f71-7964-4ca2-8350-6de29feb77fb	2026-06-27 15:59:58.988902	\N	2026-06-27 15:59:58.988902	\N	POST	status=200, durationMs=300, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/auth/mfa/verify	SUCCESS	2026-06-27 15:59:58.988903	anonymousUser
47028831-248a-4dff-bf01-926c15c50522	2026-06-27 15:59:59.122277	\N	2026-06-27 15:59:59.122277	\N	GET	status=200, durationMs=80, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 15:59:59.116269	ishimdivin2019@gmail.com
9bdc3da4-ec2d-477c-8ccb-744e8c42c1dd	2026-06-27 15:59:59.187745	\N	2026-06-27 15:59:59.187745	\N	GET	status=200, durationMs=23, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 15:59:59.187746	ishimdivin2019@gmail.com
85f2696b-20f9-4156-b0ff-e1ce98c42acc	2026-06-27 15:59:59.275587	\N	2026-06-27 15:59:59.275587	\N	GET	status=200, durationMs=19, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 15:59:59.273588	ishimdivin2019@gmail.com
a6e6ae43-543d-4295-bead-935327f72b4c	2026-06-27 15:59:59.385976	\N	2026-06-27 15:59:59.385976	\N	GET	status=200, durationMs=16, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/featured	SUCCESS	2026-06-27 15:59:59.384938	ishimdivin2019@gmail.com
b07386ae-ea0c-4ac8-9d3e-e436c3e62962	2026-06-27 15:59:59.449676	\N	2026-06-27 15:59:59.449676	\N	GET	status=200, durationMs=92, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-06-27 15:59:59.449676	ishimdivin2019@gmail.com
369d29c1-0afc-46b2-8a64-e1523f370f69	2026-06-27 16:00:03.429269	\N	2026-06-27 16:00:03.429269	\N	POST	status=200, durationMs=28, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart/items	SUCCESS	2026-06-27 16:00:03.42927	ishimdivin2019@gmail.com
7173670d-9025-48e7-b5a0-5c4380372afb	2026-06-27 16:00:03.500557	\N	2026-06-27 16:00:03.500557	\N	GET	status=200, durationMs=0, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 16:00:03.493682	ishimdivin2019@gmail.com
33e09953-395c-42df-be6f-3ecf6b692915	2026-06-27 16:00:03.519903	\N	2026-06-27 16:00:03.519903	\N	GET	status=200, durationMs=0, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 16:00:03.509518	ishimdivin2019@gmail.com
34330ec5-2e8e-49ea-8a09-a3a11a476844	2026-06-27 16:00:08.244472	\N	2026-06-27 16:00:08.244472	\N	GET	status=200, durationMs=10, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 16:00:08.242507	ishimdivin2019@gmail.com
bff18e42-9abf-48b5-8fd2-4de03459f18b	2026-06-27 16:00:08.327303	\N	2026-06-27 16:00:08.327303	\N	GET	status=200, durationMs=25, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 16:00:08.323965	ishimdivin2019@gmail.com
9ed3c2b2-db52-4990-81e4-7cc232e7b184	2026-06-27 16:00:08.358367	\N	2026-06-27 16:00:08.358367	\N	GET	status=200, durationMs=9, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/live-chat/sessions/my	SUCCESS	2026-06-27 16:00:08.356458	ishimdivin2019@gmail.com
e687aa68-d5f8-4d7d-8c18-5083bc445026	2026-06-27 16:00:10.602236	\N	2026-06-27 16:00:10.602236	\N	GET	status=200, durationMs=2, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 16:00:10.602237	ishimdivin2019@gmail.com
af71cdfc-53e6-4f0e-a7c0-786e7d0fe054	2026-06-27 16:00:10.652093	\N	2026-06-27 16:00:10.652093	\N	GET	status=200, durationMs=13, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 16:00:10.652093	ishimdivin2019@gmail.com
87530067-471c-4704-8a73-e3b4b73caed4	2026-06-27 16:00:10.692681	\N	2026-06-27 16:00:10.692681	\N	GET	status=200, durationMs=14, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/live-chat/sessions/my	SUCCESS	2026-06-27 16:00:10.691198	ishimdivin2019@gmail.com
c8230378-b263-4da5-9e4e-ad7c58052c48	2026-06-27 16:00:34.762546	\N	2026-06-27 16:00:34.762546	\N	getPaymentStatus	\N	0:0:0:0:0:0:0:1	com.luztechnology.payment.controller.PaymentWebhookController	SUCCESS	2026-06-27 16:00:34.762546	ishimdivin2019@gmail.com
99d4833e-9524-438e-aaa2-091377671724	2026-06-27 16:00:34.762546	\N	2026-06-27 16:00:34.762546	\N	GET	status=200, durationMs=7316, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/payments/status/e65365da-cb99-44b3-82ca-276f63a28e8b	SUCCESS	2026-06-27 16:00:34.762546	ishimdivin2019@gmail.com
b8336969-7739-4a9a-8673-142bd71e2255	2026-06-27 16:00:34.799537	\N	2026-06-27 16:00:34.799537	\N	getPaymentStatus	\N	0:0:0:0:0:0:0:1	com.luztechnology.payment.controller.PaymentWebhookController	SUCCESS	2026-06-27 16:00:34.799538	ishimdivin2019@gmail.com
06071d4c-0a58-4e46-b775-dca3038b0de2	2026-06-27 16:00:34.811853	\N	2026-06-27 16:00:34.811853	\N	GET	status=200, durationMs=12, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/payments/status/e65365da-cb99-44b3-82ca-276f63a28e8b	SUCCESS	2026-06-27 16:00:34.811853	ishimdivin2019@gmail.com
e7c13840-3e6f-4bf9-abd7-92445d8399d5	2026-06-27 16:00:34.847523	\N	2026-06-27 16:00:34.847523	\N	GET	status=200, durationMs=13, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/receipts/orders/e65365da-cb99-44b3-82ca-276f63a28e8b	SUCCESS	2026-06-27 16:00:34.845325	ishimdivin2019@gmail.com
0720be09-22ec-4d5c-b874-41d4871a3ca6	2026-06-27 16:00:36.466017	\N	2026-06-27 16:00:36.466017	\N	GET	status=500, durationMs=13, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	FAILURE	2026-06-27 16:00:36.465011	ishimdivin2019@gmail.com
d2ac207a-a00b-4291-b00a-d73059c0ebd0	2026-06-27 16:00:40.645479	\N	2026-06-27 16:00:40.645479	\N	GET	status=200, durationMs=0, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 16:00:40.64548	ishimdivin2019@gmail.com
13ccde39-7312-410d-a9ff-a5d6f6eb5400	2026-06-27 16:00:40.67409	\N	2026-06-27 16:00:40.67409	\N	GET	status=200, durationMs=17, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 16:00:40.672081	ishimdivin2019@gmail.com
339b9721-144d-4dbc-beb7-7040c84029d9	2026-06-27 16:00:40.696792	\N	2026-06-27 16:00:40.696792	\N	GET	status=200, durationMs=10, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 16:00:40.696793	ishimdivin2019@gmail.com
ba6276c7-0ed6-4b86-9c30-e45bd3687b5f	2026-06-27 16:00:41.483621	\N	2026-06-27 16:00:41.483621	\N	GET	status=200, durationMs=6, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications	SUCCESS	2026-06-27 16:00:41.480979	ishimdivin2019@gmail.com
1a7198fa-2736-485d-afe1-08d164359815	2026-06-27 16:00:45.338559	\N	2026-06-27 16:00:45.338559	\N	GET	status=200, durationMs=18, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 16:00:45.338559	ishimdivin2019@gmail.com
6039d41a-4a7c-480f-b3f8-ef7be625826d	2026-06-27 16:00:45.395492	\N	2026-06-27 16:00:45.395492	\N	GET	status=200, durationMs=3, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/users/profile	SUCCESS	2026-06-27 16:00:45.394587	ishimdivin2019@gmail.com
866e3da8-d0af-4f21-ac2d-4688d3f736de	2026-06-27 15:59:59.220589	\N	2026-06-27 15:59:59.220589	\N	GET	status=200, durationMs=22, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 15:59:59.220589	ishimdivin2019@gmail.com
a98780b4-5285-4cd8-a1e6-0f6597505e87	2026-06-27 15:59:59.385976	\N	2026-06-27 15:59:59.385976	\N	GET	status=200, durationMs=21, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners	SUCCESS	2026-06-27 15:59:59.385977	ishimdivin2019@gmail.com
dbb3e80e-f006-47b5-8e1a-1cae34b52a76	2026-06-27 15:59:59.548263	\N	2026-06-27 15:59:59.548263	\N	GET	status=200, durationMs=27, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/live-chat/sessions/my	SUCCESS	2026-06-27 15:59:59.548264	ishimdivin2019@gmail.com
12c9145b-daf1-4960-aea9-9e894c96f338	2026-06-27 16:00:03.475507	\N	2026-06-27 16:00:03.475507	\N	GET	status=200, durationMs=25, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 16:00:03.475508	ishimdivin2019@gmail.com
c588ea8d-26da-411d-b5ee-972c60701488	2026-06-27 16:00:08.213697	\N	2026-06-27 16:00:08.213697	\N	GET	status=200, durationMs=12, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 16:00:08.209099	ishimdivin2019@gmail.com
c9bf9429-f370-42b3-b7a0-bd369ba2436f	2026-06-27 16:00:08.270914	\N	2026-06-27 16:00:08.270914	\N	GET	status=200, durationMs=3, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 16:00:08.263607	ishimdivin2019@gmail.com
a47f40fc-df9b-4541-bad4-c360acee4274	2026-06-27 16:00:10.583656	\N	2026-06-27 16:00:10.583656	\N	GET	status=200, durationMs=94, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 16:00:10.579764	ishimdivin2019@gmail.com
b50ae35f-8bd5-4645-8abb-aa70a95a70cb	2026-06-27 16:00:10.618472	\N	2026-06-27 16:00:10.618472	\N	GET	status=200, durationMs=0, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 16:00:10.618473	ishimdivin2019@gmail.com
093d6b82-e7a2-4df4-be60-91cb6e6cf0d3	2026-06-27 16:00:18.044602	\N	2026-06-27 16:00:18.044602	\N	POST	status=200, durationMs=149, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart/checkout	SUCCESS	2026-06-27 16:00:18.044602	ishimdivin2019@gmail.com
2662fff2-50f3-4889-8122-488358ad2fc0	2026-06-27 16:00:24.357479	\N	2026-06-27 16:00:24.357479	\N	initiatePayment	\N	0:0:0:0:0:0:0:1	com.luztechnology.payment.controller.PaymentWebhookController	SUCCESS	2026-06-27 16:00:24.352309	ishimdivin2019@gmail.com
47554d5a-13b7-445e-a5d4-e8e683e293a3	2026-06-27 16:00:24.378773	\N	2026-06-27 16:00:24.378773	\N	POST	status=200, durationMs=6290, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/payments/initiate/e65365da-cb99-44b3-82ca-276f63a28e8b	SUCCESS	2026-06-27 16:00:24.378773	ishimdivin2019@gmail.com
6418de93-58b8-4f34-827e-63cc52514ffe	2026-06-27 16:00:34.784705	\N	2026-06-27 16:00:34.784705	\N	getPaymentStatus	\N	0:0:0:0:0:0:0:1	com.luztechnology.payment.controller.PaymentWebhookController	SUCCESS	2026-06-27 16:00:34.784706	ishimdivin2019@gmail.com
cf3131bf-68b8-4fe7-a7a8-3c56ecc4b1ff	2026-06-27 16:00:34.790701	\N	2026-06-27 16:00:34.790701	\N	GET	status=200, durationMs=0, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/payments/status/e65365da-cb99-44b3-82ca-276f63a28e8b	SUCCESS	2026-06-27 16:00:34.784706	ishimdivin2019@gmail.com
7d7319a4-982c-4672-a238-b07cca5b2fac	2026-06-27 16:00:34.815221	\N	2026-06-27 16:00:34.815221	\N	GET	status=200, durationMs=31, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/receipts/orders/e65365da-cb99-44b3-82ca-276f63a28e8b	SUCCESS	2026-06-27 16:00:34.815222	ishimdivin2019@gmail.com
8f9a81e8-3854-4bad-97e6-4eefb1c00156	2026-06-27 16:00:34.865489	\N	2026-06-27 16:00:34.865489	\N	GET	status=200, durationMs=10, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/receipts/orders/e65365da-cb99-44b3-82ca-276f63a28e8b	SUCCESS	2026-06-27 16:00:34.86549	ishimdivin2019@gmail.com
721c432e-5c93-4a61-97f4-62f9e6015dda	2026-06-27 16:00:40.627059	\N	2026-06-27 16:00:40.627059	\N	GET	status=200, durationMs=7, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 16:00:40.62706	ishimdivin2019@gmail.com
2685b621-ec03-4d82-8fb7-bd6392c0e33f	2026-06-27 16:00:40.725841	\N	2026-06-27 16:00:40.725841	\N	GET	status=200, durationMs=3, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/live-chat/sessions/my	SUCCESS	2026-06-27 16:00:40.725841	ishimdivin2019@gmail.com
572041ff-8093-4412-8fcf-5bab7c901b77	2026-06-27 16:00:45.317592	\N	2026-06-27 16:00:45.317592	\N	GET	status=200, durationMs=10, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	SUCCESS	2026-06-27 16:00:45.317593	ishimdivin2019@gmail.com
a24d5214-6337-474c-8613-facffd03cdb7	2026-06-27 16:00:45.357461	\N	2026-06-27 16:00:45.357461	\N	GET	status=200, durationMs=4, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 16:00:45.357462	ishimdivin2019@gmail.com
e41dcf86-e8c7-402c-bc67-ff06ea6e3fcb	2026-06-27 16:00:58.72737	\N	2026-06-27 16:00:58.72737	\N	logoutUser	\N	0:0:0:0:0:0:0:1	com.luztechnology.auth.controller.AuthController	SUCCESS	2026-06-27 16:00:58.724875	ishimdivin2019@gmail.com
d5d23a9b-2d89-4ab4-9c4b-5573304cdd70	2026-06-27 16:00:58.729041	\N	2026-06-27 16:00:58.729041	\N	POST	status=200, durationMs=20, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/auth/logout	SUCCESS	2026-06-27 16:00:58.729042	ishimdivin2019@gmail.com
20d706b0-aa93-4d0d-9857-aced8c034062	2026-06-27 16:00:58.780425	\N	2026-06-27 16:00:58.780425	\N	GET	status=200, durationMs=10, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/featured	SUCCESS	2026-06-27 16:00:58.779458	anonymousUser
59a442d3-b728-4d14-93a5-dd2a3853c179	2026-06-27 16:01:26.21498	\N	2026-06-27 16:01:26.21498	\N	authenticateUser	\N	0:0:0:0:0:0:0:1	com.luztechnology.auth.controller.AuthController	SUCCESS	2026-06-27 16:01:26.211752	SYSTEM
82580c70-ff42-4c09-bb70-9099f095fe67	2026-06-27 16:01:26.234396	\N	2026-06-27 16:01:26.234396	\N	POST	status=200, durationMs=7344, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/auth/login	SUCCESS	2026-06-27 16:01:26.234397	ANONYMOUS
3bdd3bf1-83a9-4170-a1dd-ed89b247d8c8	2026-06-27 16:01:39.226981	\N	2026-06-27 16:01:39.226981	\N	GET	status=500, durationMs=19, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	FAILURE	2026-06-27 16:01:39.226982	ishimwedivin2@gmail.com
d28277c9-794a-4ad3-b528-0ddbd311d8d9	2026-06-27 16:01:39.685566	\N	2026-06-27 16:01:39.685566	\N	GET	status=200, durationMs=152, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-06-27 16:01:39.676111	ishimwedivin2@gmail.com
ae1ad2bc-a69f-4361-836a-677bbf886a7b	2026-06-27 16:01:39.768303	\N	2026-06-27 16:01:39.768303	\N	GET	status=500, durationMs=13, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/live-chat/sessions/my	FAILURE	2026-06-27 16:01:39.7673	ishimwedivin2@gmail.com
84cf246b-5305-4d2d-bdeb-1d4cc6b9d165	2026-06-27 16:00:45.40729	\N	2026-06-27 16:00:45.40729	\N	getOrdersByCustomer	\N	0:0:0:0:0:0:0:1	com.luztechnology.order.controller.OrderController	SUCCESS	2026-06-27 16:00:45.40729	ishimdivin2019@gmail.com
27b3748b-322c-40f1-a284-0c62a3624d7f	2026-06-27 16:00:45.42053	\N	2026-06-27 16:00:45.42053	\N	GET	status=200, durationMs=29, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/orders/customer/c6089d46-ffe0-4cde-9ec0-a6f497c484b7	SUCCESS	2026-06-27 16:00:45.42053	ishimdivin2019@gmail.com
fae4c833-3c82-44bc-be2d-58b27c95a070	2026-06-27 16:00:45.454803	\N	2026-06-27 16:00:45.454803	\N	GET	status=200, durationMs=8, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/live-chat/sessions/my	SUCCESS	2026-06-27 16:00:45.454804	ishimdivin2019@gmail.com
78a9912d-882f-4691-8c79-4fbb94a90b82	2026-06-27 16:00:58.759808	\N	2026-06-27 16:00:58.759808	\N	GET	status=200, durationMs=14, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 16:00:58.759808	anonymousUser
d1528578-fcb5-43f1-87c4-e1f3467de3f6	2026-06-27 16:00:58.796611	\N	2026-06-27 16:00:58.796611	\N	GET	status=200, durationMs=20, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-06-27 16:00:58.796612	anonymousUser
65460cf7-6710-45ac-b2f1-40bfc34aae44	2026-06-27 16:01:39.154862	\N	2026-06-27 16:01:39.154862	\N	verifyMfa	\N	0:0:0:0:0:0:0:1	com.luztechnology.auth.controller.AuthController	SUCCESS	2026-06-27 16:01:39.154862	SYSTEM
782174d1-34a5-4dbb-be31-83f9ef1e5f8c	2026-06-27 16:01:39.173527	\N	2026-06-27 16:01:39.173527	\N	POST	status=200, durationMs=238, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/auth/mfa/verify	SUCCESS	2026-06-27 16:01:39.171521	anonymousUser
f90a7262-a57e-4464-a448-fa3d9daec48c	2026-06-27 16:01:39.311526	\N	2026-06-27 16:01:39.311526	\N	GET	status=200, durationMs=1, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 16:01:39.304508	ishimwedivin2@gmail.com
dc87f77d-7469-49e8-8d9e-31cbe2d8aaeb	2026-06-27 16:01:39.353961	\N	2026-06-27 16:01:39.353961	\N	GET	status=200, durationMs=16, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-06-27 16:01:39.353961	ishimwedivin2@gmail.com
972a09e1-f5e0-43dd-bbdc-7d9db635d8a8	2026-06-27 16:01:39.576739	\N	2026-06-27 16:01:39.576739	\N	GET	status=200, durationMs=69, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners	SUCCESS	2026-06-27 16:01:39.57674	ishimwedivin2@gmail.com
c1ffeb0f-7e55-422e-87f7-c8e9e8574070	2026-06-27 16:01:45.854914	\N	2026-06-27 16:01:45.854914	\N	GET	status=500, durationMs=10, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	FAILURE	2026-06-27 16:01:45.853906	ishimwedivin2@gmail.com
6a291b3d-5d2b-419a-bc7f-2008807795e8	2026-06-27 16:01:45.920705	\N	2026-06-27 16:01:45.920705	\N	GET	status=200, durationMs=2, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-06-27 16:01:45.919699	ishimwedivin2@gmail.com
7b76dc34-31c5-46f4-9c99-024b17a5686c	2026-06-27 16:01:46.001422	\N	2026-06-27 16:01:46.001422	\N	GET	status=200, durationMs=23, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-06-27 16:01:46.000782	ishimwedivin2@gmail.com
5f150f81-399b-498c-87c6-29582389dd31	2026-06-27 16:01:46.053888	\N	2026-06-27 16:01:46.053888	\N	getAllOrders	\N	0:0:0:0:0:0:0:1	com.luztechnology.order.controller.OrderController	SUCCESS	2026-06-27 16:01:46.053889	ishimwedivin2@gmail.com
cd975645-d540-453c-84cf-cb71b5e56844	2026-06-27 16:01:46.104576	\N	2026-06-27 16:01:46.104576	\N	GET	status=200, durationMs=68, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/orders	SUCCESS	2026-06-27 16:01:46.104577	ishimwedivin2@gmail.com
9e60e7f3-653e-407f-b625-b3f506a6cb9a	2026-06-27 16:00:58.788276	\N	2026-06-27 16:00:58.788276	\N	GET	status=200, durationMs=8, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/banners	SUCCESS	2026-06-27 16:00:58.784452	anonymousUser
43bb85cf-4b01-4689-b6b4-ed62a15f93a5	2026-06-27 16:01:39.274962	\N	2026-06-27 16:01:39.274962	\N	GET	status=200, durationMs=14, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 16:01:39.274963	ishimwedivin2@gmail.com
8fd03ccd-5a6b-4caa-a321-167153cd4171	2026-06-27 16:01:39.419722	\N	2026-06-27 16:01:39.419722	\N	GET	status=200, durationMs=32, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-06-27 16:01:39.419723	ishimwedivin2@gmail.com
a80fd4b9-74fe-462d-8d8a-44bddbf8a3b2	2026-06-27 16:01:39.576119	\N	2026-06-27 16:01:39.576119	\N	GET	status=200, durationMs=35, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/featured	SUCCESS	2026-06-27 16:01:39.573877	ishimwedivin2@gmail.com
2c0ae163-56a8-42c7-ab56-420319beb8b2	2026-06-27 16:01:45.895443	\N	2026-06-27 16:01:45.895443	\N	GET	status=200, durationMs=0, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-06-27 16:01:45.895443	ishimwedivin2@gmail.com
c9f59b61-43d2-4736-904e-524eeef7d96c	2026-06-27 16:01:46.000781	\N	2026-06-27 16:01:46.000781	\N	GET	status=200, durationMs=17, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/movements	SUCCESS	2026-06-27 16:01:45.99637	ishimwedivin2@gmail.com
519eed86-c5de-4f03-acd8-f87e063be5e4	2026-06-27 16:01:45.881688	\N	2026-06-27 16:01:45.881688	\N	GET	status=200, durationMs=22, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-06-27 16:01:45.881689	ishimwedivin2@gmail.com
bc6c81f1-8369-4f4e-bf8c-bdc5951cf409	2026-06-27 16:01:45.981404	\N	2026-06-27 16:01:45.981404	\N	GET	status=200, durationMs=5, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-06-27 16:01:45.979397	ishimwedivin2@gmail.com
cef4200a-caa5-4308-a3b8-60ed98d75480	2026-06-27 16:01:46.06675	\N	2026-06-27 16:01:46.06675	\N	GET	status=200, durationMs=32, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/tickets	SUCCESS	2026-06-27 16:01:46.065743	ishimwedivin2@gmail.com
048f73b8-208d-42a2-83b3-94d7933c36fc	2026-06-27 16:01:46.067256	\N	2026-06-27 16:01:46.067256	\N	GET	status=200, durationMs=29, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/returns	SUCCESS	2026-06-27 16:01:46.065743	ishimwedivin2@gmail.com
ff962c90-162a-4733-980d-0852057ed453	2026-06-27 16:02:46.156233	\N	2026-06-27 16:02:46.156233	\N	GET	status=200, durationMs=66, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-06-27 16:02:46.153233	ishimwedivin2@gmail.com
35be12f4-7fd0-48b4-bc38-5568c9378d3a	2026-06-27 16:03:05.432129	\N	2026-06-27 16:03:05.432129	\N	getAllOrders	\N	0:0:0:0:0:0:0:1	com.luztechnology.order.controller.OrderController	SUCCESS	2026-06-27 16:03:05.43213	ishimwedivin2@gmail.com
a3ef766a-27dc-44ce-b195-8e3808633f98	2026-06-27 16:03:05.483989	\N	2026-06-27 16:03:05.483989	\N	GET	status=200, durationMs=79, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/orders	SUCCESS	2026-06-27 16:03:05.483989	ishimwedivin2@gmail.com
8e67ce8d-b508-4231-8809-7e1e96a57e0d	2026-06-27 16:03:06.879234	\N	2026-06-27 16:03:06.879234	\N	getAllOrders	\N	0:0:0:0:0:0:0:1	com.luztechnology.order.controller.OrderController	SUCCESS	2026-06-27 16:03:06.873231	ishimwedivin2@gmail.com
f48beff6-d531-4a5f-879f-d8327ffb06af	2026-06-27 16:03:06.895547	\N	2026-06-27 16:03:06.895547	\N	getAllOrders	\N	0:0:0:0:0:0:0:1	com.luztechnology.order.controller.OrderController	SUCCESS	2026-06-27 16:03:06.893227	ishimwedivin2@gmail.com
31e45772-dab7-418e-8675-185ea6267412	2026-06-27 16:03:06.919237	\N	2026-06-27 16:03:06.919237	\N	GET	status=200, durationMs=51, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/orders	SUCCESS	2026-06-27 16:03:06.919238	ishimwedivin2@gmail.com
9118a6fe-3c9c-4d76-8884-2a6d898ece50	2026-06-27 16:03:06.934393	\N	2026-06-27 16:03:06.934393	\N	GET	status=200, durationMs=69, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/orders	SUCCESS	2026-06-27 16:03:06.934394	ishimwedivin2@gmail.com
fe25a48a-96ce-4620-b0fa-9b698cea04b2	2026-06-27 16:03:12.282091	\N	2026-06-27 16:03:12.282091	\N	GET	status=400, durationMs=275, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/fulfillment/orders/e65365da-cb99-44b3-82ca-276f63a28e8b	FAILURE	2026-06-27 16:03:12.282091	ishimwedivin2@gmail.com
61908291-ee51-43b5-a666-2c454111550a	2026-06-27 16:03:15.277803	\N	2026-06-27 16:03:15.277803	\N	POST	status=200, durationMs=940, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/fulfillment/orders/e65365da-cb99-44b3-82ca-276f63a28e8b/pick	SUCCESS	2026-06-27 16:03:15.277804	ishimwedivin2@gmail.com
681c2693-c35b-4280-a594-5c1726bc5f3f	2026-06-27 16:03:15.358936	\N	2026-06-27 16:03:15.358936	\N	GET	status=200, durationMs=35, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/fulfillment/orders/e65365da-cb99-44b3-82ca-276f63a28e8b	SUCCESS	2026-06-27 16:03:15.358937	ishimwedivin2@gmail.com
165de916-853c-4d9b-96a0-722c86ea17ab	2026-06-27 16:03:18.019513	\N	2026-06-27 16:03:18.019513	\N	POST	status=200, durationMs=32, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/fulfillment/orders/e65365da-cb99-44b3-82ca-276f63a28e8b/pack	SUCCESS	2026-06-27 16:03:18.019513	ishimwedivin2@gmail.com
f222feac-bb20-4239-8133-51059905e777	2026-06-27 16:03:18.069226	\N	2026-06-27 16:03:18.069226	\N	GET	status=200, durationMs=3, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/fulfillment/orders/e65365da-cb99-44b3-82ca-276f63a28e8b	SUCCESS	2026-06-27 16:03:18.061586	ishimwedivin2@gmail.com
4fcc1122-48c9-4460-b141-fc1401d8364e	2026-06-27 16:03:37.248935	\N	2026-06-27 16:03:37.248935	\N	POST	status=200, durationMs=330, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/fulfillment/orders/e65365da-cb99-44b3-82ca-276f63a28e8b/dispatch	SUCCESS	2026-06-27 16:03:37.248936	ishimwedivin2@gmail.com
88ba3070-4eb9-4b7e-b22e-e14851171af1	2026-06-27 16:03:37.302171	\N	2026-06-27 16:03:37.302171	\N	GET	status=200, durationMs=34, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/fulfillment/orders/e65365da-cb99-44b3-82ca-276f63a28e8b	SUCCESS	2026-06-27 16:03:37.302172	ishimwedivin2@gmail.com
b7311de1-c027-435c-b7a4-b332f542b538	2026-06-27 16:03:47.115126	\N	2026-06-27 16:03:47.115126	\N	GET	status=200, durationMs=118, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/shipments	SUCCESS	2026-06-27 16:03:47.115126	ishimwedivin2@gmail.com
4110e64d-08b7-4ad3-9806-7012e9271622	2026-06-27 16:04:04.375266	\N	2026-06-27 16:04:04.375266	\N	PATCH	status=200, durationMs=85, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/shipments/fa78d477-7c4a-4947-ace6-3b6174446443/status	SUCCESS	2026-06-27 16:04:04.375266	ishimwedivin2@gmail.com
3b076a4e-775e-4b1c-9693-71bb2c49bd55	2026-06-27 16:04:04.791175	\N	2026-06-27 16:04:04.791175	\N	GET	status=200, durationMs=20, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/shipments	SUCCESS	2026-06-27 16:04:04.791176	ishimwedivin2@gmail.com
ac293b8c-44a6-4b20-8966-7f878bcb07e7	2026-06-27 16:04:10.026736	\N	2026-06-27 16:04:10.026736	\N	GET	status=200, durationMs=42, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/shipments/track/TRK-1782569017113-40A21EB7	SUCCESS	2026-06-27 16:04:10.026737	ishimwedivin2@gmail.com
7a960917-4057-4e60-b0be-3764b5800286	2026-06-27 16:04:22.99989	\N	2026-06-27 16:04:22.99989	\N	GET	status=200, durationMs=75, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/admin/configurations	SUCCESS	2026-06-27 16:04:22.999891	ishimwedivin2@gmail.com
94eaee93-d045-442f-877c-e9425c46071e	2026-06-27 16:04:23.00736	\N	2026-06-27 16:04:23.00736	\N	getBackups	\N	0:0:0:0:0:0:0:1	com.luztechnology.admin.controller.AdminController	SUCCESS	2026-06-27 16:04:23.003941	ishimwedivin2@gmail.com
f508968a-5838-479b-ab59-cfe0807918a4	2026-06-27 16:04:23.012604	\N	2026-06-27 16:04:23.012604	\N	GET	status=200, durationMs=76, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/admin/backups	SUCCESS	2026-06-27 16:04:23.008946	ishimwedivin2@gmail.com
\.


--
-- Data for Name: banners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.banners (id, created_at, created_by, updated_at, updated_by, active, button_text, display_order, image_url, link_url, product_id, subtitle, tag_label, title) FROM stdin;
8cc6aa5e-bb12-44fd-906b-235633b3b471	2026-06-27 15:48:29.074508	\N	2026-06-27 15:48:29.074508	\N	t	Shop Now	1	/uploads/banners/fd15581e-ca95-4ce1-91e8-96d48938c15e.jfif	\N	\N	High-performance enterprise networking with advanced security, VPN, and cloud connectivity. Ideal for small and medium-sized businesses.	\N	Cisco ISR 1100 Series Router
dcf25965-3602-4267-8543-fafae6ae4593	2026-06-27 15:49:49.057224	\N	2026-06-27 15:49:49.057224	\N	t	Shop Now	1	/uploads/banners/b9ff8f3b-e532-41b4-b132-2160f891a83a.jfif	\N	\N	Deliver high-speed Layer 2 and Layer 3 switching with enterprise-grade security, scalability, and intelligent network management.	\N	Cisco Catalyst 9300 Multilayer Switch
\.


--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_items (id, created_at, created_by, updated_at, updated_by, quantity, cart_id, product_id) FROM stdin;
\.


--
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carts (id, created_at, created_by, updated_at, updated_by, user_id) FROM stdin;
148ef61d-7de1-487d-a1ed-b1a00c2f7ba3	2026-06-27 15:54:09.780504	\N	2026-06-27 15:54:09.780504	\N	c6089d46-ffe0-4cde-9ec0-a6f497c484b7
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, created_at, created_by, updated_at, updated_by, description, name, parent_id) FROM stdin;
509f1eb7-eaa8-486b-835f-5fdea7b5a896	2026-06-27 15:39:38.595835	\N	2026-06-27 15:39:38.595835	\N	Routers, switches, access points and network equipment	Networking	\N
4857e1f6-6d5f-4f16-b9fc-808b90446bb8	2026-06-27 15:39:38.608338	\N	2026-06-27 15:39:38.608338	\N	Notebooks and portable computers	Laptops	\N
098d7770-4210-4668-bfa0-697171a955e1	2026-06-27 15:39:38.626935	\N	2026-06-27 15:39:38.626935	\N	Desktop computers and all-in-one systems	Desktops & PCs	\N
30788f81-4e34-4ef5-9db4-4ffe6cb984e7	2026-06-27 15:39:38.635273	\N	2026-06-27 15:39:38.635273	\N	Computer monitors and display screens	Monitors	\N
6b2b1310-e443-4277-988d-ce781b980f30	2026-06-27 15:39:38.647665	\N	2026-06-27 15:39:38.647665	\N	Printers, scanners and multifunction devices	Printers & Scanners	\N
e89c254d-e9bd-41b7-ab5d-9d6aeb5f1ead	2026-06-27 15:39:38.66451	\N	2026-06-27 15:39:38.66451	\N	Hard drives, SSDs and external storage	Storage	\N
5f1fde08-0c58-415a-93f7-a87c9e170b46	2026-06-27 15:39:38.678312	\N	2026-06-27 15:39:38.678312	\N	CPUs, RAM, GPUs and PC components	Components	\N
3a6a3855-5ea8-487b-8720-4a5110713d26	2026-06-27 15:39:38.684282	\N	2026-06-27 15:39:38.684282	\N	Keyboards, mice, headsets and peripherals	Accessories	\N
1c9a7a28-9b0b-4077-8312-684891ef6d05	2026-06-27 15:39:38.709284	\N	2026-06-27 15:39:38.709284	\N	Server hardware and rack equipment	Servers	\N
5b3c9ac6-efa7-444f-b817-36d9a2529310	2026-06-27 15:39:38.727269	\N	2026-06-27 15:39:38.727269	\N	Smart devices, cameras and IoT equipment	Smart Home & IoT	\N
994b55be-c62e-4105-8ddb-8edeea93d199	2026-06-27 15:41:40.753525	\N	2026-06-27 15:41:40.756418	\N		Router	\N
dd4cbc45-4a48-4ca3-9c0f-be19d878fec8	2026-06-27 15:46:01.548334	\N	2026-06-27 15:46:01.564436	\N		Switch	\N
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_messages (id, created_at, created_by, updated_at, updated_by, message, sender_id, session_id) FROM stdin;
\.


--
-- Data for Name: chat_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_sessions (id, created_at, created_by, updated_at, updated_by, status, subject, agent_id, customer_id) FROM stdin;
\.


--
-- Data for Name: communication_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_logs (id, created_at, created_by, updated_at, updated_by, channel, notes, outcome, reference_id, reference_type, subject, customer_id, handled_by_id) FROM stdin;
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coupons (id, created_at, created_by, updated_at, updated_by, active, amount, code, current_usage, expiry_date, minimum_order_amount, type, usage_limit) FROM stdin;
\.


--
-- Data for Name: customer_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_metrics (id, created_at, created_by, updated_at, updated_by, average_order_value, engagement_score, return_rate_percentage, customer_id) FROM stdin;
\.


--
-- Data for Name: customer_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_profiles (id, created_at, created_by, updated_at, updated_by, last_purchase_date, total_purchases, total_spent, customer_id, segment_id) FROM stdin;
197af6db-d738-4077-8eec-b9533554ae55	2026-06-27 16:00:34.710885	\N	2026-06-27 16:00:34.710885	\N	2026-06-27	1	63720000.00	c6089d46-ffe0-4cde-9ec0-a6f497c484b7	1deebab2-0d72-4987-8c68-6e27acae8c60
\.


--
-- Data for Name: customer_segments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_segments (id, created_at, created_by, updated_at, updated_by, description, name) FROM stdin;
1deebab2-0d72-4987-8c68-6e27acae8c60	2026-06-27 16:00:34.702049	\N	2026-06-27 16:00:34.702049	\N	High spending customers	VIP
\.


--
-- Data for Name: discounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discounts (id, created_at, created_by, updated_at, updated_by, active, description, discount_percentage, end_date, name, start_date) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, created_at, created_by, updated_at, updated_by, amount, category, description, expense_date, status) FROM stdin;
\.


--
-- Data for Name: faq_articles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.faq_articles (id, created_at, created_by, updated_at, updated_by, answer, category, published, question) FROM stdin;
\.


--
-- Data for Name: feedbacks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedbacks (id, created_at, created_by, updated_at, updated_by, category, comments, rating, reference_id, customer_id) FROM stdin;
\.


--
-- Data for Name: financial_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_reports (id, created_at, created_by, updated_at, updated_by, generated_date, net_profit, report_period, total_expenses, total_revenue) FROM stdin;
\.


--
-- Data for Name: fulfillment_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fulfillment_orders (id, created_at, created_by, updated_at, updated_by, completed_at, dispatched_at, packed_at, picked_at, status, order_id, shipment_id) FROM stdin;
40ecb4eb-4c92-4fa5-a56a-b533ad1e4d71	2026-06-27 16:03:15.013692	\N	2026-06-27 16:03:37.248935	\N	\N	2026-06-27 16:03:37.231351	2026-06-27 16:03:18.005625	2026-06-27 16:03:14.405426	DISPATCHED	e65365da-cb99-44b3-82ca-276f63a28e8b	fa78d477-7c4a-4947-ace6-3b6174446443
\.


--
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_items (id, created_at, created_by, updated_at, updated_by, location, low_stock_threshold, product_name, quantity, sku) FROM stdin;
b9592921-4e43-45a8-9495-181c73e9865c	2026-06-27 15:43:03.322941	\N	2026-06-27 15:43:03.322941	\N	Main Warehouse	5	Router	0	LUZ-ROUTER
6686ba3a-c775-4965-b407-520a0dba8b00	2026-06-27 15:46:14.220802	\N	2026-06-27 16:00:18.004691	\N	Main Warehouse	5	Multi Layer Switch	97	LUZ-SWITCH
\.


--
-- Data for Name: kpi_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kpi_records (id, created_at, created_by, updated_at, updated_by, description, metric_name, metric_value, record_date) FROM stdin;
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_attempts (id, created_at, created_by, updated_at, updated_by, email, failure_reason, ip_address, success) FROM stdin;
3b9897dc-6c4a-4fb8-8bfa-51b1545b16db	2026-06-27 15:53:45.625106	\N	2026-06-27 15:53:45.625106	\N	ishimdivin2019@gmail.com	\N	UNKNOWN	t
11d8a3dc-9b67-4886-ae09-51c9675d6cab	2026-06-27 15:56:39.026435	\N	2026-06-27 15:56:39.026435	\N	ishimwedivin2@gmail.com	\N	UNKNOWN	t
8ea39aa1-0b51-43db-8812-ddcd55b756f7	2026-06-27 15:59:15.557855	\N	2026-06-27 15:59:15.557855	\N	ishimdivin2019@gmail.com	\N	UNKNOWN	t
e2d596f9-5edb-4d04-8b0d-13e954c14322	2026-06-27 16:01:19.301335	\N	2026-06-27 16:01:19.301335	\N	ishimwedivin2@gmail.com	\N	UNKNOWN	t
\.


--
-- Data for Name: mfa_otps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mfa_otps (id, created_at, created_by, updated_at, updated_by, code_hash, expiry_date, mfa_token, used, user_id) FROM stdin;
5dfe0a2c-1ca5-4afc-a54a-721e22e15d80	2026-06-27 15:53:53.56904	\N	2026-06-27 15:54:09.574351	\N	$2a$10$ePlWc/f/DtxAbeOC..YHS.4b.C4cBj/um2CJh4GvjDtAaEYvf3fq6	2026-06-27 16:03:45.808192+02	6dbaddae-8ae0-4b54-87ee-00a5427915e4	t	c6089d46-ffe0-4cde-9ec0-a6f497c484b7
d3f78b21-2e37-495e-8a17-c14fa947e627	2026-06-27 15:56:46.932086	\N	2026-06-27 15:57:34.029346	\N	$2a$10$uU49QEPvTl/8OkNAI7HdkOJ4Octs9JWaYcCW.X15pXp2hLadyka9G	2026-06-27 16:06:39.246685+02	178d2bf3-7d3e-4843-9b5c-2b6a7e26ec58	t	6191f168-e9fd-453f-9d66-5de018153114
c0c0c7b9-5ffc-4fc0-898c-a18c031f4142	2026-06-27 15:59:22.204912	\N	2026-06-27 15:59:58.917561	\N	$2a$10$5kZqAzMmfaEueR0SlbN6l.oiEQpgKRAqtWpLyKc078s8VAZTephtO	2026-06-27 16:09:15.674313+02	1706ae18-0451-453b-ae0a-69b0c730596c	t	c6089d46-ffe0-4cde-9ec0-a6f497c484b7
e962747e-d064-4117-a593-6bbfe9bea7d5	2026-06-27 16:01:26.199849	\N	2026-06-27 16:01:39.087023	\N	$2a$10$5QBhQhrgjHJXdRlPuP9wqesxkAZCNxHAB5EpSWcm83NpfPm.c1BOy	2026-06-27 16:11:19.482329+02	0cd129ac-c24b-4c8e-9b4b-dbc470a4d0cd	t	6191f168-e9fd-453f-9d66-5de018153114
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, created_at, created_by, updated_at, updated_by, message, read, related_id, title, type, user_id) FROM stdin;
b28ce125-e44f-4609-8bb5-025e7abfe644	2026-06-27 16:00:24.292446	\N	2026-06-27 16:00:24.292446	\N	Your order #e65365da is now PROCESSING	f	e65365da-cb99-44b3-82ca-276f63a28e8b	Order Update	ORDER	c6089d46-ffe0-4cde-9ec0-a6f497c484b7
dcee4706-5663-425a-9557-73edaf3cfbeb	2026-06-27 16:00:34.693564	\N	2026-06-27 16:00:34.693564	\N	Your order #e65365da is now PAID	f	e65365da-cb99-44b3-82ca-276f63a28e8b	Order Update	ORDER	c6089d46-ffe0-4cde-9ec0-a6f497c484b7
e7a6863b-92e8-4d69-be26-c1fb49a4a388	2026-06-27 16:03:14.505067	\N	2026-06-27 16:03:14.505067	\N	Your order #e65365da is now PROCESSING	f	e65365da-cb99-44b3-82ca-276f63a28e8b	Order Update	ORDER	c6089d46-ffe0-4cde-9ec0-a6f497c484b7
7d2ca2ed-379b-4bc0-8928-9ec18de4cd0a	2026-06-27 16:03:37.248935	\N	2026-06-27 16:03:37.248935	\N	Your order #e65365da is now SHIPPED	f	e65365da-cb99-44b3-82ca-276f63a28e8b	Order Update	ORDER	c6089d46-ffe0-4cde-9ec0-a6f497c484b7
8dc6fa2e-c377-4f91-a282-69f1539dbcbf	2026-06-27 16:04:04.35853	\N	2026-06-27 16:04:04.35853	\N	Your order #e65365da is now DELIVERED	f	e65365da-cb99-44b3-82ca-276f63a28e8b	Order Update	ORDER	c6089d46-ffe0-4cde-9ec0-a6f497c484b7
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, created_at, created_by, updated_at, updated_by, quantity, sub_total, unit_price, order_id, product_id) FROM stdin;
e9a95250-8c63-468c-90a8-a9c2335bd0a3	2026-06-27 16:00:17.996734	\N	2026-06-27 16:00:17.996734	\N	3	54000000.00	18000000.00	e65365da-cb99-44b3-82ca-276f63a28e8b	3fe56847-f3e1-41f5-904d-374508a6e6c1
\.


--
-- Data for Name: order_tracking_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_tracking_events (id, created_at, created_by, updated_at, updated_by, note, status, order_id) FROM stdin;
e04b3861-e97a-4319-a06f-30a0ca2dac0f	2026-06-27 16:00:17.996734	\N	2026-06-27 16:00:17.996734	\N	Order received and awaiting payment	PENDING	e65365da-cb99-44b3-82ca-276f63a28e8b
a2a9ae30-3f1d-4103-94b4-57b0865e1f34	2026-06-27 16:00:24.292446	\N	2026-06-27 16:00:24.292446	\N	Order is being prepared	PROCESSING	e65365da-cb99-44b3-82ca-276f63a28e8b
cc8364d2-d9a8-455d-9d13-0d22696605be	2026-06-27 16:00:34.680309	\N	2026-06-27 16:00:34.680309	\N	Payment confirmed	PAID	e65365da-cb99-44b3-82ca-276f63a28e8b
d4939d9a-d408-4997-8bff-ef0f75c8d3f8	2026-06-27 16:03:14.496713	\N	2026-06-27 16:03:14.496713	\N	Order is being prepared	PROCESSING	e65365da-cb99-44b3-82ca-276f63a28e8b
070b55e4-99f9-4b5a-97f3-8090f568011d	2026-06-27 16:03:37.240236	\N	2026-06-27 16:03:37.240236	\N	Order has shipped	SHIPPED	e65365da-cb99-44b3-82ca-276f63a28e8b
4a92a7a6-cbf2-48ad-a99c-9de221f34a02	2026-06-27 16:04:04.35853	\N	2026-06-27 16:04:04.35853	\N	Order delivered	DELIVERED	e65365da-cb99-44b3-82ca-276f63a28e8b
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, created_at, created_by, updated_at, updated_by, billing_address, coupon_code, discount_amount, order_channel, order_number, payment_method, payment_reference, shipping_address, status, sub_total_amount, tax_amount, tax_rate, total_amount, cashier_id, customer_id) FROM stdin;
e65365da-cb99-44b3-82ca-276f63a28e8b	2026-06-27 16:00:17.974325	\N	2026-06-27 16:04:04.35853	\N	Kigali, Rwanda	\N	0.00	ONLINE	LUZ-1782568817915	MTN_MOMO	9612d489-7977-47ef-8bde-18286e882323	Kigali, Rwanda	DELIVERED	54000000.00	9720000.00	0.18	63720000.00	\N	c6089d46-ffe0-4cde-9ec0-a6f497c484b7
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (id, created_at, created_by, updated_at, updated_by, expiry_date, token, used, user_id) FROM stdin;
\.


--
-- Data for Name: payment_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_transactions (id, created_at, created_by, updated_at, updated_by, amount, payment_reference, provider, reconciled_at, reconciliation_notes, reconciliation_status, status, transaction_type, order_id) FROM stdin;
3a03a6c8-e586-4ec7-8db0-ac8faf1453e9	2026-06-27 16:00:24.3136	\N	2026-06-27 16:00:34.740323	\N	63720000.00	9612d489-7977-47ef-8bde-18286e882323	MTN_MOMO	\N	\N	PENDING	PAID	PAYMENT	e65365da-cb99-44b3-82ca-276f63a28e8b
\.


--
-- Data for Name: procurement_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.procurement_orders (id, created_at, created_by, updated_at, updated_by, expected_delivery_date, quantity_ordered, quantity_received, status, total_cost, inventory_item_id, supplier_id) FROM stdin;
3ca9b26f-7f7b-4041-817c-d665d88881ed	2026-06-27 15:53:02.559153	\N	2026-06-27 15:58:31.415696	\N	2026-06-27	100	100	RECEIVED	18000000.00	6686ba3a-c775-4965-b407-520a0dba8b00	79a6d494-abc7-4795-bdfa-f7e18bb2dad8
\.


--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_images (id, created_at, created_by, updated_at, updated_by, alt_text, is_primary, url, product_id) FROM stdin;
a90d2eac-f3cc-4c9b-bce2-9a0ff93cd499	2026-06-27 15:43:03.306534	\N	2026-06-27 15:43:03.306534	\N		t	/uploads/products/7f44ef1b-7dde-4b60-9252-7e2887fafdbd.jfif	7628a03d-a6b5-4ff3-b7ce-995ca5b40d13
2ddcda48-15c8-4916-ba74-754bbbfd2963	2026-06-27 15:46:14.203209	\N	2026-06-27 15:46:14.203209	\N		t	/uploads/products/e787de92-b835-4a0c-982f-3ed757b9e4b3.jfif	3fe56847-f3e1-41f5-904d-374508a6e6c1
\.


--
-- Data for Name: product_reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_reviews (id, created_at, created_by, updated_at, updated_by, comment, rating, verified_purchase, product_id, user_id) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, created_at, created_by, updated_at, updated_by, average_rating, description, featured, name, price, sku, status, category_id, discount_id, inventory_item_id) FROM stdin;
7628a03d-a6b5-4ff3-b7ce-995ca5b40d13	2026-06-27 15:43:03.270713	\N	2026-06-27 15:43:03.484316	\N	0.00	A router is a networking device that connects multiple networks—such as your home network and the internet—and directs digital data traffic between them	f	Router	8000000.00	LUZ-ROUTER	ACTIVE	994b55be-c62e-4105-8ddb-8edeea93d199	\N	b9592921-4e43-45a8-9495-181c73e9865c
3fe56847-f3e1-41f5-904d-374508a6e6c1	2026-06-27 15:46:14.193088	\N	2026-06-27 15:46:14.253416	\N	0.00	A multilayer switch (MLS) is an advanced networking device that combines the functions of a traditional Layer 2 switch with those of a Layer 3 router	f	Multi Layer Switch	18000000.00	LUZ-SWITCH	ACTIVE	dd4cbc45-4a48-4ca3-9c0f-be19d878fec8	\N	6686ba3a-c775-4965-b407-520a0dba8b00
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, created_at, created_by, updated_at, updated_by, expiry_date, revoked, token, user_id) FROM stdin;
3bccfc49-3d4c-4de4-a323-b4d9e1bbb0a8	2026-06-27 16:01:39.137866	\N	2026-06-27 16:01:39.137866	\N	2026-07-27 16:01:39.123224+02	f	1f5ff45c-5349-4875-af6e-5eeb01d93558	6191f168-e9fd-453f-9d66-5de018153114
\.


--
-- Data for Name: return_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.return_requests (id, created_at, created_by, updated_at, updated_by, admin_notes, approved_at, completed_at, reason, refund_provider, refund_reference, refund_requested_at, refund_status, refunded_amount, requested_amount, status, order_id) FROM stdin;
\.


--
-- Data for Name: revenues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.revenues (id, created_at, created_by, updated_at, updated_by, amount, reference_id, revenue_date, source) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, created_at, created_by, updated_at, updated_by, description, name) FROM stdin;
2f742963-c0a2-41bc-81c4-2caf9cb6dbbc	2026-06-27 15:39:37.325675	\N	2026-06-27 15:39:37.327685	\N	Default role: ROLE_ADMIN	ROLE_ADMIN
56960a38-ce46-4311-b2de-e26236b8e1f9	2026-06-27 15:39:37.386477	\N	2026-06-27 15:39:37.386477	\N	Default role: ROLE_EMPLOYEE	ROLE_EMPLOYEE
a3035bb1-fc82-4fba-8b3b-56aa999939b6	2026-06-27 15:39:37.399982	\N	2026-06-27 15:39:37.399982	\N	Default role: ROLE_CUSTOMER	ROLE_CUSTOMER
f79d2e63-1785-413d-90ae-e8df367f7845	2026-06-27 15:39:37.429796	\N	2026-06-27 15:39:37.429796	\N	Default role: ROLE_SUPPORT_AGENT	ROLE_SUPPORT_AGENT
\.


--
-- Data for Name: sales_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_reports (id, created_at, created_by, updated_at, updated_by, active_customers, report_date, report_period, total_orders, total_revenue) FROM stdin;
\.


--
-- Data for Name: satisfaction_surveys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.satisfaction_surveys (id, created_at, created_by, updated_at, updated_by, feedback, rating, ticket_id) FROM stdin;
\.


--
-- Data for Name: security_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.security_settings (id, created_at, created_by, updated_at, updated_by, lockout_duration_minutes, max_failed_login_attempts, mfa_required, password_min_length, password_require_digit, password_require_lowercase, password_require_special_character, password_require_uppercase, session_timeout_minutes) FROM stdin;
fc3f928d-bdd9-478c-909e-b66dda324b85	2026-06-27 15:53:45.292103	\N	2026-06-27 15:53:45.292103	\N	15	5	t	6	f	f	f	f	1440
\.


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipments (id, created_at, created_by, updated_at, updated_by, actual_delivery_date, carrier, estimated_delivery_date, status, tracking_number, order_id) FROM stdin;
fa78d477-7c4a-4947-ace6-3b6174446443	2026-06-27 16:03:37.240236	\N	2026-06-27 16:04:04.375266	\N	2026-06-27 16:03:00	Other	2026-06-27 16:03:00	DELIVERED	TRK-1782569017113-40A21EB7	e65365da-cb99-44b3-82ca-276f63a28e8b
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_movements (id, created_at, created_by, updated_at, updated_by, quantity, reason, reference_id, type, inventory_item_id) FROM stdin;
8d2bfdc2-feae-45b0-a8a5-bcd92258dbef	2026-06-27 15:58:31.41241	\N	2026-06-27 15:58:31.41241	\N	100	Procurement received	3ca9b26f-7f7b-4041-817c-d665d88881ed	PROCUREMENT	6686ba3a-c775-4965-b407-520a0dba8b00
b1cf62f5-d3f0-4c83-b082-471b43ee0289	2026-06-27 16:00:17.974325	\N	2026-06-27 16:00:17.974325	\N	-3	Sale completed	LUZ-1782568817915	SALE	6686ba3a-c775-4965-b407-520a0dba8b00
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, created_at, created_by, updated_at, updated_by, active, address, contact_email, contact_phone, name, notes, performance_rating) FROM stdin;
79a6d494-abc7-4795-bdfa-f7e18bb2dad8	2026-06-27 15:51:57.01685	\N	2026-06-27 15:51:57.01685	\N	t	KN 54 AVE	hakizimanaeric@gmail.com	0788667733	Hakizimana Eric	\N	4.4
\.


--
-- Data for Name: support_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_messages (id, created_at, created_by, updated_at, updated_by, message, sender_id, ticket_id) FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_tickets (id, created_at, created_by, updated_at, updated_by, description, priority, status, title, assigned_agent_id, customer_id) FROM stdin;
\.


--
-- Data for Name: system_backups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_backups (id, created_at, created_by, updated_at, updated_by, completed_at, file_path, message, name, restored_at, size_bytes, status) FROM stdin;
\.


--
-- Data for Name: system_configurations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_configurations (id, created_at, created_by, updated_at, updated_by, category, config_key, config_value, description, sensitive) FROM stdin;
\.


--
-- Data for Name: tax_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_records (id, created_at, created_by, updated_at, updated_by, amount, filing_date, order_id, order_number, reference_id, status, tax_date, tax_rate, tax_type, taxable_amount) FROM stdin;
bf16cb44-af8f-4e63-8a9d-89b6060d5f45	2026-06-27 16:00:34.722503	\N	2026-06-27 16:00:34.722503	\N	9720000.00	2026-06-30	e65365da-cb99-44b3-82ca-276f63a28e8b	LUZ-1782568817915	LUZ-1782568817915	PENDING	2026-06-27	0.18	SALES_TAX	54000000.00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role_id) FROM stdin;
0c034724-a59e-4ce3-b270-932e6176621d	2f742963-c0a2-41bc-81c4-2caf9cb6dbbc
6191f168-e9fd-453f-9d66-5de018153114	2f742963-c0a2-41bc-81c4-2caf9cb6dbbc
50c73f14-927d-436d-aacc-ac3c4bcaeacb	56960a38-ce46-4311-b2de-e26236b8e1f9
c6089d46-ffe0-4cde-9ec0-a6f497c484b7	a3035bb1-fc82-4fba-8b3b-56aa999939b6
ce6487e8-9fde-4ba9-a7d6-e1a0ea8615bb	f79d2e63-1785-413d-90ae-e8df367f7845
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, created_at, created_by, updated_at, updated_by, address, email, email_verified, enabled, first_name, force_password_change, last_login_date, last_name, locked, password, phone_number) FROM stdin;
0c034724-a59e-4ce3-b270-932e6176621d	2026-06-27 15:39:37.682308	\N	2026-06-27 15:39:37.682308	\N	\N	admin@luztech.com	t	t	System	f	\N	Administrator	f	$2a$10$UTAPfiKdZyDES/i7GSipz.yLmxcM8/wRtxXTWjUnwezme8E41KtXS	\N
50c73f14-927d-436d-aacc-ac3c4bcaeacb	2026-06-27 15:39:38.131135	\N	2026-06-27 15:39:38.131135	\N	\N	ishimwedivin01@gmail.com	t	t	Divin	f	\N	Ishimwe	f	$2a$10$iVFH7qQiTN41p3KMCQj8qezqO3ncFfXtDo.fJC4.OyD55359PiKbC	\N
ce6487e8-9fde-4ba9-a7d6-e1a0ea8615bb	2026-06-27 15:39:38.513601	\N	2026-06-27 15:39:38.513601	\N	\N	idivin44@gmail.com	t	t	Divin	f	\N	Ishimwe	f	$2a$10$fn7IDXzzMImmOjfOaYrtmumbggNr1sW3YqcXVwVS41CcQJcQSRH7G	\N
c6089d46-ffe0-4cde-9ec0-a6f497c484b7	2026-06-27 15:39:38.325828	\N	2026-06-27 15:59:15.557855	\N	\N	ishimdivin2019@gmail.com	t	t	Divin	f	2026-06-27 15:59:15.557856	Ishimwe	f	$2a$10$O53DNrt6feGUSodkNMMmte4lArxo6MW0pSXhgIZDTIIGkwJIG4pmS	\N
6191f168-e9fd-453f-9d66-5de018153114	2026-06-27 15:39:37.917037	\N	2026-06-27 16:01:19.323391	\N	\N	ishimwedivin2@gmail.com	t	t	Divin	f	2026-06-27 16:01:19.314835	Ishimwe	f	$2a$10$w95gWTW.i479YIpEPuyXJeePpyJP5fTxkajqIcaSvAanSrdT4sk1m	\N
\.


--
-- Data for Name: wishlist_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wishlist_items (id, created_at, created_by, updated_at, updated_by, product_id, user_id) FROM stdin;
\.


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: banners banners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_pkey PRIMARY KEY (id);


--
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (id);


--
-- Name: carts carts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: chat_sessions chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: communication_logs communication_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_logs
    ADD CONSTRAINT communication_logs_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: customer_metrics customer_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_metrics
    ADD CONSTRAINT customer_metrics_pkey PRIMARY KEY (id);


--
-- Name: customer_profiles customer_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_profiles
    ADD CONSTRAINT customer_profiles_pkey PRIMARY KEY (id);


--
-- Name: customer_segments customer_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_segments
    ADD CONSTRAINT customer_segments_pkey PRIMARY KEY (id);


--
-- Name: discounts discounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discounts
    ADD CONSTRAINT discounts_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: faq_articles faq_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faq_articles
    ADD CONSTRAINT faq_articles_pkey PRIMARY KEY (id);


--
-- Name: feedbacks feedbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT feedbacks_pkey PRIMARY KEY (id);


--
-- Name: financial_reports financial_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_reports
    ADD CONSTRAINT financial_reports_pkey PRIMARY KEY (id);


--
-- Name: fulfillment_orders fulfillment_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_orders
    ADD CONSTRAINT fulfillment_orders_pkey PRIMARY KEY (id);


--
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- Name: kpi_records kpi_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_records
    ADD CONSTRAINT kpi_records_pkey PRIMARY KEY (id);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (id);


--
-- Name: mfa_otps mfa_otps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_otps
    ADD CONSTRAINT mfa_otps_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: order_tracking_events order_tracking_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_tracking_events
    ADD CONSTRAINT order_tracking_events_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: payment_transactions payment_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_pkey PRIMARY KEY (id);


--
-- Name: procurement_orders procurement_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_orders
    ADD CONSTRAINT procurement_orders_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_reviews product_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reviews
    ADD CONSTRAINT product_reviews_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: return_requests return_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_requests
    ADD CONSTRAINT return_requests_pkey PRIMARY KEY (id);


--
-- Name: revenues revenues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revenues
    ADD CONSTRAINT revenues_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sales_reports sales_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_reports
    ADD CONSTRAINT sales_reports_pkey PRIMARY KEY (id);


--
-- Name: satisfaction_surveys satisfaction_surveys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.satisfaction_surveys
    ADD CONSTRAINT satisfaction_surveys_pkey PRIMARY KEY (id);


--
-- Name: security_settings security_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_settings
    ADD CONSTRAINT security_settings_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: support_messages support_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: system_backups system_backups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_backups
    ADD CONSTRAINT system_backups_pkey PRIMARY KEY (id);


--
-- Name: system_configurations system_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_configurations
    ADD CONSTRAINT system_configurations_pkey PRIMARY KEY (id);


--
-- Name: tax_records tax_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_records
    ADD CONSTRAINT tax_records_pkey PRIMARY KEY (id);


--
-- Name: products uk61hq67yr3nuuwvx80rbr95r4s; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT uk61hq67yr3nuuwvx80rbr95r4s UNIQUE (inventory_item_id);


--
-- Name: carts uk64t7ox312pqal3p7fg9o503c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT uk64t7ox312pqal3p7fg9o503c2 UNIQUE (user_id);


--
-- Name: users uk6dotkott2kjsp8vw4d0m25fb7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk6dotkott2kjsp8vw4d0m25fb7 UNIQUE (email);


--
-- Name: password_reset_tokens uk71lqwbwtklmljk3qlsugr1mig; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT uk71lqwbwtklmljk3qlsugr1mig UNIQUE (token);


--
-- Name: refresh_tokens uk7tdcd6ab5wsgoudnvj7xf1b7l; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT uk7tdcd6ab5wsgoudnvj7xf1b7l UNIQUE (user_id);


--
-- Name: system_configurations uk867jsfttn43kaegq3c6c24b7r; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_configurations
    ADD CONSTRAINT uk867jsfttn43kaegq3c6c24b7r UNIQUE (config_key);


--
-- Name: customer_segments uk9v933bm211015c3i1vh4qg1iq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_segments
    ADD CONSTRAINT uk9v933bm211015c3i1vh4qg1iq UNIQUE (name);


--
-- Name: coupons ukeplt0kkm9yf2of2lnx6c1oy9b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT ukeplt0kkm9yf2of2lnx6c1oy9b UNIQUE (code);


--
-- Name: refresh_tokens ukghpmfn23vmxfu3spu3lfg4r2d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT ukghpmfn23vmxfu3spu3lfg4r2d UNIQUE (token);


--
-- Name: shipments ukhrhy2yghr8dampg1jtecuekvp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT ukhrhy2yghr8dampg1jtecuekvp UNIQUE (order_id);


--
-- Name: customer_metrics ukhuf800pbo311daueruwtpgd4w; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_metrics
    ADD CONSTRAINT ukhuf800pbo311daueruwtpgd4w UNIQUE (customer_id);


--
-- Name: mfa_otps ukicfpxf4f0hvk8up1epwolbe29; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_otps
    ADD CONSTRAINT ukicfpxf4f0hvk8up1epwolbe29 UNIQUE (mfa_token);


--
-- Name: customer_profiles ukjoftwv6r96fq3bdnu7q00hq1w; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_profiles
    ADD CONSTRAINT ukjoftwv6r96fq3bdnu7q00hq1w UNIQUE (customer_id);


--
-- Name: return_requests ukmlyu5yxuty6xy4bndr5rrnfr0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_requests
    ADD CONSTRAINT ukmlyu5yxuty6xy4bndr5rrnfr0 UNIQUE (order_id);


--
-- Name: fulfillment_orders ukng3qc69pwbil0dalh7vkmueod; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_orders
    ADD CONSTRAINT ukng3qc69pwbil0dalh7vkmueod UNIQUE (order_id);


--
-- Name: orders uknthkiu7pgmnqnu86i2jyoe2v7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT uknthkiu7pgmnqnu86i2jyoe2v7 UNIQUE (order_number);


--
-- Name: roles ukofx66keruapi6vyqpv6f2or37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT ukofx66keruapi6vyqpv6f2or37 UNIQUE (name);


--
-- Name: inventory_items ukp0mih1lkha7t38jh46r3uu0eg; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT ukp0mih1lkha7t38jh46r3uu0eg UNIQUE (sku);


--
-- Name: satisfaction_surveys ukpv41e93d5s8qmc9eq8ws0hawj; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.satisfaction_surveys
    ADD CONSTRAINT ukpv41e93d5s8qmc9eq8ws0hawj UNIQUE (ticket_id);


--
-- Name: fulfillment_orders ukrkhys3qm94etm6t863ifw77t0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_orders
    ADD CONSTRAINT ukrkhys3qm94etm6t863ifw77t0 UNIQUE (shipment_id);


--
-- Name: categories ukt8o6pivur7nn124jehx7cygw5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT ukt8o6pivur7nn124jehx7cygw5 UNIQUE (name);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wishlist_items wishlist_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist_items
    ADD CONSTRAINT wishlist_items_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens fk1lih5y2npsf8u5o3vhdb9y0os; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT fk1lih5y2npsf8u5o3vhdb9y0os FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cart_items fk1re40cjegsfvw58xrkdp6bac6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT fk1re40cjegsfvw58xrkdp6bac6 FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: support_tickets fk1tmbsselat6ceyejefrvdeis9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT fk1tmbsselat6ceyejefrvdeis9 FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: product_reviews fk35kxxqe2g9r4mww80w9e3tnw9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reviews
    ADD CONSTRAINT fk35kxxqe2g9r4mww80w9e3tnw9 FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: chat_messages fk3cpkdtwdxndrjhrx3gt9q5ux9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT fk3cpkdtwdxndrjhrx3gt9q5ux9 FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id);


--
-- Name: product_reviews fk58i39bhws2hss3tbcvdmrm60f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reviews
    ADD CONSTRAINT fk58i39bhws2hss3tbcvdmrm60f FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: products fk5cyj7v7fvm60i2ubciqfo2wxm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk5cyj7v7fvm60i2ubciqfo2wxm FOREIGN KEY (discount_id) REFERENCES public.discounts(id);


--
-- Name: products fk5u9vbactm63h16y9fj00t798f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk5u9vbactm63h16y9fj00t798f FOREIGN KEY (inventory_item_id) REFERENCES public.inventory_items(id);


--
-- Name: chat_sessions fk6acn2awn3clx0yvpn8htd70be; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT fk6acn2awn3clx0yvpn8htd70be FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: communication_logs fk81wbm56ml5kl04lda12gxhrxs; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_logs
    ADD CONSTRAINT fk81wbm56ml5kl04lda12gxhrxs FOREIGN KEY (handled_by_id) REFERENCES public.users(id);


--
-- Name: feedbacks fk8kw5agn6ypgg4lkjrbc54wk0c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT fk8kw5agn6ypgg4lkjrbc54wk0c FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: customer_profiles fk9b8jyctrw1rowxsyiwmvh3gae; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_profiles
    ADD CONSTRAINT fk9b8jyctrw1rowxsyiwmvh3gae FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: fulfillment_orders fk9r0ufkesaxvhurv9q8fch75ka; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_orders
    ADD CONSTRAINT fk9r0ufkesaxvhurv9q8fch75ka FOREIGN KEY (shipment_id) REFERENCES public.shipments(id);


--
-- Name: customer_profiles fk9u9qbkn57pxecpxjstd68deti; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_profiles
    ADD CONSTRAINT fk9u9qbkn57pxecpxjstd68deti FOREIGN KEY (segment_id) REFERENCES public.customer_segments(id);


--
-- Name: notifications fk9y21adhxn0ayjhfocscqox7bh; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk9y21adhxn0ayjhfocscqox7bh FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: chat_sessions fkao4yreakip07aurht94h7lo6r; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT fkao4yreakip07aurht94h7lo6r FOREIGN KEY (agent_id) REFERENCES public.users(id);


--
-- Name: carts fkb5o626f86h46m4s7ms6ginnop; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT fkb5o626f86h46m4s7ms6ginnop FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: order_items fkbioxgbv59vetrxe0ejfubep1w; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fkbioxgbv59vetrxe0ejfubep1w FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: return_requests fkbski88d6kewx0cbj5pk7nes01; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_requests
    ADD CONSTRAINT fkbski88d6kewx0cbj5pk7nes01 FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: procurement_orders fkbvdwa0a0j4xip16ocu2twj4bk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_orders
    ADD CONSTRAINT fkbvdwa0a0j4xip16ocu2twj4bk FOREIGN KEY (inventory_item_id) REFERENCES public.inventory_items(id);


--
-- Name: support_messages fkejv4umpsfsqv4amvnjrmni3xi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT fkejv4umpsfsqv4amvnjrmni3xi FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- Name: chat_messages fkgiqeap8ays4lf684x7m0r2729; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT fkgiqeap8ays4lf684x7m0r2729 FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: communication_logs fkgk9474pf5rnu0c37mekk9gap9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_logs
    ADD CONSTRAINT fkgk9474pf5rnu0c37mekk9gap9 FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: user_roles fkh8ciramu9cc9q3qcqiv4ue8a6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fkh8ciramu9cc9q3qcqiv4ue8a6 FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: user_roles fkhfh9dx7w3ubf1co1vdev94g3f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fkhfh9dx7w3ubf1co1vdev94g3f FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: password_reset_tokens fkk3ndxg5xp6v7wd4gjyusp15gq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT fkk3ndxg5xp6v7wd4gjyusp15gq FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: fulfillment_orders fklqmme8l6wu2wdx6m5pdg5kvc6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_orders
    ADD CONSTRAINT fklqmme8l6wu2wdx6m5pdg5kvc6 FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: mfa_otps fkm4pfhtf6c4ov8if1v97yfrpy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_otps
    ADD CONSTRAINT fkm4pfhtf6c4ov8if1v97yfrpy FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: orders fkmb88e3a35geg9rxiefr1qma88; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fkmb88e3a35geg9rxiefr1qma88 FOREIGN KEY (cashier_id) REFERENCES public.users(id);


--
-- Name: wishlist_items fkmmj2k1i459yu449k3h1vx5abp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist_items
    ADD CONSTRAINT fkmmj2k1i459yu449k3h1vx5abp FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payment_transactions fknsous9qyrjv5ss8que6o6617; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT fknsous9qyrjv5ss8que6o6617 FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: support_tickets fko9o82krkf7cg9ic4r5froc83v; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT fko9o82krkf7cg9ic4r5froc83v FOREIGN KEY (assigned_agent_id) REFERENCES public.users(id);


--
-- Name: order_items fkocimc7dtr037rh4ls4l95nlfi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fkocimc7dtr037rh4ls4l95nlfi FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: products fkog2rp4qthbtt2lfyhfo32lsw9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fkog2rp4qthbtt2lfyhfo32lsw9 FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: cart_items fkpcttvuq4mxppo8sxggjtn5i2c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT fkpcttvuq4mxppo8sxggjtn5i2c FOREIGN KEY (cart_id) REFERENCES public.carts(id);


--
-- Name: order_tracking_events fkpiysrnkv9a30xirabwtyd0poj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_tracking_events
    ADD CONSTRAINT fkpiysrnkv9a30xirabwtyd0poj FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: customer_metrics fkqj2ewu7pf91h6a56jvd05l6s; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_metrics
    ADD CONSTRAINT fkqj2ewu7pf91h6a56jvd05l6s FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: product_images fkqnq71xsohugpqwf3c9gxmsuy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT fkqnq71xsohugpqwf3c9gxmsuy FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: wishlist_items fkqxj7lncd242b59fb78rqegyxj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist_items
    ADD CONSTRAINT fkqxj7lncd242b59fb78rqegyxj FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: satisfaction_surveys fkrivxx8qmqpjxdli4nwquxol58; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.satisfaction_surveys
    ADD CONSTRAINT fkrivxx8qmqpjxdli4nwquxol58 FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- Name: shipments fkrnt4wht95lxxplspltrg9681s; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT fkrnt4wht95lxxplspltrg9681s FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: categories fksaok720gsu4u2wrgbk10b5n8d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT fksaok720gsu4u2wrgbk10b5n8d FOREIGN KEY (parent_id) REFERENCES public.categories(id);


--
-- Name: stock_movements fksf8xqne4s20910sgk48jvyx4u; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT fksf8xqne4s20910sgk48jvyx4u FOREIGN KEY (inventory_item_id) REFERENCES public.inventory_items(id);


--
-- Name: orders fksjfs85qf6vmcurlx43cnc16gy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fksjfs85qf6vmcurlx43cnc16gy FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: support_messages fkt3x5f2qc7d89medr0xxslx982; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT fkt3x5f2qc7d89medr0xxslx982 FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: procurement_orders fkthjya06tx4ktno1tw72q1vogf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_orders
    ADD CONSTRAINT fkthjya06tx4ktno1tw72q1vogf FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- PostgreSQL database dump complete
--

