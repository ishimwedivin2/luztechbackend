--
-- PostgreSQL database dump
--

-- Dumped from database version 17.1
-- Dumped by pg_dump version 17.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.procurement_orders DROP CONSTRAINT IF EXISTS fkthjya06tx4ktno1tw72q1vogf;
ALTER TABLE IF EXISTS ONLY public.support_messages DROP CONSTRAINT IF EXISTS fkt3x5f2qc7d89medr0xxslx982;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fksjfs85qf6vmcurlx43cnc16gy;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS fksf8xqne4s20910sgk48jvyx4u;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS fksaok720gsu4u2wrgbk10b5n8d;
ALTER TABLE IF EXISTS ONLY public.shipments DROP CONSTRAINT IF EXISTS fkrnt4wht95lxxplspltrg9681s;
ALTER TABLE IF EXISTS ONLY public.satisfaction_surveys DROP CONSTRAINT IF EXISTS fkrivxx8qmqpjxdli4nwquxol58;
ALTER TABLE IF EXISTS ONLY public.wishlist_items DROP CONSTRAINT IF EXISTS fkqxj7lncd242b59fb78rqegyxj;
ALTER TABLE IF EXISTS ONLY public.customer_addresses DROP CONSTRAINT IF EXISTS fkqptcrpu3x8qle4pawfritva6o;
ALTER TABLE IF EXISTS ONLY public.product_images DROP CONSTRAINT IF EXISTS fkqnq71xsohugpqwf3c9gxmsuy;
ALTER TABLE IF EXISTS ONLY public.customer_metrics DROP CONSTRAINT IF EXISTS fkqj2ewu7pf91h6a56jvd05l6s;
ALTER TABLE IF EXISTS ONLY public.order_tracking_events DROP CONSTRAINT IF EXISTS fkpiysrnkv9a30xirabwtyd0poj;
ALTER TABLE IF EXISTS ONLY public.cart_items DROP CONSTRAINT IF EXISTS fkpcttvuq4mxppo8sxggjtn5i2c;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS fkog2rp4qthbtt2lfyhfo32lsw9;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS fkocimc7dtr037rh4ls4l95nlfi;
ALTER TABLE IF EXISTS ONLY public.support_tickets DROP CONSTRAINT IF EXISTS fko9o82krkf7cg9ic4r5froc83v;
ALTER TABLE IF EXISTS ONLY public.payment_transactions DROP CONSTRAINT IF EXISTS fknsous9qyrjv5ss8que6o6617;
ALTER TABLE IF EXISTS ONLY public.wishlist_items DROP CONSTRAINT IF EXISTS fkmmj2k1i459yu449k3h1vx5abp;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fkmb88e3a35geg9rxiefr1qma88;
ALTER TABLE IF EXISTS ONLY public.mfa_otps DROP CONSTRAINT IF EXISTS fkm4pfhtf6c4ov8if1v97yfrpy;
ALTER TABLE IF EXISTS ONLY public.fulfillment_orders DROP CONSTRAINT IF EXISTS fklqmme8l6wu2wdx6m5pdg5kvc6;
ALTER TABLE IF EXISTS ONLY public.sectors DROP CONSTRAINT IF EXISTS fklj3sbd4y976qcn545xkiptog6;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS fkk3ndxg5xp6v7wd4gjyusp15gq;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS fkhfh9dx7w3ubf1co1vdev94g3f;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS fkh8ciramu9cc9q3qcqiv4ue8a6;
ALTER TABLE IF EXISTS ONLY public.communication_logs DROP CONSTRAINT IF EXISTS fkgk9474pf5rnu0c37mekk9gap9;
ALTER TABLE IF EXISTS ONLY public.chat_messages DROP CONSTRAINT IF EXISTS fkgiqeap8ays4lf684x7m0r2729;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fkg3485uyc54ym22haggn1lwumx;
ALTER TABLE IF EXISTS ONLY public.support_messages DROP CONSTRAINT IF EXISTS fkejv4umpsfsqv4amvnjrmni3xi;
ALTER TABLE IF EXISTS ONLY public.procurement_orders DROP CONSTRAINT IF EXISTS fke1ykrunqgqpagtdqorh0ea8l;
ALTER TABLE IF EXISTS ONLY public.procurement_orders DROP CONSTRAINT IF EXISTS fkbvdwa0a0j4xip16ocu2twj4bk;
ALTER TABLE IF EXISTS ONLY public.return_requests DROP CONSTRAINT IF EXISTS fkbski88d6kewx0cbj5pk7nes01;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS fkbioxgbv59vetrxe0ejfubep1w;
ALTER TABLE IF EXISTS ONLY public.carts DROP CONSTRAINT IF EXISTS fkb5o626f86h46m4s7ms6ginnop;
ALTER TABLE IF EXISTS ONLY public.chat_sessions DROP CONSTRAINT IF EXISTS fkao4yreakip07aurht94h7lo6r;
ALTER TABLE IF EXISTS ONLY public.villages DROP CONSTRAINT IF EXISTS fkancrfdwvkb9r5d743uydn9ocf;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS fk9y21adhxn0ayjhfocscqox7bh;
ALTER TABLE IF EXISTS ONLY public.customer_profiles DROP CONSTRAINT IF EXISTS fk9u9qbkn57pxecpxjstd68deti;
ALTER TABLE IF EXISTS ONLY public.fulfillment_orders DROP CONSTRAINT IF EXISTS fk9r0ufkesaxvhurv9q8fch75ka;
ALTER TABLE IF EXISTS ONLY public.customer_profiles DROP CONSTRAINT IF EXISTS fk9b8jyctrw1rowxsyiwmvh3gae;
ALTER TABLE IF EXISTS ONLY public.feedbacks DROP CONSTRAINT IF EXISTS fk8kw5agn6ypgg4lkjrbc54wk0c;
ALTER TABLE IF EXISTS ONLY public.districts DROP CONSTRAINT IF EXISTS fk82doq1t64jhly7a546lpvnu2c;
ALTER TABLE IF EXISTS ONLY public.communication_logs DROP CONSTRAINT IF EXISTS fk81wbm56ml5kl04lda12gxhrxs;
ALTER TABLE IF EXISTS ONLY public.chat_sessions DROP CONSTRAINT IF EXISTS fk6acn2awn3clx0yvpn8htd70be;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS fk5u9vbactm63h16y9fj00t798f;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS fk5cyj7v7fvm60i2ubciqfo2wxm;
ALTER TABLE IF EXISTS ONLY public.product_reviews DROP CONSTRAINT IF EXISTS fk58i39bhws2hss3tbcvdmrm60f;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS fk4b4af0ov0jw6r9xtq3tabt5a;
ALTER TABLE IF EXISTS ONLY public.cells DROP CONSTRAINT IF EXISTS fk3dykl3bvacycgrefqn0kwl7kx;
ALTER TABLE IF EXISTS ONLY public.chat_messages DROP CONSTRAINT IF EXISTS fk3cpkdtwdxndrjhrx3gt9q5ux9;
ALTER TABLE IF EXISTS ONLY public.product_reviews DROP CONSTRAINT IF EXISTS fk35kxxqe2g9r4mww80w9e3tnw9;
ALTER TABLE IF EXISTS ONLY public.support_tickets DROP CONSTRAINT IF EXISTS fk1tmbsselat6ceyejefrvdeis9;
ALTER TABLE IF EXISTS ONLY public.cart_items DROP CONSTRAINT IF EXISTS fk1re40cjegsfvw58xrkdp6bac6;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS fk1lih5y2npsf8u5o3vhdb9y0os;
DROP INDEX IF EXISTS public.idx_village_name;
DROP INDEX IF EXISTS public.idx_village_cell;
DROP INDEX IF EXISTS public.idx_sector_name;
DROP INDEX IF EXISTS public.idx_sector_district;
DROP INDEX IF EXISTS public.idx_province_name;
DROP INDEX IF EXISTS public.idx_district_province;
DROP INDEX IF EXISTS public.idx_district_name;
DROP INDEX IF EXISTS public.idx_cell_sector;
DROP INDEX IF EXISTS public.idx_cell_name;
ALTER TABLE IF EXISTS ONLY public.wishlist_items DROP CONSTRAINT IF EXISTS wishlist_items_pkey;
ALTER TABLE IF EXISTS ONLY public.villages DROP CONSTRAINT IF EXISTS villages_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS ukt8o6pivur7nn124jehx7cygw5;
ALTER TABLE IF EXISTS ONLY public.fulfillment_orders DROP CONSTRAINT IF EXISTS ukrkhys3qm94etm6t863ifw77t0;
ALTER TABLE IF EXISTS ONLY public.satisfaction_surveys DROP CONSTRAINT IF EXISTS ukpv41e93d5s8qmc9eq8ws0hawj;
ALTER TABLE IF EXISTS ONLY public.inventory_items DROP CONSTRAINT IF EXISTS ukp0mih1lkha7t38jh46r3uu0eg;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS ukofx66keruapi6vyqpv6f2or37;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS uknthkiu7pgmnqnu86i2jyoe2v7;
ALTER TABLE IF EXISTS ONLY public.fulfillment_orders DROP CONSTRAINT IF EXISTS ukng3qc69pwbil0dalh7vkmueod;
ALTER TABLE IF EXISTS ONLY public.return_requests DROP CONSTRAINT IF EXISTS ukmlyu5yxuty6xy4bndr5rrnfr0;
ALTER TABLE IF EXISTS ONLY public.provinces DROP CONSTRAINT IF EXISTS ukl256wnwfdobq071mcq7rckr9y;
ALTER TABLE IF EXISTS ONLY public.customer_profiles DROP CONSTRAINT IF EXISTS ukjoftwv6r96fq3bdnu7q00hq1w;
ALTER TABLE IF EXISTS ONLY public.mfa_otps DROP CONSTRAINT IF EXISTS ukicfpxf4f0hvk8up1epwolbe29;
ALTER TABLE IF EXISTS ONLY public.customer_metrics DROP CONSTRAINT IF EXISTS ukhuf800pbo311daueruwtpgd4w;
ALTER TABLE IF EXISTS ONLY public.shipments DROP CONSTRAINT IF EXISTS ukhrhy2yghr8dampg1jtecuekvp;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS ukghpmfn23vmxfu3spu3lfg4r2d;
ALTER TABLE IF EXISTS ONLY public.coupons DROP CONSTRAINT IF EXISTS ukeplt0kkm9yf2of2lnx6c1oy9b;
ALTER TABLE IF EXISTS ONLY public.villages DROP CONSTRAINT IF EXISTS uk_village_cell_name;
ALTER TABLE IF EXISTS ONLY public.sectors DROP CONSTRAINT IF EXISTS uk_sector_district_name;
ALTER TABLE IF EXISTS ONLY public.districts DROP CONSTRAINT IF EXISTS uk_district_province_name;
ALTER TABLE IF EXISTS ONLY public.cells DROP CONSTRAINT IF EXISTS uk_cell_sector_name;
ALTER TABLE IF EXISTS ONLY public.customer_segments DROP CONSTRAINT IF EXISTS uk9v933bm211015c3i1vh4qg1iq;
ALTER TABLE IF EXISTS ONLY public.tax_rates DROP CONSTRAINT IF EXISTS uk88nhapcsosjsuypf5wedngqgk;
ALTER TABLE IF EXISTS ONLY public.system_configurations DROP CONSTRAINT IF EXISTS uk867jsfttn43kaegq3c6c24b7r;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS uk7tdcd6ab5wsgoudnvj7xf1b7l;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS uk71lqwbwtklmljk3qlsugr1mig;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS uk6dotkott2kjsp8vw4d0m25fb7;
ALTER TABLE IF EXISTS ONLY public.carts DROP CONSTRAINT IF EXISTS uk64t7ox312pqal3p7fg9o503c2;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS uk61hq67yr3nuuwvx80rbr95r4s;
ALTER TABLE IF EXISTS ONLY public.tax_records DROP CONSTRAINT IF EXISTS tax_records_pkey;
ALTER TABLE IF EXISTS ONLY public.tax_rates DROP CONSTRAINT IF EXISTS tax_rates_pkey;
ALTER TABLE IF EXISTS ONLY public.system_configurations DROP CONSTRAINT IF EXISTS system_configurations_pkey;
ALTER TABLE IF EXISTS ONLY public.system_backups DROP CONSTRAINT IF EXISTS system_backups_pkey;
ALTER TABLE IF EXISTS ONLY public.support_tickets DROP CONSTRAINT IF EXISTS support_tickets_pkey;
ALTER TABLE IF EXISTS ONLY public.support_messages DROP CONSTRAINT IF EXISTS support_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.suppliers DROP CONSTRAINT IF EXISTS suppliers_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_pkey;
ALTER TABLE IF EXISTS ONLY public.shipments DROP CONSTRAINT IF EXISTS shipments_pkey;
ALTER TABLE IF EXISTS ONLY public.security_settings DROP CONSTRAINT IF EXISTS security_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.sectors DROP CONSTRAINT IF EXISTS sectors_pkey;
ALTER TABLE IF EXISTS ONLY public.satisfaction_surveys DROP CONSTRAINT IF EXISTS satisfaction_surveys_pkey;
ALTER TABLE IF EXISTS ONLY public.sales_reports DROP CONSTRAINT IF EXISTS sales_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.revenues DROP CONSTRAINT IF EXISTS revenues_pkey;
ALTER TABLE IF EXISTS ONLY public.return_requests DROP CONSTRAINT IF EXISTS return_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.provinces DROP CONSTRAINT IF EXISTS provinces_pkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_pkey;
ALTER TABLE IF EXISTS ONLY public.product_reviews DROP CONSTRAINT IF EXISTS product_reviews_pkey;
ALTER TABLE IF EXISTS ONLY public.product_images DROP CONSTRAINT IF EXISTS product_images_pkey;
ALTER TABLE IF EXISTS ONLY public.procurement_orders DROP CONSTRAINT IF EXISTS procurement_orders_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_transactions DROP CONSTRAINT IF EXISTS payment_transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS password_reset_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_pkey;
ALTER TABLE IF EXISTS ONLY public.order_tracking_events DROP CONSTRAINT IF EXISTS order_tracking_events_pkey;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.mfa_otps DROP CONSTRAINT IF EXISTS mfa_otps_pkey;
ALTER TABLE IF EXISTS ONLY public.login_attempts DROP CONSTRAINT IF EXISTS login_attempts_pkey;
ALTER TABLE IF EXISTS ONLY public.kpi_records DROP CONSTRAINT IF EXISTS kpi_records_pkey;
ALTER TABLE IF EXISTS ONLY public.inventory_items DROP CONSTRAINT IF EXISTS inventory_items_pkey;
ALTER TABLE IF EXISTS ONLY public.fulfillment_orders DROP CONSTRAINT IF EXISTS fulfillment_orders_pkey;
ALTER TABLE IF EXISTS ONLY public.financial_reports DROP CONSTRAINT IF EXISTS financial_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.feedbacks DROP CONSTRAINT IF EXISTS feedbacks_pkey;
ALTER TABLE IF EXISTS ONLY public.faq_articles DROP CONSTRAINT IF EXISTS faq_articles_pkey;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_pkey;
ALTER TABLE IF EXISTS ONLY public.districts DROP CONSTRAINT IF EXISTS districts_pkey;
ALTER TABLE IF EXISTS ONLY public.discounts DROP CONSTRAINT IF EXISTS discounts_pkey;
ALTER TABLE IF EXISTS ONLY public.customer_segments DROP CONSTRAINT IF EXISTS customer_segments_pkey;
ALTER TABLE IF EXISTS ONLY public.customer_profiles DROP CONSTRAINT IF EXISTS customer_profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.customer_metrics DROP CONSTRAINT IF EXISTS customer_metrics_pkey;
ALTER TABLE IF EXISTS ONLY public.customer_addresses DROP CONSTRAINT IF EXISTS customer_addresses_pkey;
ALTER TABLE IF EXISTS ONLY public.coupons DROP CONSTRAINT IF EXISTS coupons_pkey;
ALTER TABLE IF EXISTS ONLY public.communication_logs DROP CONSTRAINT IF EXISTS communication_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.chat_sessions DROP CONSTRAINT IF EXISTS chat_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.chat_messages DROP CONSTRAINT IF EXISTS chat_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.cells DROP CONSTRAINT IF EXISTS cells_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.carts DROP CONSTRAINT IF EXISTS carts_pkey;
ALTER TABLE IF EXISTS ONLY public.cart_items DROP CONSTRAINT IF EXISTS cart_items_pkey;
ALTER TABLE IF EXISTS ONLY public.banners DROP CONSTRAINT IF EXISTS banners_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
DROP TABLE IF EXISTS public.wishlist_items;
DROP TABLE IF EXISTS public.villages;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.tax_records;
DROP TABLE IF EXISTS public.tax_rates;
DROP TABLE IF EXISTS public.system_configurations;
DROP TABLE IF EXISTS public.system_backups;
DROP TABLE IF EXISTS public.support_tickets;
DROP TABLE IF EXISTS public.support_messages;
DROP TABLE IF EXISTS public.suppliers;
DROP TABLE IF EXISTS public.stock_movements;
DROP TABLE IF EXISTS public.shipments;
DROP TABLE IF EXISTS public.security_settings;
DROP TABLE IF EXISTS public.sectors;
DROP TABLE IF EXISTS public.satisfaction_surveys;
DROP TABLE IF EXISTS public.sales_reports;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.revenues;
DROP TABLE IF EXISTS public.return_requests;
DROP TABLE IF EXISTS public.refresh_tokens;
DROP TABLE IF EXISTS public.provinces;
DROP TABLE IF EXISTS public.products;
DROP TABLE IF EXISTS public.product_reviews;
DROP TABLE IF EXISTS public.product_images;
DROP TABLE IF EXISTS public.procurement_orders;
DROP TABLE IF EXISTS public.payment_transactions;
DROP TABLE IF EXISTS public.password_reset_tokens;
DROP TABLE IF EXISTS public.orders;
DROP TABLE IF EXISTS public.order_tracking_events;
DROP TABLE IF EXISTS public.order_items;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.mfa_otps;
DROP TABLE IF EXISTS public.login_attempts;
DROP TABLE IF EXISTS public.kpi_records;
DROP TABLE IF EXISTS public.inventory_items;
DROP TABLE IF EXISTS public.fulfillment_orders;
DROP TABLE IF EXISTS public.financial_reports;
DROP TABLE IF EXISTS public.feedbacks;
DROP TABLE IF EXISTS public.faq_articles;
DROP TABLE IF EXISTS public.expenses;
DROP TABLE IF EXISTS public.districts;
DROP TABLE IF EXISTS public.discounts;
DROP TABLE IF EXISTS public.customer_segments;
DROP TABLE IF EXISTS public.customer_profiles;
DROP TABLE IF EXISTS public.customer_metrics;
DROP TABLE IF EXISTS public.customer_addresses;
DROP TABLE IF EXISTS public.coupons;
DROP TABLE IF EXISTS public.communication_logs;
DROP TABLE IF EXISTS public.chat_sessions;
DROP TABLE IF EXISTS public.chat_messages;
DROP TABLE IF EXISTS public.cells;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.carts;
DROP TABLE IF EXISTS public.cart_items;
DROP TABLE IF EXISTS public.banners;
DROP TABLE IF EXISTS public.audit_logs;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    action character varying(255) NOT NULL,
    details character varying(255),
    ip_address character varying(255) NOT NULL,
    resource character varying(255) NOT NULL,
    status character varying(255),
    "timestamp" timestamp(6) without time zone,
    user_email character varying(255)
);


--
-- Name: banners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.banners (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    active boolean NOT NULL,
    button_text character varying(255),
    display_order integer,
    image_url character varying(255),
    link_url character varying(255),
    product_id uuid,
    subtitle text,
    tag_label character varying(255),
    title character varying(255) NOT NULL
);


--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_items (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    quantity integer NOT NULL,
    cart_id uuid NOT NULL,
    product_id uuid NOT NULL
);


--
-- Name: carts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carts (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    user_id uuid NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    description character varying(255),
    name character varying(255) NOT NULL,
    parent_id uuid
);


--
-- Name: cells; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cells (
    id uuid NOT NULL,
    enabled boolean NOT NULL,
    name character varying(255) NOT NULL,
    sector_id uuid NOT NULL
);


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_messages (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    message text NOT NULL,
    sender_id uuid NOT NULL,
    session_id uuid NOT NULL
);


--
-- Name: chat_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_sessions (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    status character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    agent_id uuid,
    customer_id uuid NOT NULL
);


--
-- Name: communication_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_logs (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    channel character varying(255) NOT NULL,
    notes text,
    outcome character varying(255),
    reference_id character varying(255),
    reference_type character varying(255),
    subject character varying(255) NOT NULL,
    customer_id uuid NOT NULL,
    handled_by_id uuid
);


--
-- Name: coupons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coupons (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    active boolean NOT NULL,
    amount numeric(38,2) NOT NULL,
    code character varying(255) NOT NULL,
    current_usage integer,
    expiry_date timestamp(6) without time zone,
    minimum_order_amount numeric(38,2),
    type character varying(255) NOT NULL,
    usage_limit integer
);


--
-- Name: customer_addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_addresses (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    cell character varying(255) NOT NULL,
    default_address boolean NOT NULL,
    delivery_instructions character varying(1000),
    delivery_phone_number character varying(255),
    district character varying(255) NOT NULL,
    label character varying(255),
    province character varying(255) NOT NULL,
    sector character varying(255) NOT NULL,
    village character varying(255) NOT NULL,
    customer_id uuid NOT NULL
);


--
-- Name: customer_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_metrics (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    average_order_value numeric(38,2),
    engagement_score integer,
    return_rate_percentage integer,
    customer_id uuid NOT NULL
);


--
-- Name: customer_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_profiles (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    last_purchase_date date,
    total_purchases integer,
    total_spent numeric(38,2),
    customer_id uuid NOT NULL,
    segment_id uuid
);


--
-- Name: customer_segments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_segments (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    description character varying(255),
    name character varying(255) NOT NULL
);


--
-- Name: discounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discounts (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    active boolean NOT NULL,
    description character varying(255) NOT NULL,
    discount_percentage numeric(38,2) NOT NULL,
    end_date timestamp(6) without time zone,
    name character varying(255) NOT NULL,
    start_date timestamp(6) without time zone
);


--
-- Name: districts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.districts (
    id uuid NOT NULL,
    enabled boolean NOT NULL,
    name character varying(255) NOT NULL,
    province_id uuid NOT NULL
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    amount numeric(38,2) NOT NULL,
    category character varying(255) NOT NULL,
    description character varying(255),
    expense_date date NOT NULL,
    status character varying(255) NOT NULL
);


--
-- Name: faq_articles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.faq_articles (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    answer text NOT NULL,
    category character varying(255) NOT NULL,
    published boolean NOT NULL,
    question character varying(255) NOT NULL
);


--
-- Name: feedbacks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedbacks (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    category character varying(255),
    comments text,
    rating integer NOT NULL,
    reference_id character varying(255),
    customer_id uuid NOT NULL
);


--
-- Name: financial_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_reports (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    generated_date date,
    net_profit numeric(38,2) NOT NULL,
    report_period character varying(255) NOT NULL,
    total_expenses numeric(38,2) NOT NULL,
    total_revenue numeric(38,2) NOT NULL
);


--
-- Name: fulfillment_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fulfillment_orders (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    completed_at timestamp(6) without time zone,
    dispatched_at timestamp(6) without time zone,
    packed_at timestamp(6) without time zone,
    picked_at timestamp(6) without time zone,
    status character varying(255) NOT NULL,
    order_id uuid NOT NULL,
    shipment_id uuid
);


--
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_items (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    location character varying(255) NOT NULL,
    low_stock_threshold integer NOT NULL,
    product_name character varying(255) NOT NULL,
    quantity integer NOT NULL,
    sku character varying(255) NOT NULL,
    unit_cost numeric(38,2)
);


--
-- Name: kpi_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kpi_records (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    description character varying(255),
    metric_name character varying(255) NOT NULL,
    metric_value numeric(38,2) NOT NULL,
    record_date date NOT NULL
);


--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_attempts (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    email character varying(255) NOT NULL,
    failure_reason character varying(255),
    ip_address character varying(255) NOT NULL,
    success boolean NOT NULL
);


--
-- Name: mfa_otps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mfa_otps (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    code_hash character varying(255) NOT NULL,
    expiry_date timestamp(6) with time zone NOT NULL,
    mfa_token character varying(255) NOT NULL,
    used boolean NOT NULL,
    user_id uuid NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    message text NOT NULL,
    read boolean NOT NULL,
    related_id character varying(255),
    title character varying(255) NOT NULL,
    type character varying(255),
    user_id uuid NOT NULL
);


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    applied_tax_code character varying(255),
    applied_tax_name character varying(255),
    applied_tax_rate numeric(38,2),
    line_cost numeric(38,2),
    line_tax_amount numeric(38,2),
    line_total_including_tax numeric(38,2),
    quantity integer NOT NULL,
    sub_total numeric(38,2) NOT NULL,
    unit_cost numeric(38,2),
    unit_price numeric(38,2) NOT NULL,
    unit_price_including_tax numeric(38,2),
    unit_tax_amount numeric(38,2),
    order_id uuid NOT NULL,
    product_id uuid NOT NULL
);


--
-- Name: order_tracking_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_tracking_events (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    note text,
    status character varying(255) NOT NULL,
    order_id uuid NOT NULL,
    CONSTRAINT order_tracking_events_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'CREATED'::character varying, 'PAID'::character varying, 'PROCESSING'::character varying, 'SHIPPED'::character varying, 'DELIVERED'::character varying, 'CANCELLED'::character varying, 'RETURN_REQUESTED'::character varying, 'RETURNED'::character varying, 'REFUNDED'::character varying])::text[])))
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    billing_address character varying(255),
    coupon_code character varying(255),
    delivery_instructions character varying(1000),
    delivery_phone_number character varying(255),
    discount_amount numeric(38,2),
    order_channel character varying(255) NOT NULL,
    order_number character varying(255) NOT NULL,
    payment_method character varying(255),
    payment_reference character varying(255),
    shipping_address character varying(255) NOT NULL,
    shipping_cell character varying(255),
    shipping_district character varying(255),
    shipping_province character varying(255),
    shipping_sector character varying(255),
    shipping_village character varying(255),
    status character varying(255) NOT NULL,
    sub_total_amount numeric(38,2),
    tax_amount numeric(38,2),
    tax_rate numeric(38,2),
    total_amount numeric(38,2) NOT NULL,
    cashier_id uuid,
    customer_id uuid,
    shipping_address_id uuid,
    CONSTRAINT orders_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'CREATED'::character varying, 'PAID'::character varying, 'PROCESSING'::character varying, 'SHIPPED'::character varying, 'DELIVERED'::character varying, 'CANCELLED'::character varying, 'RETURN_REQUESTED'::character varying, 'RETURNED'::character varying, 'REFUNDED'::character varying])::text[])))
);


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    expiry_date timestamp(6) with time zone NOT NULL,
    token character varying(255) NOT NULL,
    used boolean NOT NULL,
    user_id uuid NOT NULL
);


--
-- Name: payment_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_transactions (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    amount numeric(38,2) NOT NULL,
    payment_reference character varying(255),
    provider character varying(255) NOT NULL,
    reconciled_at timestamp(6) without time zone,
    reconciliation_notes text,
    reconciliation_status character varying(255),
    status character varying(255) NOT NULL,
    transaction_type character varying(255) NOT NULL,
    order_id uuid NOT NULL
);


--
-- Name: procurement_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.procurement_orders (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    expected_delivery_date date,
    quantity_ordered integer NOT NULL,
    quantity_received integer,
    status character varying(255) NOT NULL,
    total_cost numeric(38,2),
    unit_cost numeric(38,2),
    inventory_item_id uuid NOT NULL,
    product_id uuid,
    supplier_id uuid NOT NULL
);


--
-- Name: product_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_images (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    alt_text character varying(255) NOT NULL,
    is_primary boolean NOT NULL,
    url character varying(255) NOT NULL,
    product_id uuid NOT NULL
);


--
-- Name: product_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_reviews (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    comment text,
    rating integer NOT NULL,
    verified_purchase boolean NOT NULL,
    product_id uuid NOT NULL,
    user_id uuid NOT NULL
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    average_rating numeric(3,2),
    cost_price numeric(38,2),
    description text,
    featured boolean NOT NULL,
    name character varying(255) NOT NULL,
    price numeric(38,2) NOT NULL,
    sku character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    category_id uuid,
    discount_id uuid,
    inventory_item_id uuid,
    tax_rate_id uuid,
    CONSTRAINT products_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'DRAFT'::character varying, 'ARCHIVED'::character varying])::text[])))
);


--
-- Name: provinces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provinces (
    id uuid NOT NULL,
    enabled boolean NOT NULL,
    name character varying(255) NOT NULL
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    expiry_date timestamp(6) with time zone NOT NULL,
    revoked boolean NOT NULL,
    token character varying(255) NOT NULL,
    user_id uuid
);


--
-- Name: return_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.return_requests (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    admin_notes character varying(255),
    approved_at timestamp(6) without time zone,
    completed_at timestamp(6) without time zone,
    reason character varying(255) NOT NULL,
    refund_provider character varying(255),
    refund_reference character varying(255),
    refund_requested_at timestamp(6) without time zone,
    refund_status character varying(255),
    refunded_amount numeric(38,2),
    requested_amount numeric(38,2),
    status character varying(255) NOT NULL,
    order_id uuid NOT NULL
);


--
-- Name: revenues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.revenues (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    amount numeric(38,2) NOT NULL,
    reference_id character varying(255),
    revenue_date date NOT NULL,
    source character varying(255) NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    description character varying(255),
    name character varying(255) NOT NULL
);


--
-- Name: sales_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_reports (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    active_customers integer NOT NULL,
    report_date date NOT NULL,
    report_period character varying(255),
    total_orders integer NOT NULL,
    total_revenue numeric(38,2) NOT NULL
);


--
-- Name: satisfaction_surveys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.satisfaction_surveys (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    feedback text,
    rating integer NOT NULL,
    ticket_id uuid NOT NULL
);


--
-- Name: sectors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sectors (
    id uuid NOT NULL,
    enabled boolean NOT NULL,
    name character varying(255) NOT NULL,
    district_id uuid NOT NULL
);


--
-- Name: security_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_settings (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    lockout_duration_minutes integer NOT NULL,
    max_failed_login_attempts integer NOT NULL,
    mfa_required boolean NOT NULL,
    password_min_length integer NOT NULL,
    password_require_digit boolean NOT NULL,
    password_require_lowercase boolean NOT NULL,
    password_require_special_character boolean NOT NULL,
    password_require_uppercase boolean NOT NULL,
    session_timeout_minutes integer NOT NULL
);


--
-- Name: shipments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipments (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    actual_delivery_date timestamp(6) without time zone,
    carrier character varying(255) NOT NULL,
    estimated_delivery_date timestamp(6) without time zone,
    status character varying(255) NOT NULL,
    tracking_number character varying(255) NOT NULL,
    order_id uuid NOT NULL
);


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_movements (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    quantity integer NOT NULL,
    reason character varying(255),
    reference_id character varying(255),
    type character varying(255) NOT NULL,
    inventory_item_id uuid NOT NULL
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    active boolean NOT NULL,
    address character varying(255),
    contact_email character varying(255) NOT NULL,
    contact_phone character varying(255),
    name character varying(255) NOT NULL,
    notes text,
    performance_rating double precision
);


--
-- Name: support_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_messages (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    message text NOT NULL,
    sender_id uuid NOT NULL,
    ticket_id uuid NOT NULL
);


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_tickets (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    description text NOT NULL,
    priority character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    assigned_agent_id uuid,
    customer_id uuid NOT NULL
);


--
-- Name: system_backups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_backups (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    completed_at timestamp(6) without time zone,
    file_path character varying(255) NOT NULL,
    message character varying(255),
    name character varying(255) NOT NULL,
    restored_at timestamp(6) without time zone,
    size_bytes bigint NOT NULL,
    status character varying(255) NOT NULL
);


--
-- Name: system_configurations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_configurations (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    category character varying(255),
    config_key character varying(255) NOT NULL,
    config_value text,
    description character varying(255),
    sensitive boolean NOT NULL
);


--
-- Name: tax_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rates (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    active boolean NOT NULL,
    code character varying(255) NOT NULL,
    description character varying(500),
    name character varying(255) NOT NULL,
    rate numeric(5,4) NOT NULL
);


--
-- Name: tax_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_records (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    amount numeric(38,2) NOT NULL,
    filing_date date NOT NULL,
    order_id uuid,
    order_number character varying(255),
    reference_id character varying(255),
    status character varying(255),
    tax_date date,
    tax_rate numeric(38,2),
    tax_type character varying(255) NOT NULL,
    taxable_amount numeric(38,2)
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role_id uuid NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    address character varying(255),
    email character varying(255) NOT NULL,
    email_verified boolean NOT NULL,
    enabled boolean NOT NULL,
    first_name character varying(255) NOT NULL,
    force_password_change boolean NOT NULL,
    last_login_date timestamp(6) without time zone,
    last_name character varying(255) NOT NULL,
    locked boolean NOT NULL,
    password character varying(255),
    phone_number character varying(255)
);


--
-- Name: villages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.villages (
    id uuid NOT NULL,
    enabled boolean NOT NULL,
    name character varying(255) NOT NULL,
    cell_id uuid NOT NULL
);


--
-- Name: wishlist_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wishlist_items (
    id uuid NOT NULL,
    created_at timestamp(6) without time zone,
    created_by character varying(255),
    updated_at timestamp(6) without time zone,
    updated_by character varying(255),
    product_id uuid NOT NULL,
    user_id uuid NOT NULL
);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, created_at, created_by, updated_at, updated_by, action, details, ip_address, resource, status, "timestamp", user_email) FROM stdin;
6a0ef6df-3777-47fa-9efc-431b24d9185a	2026-07-13 20:32:05.628794	\N	2026-07-13 20:32:05.628794	\N	GET	status=200, durationMs=654, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-07-13 20:32:05.612876	ishimwedivin2@gmail.com
792abad1-1216-4f76-82f8-4cf828d2c748	2026-07-13 20:32:06.045909	\N	2026-07-13 20:32:06.045909	\N	GET	status=200, durationMs=342, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/analytics/dashboard/kpis	SUCCESS	2026-07-13 20:32:06.044152	ishimwedivin2@gmail.com
685631e0-6284-4758-8094-4a1b94e64d25	2026-07-13 20:32:12.973567	\N	2026-07-13 20:32:12.973567	\N	GET	status=200, durationMs=16, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-07-13 20:32:12.972834	ishimwedivin2@gmail.com
1fac92b8-c33b-498e-ba79-cc9adc87b8d0	2026-07-13 20:32:14.828865	\N	2026-07-13 20:32:14.828865	\N	GET	status=200, durationMs=290, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-07-13 20:32:14.8261	ishimwedivin2@gmail.com
a8c0fd9c-81c1-4209-b2cc-e1f991d27d7d	2026-07-13 20:36:24.178379	\N	2026-07-13 20:36:24.178379	\N	GET	status=200, durationMs=296, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/search	SUCCESS	2026-07-13 20:36:24.17838	ishimwedivin2@gmail.com
93ee78dc-a6cd-42ba-9482-ed524346ad03	2026-07-13 20:36:43.797518	\N	2026-07-13 20:36:43.797518	\N	GET	status=200, durationMs=23, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-07-13 20:36:43.796392	ishimwedivin2@gmail.com
730a2fba-2845-481c-a51e-311b10cabf10	2026-07-13 20:38:44.079428	\N	2026-07-13 20:38:44.079428	\N	POST	status=200, durationMs=1099, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-07-13 20:38:44.077283	ishimwedivin2@gmail.com
04ecee3e-77a6-4412-957a-4b0cf60f6b53	2026-07-13 20:38:48.459794	\N	2026-07-13 20:38:48.459794	\N	GET	status=200, durationMs=65, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/procurements	SUCCESS	2026-07-13 20:38:48.457784	ishimwedivin2@gmail.com
db36f900-eae3-4cbb-8d88-57498e6f2f39	2026-07-13 20:39:18.246935	\N	2026-07-13 20:39:18.246935	\N	POST	status=200, durationMs=1226, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/procurements	SUCCESS	2026-07-13 20:39:18.245494	ishimwedivin2@gmail.com
e3c86b41-e989-44d2-b6ce-95dc3ad5b488	2026-07-13 20:39:18.679446	\N	2026-07-13 20:39:18.679446	\N	GET	status=200, durationMs=70, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/procurements	SUCCESS	2026-07-13 20:39:18.679446	ishimwedivin2@gmail.com
bce18412-ce6d-4b73-b0db-2129274c6581	2026-07-13 20:39:27.086779	\N	2026-07-13 20:39:27.086779	\N	GET	status=200, durationMs=52, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-07-13 20:39:27.08338	ishimwedivin2@gmail.com
bac34a16-6c0f-4b1a-8748-ca9be661196d	2026-07-13 20:39:33.592607	\N	2026-07-13 20:39:33.592607	\N	GET	status=200, durationMs=79, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/movements	SUCCESS	2026-07-13 20:39:33.592607	ishimwedivin2@gmail.com
1c64b4e5-1e41-4547-b17e-b39f2180b47c	2026-07-13 20:39:39.873186	\N	2026-07-13 20:39:39.873186	\N	GET	status=200, durationMs=58, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/shipments	SUCCESS	2026-07-13 20:39:39.872246	ishimwedivin2@gmail.com
e6f9a119-c7f7-4738-9b9c-28ec806b7b71	2026-07-13 20:39:48.31058	\N	2026-07-13 20:39:48.31058	\N	GET	status=200, durationMs=210, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/finance/summary	SUCCESS	2026-07-13 20:39:48.30856	ishimwedivin2@gmail.com
1d5b7b89-4edf-40ea-af97-d757665437f7	2026-07-13 20:32:05.628794	\N	2026-07-13 20:32:05.628794	\N	GET	status=200, durationMs=654, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/wishlist	SUCCESS	2026-07-13 20:32:05.612876	ishimwedivin2@gmail.com
ab2280d8-e19b-47b0-bf41-95220aab8709	2026-07-13 20:32:05.976905	\N	2026-07-13 20:32:05.976905	\N	GET	status=200, durationMs=115, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/analytics/support	SUCCESS	2026-07-13 20:32:05.975838	ishimwedivin2@gmail.com
ae0d9d84-5a43-433c-8cc0-1118e0c9f576	2026-07-13 20:32:14.579881	\N	2026-07-13 20:32:14.579881	\N	GET	status=200, durationMs=69, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/discounts	SUCCESS	2026-07-13 20:32:14.57875	ishimwedivin2@gmail.com
bcbb72a6-a8b8-4480-a5d0-0cd2fe7dd4c9	2026-07-13 20:36:03.334228	\N	2026-07-13 20:36:03.334228	\N	POST	status=200, durationMs=1770, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-07-13 20:36:03.334229	ishimwedivin2@gmail.com
9fa00272-707d-4d91-8e0f-f950fa69e984	2026-07-13 20:39:18.663771	\N	2026-07-13 20:39:18.663771	\N	GET	status=200, durationMs=51, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-07-13 20:39:18.662762	ishimwedivin2@gmail.com
c90022de-0e0a-4dd6-8197-46276459172c	2026-07-13 20:32:05.628794	\N	2026-07-13 20:32:05.628794	\N	GET	status=200, durationMs=654, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/notifications/unread-count	SUCCESS	2026-07-13 20:32:05.614882	ishimwedivin2@gmail.com
feabbff8-776c-463e-ad00-f7da33845a5f	2026-07-13 20:32:05.976905	\N	2026-07-13 20:32:05.976905	\N	GET	status=200, durationMs=265, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/analytics/customers	SUCCESS	2026-07-13 20:32:05.967995	ishimwedivin2@gmail.com
f55f5501-6a98-4f4f-b97e-c4cc897bcf4f	2026-07-13 20:32:14.772871	\N	2026-07-13 20:32:14.772871	\N	GET	status=200, durationMs=256, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-07-13 20:32:14.770859	ishimwedivin2@gmail.com
04f5d759-1493-437f-9376-2ce19011989a	2026-07-13 20:36:23.074048	\N	2026-07-13 20:36:23.074048	\N	POST	status=200, durationMs=1232, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/upload	SUCCESS	2026-07-13 20:36:23.074049	ishimwedivin2@gmail.com
90cd87c6-c01d-4b8a-9388-bc929feefa73	2026-07-13 20:37:00.910794	\N	2026-07-13 20:37:00.910794	\N	GET	status=200, durationMs=29, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-07-13 20:37:00.907151	ishimwedivin2@gmail.com
8f0a7d6b-057e-4c14-b54f-c1375d7d3dab	2026-07-13 20:38:48.434504	\N	2026-07-13 20:38:48.436303	\N	GET	status=200, durationMs=109, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-07-13 20:38:48.421332	ishimwedivin2@gmail.com
55f083fc-b952-4b6c-b0db-56e9c400fb28	2026-07-13 20:39:26.626963	\N	2026-07-13 20:39:26.626963	\N	POST	status=200, durationMs=218, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/procurements/dc760987-1cd1-4cb5-8801-f596c8b14e61/receive	SUCCESS	2026-07-13 20:39:26.626964	ishimwedivin2@gmail.com
4dcde59b-f9e3-46e9-bd9e-65a3c79f5e63	2026-07-13 20:39:42.054961	\N	2026-07-13 20:39:42.054961	\N	GET	status=200, durationMs=73, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/locations/manage/provinces	SUCCESS	2026-07-13 20:39:42.054961	ishimwedivin2@gmail.com
37868054-67c2-4ef5-9975-5e2164e949fa	2026-07-13 20:32:05.628794	\N	2026-07-13 20:32:05.628794	\N	GET	status=200, durationMs=654, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/returns	SUCCESS	2026-07-13 20:32:05.612876	ishimwedivin2@gmail.com
b9dbacd2-491f-4480-94d0-a9d71c27a288	2026-07-13 20:32:06.045909	\N	2026-07-13 20:32:06.045909	\N	GET	status=200, durationMs=301, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/analytics/dashboard/kpis	SUCCESS	2026-07-13 20:32:06.04509	ishimwedivin2@gmail.com
6c4c6a9c-a495-40ca-b3a3-82600c16b79c	2026-07-13 20:32:13.092682	\N	2026-07-13 20:32:13.092682	\N	GET	status=200, durationMs=132, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/movements	SUCCESS	2026-07-13 20:32:13.090672	ishimwedivin2@gmail.com
47959398-a303-4556-bb7c-f938299a37d7	2026-07-13 20:32:18.647834	\N	2026-07-13 20:32:18.647834	\N	GET	status=200, durationMs=58, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/finance/tax-rates	SUCCESS	2026-07-13 20:32:18.647834	ishimwedivin2@gmail.com
e5cfeea7-3a48-4df7-b16b-d1bd7543bb28	2026-07-13 20:36:23.947231	\N	2026-07-13 20:36:23.947231	\N	GET	status=200, durationMs=61, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-07-13 20:36:23.945225	ishimwedivin2@gmail.com
b9cd6c40-5725-41ac-b570-4b930a8d0b83	2026-07-13 20:38:51.073178	\N	2026-07-13 20:38:51.073178	\N	GET	status=200, durationMs=52, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-07-13 20:38:51.070953	ishimwedivin2@gmail.com
da1788d1-2e47-4244-9692-873634d6a90d	2026-07-13 20:39:27.085281	\N	2026-07-13 20:39:27.085281	\N	GET	status=200, durationMs=36, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/procurements	SUCCESS	2026-07-13 20:39:27.085282	ishimwedivin2@gmail.com
8431849a-8fef-4cdb-8e84-5ad8f25a859a	2026-07-13 20:39:33.554199	\N	2026-07-13 20:39:33.554199	\N	GET	status=200, durationMs=41, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-07-13 20:39:33.55118	ishimwedivin2@gmail.com
efd5b131-6717-4221-a7f2-6b41f5bd3d31	2026-07-13 20:39:43.699835	\N	2026-07-13 20:39:43.699835	\N	GET	status=500, durationMs=134, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/orders	FAILURE	2026-07-13 20:39:43.699835	ishimwedivin2@gmail.com
d85bbe87-e486-4f92-a05b-463ea6340740	2026-07-13 20:32:05.628794	\N	2026-07-13 20:32:05.628794	\N	GET	status=500, durationMs=654, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/cart	FAILURE	2026-07-13 20:32:05.614882	ishimwedivin2@gmail.com
86f93466-1c8e-44a1-98a2-8a8ec88a56ca	2026-07-13 20:32:05.749053	\N	2026-07-13 20:32:05.749053	\N	GET	status=500, durationMs=802, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/orders	FAILURE	2026-07-13 20:32:05.747045	ishimwedivin2@gmail.com
2e130138-69b4-4d2c-b04a-b16b42f0a49d	2026-07-13 20:32:05.815544	\N	2026-07-13 20:32:05.815544	\N	GET	status=200, durationMs=66, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/support/tickets	SUCCESS	2026-07-13 20:32:05.813028	ishimwedivin2@gmail.com
75b3d6b0-9990-4c16-be78-dc357bbba2f1	2026-07-13 20:32:05.892942	\N	2026-07-13 20:32:05.892942	\N	GET	status=200, durationMs=163, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/analytics/revenue	SUCCESS	2026-07-13 20:32:05.883627	ishimwedivin2@gmail.com
260a0e1d-b705-4d01-9c4b-86b43803cc49	2026-07-13 20:32:05.946355	\N	2026-07-13 20:32:05.946355	\N	GET	status=200, durationMs=47, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/analytics/revenue/monthly	SUCCESS	2026-07-13 20:32:05.943788	ishimwedivin2@gmail.com
5e87023b-f5d8-4adb-a01a-fcfe687ab2b5	2026-07-13 20:32:06.029075	\N	2026-07-13 20:32:06.029075	\N	GET	status=200, durationMs=82, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/analytics/inventory	SUCCESS	2026-07-13 20:32:06.029076	ishimwedivin2@gmail.com
c08fd0df-9f60-41d3-9510-c5775738fb2e	2026-07-13 20:32:13.025933	\N	2026-07-13 20:32:13.025933	\N	GET	status=200, durationMs=69, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-07-13 20:32:13.024414	ishimwedivin2@gmail.com
68f150d1-3f44-4812-9395-278d215bf920	2026-07-13 20:32:14.654529	\N	2026-07-13 20:32:14.654529	\N	GET	status=200, durationMs=130, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/finance/tax-rates	SUCCESS	2026-07-13 20:32:14.654529	ishimwedivin2@gmail.com
fafb59fe-1db2-4695-9b64-6821b086d9e3	2026-07-13 20:32:18.649498	\N	2026-07-13 20:32:18.649498	\N	GET	status=200, durationMs=56, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/categories	SUCCESS	2026-07-13 20:32:18.649499	ishimwedivin2@gmail.com
9bb99d75-9436-4162-bba4-6e2eb8376dd4	2026-07-13 20:36:23.926824	\N	2026-07-13 20:36:23.926824	\N	GET	status=200, durationMs=21, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/products/discounts	SUCCESS	2026-07-13 20:36:23.916253	ishimwedivin2@gmail.com
74879618-93d1-44e8-be4c-b94216137cca	2026-07-13 20:36:23.930131	\N	2026-07-13 20:36:23.932324	\N	GET	status=200, durationMs=48, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/finance/tax-rates	SUCCESS	2026-07-13 20:36:23.930132	ishimwedivin2@gmail.com
027f8b57-abd2-4c58-b985-0635df55b9ae	2026-07-13 20:36:43.800605	\N	2026-07-13 20:36:43.800605	\N	GET	status=200, durationMs=24, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/movements	SUCCESS	2026-07-13 20:36:43.799032	ishimwedivin2@gmail.com
86d3721f-8e10-4d9e-863f-81dda852d777	2026-07-13 20:36:43.832909	\N	2026-07-13 20:36:43.832909	\N	GET	status=200, durationMs=70, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-07-13 20:36:43.832909	ishimwedivin2@gmail.com
bdcb9e69-a26c-45ec-b245-bc18f27eb70b	2026-07-13 20:36:57.310387	\N	2026-07-13 20:36:57.310387	\N	GET	status=200, durationMs=31, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-07-13 20:36:57.308946	ishimwedivin2@gmail.com
51d5e563-6da8-4a95-b30e-93344401b8ee	2026-07-13 20:38:44.507053	\N	2026-07-13 20:38:44.507053	\N	GET	status=200, durationMs=48, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-07-13 20:38:44.493796	ishimwedivin2@gmail.com
8e7e25f9-deca-412f-bbd6-045142fbd231	2026-07-13 20:38:48.473652	\N	2026-07-13 20:38:48.473652	\N	GET	status=200, durationMs=137, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-07-13 20:38:48.473652	ishimwedivin2@gmail.com
21fe339c-38d2-43c0-939e-da38bbfd2fb5	2026-07-13 20:38:51.049962	\N	2026-07-13 20:38:51.049962	\N	GET	status=200, durationMs=30, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-07-13 20:38:51.048715	ishimwedivin2@gmail.com
8abbd66e-b155-4264-9373-5592d7bdbbc5	2026-07-13 20:39:18.656713	\N	2026-07-13 20:39:18.656713	\N	GET	status=200, durationMs=30, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/suppliers	SUCCESS	2026-07-13 20:39:18.656713	ishimwedivin2@gmail.com
f16b9728-7c02-42d6-923d-84562c69a285	2026-07-13 20:39:27.095699	\N	2026-07-13 20:39:27.095699	\N	GET	status=200, durationMs=74, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory	SUCCESS	2026-07-13 20:39:27.095699	ishimwedivin2@gmail.com
b8b0b62c-801c-4f5c-b3df-23e6f22a208e	2026-07-13 20:39:33.568844	\N	2026-07-13 20:39:33.568844	\N	GET	status=200, durationMs=24, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/inventory/low-stock	SUCCESS	2026-07-13 20:39:33.565508	ishimwedivin2@gmail.com
831494ea-964b-4e37-a65c-0a1a2cd2f274	2026-07-13 20:39:43.699835	\N	2026-07-13 20:39:43.699835	\N	GET	status=500, durationMs=124, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/orders	FAILURE	2026-07-13 20:39:43.699835	ishimwedivin2@gmail.com
d34f90ad-0677-4cdd-a8cc-6b70beef6d33	2026-07-13 20:39:54.222289	\N	2026-07-13 20:39:54.222289	\N	GET	status=200, durationMs=42, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/admin/configurations	SUCCESS	2026-07-13 20:39:54.220213	ishimwedivin2@gmail.com
811479b2-7ab9-4619-9000-c880a7242eec	2026-07-13 20:39:54.264283	\N	2026-07-13 20:39:54.264283	\N	getBackups	\N	0:0:0:0:0:0:0:1	com.luztechnology.admin.controller.AdminController	SUCCESS	2026-07-13 20:39:54.261872	ishimwedivin2@gmail.com
c0f933c1-0558-4bfb-9c12-02162aa0532e	2026-07-13 20:39:54.264283	\N	2026-07-13 20:39:54.264283	\N	getSystemHealth	\N	0:0:0:0:0:0:0:1	com.luztechnology.admin.controller.AdminController	SUCCESS	2026-07-13 20:39:54.261872	ishimwedivin2@gmail.com
86ce5941-1192-4376-8fd5-02b4314f16a5	2026-07-13 20:39:54.276455	\N	2026-07-13 20:39:54.276455	\N	GET	status=200, durationMs=96, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/admin/backups	SUCCESS	2026-07-13 20:39:54.273622	ishimwedivin2@gmail.com
7a52c8e8-30bc-4e2a-a081-086868ffc4f9	2026-07-13 20:39:54.277967	\N	2026-07-13 20:39:54.277967	\N	GET	status=200, durationMs=91, userAgent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	0:0:0:0:0:0:0:1	/api/admin/system/health	SUCCESS	2026-07-13 20:39:54.277967	ishimwedivin2@gmail.com
\.


--
-- Data for Name: banners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.banners (id, created_at, created_by, updated_at, updated_by, active, button_text, display_order, image_url, link_url, product_id, subtitle, tag_label, title) FROM stdin;
\.


--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_items (id, created_at, created_by, updated_at, updated_by, quantity, cart_id, product_id) FROM stdin;
\.


--
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carts (id, created_at, created_by, updated_at, updated_by, user_id) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, created_at, created_by, updated_at, updated_by, description, name, parent_id) FROM stdin;
a298c1b3-fe6f-4a3f-97bd-0aa67a3c369a	2026-07-13 20:31:26.114378	\N	2026-07-13 20:31:26.114378	\N	Routers, switches, access points and network equipment	Networking	\N
23e002f4-1242-48b0-8ab1-f47e67b9aca0	2026-07-13 20:31:26.114378	\N	2026-07-13 20:31:26.114378	\N	Notebooks and portable computers	Laptops	\N
da818193-a7c0-4a1f-9cf0-88f88247b2b0	2026-07-13 20:31:26.128068	\N	2026-07-13 20:31:26.128068	\N	Desktop computers and all-in-one systems	Desktops & PCs	\N
fcc08616-173a-4bcc-8f09-2cb302ab1fdb	2026-07-13 20:31:26.128068	\N	2026-07-13 20:31:26.128068	\N	Computer monitors and display screens	Monitors	\N
b1d18977-b6d9-40e3-a165-2832a3db47de	2026-07-13 20:31:26.128068	\N	2026-07-13 20:31:26.128068	\N	Printers, scanners and multifunction devices	Printers & Scanners	\N
740ff1ac-4d2b-4628-b314-8490bf4a2269	2026-07-13 20:31:26.143971	\N	2026-07-13 20:31:26.143971	\N	Hard drives, SSDs and external storage	Storage	\N
d7e10ef8-aa07-4922-a5ae-9f0b80dea7ba	2026-07-13 20:31:26.146527	\N	2026-07-13 20:31:26.146527	\N	CPUs, RAM, GPUs and PC components	Components	\N
efa7d2ea-de70-441a-9c31-71f188de771a	2026-07-13 20:31:26.146527	\N	2026-07-13 20:31:26.146527	\N	Keyboards, mice, headsets and peripherals	Accessories	\N
12ba23a9-376e-498a-a060-c69bc32d2486	2026-07-13 20:31:26.146527	\N	2026-07-13 20:31:26.146527	\N	Server hardware and rack equipment	Servers	\N
9f8cebca-70ac-4592-a333-1ebc6cebd9ec	2026-07-13 20:31:26.159626	\N	2026-07-13 20:31:26.159626	\N	Smart devices, cameras and IoT equipment	Smart Home & IoT	\N
5c43f8cd-7892-4f9d-809d-67f380990110	2026-07-13 20:36:03.150011	\N	2026-07-13 20:36:03.15044	\N		Router	\N
\.


--
-- Data for Name: cells; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cells (id, enabled, name, sector_id) FROM stdin;
ca44860c-fe25-405f-8065-992a58dd6489	t	Kinyaga	0a01c67c-79a6-4e1f-b613-b959c0a28eaa
f96eb74a-336d-4301-b29c-81ffae09729b	t	Musave	0a01c67c-79a6-4e1f-b613-b959c0a28eaa
cc8970f6-b373-4bd9-b9af-476c7dca60e0	t	Mvuzo	0a01c67c-79a6-4e1f-b613-b959c0a28eaa
8d174020-c8e0-41bf-8323-e6f35cebfb3a	t	Ngara	0a01c67c-79a6-4e1f-b613-b959c0a28eaa
2567f7db-d121-4516-a33f-3b4ba4ded5de	t	Nkuzuzu	0a01c67c-79a6-4e1f-b613-b959c0a28eaa
f1df1f42-6f02-4436-8833-69fbbb3a5c1e	t	Nyabikenke	0a01c67c-79a6-4e1f-b613-b959c0a28eaa
f58b81fb-2e46-4b29-a977-f48ed18a1410	t	Nyagasozi	0a01c67c-79a6-4e1f-b613-b959c0a28eaa
110eb0bd-1144-4f29-a2bd-e536bb5a8693	t	Karuruma	46edd343-b0ed-4378-8f21-22fa3b301e0e
f70e2931-2f2e-40fa-9381-0968c470561a	t	Nyamabuye	46edd343-b0ed-4378-8f21-22fa3b301e0e
20e8f80a-ac72-4438-bbf6-58ea6d6f1201	t	Nyamugari	46edd343-b0ed-4378-8f21-22fa3b301e0e
a22b6540-9de0-4b32-9c57-5a4d6fbff460	t	Gasagara	a5f9264d-6549-486b-b3d7-525e4553c91a
439f0a77-91e5-4c96-b699-709f125827d0	t	Gicaca	a5f9264d-6549-486b-b3d7-525e4553c91a
40aae848-8dd8-4b20-a688-1a519bb71382	t	Kibara	a5f9264d-6549-486b-b3d7-525e4553c91a
f5d0d715-c214-4e81-ad93-058790b75ae6	t	Munini	a5f9264d-6549-486b-b3d7-525e4553c91a
c2c22331-4623-4507-870e-0806ff871a64	t	Murambi	a5f9264d-6549-486b-b3d7-525e4553c91a
8bf23434-6812-459e-9ee9-5b87445bced3	t	Musezero	fb3a3004-29da-48b2-81f7-7ff489fda9be
d9dd88cd-f19a-427a-ada2-fe8d6dc603e3	t	Ruhango	fb3a3004-29da-48b2-81f7-7ff489fda9be
a4ccd460-c75e-488c-be3a-44c4afc3eff9	t	Akamatamu	86beaf47-4afe-4ef7-8d70-6859a4a01f6e
35d338ce-9b0e-41ba-be87-790a26f51115	t	Bweramvura	86beaf47-4afe-4ef7-8d70-6859a4a01f6e
a6874be7-2b98-41e3-ae83-47e857879530	t	Kabuye	86beaf47-4afe-4ef7-8d70-6859a4a01f6e
4556cec7-239c-45eb-a49e-8faad6b18533	t	Kidashya	86beaf47-4afe-4ef7-8d70-6859a4a01f6e
374583ef-89b6-441c-9700-58ea8cc035d5	t	Ngiryi	86beaf47-4afe-4ef7-8d70-6859a4a01f6e
bc0028fa-3773-4b09-9636-e863b39cffd7	t	Agateko	e038b050-139c-4942-bc38-02031f6d7485
30302e5a-3d8d-4bf1-a985-b83a21b35f7f	t	Buhiza	e038b050-139c-4942-bc38-02031f6d7485
439c14f8-a353-4fb3-a659-a4e52289445b	t	Muko	e038b050-139c-4942-bc38-02031f6d7485
56431de6-c761-4f0e-bb3f-0c02a1ee1245	t	Nkusi	e038b050-139c-4942-bc38-02031f6d7485
6c03c460-44d7-479e-a903-274f04e84121	t	Nyabuliba	e038b050-139c-4942-bc38-02031f6d7485
e72e4726-7fd2-41f0-b856-45d93a61d1aa	t	Nyakabungo	e038b050-139c-4942-bc38-02031f6d7485
8635fd03-0563-4601-b550-05ecf747ec59	t	Nyamitanga	e038b050-139c-4942-bc38-02031f6d7485
4810bbb7-29f2-4d9c-a625-27a958b73e6c	t	Kamatamu	d4418fab-308b-4a3d-8e5d-0de1f2e5ea6f
29f3b4e1-dcca-409c-bd08-7c48465a1fa4	t	Kamutwa	d4418fab-308b-4a3d-8e5d-0de1f2e5ea6f
497d4cf1-0de8-4574-afd9-c875d25c3860	t	Kibaza	d4418fab-308b-4a3d-8e5d-0de1f2e5ea6f
5b9e8df2-d771-4a00-8ece-73f25d905f18	t	Kamukina	7f2423ee-15cd-4e71-8d53-9000a6b484bb
859046a6-0bc5-4d33-b6fc-e85bcb8c9d7d	t	Kimihurura	7f2423ee-15cd-4e71-8d53-9000a6b484bb
04a1de20-a2a8-4b62-a818-2b2b75add013	t	Rugando	7f2423ee-15cd-4e71-8d53-9000a6b484bb
62e7f31f-e34e-4595-9375-a90e0a2cbc5e	t	Bibare	e8316911-3b59-47d5-bc45-f105b8bddf79
19897d72-9104-4174-8115-948a94b94849	t	Kibagabaga	e8316911-3b59-47d5-bc45-f105b8bddf79
78a13b66-c34d-45db-9aa8-2e0efbc4f75b	t	Nyagatovu	e8316911-3b59-47d5-bc45-f105b8bddf79
39241f3f-54ba-4f89-ade8-677e002da6ce	t	Gacuriro	696f0053-5267-4519-85f1-039a4e86b9f0
9cc8abdd-4a50-4f6e-ba2f-156a4221a172	t	Gasharu	696f0053-5267-4519-85f1-039a4e86b9f0
aa8b2480-d27f-4071-8185-1882f7067b0c	t	Kagugu	696f0053-5267-4519-85f1-039a4e86b9f0
65a4d6b1-1681-4cb3-be3f-cd9ef4f9c927	t	Murama	696f0053-5267-4519-85f1-039a4e86b9f0
5f8dbda1-d6af-45ad-a194-a27bcd1c0f26	t	Bwiza	056b7138-83dd-40de-b68f-c2e57127c7b9
46adcc7b-3011-445d-8fb0-889c15ed8284	t	Cyaruzinge	056b7138-83dd-40de-b68f-c2e57127c7b9
fed05088-2c1b-43f4-9eb6-776246f06150	t	Kibenga	056b7138-83dd-40de-b68f-c2e57127c7b9
280f4a22-137f-4773-8dac-680282411da0	t	Masoro	056b7138-83dd-40de-b68f-c2e57127c7b9
e90b6a67-3b90-409d-a24e-91b467d3b698	t	Mukuyu	056b7138-83dd-40de-b68f-c2e57127c7b9
93b50513-f3f8-4f12-a6bc-d12eb154ee86	t	Rudashya	056b7138-83dd-40de-b68f-c2e57127c7b9
f6f1f309-e671-40ee-b5b3-7e9691ef4d4a	t	Butare	f6364dce-8346-4f60-9891-7eeb0fdecd24
861aaf4f-9746-4dfe-be63-14d0e5275f47	t	Gasanze	f6364dce-8346-4f60-9891-7eeb0fdecd24
10d1229d-3d92-42da-ade9-4fce6c7a0903	t	Gasura	f6364dce-8346-4f60-9891-7eeb0fdecd24
b5a337ce-b2c5-409d-b748-632ce74c50b6	t	Gatunga	f6364dce-8346-4f60-9891-7eeb0fdecd24
fab27b58-d78e-4756-9df8-1599a7ddd1a8	t	Muremure	f6364dce-8346-4f60-9891-7eeb0fdecd24
3f27e1a1-fe5d-45f8-b7a5-09e0caee2866	t	Sha	f6364dce-8346-4f60-9891-7eeb0fdecd24
82f4fb2e-abd4-4409-9e53-4789ddc99687	t	Shango	f6364dce-8346-4f60-9891-7eeb0fdecd24
0965d705-f129-45bf-9377-dbab02b986ea	t	Nyabisindu	0d66bb51-af25-4590-b407-677477455237
cbf6f0be-44b8-4db1-9e54-c66f201dc002	t	Nyarutarama	0d66bb51-af25-4590-b407-677477455237
541c433c-f62c-45cf-9cb6-0fd0751826d2	t	Rukiri I	0d66bb51-af25-4590-b407-677477455237
af73e10f-0dd7-4bf2-9275-73cf03c9371f	t	Rukiri II	0d66bb51-af25-4590-b407-677477455237
17d3d9af-40db-4ec4-bad0-61101c1e4ed3	t	Bisenga	0d99660e-b9e4-4d71-8371-e01cbcb6f99f
1ddb5dfe-32f3-4493-beea-c2d38d0448eb	t	Gasagara	0d99660e-b9e4-4d71-8371-e01cbcb6f99f
09eff11b-f56f-4466-9de8-9a863d4006c2	t	Kabuga I	0d99660e-b9e4-4d71-8371-e01cbcb6f99f
4c792132-700e-47b9-9ed8-12d8fbd949b1	t	Kabuga II	0d99660e-b9e4-4d71-8371-e01cbcb6f99f
1f85d947-5b6c-43a8-a70e-2279ad869422	t	Kinyana	0d99660e-b9e4-4d71-8371-e01cbcb6f99f
accf61af-3eaf-41a3-a0cb-52c1cf2c13d8	t	Mbandazi	0d99660e-b9e4-4d71-8371-e01cbcb6f99f
8aff94b0-e5d1-4535-b27c-c9572afaca22	t	Nyagahinga	0d99660e-b9e4-4d71-8371-e01cbcb6f99f
14b4580b-b674-4fc2-92d5-9d856e1dd61a	t	Ruhanga	0d99660e-b9e4-4d71-8371-e01cbcb6f99f
626a5fd0-2d1b-4aff-a386-546b45dcc4ca	t	Gasabo	cafc6a44-96e8-479e-a262-980c4be228d1
5748c81d-fed8-4335-babe-ec7c1923c5d0	t	Indatemwa	cafc6a44-96e8-479e-a262-980c4be228d1
46a983a0-f8e0-42d0-b10c-142ae3516fe4	t	Kabaliza	cafc6a44-96e8-479e-a262-980c4be228d1
a1df1363-df9a-4f34-b1a2-a1505c671be0	t	Kacyatwa	cafc6a44-96e8-479e-a262-980c4be228d1
2bbc125e-c287-4209-822c-7807632f98d0	t	Kibenga	cafc6a44-96e8-479e-a262-980c4be228d1
13d65481-9011-425e-94f4-e9ffc9ce3738	t	Kigabiro	cafc6a44-96e8-479e-a262-980c4be228d1
7b3f273d-de89-4ee4-a794-470fa497abc9	t	Gahanga	463b76a8-b47a-4150-8bf8-55514590bf24
cda083a8-c40d-4cd1-b7b8-cc60fc98e4ae	t	Kagasa	463b76a8-b47a-4150-8bf8-55514590bf24
de6795ae-be79-449d-8efc-fd5c0c557641	t	Karembure	463b76a8-b47a-4150-8bf8-55514590bf24
c96d6cca-f88b-4d8a-bb57-d54ad9771b37	t	Murinja	463b76a8-b47a-4150-8bf8-55514590bf24
cc95bbe5-1172-4850-a614-0a12ec504acb	t	Nunga	463b76a8-b47a-4150-8bf8-55514590bf24
8c9817ab-49f1-4b6d-993c-23005052b147	t	Rwabutenge	463b76a8-b47a-4150-8bf8-55514590bf24
dc215096-c8cd-4e47-8c1d-954d7d015aaf	t	Gatenga	2fc73e48-56c6-4602-91bf-bd03282a5103
16d010c2-af73-404e-b790-78370604ffb2	t	Karambo	2fc73e48-56c6-4602-91bf-bd03282a5103
77410805-c85a-4a40-81e7-3fe8163acde6	t	Nyanza	2fc73e48-56c6-4602-91bf-bd03282a5103
5867fdb6-d64d-44ca-86fa-fd942551b4f9	t	Nyarurama	2fc73e48-56c6-4602-91bf-bd03282a5103
d99a8e06-98d5-49d0-83a7-4ed2e921e768	t	Kagunga	d695f8cf-e75d-4c62-867f-01098492c16d
580e2d20-e905-4019-84fc-cd494e9abfeb	t	Kanserege	d695f8cf-e75d-4c62-867f-01098492c16d
67da26b0-5214-43bf-85ee-aafb66c1fb56	t	Kinunga	d695f8cf-e75d-4c62-867f-01098492c16d
face7c94-4223-407e-af5b-a54f615f0d0f	t	Kanserege	54c6a1d5-656d-4bbd-8be8-3695e6ee1f68
7f3133f0-15a1-4922-b43f-4e6b305576d3	t	Muyange	54c6a1d5-656d-4bbd-8be8-3695e6ee1f68
0261596c-e4b9-4dd8-ae36-70c93bde9632	t	Rukatsa	54c6a1d5-656d-4bbd-8be8-3695e6ee1f68
e7672eea-69dd-4efd-b832-63d80a6c2a38	t	Busanza	d3b6a9e9-7881-4ab0-8115-5f8c2ba8cc46
4246847c-8c6d-4b60-a32a-3161cdbf55a2	t	Kabeza	d3b6a9e9-7881-4ab0-8115-5f8c2ba8cc46
b242525d-1f72-452c-8515-2d898981fc67	t	Karama	d3b6a9e9-7881-4ab0-8115-5f8c2ba8cc46
fd388ed9-b0ee-4508-8376-eac69f19a5c4	t	Rubirizi	d3b6a9e9-7881-4ab0-8115-5f8c2ba8cc46
b39143f3-da6c-401c-afff-cec94c810c1f	t	Gasharu	92098a18-31b9-4685-b312-8b609e88f3e1
ce4e6dd7-412f-4820-bd01-0f1870fe9262	t	Kagina	92098a18-31b9-4685-b312-8b609e88f3e1
6593c3d6-fbeb-4851-b3c7-47c2246a6a33	t	Kicukiro	92098a18-31b9-4685-b312-8b609e88f3e1
d875650b-a248-4f5a-864f-b90da68b3739	t	Ngoma	92098a18-31b9-4685-b312-8b609e88f3e1
d4abc68d-5d54-4068-a76e-5706e18d9faa	t	Bwerankori	b537b3f9-5bb8-43ad-bc09-9b37b7d91bfb
66781237-f052-4422-856b-a83724abdedb	t	Karugira	b537b3f9-5bb8-43ad-bc09-9b37b7d91bfb
acac8cdb-3da1-447d-a8e6-5f8a72cb57a8	t	Kigarama	b537b3f9-5bb8-43ad-bc09-9b37b7d91bfb
da74eb7a-da52-4515-8389-0d9715619e40	t	Nyarurama	b537b3f9-5bb8-43ad-bc09-9b37b7d91bfb
524ded00-f69a-4eea-920c-d859bca1f621	t	Rwampara	b537b3f9-5bb8-43ad-bc09-9b37b7d91bfb
0b1cded7-1ce5-46cf-8115-0412826cf7f0	t	Ayabaraya	bc63d289-0931-4774-9e79-5289e1d7a400
ea4cf5fd-c64c-48c0-bc5e-47818cc4e108	t	Cyimo	bc63d289-0931-4774-9e79-5289e1d7a400
0619e879-1447-4fd5-b64f-025916638c9b	t	Gako	bc63d289-0931-4774-9e79-5289e1d7a400
28c81d10-915c-4021-907d-493c197da71f	t	Gitaraga	bc63d289-0931-4774-9e79-5289e1d7a400
205fe746-f046-4710-9c33-84be55a4a404	t	Mbabe	bc63d289-0931-4774-9e79-5289e1d7a400
52f1fee4-20fe-4776-a505-fc3e72455259	t	Rusheshe	bc63d289-0931-4774-9e79-5289e1d7a400
8da92b40-5d48-45b7-99e3-12fc8e22ee6f	t	Gatare	905d0f84-b829-4147-9d77-0a2b42161f2b
5daa8c47-5ef5-4797-9fa0-23960d441f4d	t	Niboye	905d0f84-b829-4147-9d77-0a2b42161f2b
3e68c135-9438-4866-8c84-8df1e5b4b373	t	Nyakabanda	905d0f84-b829-4147-9d77-0a2b42161f2b
1246e749-20e8-4ef9-83ed-da3e8ff8eb81	t	Kamashashi	44587844-75e9-4940-9581-7f2e57c09ce3
7daa0499-e03f-4e82-9d6e-f84b9bb2468d	t	Nonko	44587844-75e9-4940-9581-7f2e57c09ce3
6218d840-469d-4dd2-81b5-2e1d0e1284e7	t	Rwimbogo	44587844-75e9-4940-9581-7f2e57c09ce3
5fde4068-e18d-411e-ac8d-576a8dcd8b66	t	Akabahizi	b35070ee-8b2f-44f7-96d1-8267d667db37
ca4aca4c-a74a-4879-98cd-b12d9c25828f	t	Akabeza	b35070ee-8b2f-44f7-96d1-8267d667db37
9a23aaa7-e1ec-4109-940b-62b477cf772e	t	Gacyamo	b35070ee-8b2f-44f7-96d1-8267d667db37
56b2677a-05b3-4ce9-80ee-4096e2e730f3	t	Kigarama	b35070ee-8b2f-44f7-96d1-8267d667db37
6287c9b9-dc76-40d0-8f9a-9b593fb99445	t	Kinyange	b35070ee-8b2f-44f7-96d1-8267d667db37
d5ece781-f245-4303-a9e7-961d82fdeeed	t	Kora	b35070ee-8b2f-44f7-96d1-8267d667db37
e8bb001d-c935-485e-b2ee-357b300b0f54	t	Nyamweru	fce63fef-f05b-427c-ba0c-614d7aba9bf6
b475d9d1-10ef-466e-bb56-5dc221009d43	t	Nzove	fce63fef-f05b-427c-ba0c-614d7aba9bf6
894299bb-2beb-49a8-b5a6-4fd4bbb6fc1b	t	Taba	fce63fef-f05b-427c-ba0c-614d7aba9bf6
8da563a1-d5c9-47ff-b33f-53821a136359	t	Kigali	f4a0ffe2-5bbe-488c-89f6-238f41af88cb
458f75cf-ddc9-4c6f-b3fe-a35129ddd0af	t	Mwendo	f4a0ffe2-5bbe-488c-89f6-238f41af88cb
8e2e6ebf-9353-47b1-ac84-97c294bef294	t	Nyabugogo	f4a0ffe2-5bbe-488c-89f6-238f41af88cb
c19bd981-69dc-49ef-a4e2-9e0263017d41	t	Ruriba	f4a0ffe2-5bbe-488c-89f6-238f41af88cb
69ad2b06-8f9e-4edf-9359-f0184b4eff6b	t	Rwesero	f4a0ffe2-5bbe-488c-89f6-238f41af88cb
c94c188e-2930-4138-9e33-16852612da72	t	Kamuhoza	fe6cac85-61e9-4a2d-ae2e-96df1b32fae8
b7819e46-f1a1-4c0d-9fef-51367161f825	t	Katabaro	fe6cac85-61e9-4a2d-ae2e-96df1b32fae8
70e9dd1c-4da5-4161-97df-2615ce84cb2c	t	Kimisagara	fe6cac85-61e9-4a2d-ae2e-96df1b32fae8
f67dde5d-0ad1-471e-8dba-e37cb006798d	t	Kankuba	21c19b30-7a64-4fb7-9522-9a9bfee41143
3a20595b-086c-46e6-903d-519f2e5e6c24	t	Kavumu	21c19b30-7a64-4fb7-9522-9a9bfee41143
cd3f776e-38c9-4afa-ad94-b04eb568bc47	t	Mataba	21c19b30-7a64-4fb7-9522-9a9bfee41143
05befc31-d3c3-4183-a1d3-cd85759b24c7	t	Ntungamo	21c19b30-7a64-4fb7-9522-9a9bfee41143
52923e99-df7d-48e1-ab39-a1dcf687e9e1	t	Nyarufunzo	21c19b30-7a64-4fb7-9522-9a9bfee41143
0afe7964-795a-4b8d-bc39-1c8b6de6ee5b	t	Nyarurenzi	21c19b30-7a64-4fb7-9522-9a9bfee41143
c92ad023-972a-44e4-b045-11c2984ae341	t	Runzenze	21c19b30-7a64-4fb7-9522-9a9bfee41143
6cdafca0-8756-4d8b-a92f-db1eab51d990	t	Amahoro	1695dc25-13c8-40cf-9065-0f2f47859406
a760cb3d-22cd-40fa-91a1-926621988b5b	t	Kabasengerezi	1695dc25-13c8-40cf-9065-0f2f47859406
a38f321d-84b0-4781-85f2-646b86ade175	t	Kabeza	1695dc25-13c8-40cf-9065-0f2f47859406
0fb04d34-6e22-4630-b927-2da07b41753e	t	Nyabugogo	1695dc25-13c8-40cf-9065-0f2f47859406
f7a93c8e-745b-4a57-9b80-507e99dae65e	t	Rugenge	1695dc25-13c8-40cf-9065-0f2f47859406
32068352-ccc5-4f94-b6f9-a229ed9e3212	t	Tetero	1695dc25-13c8-40cf-9065-0f2f47859406
cc502a30-1580-40b6-8a65-9f76532bb844	t	Ubumwe	1695dc25-13c8-40cf-9065-0f2f47859406
4dea5cba-d0d8-4d28-a51f-fc6575353a0e	t	Munanira I	68a376c7-4361-4647-a010-bfc953c4792a
551b444b-8996-4582-bbde-b0f7953a1489	t	Munanira II	68a376c7-4361-4647-a010-bfc953c4792a
5b004d3e-5fd6-403a-9441-7efa168b2e79	t	Nyakabanda I	68a376c7-4361-4647-a010-bfc953c4792a
1441c0d9-6d1d-4050-af08-291100bcca1a	t	Nyakabanda II	68a376c7-4361-4647-a010-bfc953c4792a
05e59d37-6dce-4cea-acfc-e567455f5114	t	Cyivugiza	382b2b54-f769-4797-9ce6-a0dc01efabfb
2f027b2b-e9c9-4ad8-8fce-7f83a75ad3fb	t	Gasharu	382b2b54-f769-4797-9ce6-a0dc01efabfb
b1904295-b3b2-481d-86d9-b56a9b455c13	t	Mumena	382b2b54-f769-4797-9ce6-a0dc01efabfb
335d18f9-c3e0-4e6b-8e57-6ae37689f802	t	Rugarama	382b2b54-f769-4797-9ce6-a0dc01efabfb
2ee7d76a-b4f4-442a-9fa5-08c68402d6c1	t	Agatare	7c08603e-9442-4982-a8cd-ffa014a28aed
ef3c1bc4-785a-4d78-9c20-aca951b99dfc	t	Biryogo	7c08603e-9442-4982-a8cd-ffa014a28aed
364702d6-a274-4729-a48f-63d6179952fc	t	Kiyovu	7c08603e-9442-4982-a8cd-ffa014a28aed
8c7f972e-2d62-4f31-909d-8dfe4de785c2	t	Rwampara	7c08603e-9442-4982-a8cd-ffa014a28aed
0ddc1081-30dc-4893-9168-07e283f9bd91	t	Kabuguru I	55ef0dd7-13f9-464d-98ba-03867acfcdc0
2db3cb56-5681-4df6-8938-2d2a0b970b06	t	Kabuguru II	55ef0dd7-13f9-464d-98ba-03867acfcdc0
e650c442-8a90-4d33-853d-a2ada1c2d682	t	Rwezamenyo I	55ef0dd7-13f9-464d-98ba-03867acfcdc0
42d82f52-683f-4fae-8d8c-bdd18e5c0389	t	Rwezamenyo II	55ef0dd7-13f9-464d-98ba-03867acfcdc0
2430cb83-ebad-44f6-ae2c-8e97ff9f00ea	t	Cyiri	0388e717-d8d7-430b-9740-5c96eea98be4
bb83c731-3a50-4792-bf8a-0050bd820aad	t	Gasagara	0388e717-d8d7-430b-9740-5c96eea98be4
33679b9c-4172-487c-a256-72264e62eb1b	t	Gikonko	0388e717-d8d7-430b-9740-5c96eea98be4
d14d3324-07c9-49ca-90b3-803f4b945ae3	t	Mbogo	0388e717-d8d7-430b-9740-5c96eea98be4
4ff7ee6e-2184-481f-ad45-77ba83c1f351	t	Gabiro	173351f7-bd8a-40e1-8ccf-a43ded755495
7d99a7ff-9591-4f13-9567-1c41fc494785	t	Nyabitare	173351f7-bd8a-40e1-8ccf-a43ded755495
54d7f36f-8839-47aa-965b-9ab92e7454e6	t	Nyakibungo	173351f7-bd8a-40e1-8ccf-a43ded755495
c88af425-c76d-461e-906c-4e5616ea1e58	t	Nyeranzi	173351f7-bd8a-40e1-8ccf-a43ded755495
e6f0e394-9d08-40a2-8a08-fa41863b854a	t	Akaboti	2a1735bd-d3b0-4365-977c-0429f08639b3
219f07f2-c437-4265-a703-d2bfd980a7f8	t	Bwiza	2a1735bd-d3b0-4365-977c-0429f08639b3
dab3a1b5-f8d4-41fc-b0ad-276c81cb1d8f	t	Sabusaro	2a1735bd-d3b0-4365-977c-0429f08639b3
e5e8b296-8af5-47e1-865f-f9259e821f1a	t	Duwani	1e81c6d2-0300-4dee-a708-b34f99d7ff4a
54000954-8f1c-470f-bd8a-79dc75bdae15	t	Kibirizi	1e81c6d2-0300-4dee-a708-b34f99d7ff4a
39226421-cdd2-4db3-b92c-a3d90af9a2d0	t	Muyira	1e81c6d2-0300-4dee-a708-b34f99d7ff4a
bea039ff-4d67-4723-bad4-30b83f1abcc6	t	Ruturo	1e81c6d2-0300-4dee-a708-b34f99d7ff4a
0775ee9d-8e5c-4b56-a87b-74a5efb00ce4	t	Agahabwa	fee2b6f7-71b4-4f55-8ca9-95a3dac5419f
d416a3b0-824b-48ab-8e1b-515d7996fbd3	t	Gatovu	fee2b6f7-71b4-4f55-8ca9-95a3dac5419f
342a2b36-9f05-4b87-8b89-2b4a1e827422	t	Impinga	fee2b6f7-71b4-4f55-8ca9-95a3dac5419f
54c4e7c6-8cdf-4845-989b-27c457865d51	t	Nyabikenke	fee2b6f7-71b4-4f55-8ca9-95a3dac5419f
614a5c90-a00e-4040-9935-898cc0cc1a69	t	Rubona	fee2b6f7-71b4-4f55-8ca9-95a3dac5419f
c37c9dad-c446-4027-b6fc-a0e165f842aa	t	Rusagara	fee2b6f7-71b4-4f55-8ca9-95a3dac5419f
16af960d-aab6-4757-9bef-488b790ae7b7	t	Gakoma	dbab57fc-6c0e-401f-b811-cc2f6117ca39
adb767b3-e5b7-42a6-ad8f-f97bbfb37934	t	Kabumbwe	dbab57fc-6c0e-401f-b811-cc2f6117ca39
5988a320-4321-4c6f-967a-32e05d2718a8	t	Mamba	dbab57fc-6c0e-401f-b811-cc2f6117ca39
59a29314-53ba-4f12-bc2f-8ba4e02821da	t	Muyaga	dbab57fc-6c0e-401f-b811-cc2f6117ca39
b83e14d5-0c4a-439a-adba-3db8988dbd2e	t	Ramba	dbab57fc-6c0e-401f-b811-cc2f6117ca39
2f0b4293-20b5-4425-8382-66c24fcf3a18	t	Cyumba	c6d80118-a045-42b9-932a-1875a0ba71c1
60ea014a-c44b-4d20-a202-dca9d3b61dbe	t	Muganza	c6d80118-a045-42b9-932a-1875a0ba71c1
0d9c0168-060c-4c68-a83d-02a89b4daf1a	t	Remera	c6d80118-a045-42b9-932a-1875a0ba71c1
b10b0e33-5b80-48f6-b058-ee6ec10acc83	t	Rwamiko	c6d80118-a045-42b9-932a-1875a0ba71c1
55117b1b-b6ac-485c-be03-3373a1d97f04	t	Saga	c6d80118-a045-42b9-932a-1875a0ba71c1
0362ffce-7a6e-4578-980c-2425c30a1576	t	Baziro	1cc29f55-8cbd-4c61-8ddf-66ba642b222a
6d661922-3d8f-489f-97b9-1c573eb14bbe	t	Kibayi	1cc29f55-8cbd-4c61-8ddf-66ba642b222a
bf63e9e9-1d5b-457e-a661-a9344a6154dd	t	Kibu	1cc29f55-8cbd-4c61-8ddf-66ba642b222a
9dbb0c47-5fec-4325-bc27-c160914f343b	t	Mugombwa	1cc29f55-8cbd-4c61-8ddf-66ba642b222a
938e7bd6-2b9d-4ec1-8bf4-d2183c0225b8	t	Mukomacara	1cc29f55-8cbd-4c61-8ddf-66ba642b222a
dfedea52-4c26-4c06-b6cc-8e6e8605a79e	t	Gitega	832e97ce-7d2d-42ab-b662-bbd3186223cd
e0e2695a-5380-4dab-8c79-5e0dd4bd35a3	t	Mukiza	832e97ce-7d2d-42ab-b662-bbd3186223cd
5b0d0286-4abc-4ea7-bff6-2719ee991c51	t	Nyabisagara	832e97ce-7d2d-42ab-b662-bbd3186223cd
6010cbb4-eeac-4636-ab83-7fc0ceaa548b	t	Runyinya	832e97ce-7d2d-42ab-b662-bbd3186223cd
4667107a-58ed-4fbe-98d2-e60d04a74b51	t	Bukinanyana	92a426b1-93fc-4c2f-99c4-fe5d163ef3b7
83c85f59-069d-43be-b6a1-2e386ac671d8	t	Gatovu	92a426b1-93fc-4c2f-99c4-fe5d163ef3b7
997c7fe5-aa07-4fb0-99c8-78242731ddb2	t	Kigarama	92a426b1-93fc-4c2f-99c4-fe5d163ef3b7
9b5e551d-fc4b-49eb-bcac-6ac55858ea00	t	Kimana	92a426b1-93fc-4c2f-99c4-fe5d163ef3b7
de6fd126-fe8d-4e79-8337-553eb1bb5df5	t	Bweya	e3c32754-1f94-4f3a-9a79-b68713120efb
7d67fc0c-756d-4687-bbce-c8770ff454c1	t	Cyamukuza	e3c32754-1f94-4f3a-9a79-b68713120efb
0ed33221-2f3b-4743-bc0f-07e57f2b156c	t	Dahwe	e3c32754-1f94-4f3a-9a79-b68713120efb
91c7f8a7-ea16-4303-b790-4522b331f516	t	Gisagara	e3c32754-1f94-4f3a-9a79-b68713120efb
d1b12fa3-f762-4639-a81e-4bf4aa3ea97d	t	Mukande	e3c32754-1f94-4f3a-9a79-b68713120efb
f67af2d5-2f8d-48a2-9eb6-17625877562d	t	Higiro	93fd566c-a728-46d2-a5e1-1f2ff93cfa54
66ee91c3-9f8f-4ef8-8693-82c5969178d4	t	Nyamugari	93fd566c-a728-46d2-a5e1-1f2ff93cfa54
a8ff98dd-ad24-4c4e-927e-54dfbb27bf86	t	Nyaruteja	93fd566c-a728-46d2-a5e1-1f2ff93cfa54
ed5b522b-502a-43e5-b32b-54923e0cb156	t	Umubanga	93fd566c-a728-46d2-a5e1-1f2ff93cfa54
12cc6a20-a0c8-4eae-aa44-1d4c36b56775	t	Gatoki	9f6dd92e-9268-4732-8a97-6beff211d63c
fb0da952-1dce-4ce7-9dcc-64b356c4a21f	t	Munazi	9f6dd92e-9268-4732-8a97-6beff211d63c
95e99b83-53ac-44be-8597-e03a61f33c74	t	Rwanza	9f6dd92e-9268-4732-8a97-6beff211d63c
6737e4d4-764d-4eb8-a8e1-c8ce3a83f7f3	t	Shyanda	9f6dd92e-9268-4732-8a97-6beff211d63c
206fcb8e-4756-484d-b9f5-d63e1d01e3b8	t	Zivu	9f6dd92e-9268-4732-8a97-6beff211d63c
8e5e8ab0-2c05-4405-b076-2e8cbafee808	t	Nyakibanda	8decb1c5-e7c5-4d71-9799-f1f33c6c5052
5d68a628-908b-4698-87c7-59f0a4f2c2b5	t	Nyumba	8decb1c5-e7c5-4d71-9799-f1f33c6c5052
e6e8ae56-cb90-452d-bf09-3a904b920067	t	Ryakibogo	8decb1c5-e7c5-4d71-9799-f1f33c6c5052
1611f9c5-9ebd-4f2e-9a9f-f134954f0c9e	t	Shori	8decb1c5-e7c5-4d71-9799-f1f33c6c5052
687d684c-7033-4a22-81d0-898db4968d38	t	Muyogoro	3bf7db48-2a6b-43c1-98c5-c42e7b597ecf
207bd739-7c5d-45ee-9381-ad12ca5bacdc	t	Nyakagezi	3bf7db48-2a6b-43c1-98c5-c42e7b597ecf
910dc1fb-85d8-4696-b1d1-9a53ff4a1efe	t	Rukira	3bf7db48-2a6b-43c1-98c5-c42e7b597ecf
e09d7748-edcc-4f94-9893-80cbe6159874	t	Sovu	3bf7db48-2a6b-43c1-98c5-c42e7b597ecf
52c48996-b32e-469e-859d-22f6c76d51ef	t	Buhoro	03ed83e7-4262-4dcb-a3e0-832ef23adcc8
ec92236a-6da5-448b-a179-cb5578cdd9b8	t	Bunazi	03ed83e7-4262-4dcb-a3e0-832ef23adcc8
af6cdfdb-7964-4fea-98da-0698f2259919	t	Gahororo	03ed83e7-4262-4dcb-a3e0-832ef23adcc8
997c515b-26bc-43b8-b116-03d68bf93c97	t	Kibingo	03ed83e7-4262-4dcb-a3e0-832ef23adcc8
55198202-8d7e-4919-a553-400d51cab894	t	Muhembe	03ed83e7-4262-4dcb-a3e0-832ef23adcc8
5a1e86cb-39bb-43bc-b324-7048015ef6a2	t	Gishihe	147901ff-7128-442a-a8bf-be1b3c76fb3b
945bb103-3143-4344-9830-617dd47237fc	t	Kabuga	147901ff-7128-442a-a8bf-be1b3c76fb3b
4e0fbf8a-0f68-4dca-bb56-60f4a2daae24	t	Karambi	147901ff-7128-442a-a8bf-be1b3c76fb3b
1f6c4bea-bb92-413c-9147-f29884eca132	t	Musebeya	147901ff-7128-442a-a8bf-be1b3c76fb3b
209df342-0185-4b14-9d04-59dab8516294	t	Nyabisindu	147901ff-7128-442a-a8bf-be1b3c76fb3b
80d395e2-2184-4465-a4c5-64a6330a7ce0	t	Rugarama	147901ff-7128-442a-a8bf-be1b3c76fb3b
a594fd7d-8bef-47b3-8962-b5b28c959686	t	Shanga	147901ff-7128-442a-a8bf-be1b3c76fb3b
55beaa67-772e-421f-bb73-64d1c42e09c4	t	Byinza	30dff643-a15d-4c96-8d0b-8b2b6be49885
39c33149-582d-4f4c-925a-8621dbdba71b	t	Gahana	30dff643-a15d-4c96-8d0b-8b2b6be49885
46d92fd8-f418-4074-ac1a-cfb6b4de4c27	t	Gitovu	30dff643-a15d-4c96-8d0b-8b2b6be49885
e911c381-49cd-432c-8eb8-524b815940e5	t	Kabona	30dff643-a15d-4c96-8d0b-8b2b6be49885
97c32539-dbe3-4584-9bcd-6f371e079d8c	t	Sazange	30dff643-a15d-4c96-8d0b-8b2b6be49885
fb75df0f-1b96-4dd8-b2c5-eea26ccff061	t	Shanga	1aa3017a-9d93-4da0-bdc4-fab703cc8535
2b7ace59-a955-44b6-bd14-f255224936ea	t	Shyembe	1aa3017a-9d93-4da0-bdc4-fab703cc8535
286ea5fb-342d-456c-b6b1-13e5d825bd76	t	Gatobotobo	ccd9089b-6b99-4830-a8e2-379b74185850
4383fd7b-edb7-4582-b01b-ce56818581e0	t	Kabuga	ccd9089b-6b99-4830-a8e2-379b74185850
998d2ac5-75de-43f9-93af-9a653323e7c7	t	Mutunda	ccd9089b-6b99-4830-a8e2-379b74185850
4c1b81e1-b7de-4665-b06c-c8bbc33d1478	t	Mwulire	ccd9089b-6b99-4830-a8e2-379b74185850
317bd051-332f-4432-9f13-2c579b0bca41	t	Rugango	ccd9089b-6b99-4830-a8e2-379b74185850
d8cb6e6a-0676-4a98-9226-cd06895a78f2	t	Rusagara	ccd9089b-6b99-4830-a8e2-379b74185850
372e6795-ab36-4670-8592-75eba2bab224	t	Tare	ccd9089b-6b99-4830-a8e2-379b74185850
118b1ecb-0a4f-4324-a602-0fd3b16bfd5a	t	Bukomeye	ee906b05-e5ea-4ec8-a17f-5b71f202a394
a706170c-982f-473d-abfd-6f4992c75375	t	Buvumu	ee906b05-e5ea-4ec8-a17f-5b71f202a394
04f80804-e2fa-4a77-b22d-654cbb31c11a	t	Icyeru	ee906b05-e5ea-4ec8-a17f-5b71f202a394
458557fe-b913-476c-b99e-c6c706ffa6f4	t	Rango A	ee906b05-e5ea-4ec8-a17f-5b71f202a394
40cb4b8c-fd3e-435f-b2af-da659b5d815b	t	Butare	506ac159-d250-4145-a6b6-864e04511b5f
ba8be250-d971-4e7a-8b07-1fafe0724199	t	Kaburemera	506ac159-d250-4145-a6b6-864e04511b5f
84370341-c761-43ad-a3c1-ca8e7a481cfd	t	Matyazo	506ac159-d250-4145-a6b6-864e04511b5f
a8fea5e2-e92c-4b5e-94e6-e81c4d254dca	t	Ngoma	506ac159-d250-4145-a6b6-864e04511b5f
905197c4-9fd6-4c2e-bcae-9e5e8b297abe	t	Gatovu	e2cede17-bdb0-459e-be35-bf3c33e7697f
f274108a-5e61-4cc7-a689-d475a5cee7ad	t	Karama	e2cede17-bdb0-459e-be35-bf3c33e7697f
51df8f17-ccf0-43b5-b15f-ad7d76a973d1	t	Mara	e2cede17-bdb0-459e-be35-bf3c33e7697f
18746d64-4f20-4694-bb39-107ea55e94bc	t	Muhororo	e2cede17-bdb0-459e-be35-bf3c33e7697f
13ad08f6-e814-4981-b908-643d6f14002f	t	Rugogwe	e2cede17-bdb0-459e-be35-bf3c33e7697f
19ee5c18-5d03-4a6c-816c-73244a72b81c	t	Ruhashya	e2cede17-bdb0-459e-be35-bf3c33e7697f
6bb94ac8-ca25-4997-8c41-76fbf7a5d5af	t	Buhimba	000f5dbb-a7fb-4440-bb35-0d710ba30402
58575571-08d2-40eb-8b32-e50b4df4828a	t	Gafumba	000f5dbb-a7fb-4440-bb35-0d710ba30402
db1bee31-63db-405a-9c97-94a3f0babe9e	t	Kimirehe	000f5dbb-a7fb-4440-bb35-0d710ba30402
6dd14e41-dbf9-4c00-9527-69895dae9ab9	t	Kimuna	000f5dbb-a7fb-4440-bb35-0d710ba30402
f5a4fab4-7cc0-44a6-989c-f0d0ca712128	t	Kiruhura	000f5dbb-a7fb-4440-bb35-0d710ba30402
d867a954-a944-4a05-9d72-ef36d107eece	t	Mugogwe	000f5dbb-a7fb-4440-bb35-0d710ba30402
74d38a17-0537-4bb6-a4de-62b24e0d8f26	t	Gatwaro	bcab62b5-d5a9-4081-814b-a814a14b5814
19a2fd84-6b3f-4b27-84b9-081e54fee885	t	Kamwambi	bcab62b5-d5a9-4081-814b-a814a14b5814
73cde831-69ad-45e3-b382-653957aee0b7	t	Kibiraro	bcab62b5-d5a9-4081-814b-a814a14b5814
eeae03d9-dd11-4e90-b1d9-4e1992802074	t	Mwendo	bcab62b5-d5a9-4081-814b-a814a14b5814
9808b312-dbe6-4532-b807-a0e6f62836ca	t	Nyamabuye	bcab62b5-d5a9-4081-814b-a814a14b5814
1eb98234-dc14-4def-8677-50b3a3203a26	t	Nyaruhombo	bcab62b5-d5a9-4081-814b-a814a14b5814
88b8b8b0-b278-4379-ba45-6b611f08bac8	t	Shyunga	bcab62b5-d5a9-4081-814b-a814a14b5814
8d9b6373-535a-4c52-a44b-d2804b9f1875	t	Cyendajuru	6e8e6a50-5878-47e5-971f-21a01973b5f4
2ed69990-6f83-4280-b141-6eb7a508c894	t	Kabusanza	6e8e6a50-5878-47e5-971f-21a01973b5f4
561cb518-1a77-428d-8cb1-cca72bde53aa	t	Mugobore	6e8e6a50-5878-47e5-971f-21a01973b5f4
4aa51065-6ccb-4117-b00f-6b9973eb12e6	t	Cyarwa	f9160dcf-e616-4322-929f-c08b2bcaddae
2b957380-9ca9-4df4-a622-5af04215a43f	t	Cyimana	f9160dcf-e616-4322-929f-c08b2bcaddae
ce8f4f18-3a6c-4542-8bdd-85d0c351dd70	t	Gitwa	f9160dcf-e616-4322-929f-c08b2bcaddae
07516222-36f4-4033-ac2c-0af933387bd6	t	Mpare	f9160dcf-e616-4322-929f-c08b2bcaddae
2eef0f48-3b86-4aa0-914d-0f242d19a1ad	t	Rango B	f9160dcf-e616-4322-929f-c08b2bcaddae
3f2e6c04-57fe-4ace-9dee-56b19c311fb9	t	Gihinga	e1ddb632-2743-4015-82a2-e7ad86185aeb
d7d7d651-418c-4517-a616-8cfd74ae0c87	t	Gihira	e1ddb632-2743-4015-82a2-e7ad86185aeb
e4fce17b-e805-4daf-ba9a-81c02e5693e5	t	Kigembe	e1ddb632-2743-4015-82a2-e7ad86185aeb
aa4e853b-878a-4a65-acdf-0cd7d8efcdb1	t	Nkingo	e1ddb632-2743-4015-82a2-e7ad86185aeb
2dc23136-17dd-4941-9ec1-40784381158d	t	Bitare	1e942e78-188b-43ea-af3b-9db80092362e
65a37abf-b4f4-413d-94df-b998e7adaddd	t	Bunyonga	1e942e78-188b-43ea-af3b-9db80092362e
e713e313-df8a-472b-a7cb-904d97dda34c	t	Muganza	1e942e78-188b-43ea-af3b-9db80092362e
2bf3dacf-e537-4582-9b8d-6d799eaf0077	t	Nyamirembe	1e942e78-188b-43ea-af3b-9db80092362e
8bfd0a30-3377-4e7f-b58d-d3141d684016	t	Bugarama	d78eb1ab-9316-412e-a902-e03dd21a6393
687ce23f-276a-4496-b13c-54af5170800e	t	Cubi	d78eb1ab-9316-412e-a902-e03dd21a6393
7d23eb68-bf1c-4b59-a065-69a053fa688c	t	Kirwa	d78eb1ab-9316-412e-a902-e03dd21a6393
19a19289-b38f-40af-9d87-9e69b61d6538	t	Mataba	d78eb1ab-9316-412e-a902-e03dd21a6393
83001b51-ad71-4302-a2a6-f1f4994f9383	t	Gaseke	45619d8b-bdd4-4ad2-8cf2-6f2371469cf0
3a53e06c-f319-4069-bfd5-ca6acea537c6	t	Giko	45619d8b-bdd4-4ad2-8cf2-6f2371469cf0
5c8751c5-b33c-450d-8f37-8f9e7b1cedb8	t	Muyange	45619d8b-bdd4-4ad2-8cf2-6f2371469cf0
97483b97-9f6b-45b3-baab-fdab58035dcc	t	Jenda	810f3764-a776-4a17-99ac-c23b05881981
7882126e-9359-4f8b-8804-4930fd0b62e3	t	Kabugondo	810f3764-a776-4a17-99ac-c23b05881981
d95f5e88-e85d-4bea-b832-41a43bbb2321	t	Mbati	810f3764-a776-4a17-99ac-c23b05881981
184f4780-eead-485b-8ec4-f7a421062f52	t	Mugina	810f3764-a776-4a17-99ac-c23b05881981
c54c7b84-ec1d-4205-ac11-16f50e220b86	t	Nteko	810f3764-a776-4a17-99ac-c23b05881981
09572e7f-8686-4705-a1fc-f756076c5582	t	Buhoro	8c4377c7-6574-4d0b-a4fa-99c89867519c
26621101-4538-43e6-af87-b98ffa272999	t	Cyambwe	8c4377c7-6574-4d0b-a4fa-99c89867519c
5fb15cf8-4094-4ad4-bc81-e49ebdd40e0e	t	Karengera	8c4377c7-6574-4d0b-a4fa-99c89867519c
3ff9d1ef-7381-4331-be6c-3e89e0fce7cb	t	Kivumu	8c4377c7-6574-4d0b-a4fa-99c89867519c
88d48a13-e8dd-4717-86f5-6763f6071fd6	t	Mpushi	8c4377c7-6574-4d0b-a4fa-99c89867519c
844fe150-3fbb-4994-8a08-2e1b57be0fea	t	Rukambura	8c4377c7-6574-4d0b-a4fa-99c89867519c
1fde8906-84d0-4382-9719-550461936c25	t	Kabuga	92c56d3d-f84b-4565-b738-a964486ad874
03ba493f-c611-4946-a53a-b73ccb55c9f8	t	Kazirabonde	92c56d3d-f84b-4565-b738-a964486ad874
fb8ab0b8-c0f9-454f-af95-5f876f1e9050	t	Marembo	92c56d3d-f84b-4565-b738-a964486ad874
11c7cdc3-2443-4348-8f7c-3954067a1f85	t	Bibungo	5c2599bd-04a2-4b83-b544-9e896ce401f2
e534c91f-0584-4bb8-b0d6-f42b64411bb7	t	Kabashumba	5c2599bd-04a2-4b83-b544-9e896ce401f2
a1b90152-a6c2-4060-bad0-f23c486c18d0	t	Kidahwe	5c2599bd-04a2-4b83-b544-9e896ce401f2
ce983105-e20d-47ae-af23-642c36ea0439	t	Mukinga	5c2599bd-04a2-4b83-b544-9e896ce401f2
f2f87bd6-1c3a-43de-b7d7-48d0bf47dd2f	t	Ngoma	5c2599bd-04a2-4b83-b544-9e896ce401f2
3d1e96dd-b4f1-42a2-ac21-fad6f7a74b4c	t	Gitare	124248c8-a5ef-40ae-86fb-7963144679c5
95aa2f0e-10e0-4d6d-a203-b6f4a94ba672	t	Kambyeyi	124248c8-a5ef-40ae-86fb-7963144679c5
d5449ce2-6811-4ecf-b459-c010f58995c2	t	Kigusa	124248c8-a5ef-40ae-86fb-7963144679c5
e408f673-b9d7-4ff6-9ac8-7cd97faa0afa	t	Nyagishubi	124248c8-a5ef-40ae-86fb-7963144679c5
0b9072a0-837c-41ec-8703-9d593698ba8e	t	Ruyanza	124248c8-a5ef-40ae-86fb-7963144679c5
8a7230a9-2df4-4770-a1df-5cb610b2a1be	t	Kigese	c837e9b2-fcf0-4bd4-86e2-d5235ff0991e
dc43b606-76f3-4d0f-84a5-0522f257c7bf	t	Masaka	c837e9b2-fcf0-4bd4-86e2-d5235ff0991e
31fc1286-ef4d-4ca6-87da-fcae8abc6979	t	Nyarubuye	c837e9b2-fcf0-4bd4-86e2-d5235ff0991e
da777c48-65e8-44a9-846e-1d0177b6309f	t	Sheli	c837e9b2-fcf0-4bd4-86e2-d5235ff0991e
445d3be4-30f8-47fe-a102-9748c00a5c41	t	Bugoba	6cc922a5-8a2b-4015-97f7-b51400fdf160
f6963b1b-7c8a-424c-8257-175ce7b28b26	t	Buguri	6cc922a5-8a2b-4015-97f7-b51400fdf160
4e2a2ffe-2463-48f8-837d-b753fd75eb6d	t	Gishyeshye	6cc922a5-8a2b-4015-97f7-b51400fdf160
cab991bd-4a40-44a2-9761-697df5901caa	t	Murehe	6cc922a5-8a2b-4015-97f7-b51400fdf160
281f4739-0030-49c4-b87b-01199473a908	t	Mwirute	6cc922a5-8a2b-4015-97f7-b51400fdf160
28d0f27c-60b3-43cf-8c1c-321ad023bd59	t	Remera	6cc922a5-8a2b-4015-97f7-b51400fdf160
00658efd-ffa9-410c-b126-4e401840c74e	t	Taba	6cc922a5-8a2b-4015-97f7-b51400fdf160
a8e4abc9-3b2d-4c5b-908b-94adac0e6d86	t	Gihara	bfcb5fa8-2c7c-4f05-a76d-0b3014225511
5e664266-d072-4730-85ac-d622ef110370	t	Kabagesera	bfcb5fa8-2c7c-4f05-a76d-0b3014225511
20dd6724-7d0b-4c06-8c2a-31529272e2cf	t	Kagina	bfcb5fa8-2c7c-4f05-a76d-0b3014225511
e8c6d8e4-d972-4087-a4d2-4acfaf9955a5	t	Muganza	bfcb5fa8-2c7c-4f05-a76d-0b3014225511
a34c9fc5-797c-46eb-a618-47c5a3282d97	t	Ruyenzi	bfcb5fa8-2c7c-4f05-a76d-0b3014225511
95b77d2e-0171-4203-9997-55bf284a60d4	t	Kigarama	df558d77-e1ef-4dcf-ac50-c25082fcb266
8c38ff83-875c-4326-8e2a-fa7b9694989e	t	Kivumu	df558d77-e1ef-4dcf-ac50-c25082fcb266
03cca771-ccc7-482a-8379-70cadbb850fd	t	Makera	df558d77-e1ef-4dcf-ac50-c25082fcb266
59bec503-ea3e-4087-80c8-099195c4f21a	t	Nyarunyinya	df558d77-e1ef-4dcf-ac50-c25082fcb266
a4fa5f0e-656c-476f-a8d6-c5ee63fc97c2	t	Buramba	8a255b7f-de97-4e14-a5e8-a131c56f68f3
61ced810-662e-4539-a3bc-3300be76c950	t	Butare	8a255b7f-de97-4e14-a5e8-a131c56f68f3
63b432ad-a3c3-4a3e-b42c-e357a7c68506	t	Kabuye	8a255b7f-de97-4e14-a5e8-a131c56f68f3
2c70fd7b-43a8-45b1-91a6-fcd5d7273230	t	Kavumu	8a255b7f-de97-4e14-a5e8-a131c56f68f3
ba9d20e8-d065-408d-be91-71c79cb29c77	t	Kibyimba	8a255b7f-de97-4e14-a5e8-a131c56f68f3
dec6aa0c-abfe-4fa8-9996-aa564e81f9f9	t	Ngarama	8a255b7f-de97-4e14-a5e8-a131c56f68f3
2c73c255-c2b0-4311-9519-e8e42ce6f024	t	Ngoma	8a255b7f-de97-4e14-a5e8-a131c56f68f3
5e6aa3a6-b7a3-4cde-905f-21398877d251	t	Budende	af7cf2cf-30aa-4006-ba78-30ee4cdabd82
a4193cb1-dee8-4b6e-9dec-352ab698312c	t	Remera	af7cf2cf-30aa-4006-ba78-30ee4cdabd82
7ad849ff-67c2-4316-9962-21480f337285	t	Ruhina	af7cf2cf-30aa-4006-ba78-30ee4cdabd82
809b1dbb-cde3-464d-987c-6475aa11e714	t	Rukeri	af7cf2cf-30aa-4006-ba78-30ee4cdabd82
2bcc094e-be15-485d-bb60-a79b631dffb1	t	Kanyinya	5da48229-5960-4cd4-ac4f-3f75891c8608
183afc7a-7fb8-436b-a3d9-f5eaa56ccb78	t	Nganzo	5da48229-5960-4cd4-ac4f-3f75891c8608
c201d97b-217f-4718-a0c1-73741004f881	t	Tyazo	5da48229-5960-4cd4-ac4f-3f75891c8608
e1797c34-9374-49ee-8c36-d7d92ce87c81	t	Matyazo	21f9b004-2024-4667-8723-cb34421b644d
936716f5-8708-4f3f-bf8e-6c6e95b95dc9	t	Munazi	21f9b004-2024-4667-8723-cb34421b644d
a43b5d09-1a58-46d8-89c2-38ecd9ef42e4	t	Nyagasozi	21f9b004-2024-4667-8723-cb34421b644d
d5887628-3ff8-4cd3-9b3d-41de198bd73b	t	Rukaragata	21f9b004-2024-4667-8723-cb34421b644d
e1b2e68f-a330-4022-b28b-745782257908	t	Rwasare	21f9b004-2024-4667-8723-cb34421b644d
3b8124f0-5a95-49db-91ff-a937e1ebfb0d	t	Rwigerero	21f9b004-2024-4667-8723-cb34421b644d
c71e7de2-dd62-4a8d-801a-35b8811b940e	t	Nyarusozi	f954ac85-b496-4a48-aa49-39221c0b430f
6a1e3211-9aef-42a8-86fe-3ac29cea24ac	t	Gahogo	1e7eeac4-1cdc-4a62-a43a-b326be6765aa
ebb6a7c4-66d0-4486-971f-01362692c4d4	t	Gifumba	1e7eeac4-1cdc-4a62-a43a-b326be6765aa
d91d5dc5-2b37-4013-a1ba-607521ced68f	t	Gitarama	1e7eeac4-1cdc-4a62-a43a-b326be6765aa
fd46b2aa-65aa-452a-a713-67c190e5d7da	t	Remera	1e7eeac4-1cdc-4a62-a43a-b326be6765aa
83d665b8-74da-4411-9d51-60f615073c5c	t	Mbiriri	1c488690-8603-462f-b566-2b74078889c7
b1bcad2a-7da6-436b-8c88-2b1d63522563	t	Musongati	1c488690-8603-462f-b566-2b74078889c7
d75d499a-a88e-4771-81a7-c19289396e49	t	Ngaru	1c488690-8603-462f-b566-2b74078889c7
a8615151-09b0-4d46-9d92-cc144b2eb0d2	t	Rusovu	1c488690-8603-462f-b566-2b74078889c7
4660c564-2633-42af-a1d7-2228eb2abfe4	t	Gasagara	ef727609-2ad5-4cba-b606-b1233f8cac22
9f2db773-821d-4f79-97c4-1b54563267c9	t	Gasharu	ef727609-2ad5-4cba-b606-b1233f8cac22
906a133a-1daa-4c7a-9440-cbd97b64e1d9	t	Karambo	ef727609-2ad5-4cba-b606-b1233f8cac22
ed8b57ee-27d6-449a-a375-610d81f59437	t	Nyamirambo	ef727609-2ad5-4cba-b606-b1233f8cac22
9f9037a8-16a2-4104-9428-ce4ab7489519	t	Ruhango	ef727609-2ad5-4cba-b606-b1233f8cac22
e153a879-cce2-44e6-aef5-9b9b42d879e5	t	Gasave	c58ab6ee-3cc9-4987-93bd-2e8f34e7fb7c
0f5b7db9-95ce-4dc1-ac0b-75857460061c	t	Nsanga	c58ab6ee-3cc9-4987-93bd-2e8f34e7fb7c
1b39ca5d-d6a0-4b52-8837-33aaf6bc998c	t	Kinini	c35c516f-75af-4f21-9d90-2ef526b081f9
cd13198a-7b86-4f41-8447-d7899fa4f03d	t	Mbare	c35c516f-75af-4f21-9d90-2ef526b081f9
c16cd61b-cea6-4382-a519-dbd40a0b2498	t	Mubuga	c35c516f-75af-4f21-9d90-2ef526b081f9
1d3f9ad5-b3c3-46f4-bcc2-a26fa5ba490e	t	Ruli	c35c516f-75af-4f21-9d90-2ef526b081f9
4ce39303-7aa7-4095-9f08-07456e4c77e2	t	Bushigishigi	f3fab009-b08b-4264-8a05-b9c04e5614ac
441c1db8-8167-4708-8cf4-14e68ce20b10	t	Byimana	f3fab009-b08b-4264-8a05-b9c04e5614ac
cca95e95-36c1-40ae-b995-e7c262503aed	t	Gifurwe	f3fab009-b08b-4264-8a05-b9c04e5614ac
93cd66b0-f85d-49a0-bb4d-af3497caa61c	t	Munini	f3fab009-b08b-4264-8a05-b9c04e5614ac
4a0f2bab-6155-4ed2-a498-86c761b8b790	t	Rambya	f3fab009-b08b-4264-8a05-b9c04e5614ac
b9621118-4b55-428b-9b19-009fb6ae7d06	t	Gitega	e5a56ded-c6d2-423f-acf4-529ac7d3ef6f
eeee8779-0959-45d3-8ca4-246bf2641ed1	t	Karama	e5a56ded-c6d2-423f-acf4-529ac7d3ef6f
f99eaadf-75a6-4915-9055-2f1b1b75f7e0	t	Kiyumba	e5a56ded-c6d2-423f-acf4-529ac7d3ef6f
cbea40ea-4ac0-4aca-bc9e-1289ef959310	t	Ngoma	e5a56ded-c6d2-423f-acf4-529ac7d3ef6f
8be8ea52-b3d6-49be-91ec-dfd5e0d49041	t	Nyanza	e5a56ded-c6d2-423f-acf4-529ac7d3ef6f
10f06b38-c6f1-4349-b5e0-712813967e14	t	Nyanzoga	e5a56ded-c6d2-423f-acf4-529ac7d3ef6f
2951600e-17be-41b9-adeb-e46fa346cf79	t	Kigeme	7e55dffb-19a0-4ddd-90de-ad1a211b785c
67bbbd31-155d-420b-898c-29279257b349	t	Ngiryi	7e55dffb-19a0-4ddd-90de-ad1a211b785c
6b4dd0a0-baff-4f94-8f63-5f02f4bed71a	t	Nyabivumu	7e55dffb-19a0-4ddd-90de-ad1a211b785c
a21848e9-b9d3-4f15-b889-0fbd7cb41cd1	t	Nyamugari	7e55dffb-19a0-4ddd-90de-ad1a211b785c
d80cec4f-3e00-4674-9acc-f8b1aaec10b9	t	Nzega	7e55dffb-19a0-4ddd-90de-ad1a211b785c
4676f5a5-2672-4ba2-a309-e421d162fddb	t	Remera	7e55dffb-19a0-4ddd-90de-ad1a211b785c
862f9b70-d252-440d-a1ad-b8ec7b651b2b	t	Gatare	36392606-af11-4079-9726-fd9387a278fe
deae4157-c13d-4f3f-8186-f8746eaf9d6f	t	Kavumu	a7930067-6b4b-4aea-a5e8-0c76006378e7
1561abdb-e2da-4e2a-9bdc-7888a8411cab	t	Murambi	a7930067-6b4b-4aea-a5e8-0c76006378e7
b4de1127-f055-4f30-a883-e6c873b824b3	t	Musenyi	a7930067-6b4b-4aea-a5e8-0c76006378e7
20e11c99-6dbc-492e-bc52-5e9176f80daa	t	Nyabisindu	a7930067-6b4b-4aea-a5e8-0c76006378e7
c57caec7-b7af-488b-9347-7ce041ce13b8	t	Nyamiyaga	a7930067-6b4b-4aea-a5e8-0c76006378e7
c7e4bca0-1e1d-4257-b4a3-fb2221bfb2d9	t	Bwama	aab32ff2-9eb2-4703-8588-a02eb5fa1fbd
6ec107a4-9b5b-4a87-85cc-4ac64af95b83	t	Kirehe	aab32ff2-9eb2-4703-8588-a02eb5fa1fbd
8637b380-1d39-43a7-b178-63bba5a819ff	t	Nyarusiza	aab32ff2-9eb2-4703-8588-a02eb5fa1fbd
0f7ccbfb-4a2b-42ff-8532-a5cdd8fd162a	t	Bugarama	b817a162-0fa7-4de9-b700-7b04a80a2cbf
392b38b2-d523-443b-9ac9-928a756dfc23	t	Bugarura	b817a162-0fa7-4de9-b700-7b04a80a2cbf
3ea00ba9-4231-40ba-bdd2-bc92a2a46670	t	Gashiha	b817a162-0fa7-4de9-b700-7b04a80a2cbf
bcb04680-450f-4fdb-9cea-5d0084dba6f0	t	Karambo	b817a162-0fa7-4de9-b700-7b04a80a2cbf
a8bd6183-8e42-483e-b079-e0703107ecb5	t	Ruhunga	b817a162-0fa7-4de9-b700-7b04a80a2cbf
c389b481-cdc4-444b-8964-605336684bf1	t	Uwindekezi	b817a162-0fa7-4de9-b700-7b04a80a2cbf
2d3df74a-f124-4f29-a8ba-d26bc3acf96f	t	Bwenda	063f8e59-1906-41b3-9ee0-98803cf55590
c6d6c965-3c1c-455e-998b-07296a95f569	t	Gakanka	063f8e59-1906-41b3-9ee0-98803cf55590
3ad8a839-cac1-4ed8-b2f6-031805f349d3	t	Kibibi	063f8e59-1906-41b3-9ee0-98803cf55590
66da9cd8-69b6-4e9f-bf0b-fefca8fad62b	t	Nyakiza	063f8e59-1906-41b3-9ee0-98803cf55590
e939d47d-ae3c-4bb8-adf4-d9b66e58aaa3	t	Kagano	4a26588a-6428-410b-a20d-4733a8ac21c9
aef6362c-8bbe-4233-a691-cec2bb51d646	t	Mujuga	4a26588a-6428-410b-a20d-4733a8ac21c9
22667417-a584-43ef-af0b-a33b5909d486	t	Mukungu	4a26588a-6428-410b-a20d-4733a8ac21c9
4dc092f8-9b5f-46c8-a6c6-26161fe4adef	t	Mutiwingoma	2ccbb7a7-eb28-492c-abc7-bec2def9c543
d846c3c1-5671-4a88-813b-0840e111f6d1	t	Ngambi	2ccbb7a7-eb28-492c-abc7-bec2def9c543
857d214d-86d0-4097-b9dd-7f16dcf5ab9c	t	Ngara	2ccbb7a7-eb28-492c-abc7-bec2def9c543
6bf05a68-cedb-4d13-8ac3-c1e52587129b	t	Gitwa	b34952d4-5f81-48ac-b89b-46e37b9b6d69
1d323fc7-228c-4295-acd5-75730d71a7fb	t	Ruhinga	b34952d4-5f81-48ac-b89b-46e37b9b6d69
449f990f-5856-4f66-b60a-e7afde111a47	t	Sovu	b34952d4-5f81-48ac-b89b-46e37b9b6d69
cba0cb0a-57e6-4f48-b7fe-6be8b3fe3308	t	Suti	b34952d4-5f81-48ac-b89b-46e37b9b6d69
c3515585-bb97-4ed8-b76d-a57e07b9f902	t	Gasave	2f03368c-d03e-43f9-923c-006b95ae6c35
e506df0d-57e1-43ac-a7c9-10d865b9df87	t	Jenda	2f03368c-d03e-43f9-923c-006b95ae6c35
96b07be8-a767-4243-9e76-1ac9a4ba25db	t	Masagara	2f03368c-d03e-43f9-923c-006b95ae6c35
3b9e32af-022e-4535-85a2-fc4215710daf	t	Masangano	2f03368c-d03e-43f9-923c-006b95ae6c35
d5f9f0eb-a436-4142-9d33-a1d9789a55a9	t	Nyagisozi	2f03368c-d03e-43f9-923c-006b95ae6c35
ac430462-886b-4c53-ad46-b116edeb1f6b	t	Gatovu	bf9b9f60-23ab-4ac9-80e9-7e2e9cc0e9c8
e10fdabd-895c-4246-9d0e-d2104baf7d5a	t	Rugano	bf9b9f60-23ab-4ac9-80e9-7e2e9cc0e9c8
21ecc4da-54e1-40ea-8b7f-aaaf09888c73	t	Runege	bf9b9f60-23ab-4ac9-80e9-7e2e9cc0e9c8
d606ed87-fc3f-4f8a-ac1e-89e6b78f0abc	t	Rusekera	bf9b9f60-23ab-4ac9-80e9-7e2e9cc0e9c8
98685999-8dc3-497d-925a-e2e0932c1e68	t	Sekera	bf9b9f60-23ab-4ac9-80e9-7e2e9cc0e9c8
32c8554c-dc81-4c24-b890-29915207a234	t	Buteteri	5329a5d2-6dfe-4b86-8819-f0d747d0d289
822517b3-9480-4903-a108-44b04e3031dd	t	Cyobe	5329a5d2-6dfe-4b86-8819-f0d747d0d289
62bad14c-23c0-4914-a010-ba4c03a45ecc	t	Gashwati	5329a5d2-6dfe-4b86-8819-f0d747d0d289
6d793e67-ec24-467d-ac8d-e9c26c7fe803	t	Bitandara	a6ab9c00-5563-4ed4-adf8-b68f4929b798
3604ac56-0019-4b72-95b1-40e9ffd8da66	t	Musaraba	a6ab9c00-5563-4ed4-adf8-b68f4929b798
f564c90e-197a-4b0b-893d-6a382ec22416	t	Mutengeri	a6ab9c00-5563-4ed4-adf8-b68f4929b798
07137ddf-7652-4d14-bf2e-103bd70a21eb	t	Nkomane	a6ab9c00-5563-4ed4-adf8-b68f4929b798
00c65a3b-be47-4944-b69b-1703a4d44e7c	t	Nyarwungo	a6ab9c00-5563-4ed4-adf8-b68f4929b798
84e68c0d-db2a-486f-b35a-146934851aca	t	Twiya	a6ab9c00-5563-4ed4-adf8-b68f4929b798
55efb95c-4eec-4604-93f7-c9c20ae9a6f3	t	Gasarenda	81e298b0-7e57-41b4-ab37-1e156e4e356e
66a0e5f8-3c33-44f5-89db-7e16e410299b	t	Gatovu	81e298b0-7e57-41b4-ab37-1e156e4e356e
d5646c11-027b-413d-a368-1711d57cc52e	t	Kaganza	81e298b0-7e57-41b4-ab37-1e156e4e356e
55310ce3-a46e-4597-8cac-c817350728c5	t	Nkumbure	81e298b0-7e57-41b4-ab37-1e156e4e356e
a4dbd83b-55df-4529-a0f9-f8d63dcbea08	t	Nyamigina	81e298b0-7e57-41b4-ab37-1e156e4e356e
7511af33-2404-4191-878d-8d388b76d801	t	Bigumira	61d1ee6d-f5b0-4d20-8b87-704e9fd2eba6
3e00d6aa-b711-4e5f-aff4-c2000c300f85	t	Gahira	61d1ee6d-f5b0-4d20-8b87-704e9fd2eba6
87edf933-c1b5-41fc-8a89-0e5190f6ab83	t	Kibyagira	61d1ee6d-f5b0-4d20-8b87-704e9fd2eba6
8dceb21a-5d0d-4ff8-b4f8-1ceeff6cd4d1	t	Mudasomwa	61d1ee6d-f5b0-4d20-8b87-704e9fd2eba6
1be1180d-e296-4330-84e3-6b82159124e0	t	Munyege	61d1ee6d-f5b0-4d20-8b87-704e9fd2eba6
8915d965-916f-42f1-a3c8-66863bdfc313	t	Rugogwe	61d1ee6d-f5b0-4d20-8b87-704e9fd2eba6
ab7695b6-866a-47ca-849a-4490422cbd3f	t	Gahondo	a5c86c1a-34f6-4365-aa1a-c8a401d5772b
9b9cd723-d537-4c1f-9e93-0dca4320ea4d	t	Kavumu	a5c86c1a-34f6-4365-aa1a-c8a401d5772b
42b5b74d-1db4-4bbb-9ade-054e8a79da21	t	Kibinja	a5c86c1a-34f6-4365-aa1a-c8a401d5772b
0b4ed8e6-a3af-48d7-a361-5de1f6151e91	t	Nyanza	a5c86c1a-34f6-4365-aa1a-c8a401d5772b
c2896955-f3ba-4306-8de4-71732caa7a29	t	Rwesero	a5c86c1a-34f6-4365-aa1a-c8a401d5772b
047cc418-878e-45d4-bf83-46fb711b1035	t	Gitovu	0eb382ca-8bbc-448c-89c8-b33258169f0a
3a6ac51a-0cab-4adc-941d-428d4615c235	t	Kimirama	0eb382ca-8bbc-448c-89c8-b33258169f0a
fa84081f-2513-4419-9fa4-01b508977b7b	t	Masangano	0eb382ca-8bbc-448c-89c8-b33258169f0a
b9891e12-eced-4b24-9bdd-0704cab3557b	t	Munyinya	0eb382ca-8bbc-448c-89c8-b33258169f0a
f280cda4-e5e7-493f-b951-48c51d965a9e	t	Rukingiro	0eb382ca-8bbc-448c-89c8-b33258169f0a
1a8b3028-9d36-4ee3-93fb-032397c6e4e4	t	Shyira	0eb382ca-8bbc-448c-89c8-b33258169f0a
1efc0ffc-9a6e-4673-a932-640f42e00b0b	t	Kadaho	a6fef9d4-bd7e-42c9-b60b-874aa8d55e75
6140ef18-4c83-491b-8679-f3b466d167ad	t	Karama	a6fef9d4-bd7e-42c9-b60b-874aa8d55e75
ca983f0a-7bc5-4e51-95c9-41e61a52b3f5	t	Nyabinyenga	a6fef9d4-bd7e-42c9-b60b-874aa8d55e75
f4bfff48-f832-4192-8be8-99c6f11035e8	t	Nyarurama	a6fef9d4-bd7e-42c9-b60b-874aa8d55e75
ed904580-1cc4-4415-a949-322f74a1ccd9	t	Rubona	a6fef9d4-bd7e-42c9-b60b-874aa8d55e75
7408d6bd-2c8e-48a0-a1f9-02e1be8cd855	t	Cyeru	79272797-385c-4ee0-bba3-de14c2540a8e
457f7389-ebab-478f-98c7-b8831e3ad55b	t	Mbuye	79272797-385c-4ee0-bba3-de14c2540a8e
8fc6f862-5585-4392-879a-4339d2cb2ac7	t	Mututu	79272797-385c-4ee0-bba3-de14c2540a8e
9ced01ef-5970-422d-98ca-51f3759244a6	t	Rwotso	79272797-385c-4ee0-bba3-de14c2540a8e
7c042565-eb08-4626-9d0f-57e2c48336b1	t	Butansinda	e7ddc72f-3d07-4c1d-9e27-c9f55991c9ad
33d922b2-4d81-4ad5-b8ba-3123a78a5365	t	Butara	e7ddc72f-3d07-4c1d-9e27-c9f55991c9ad
68017a48-4545-4263-9e6b-adf02133676e	t	Gahombo	e7ddc72f-3d07-4c1d-9e27-c9f55991c9ad
ef33306a-0a25-4ab0-8aa9-e124ad054955	t	Gasoro	e7ddc72f-3d07-4c1d-9e27-c9f55991c9ad
1b46fcd3-c8f8-48e7-b079-4b8de4dbccd8	t	Mulinja	e7ddc72f-3d07-4c1d-9e27-c9f55991c9ad
964b6c94-adb6-449e-a604-e35ae4f846d7	t	Cyerezo	331147fa-756b-4d35-99ea-9325baa75f16
bb41e89e-f585-49f3-928e-a05711ca9ea2	t	Gatagara	331147fa-756b-4d35-99ea-9325baa75f16
1225b010-9650-4dee-a6a2-bef313a44888	t	Kiruli	331147fa-756b-4d35-99ea-9325baa75f16
5d340e15-f226-4e8f-b1af-54630eee572d	t	Mpanga	331147fa-756b-4d35-99ea-9325baa75f16
57d53b8c-182e-4fee-b3f7-ee7d1c3ce881	t	Ngwa	331147fa-756b-4d35-99ea-9325baa75f16
5cb91c8b-55a0-46ec-af57-fefa610d06b2	t	Nkomero	331147fa-756b-4d35-99ea-9325baa75f16
05a91f2d-cdae-4a03-8a98-885faf26f0e7	t	Gati	e28c2906-de98-4e04-b506-04721c145428
82efdb5c-73cc-44ac-a2a8-4cd5c74a7c6a	t	Migina	e28c2906-de98-4e04-b506-04721c145428
81d9cd02-2e44-4ed7-b1ff-131237b13f6d	t	Nyamiyaga	e28c2906-de98-4e04-b506-04721c145428
50e8f0aa-f953-41a3-bd6b-dda252622bc9	t	Nyamure	e28c2906-de98-4e04-b506-04721c145428
d561ac81-1435-4ac1-86b8-5db76a3688b1	t	Nyundo	e28c2906-de98-4e04-b506-04721c145428
a9e501a9-c6af-4cb7-a919-d04e32b2c2d5	t	Bugali	4bc1711a-2655-4fd2-be1b-92ede8f59a1a
1543ea98-27b5-4651-8afb-2767395bb130	t	Cyotamakara	4bc1711a-2655-4fd2-be1b-92ede8f59a1a
3ddd9df5-0290-4044-a3f2-5813ffefdadb	t	Kagunga	4bc1711a-2655-4fd2-be1b-92ede8f59a1a
d0847425-c9df-46a9-9e2a-c83ffa79d738	t	Katarara	4bc1711a-2655-4fd2-be1b-92ede8f59a1a
8c48bbc0-d1e6-46d7-847f-ff63d703602e	t	Gahunga	50f6acf7-0c12-432d-80fa-c2bc7ed2c2bb
6b85270e-f464-485f-bd23-6974bab66b80	t	Kabirizi	50f6acf7-0c12-432d-80fa-c2bc7ed2c2bb
7d7769b0-0e2f-4cf4-b67b-bd197356d725	t	Kabuga	50f6acf7-0c12-432d-80fa-c2bc7ed2c2bb
ebfd73a0-f25d-4b45-9826-98fba2839f5a	t	Kirambi	50f6acf7-0c12-432d-80fa-c2bc7ed2c2bb
bb96b472-bc47-4f6d-bab2-82fa41104a21	t	Rurangazi	50f6acf7-0c12-432d-80fa-c2bc7ed2c2bb
eb8c3f7e-44fb-4c37-aa19-182c3b3648cd	t	Gacu	8ab43af9-8a55-4a36-bab6-63947ec93baa
14bd6a26-126a-4df5-83a6-85d31e9e8e71	t	Gishike	8ab43af9-8a55-4a36-bab6-63947ec93baa
a4b5debb-c8af-40d2-903b-a5b9e5ee6f5f	t	Mubuga	8ab43af9-8a55-4a36-bab6-63947ec93baa
0cbec2d5-4085-4403-9228-b14a75bbd968	t	Mushirarungu	8ab43af9-8a55-4a36-bab6-63947ec93baa
1d256e32-81fd-424f-9454-722aa716975d	t	Nyarusange	8ab43af9-8a55-4a36-bab6-63947ec93baa
c2ad5bdd-5c47-4e5a-a530-980158226622	t	Kirarangombe	b79c3f95-c2c2-449f-a4fd-719c9c56e22b
731819c9-cdc6-4f77-a06f-cb4cc151e88f	t	Nkanda	b79c3f95-c2c2-449f-a4fd-719c9c56e22b
fd771b01-58f0-4962-8fef-699a1b16163a	t	Nteko	b79c3f95-c2c2-449f-a4fd-719c9c56e22b
0203909d-c7c2-4875-b7a9-80a4497c791a	t	Runyombyi	b79c3f95-c2c2-449f-a4fd-719c9c56e22b
91cb3161-4655-4389-accb-ac480fde938e	t	Shororo	b79c3f95-c2c2-449f-a4fd-719c9c56e22b
c32f9205-2976-491d-87eb-366292971a5f	t	Coko	8810bdb3-6135-4632-be88-6d1effd62365
855d3c55-ba35-4878-a70c-3ea28a28b91e	t	Cyahinda	8810bdb3-6135-4632-be88-6d1effd62365
e958a7a2-8413-44f8-93bb-376911b8d57d	t	Gasasa	8810bdb3-6135-4632-be88-6d1effd62365
f90e335d-ad32-4d33-a2c3-1635469af1ed	t	Muhambara	8810bdb3-6135-4632-be88-6d1effd62365
c89bd8bc-ed21-46fd-a116-ccfb324fa9ef	t	Rutobwe	8810bdb3-6135-4632-be88-6d1effd62365
52abc701-d625-4155-95f4-676f07fba4fd	t	Gakoma	b5bd1b18-0ee2-4e6f-850b-6c53b9f39cb2
1eba0e01-47e2-405f-b826-1112cd2b6c4e	t	Kibeho	b5bd1b18-0ee2-4e6f-850b-6c53b9f39cb2
2c10107a-e1bb-4318-b8c7-583a941e29a6	t	Mbasa	b5bd1b18-0ee2-4e6f-850b-6c53b9f39cb2
b685946f-6fd4-4da2-8c6e-b826384f6372	t	Mpanda	b5bd1b18-0ee2-4e6f-850b-6c53b9f39cb2
ec58c769-a252-439a-92da-4830ea7dcd2c	t	Mubuga	b5bd1b18-0ee2-4e6f-850b-6c53b9f39cb2
5e66db1a-ee12-4009-a1a9-e6e84277b332	t	Nyange	b5bd1b18-0ee2-4e6f-850b-6c53b9f39cb2
043e6255-45d8-4dfe-8d05-45740ac67fc2	t	Cyanyirankora	841f69cd-9c8e-481e-a44e-1c596aad9eec
633844ac-7e59-4eb6-be17-41435a599625	t	Gahurizo	841f69cd-9c8e-481e-a44e-1c596aad9eec
f21b81c1-17d3-45bd-8f5e-c1aa6dc6c6b1	t	Kimina	841f69cd-9c8e-481e-a44e-1c596aad9eec
ac87e618-d296-4892-8a4a-6a11ced13831	t	Kivu	841f69cd-9c8e-481e-a44e-1c596aad9eec
4998e6b7-d0f1-4761-980e-b2399efd2281	t	Rugerero	841f69cd-9c8e-481e-a44e-1c596aad9eec
c57b1143-c8df-49bc-8355-54872857a493	t	Gorwe	00819b8f-b3c5-47fc-af18-a50170640e55
63a87db5-c9ae-4231-8fc8-36c62bfbe5ab	t	Murambi	00819b8f-b3c5-47fc-af18-a50170640e55
3301ca98-b533-4cff-a53a-cbc877b42f56	t	Nyamabuye	00819b8f-b3c5-47fc-af18-a50170640e55
4258d9bc-81ff-45b4-98d2-46c0acd5db1d	t	Ramba	00819b8f-b3c5-47fc-af18-a50170640e55
e2a3c837-e2a0-4eed-8864-22367eb54ccd	t	Rwamiko	00819b8f-b3c5-47fc-af18-a50170640e55
73c57327-89f4-4d5d-88f2-51b956a73d64	t	Muganza	07b5ce7b-816b-4c69-b16f-da28747371f6
ddaad8fb-33ce-4239-ad83-0367dbc0d970	t	Rukore	07b5ce7b-816b-4c69-b16f-da28747371f6
121700d1-4ff7-44c7-be22-cc6b84556a0a	t	Samiyonga	07b5ce7b-816b-4c69-b16f-da28747371f6
2863ad1f-fdb7-4318-9e3d-68c4e8202da0	t	Uwacyiza	07b5ce7b-816b-4c69-b16f-da28747371f6
c2e855e1-4fda-4da2-a15c-86b1f6965318	t	Ngarurira	5d51b7f1-4c7e-4185-9d0a-f3a844a648c2
fb40d41d-a43a-4d88-8494-f6e790e680e0	t	Ngeri	5d51b7f1-4c7e-4185-9d0a-f3a844a648c2
b9bd6c6d-53f9-42fd-b81c-63d760b15dc6	t	Ntwali	5d51b7f1-4c7e-4185-9d0a-f3a844a648c2
c039ad7d-9596-46f7-8c9b-05278f575d69	t	Nyarure	5d51b7f1-4c7e-4185-9d0a-f3a844a648c2
e2715554-222a-4040-aafe-bccf518c1de4	t	Bitare	72ad81d6-fa2b-4a93-ab8f-c3e3790343de
5ad7f1fd-5ce3-46ce-a8fa-981ea684da52	t	Mukuge	72ad81d6-fa2b-4a93-ab8f-c3e3790343de
72703c5d-6706-416f-848e-d82bbfeeeace	t	Murama	72ad81d6-fa2b-4a93-ab8f-c3e3790343de
1a31b9b4-1fa8-40d4-8560-397e1aa4dbb5	t	Nyamirama	72ad81d6-fa2b-4a93-ab8f-c3e3790343de
7b3fdece-85c0-4d3b-bf96-580e7f44d57c	t	Nyanza	72ad81d6-fa2b-4a93-ab8f-c3e3790343de
23968414-166b-49a4-a074-c026c7470ff4	t	Yaramba	72ad81d6-fa2b-4a93-ab8f-c3e3790343de
4e4b2412-9f30-4cc3-926e-67d9ad344978	t	Fugi	eff5a0cf-18f3-4c04-9f3e-b3cddaec8ec9
82c23631-4a27-4f7f-b6fe-7cf438b607e5	t	Kiyonza	eff5a0cf-18f3-4c04-9f3e-b3cddaec8ec9
cc0d1643-3b72-44bd-a046-c5ea04b5bcab	t	Mbuye	eff5a0cf-18f3-4c04-9f3e-b3cddaec8ec9
db9ba809-5494-49d8-90e5-cf5dc2432b07	t	Nyamirama	eff5a0cf-18f3-4c04-9f3e-b3cddaec8ec9
86eef330-ca27-4054-bfc4-09abc4de944c	t	Gihemvu	32a1d3c3-1fd3-43ca-8f29-d4639901951a
9a77e63c-6b03-4503-8271-0caae654b92a	t	Kabere	32a1d3c3-1fd3-43ca-8f29-d4639901951a
1e7f42db-7d61-4769-8fac-35d0d07e38da	t	Mishungero	32a1d3c3-1fd3-43ca-8f29-d4639901951a
debc248e-9eb6-4a15-adc9-ec6ed26a0932	t	Nyabimata	32a1d3c3-1fd3-43ca-8f29-d4639901951a
b97fb7a0-60bd-4937-a299-5c140afebbc3	t	Ruhinga	32a1d3c3-1fd3-43ca-8f29-d4639901951a
7fb028ea-62ca-4f74-9571-b69861fcfb03	t	Maraba	77ea66d6-ff5b-4eac-abcb-ee08086ebe4e
9dd6ab32-9d1d-46fa-b65f-cdb079da64b8	t	Mwoya	77ea66d6-ff5b-4eac-abcb-ee08086ebe4e
b7ddf90d-951e-4787-beb9-7f82bf11e47c	t	Nkakwa	77ea66d6-ff5b-4eac-abcb-ee08086ebe4e
22eb4f2d-2308-4709-8580-63b99c15a2a9	t	Nyagisozi	77ea66d6-ff5b-4eac-abcb-ee08086ebe4e
619f7cf8-cdaa-417b-8918-361982f0b704	t	Gitita	c4c4b347-d051-4b48-b63d-071f2e990b7c
e149ba4f-02e2-4405-911a-b24090173a8a	t	Kabere	c4c4b347-d051-4b48-b63d-071f2e990b7c
95412e2f-f613-4512-aaec-c2c875551668	t	Remera	c4c4b347-d051-4b48-b63d-071f2e990b7c
7041f288-8950-4fc8-ab1c-77295d2d7221	t	Ruyenzi	c4c4b347-d051-4b48-b63d-071f2e990b7c
060460e0-f9f6-4c4b-8518-efc30fe524b0	t	Uwumusebeya	c4c4b347-d051-4b48-b63d-071f2e990b7c
f61dbeb9-2acc-4d8b-b6a4-09e8a4d14526	t	Gabiro	89a81ad5-fdfb-4496-816d-05ea50b312f4
1a4e192d-4bfb-49f6-8871-1b46e1f9dd6f	t	Giseke	89a81ad5-fdfb-4496-816d-05ea50b312f4
e921c6d3-cb9e-4bc4-a6de-3251ef8b059d	t	Nyarugano	89a81ad5-fdfb-4496-816d-05ea50b312f4
d963a52a-f641-49ee-b9ce-4798e1a6a214	t	Ruramba	89a81ad5-fdfb-4496-816d-05ea50b312f4
4b968b06-fe64-48c8-a231-d2619ad39268	t	Bunge	4eb1003f-ed6e-4cd3-8cb9-17723d737e08
25e8ba59-4625-4611-ac28-075f94fb0178	t	Cyuna	4eb1003f-ed6e-4cd3-8cb9-17723d737e08
b9f5f74c-13e8-4184-ac1f-1c60dd3f92dd	t	Gikunzi	4eb1003f-ed6e-4cd3-8cb9-17723d737e08
2c9e1a09-3dc0-4428-8f05-4d4aca43b46b	t	Mariba	4eb1003f-ed6e-4cd3-8cb9-17723d737e08
ed5db0ad-0b37-4b6a-8710-dc1dc169e3a5	t	Raranzige	4eb1003f-ed6e-4cd3-8cb9-17723d737e08
e7a802d6-2836-4f75-8286-df380b73ae7f	t	Rusenge	4eb1003f-ed6e-4cd3-8cb9-17723d737e08
2008b1cb-f548-42ca-a6eb-dc1cf0c0c15a	t	Buhanda	e9a9d307-b6a1-4989-9a96-59e376b11db5
6fff7527-a832-4ea9-877c-e325ad357ef8	t	Gitisi	e9a9d307-b6a1-4989-9a96-59e376b11db5
9cea8b60-e709-40c2-bcec-7b7b178a57aa	t	Murama	e9a9d307-b6a1-4989-9a96-59e376b11db5
9d820010-adc5-4d33-99ce-6ec7283496b0	t	Rubona	e9a9d307-b6a1-4989-9a96-59e376b11db5
3a2c8864-3d16-4f96-8ba7-12d7c81771ef	t	Rwinyana	e9a9d307-b6a1-4989-9a96-59e376b11db5
2c3a862f-2169-451b-8bcd-44cc656ad65d	t	Kamusenyi	7b90fa53-8c1e-4a13-be6b-0eb3abc65131
8e29389f-ef23-4ba2-b59c-d2ff5d14497b	t	Kirengeri	7b90fa53-8c1e-4a13-be6b-0eb3abc65131
690192db-9cfe-4621-9f19-3726eaae97ac	t	Mahembe	7b90fa53-8c1e-4a13-be6b-0eb3abc65131
1f667d1a-7449-4f03-8ad7-ededb027aa35	t	Mpanda	7b90fa53-8c1e-4a13-be6b-0eb3abc65131
a1bd43f5-b02a-42a2-a51a-ede2bbb8909e	t	Muhororo	7b90fa53-8c1e-4a13-be6b-0eb3abc65131
8a87bf5a-ddeb-4b69-b18c-f55d74f74f81	t	Ntenyo	7b90fa53-8c1e-4a13-be6b-0eb3abc65131
42de3933-d6fe-47ac-9c2c-e31a836cc36c	t	Nyakabuye	7b90fa53-8c1e-4a13-be6b-0eb3abc65131
8215cd94-9a73-4dab-a3f4-b4b4ae970f6f	t	Bihembe	47840b0b-9f86-4833-9906-19692413a49d
cd43ad8c-5fd6-4bbf-a080-b8acc3b9bc03	t	Karambi	47840b0b-9f86-4833-9906-19692413a49d
58c11058-84f4-4324-8c6d-fb58e4c77cde	t	Munanira	47840b0b-9f86-4833-9906-19692413a49d
27652664-344f-49be-93da-4698548d8ddf	t	Remera	47840b0b-9f86-4833-9906-19692413a49d
81fd434d-f8e8-448e-8732-42d0170e8cbb	t	Rwesero	47840b0b-9f86-4833-9906-19692413a49d
e7f155ac-a00e-42f8-9ac3-4d74e5cdc450	t	Rwoga	47840b0b-9f86-4833-9906-19692413a49d
1fc5daa2-bd37-4f61-be68-68c43c91f95c	t	Burima	8f93049b-c929-4a9d-a836-d00e6579deb9
05489fe3-94da-440e-9265-d4cffdeb8513	t	Gisali	8f93049b-c929-4a9d-a836-d00e6579deb9
f59a8ab4-ae82-4338-9f30-4f565c1deb77	t	Kinazi	8f93049b-c929-4a9d-a836-d00e6579deb9
0a17d3c1-83e7-458f-8473-c2674843b8a8	t	Rubona	8f93049b-c929-4a9d-a836-d00e6579deb9
bbeff635-9f83-48ac-8d90-1e37a47602a0	t	Rutabo	8f93049b-c929-4a9d-a836-d00e6579deb9
bf3cf9a3-4ff7-4bd9-bbbd-642e79d6dfd7	t	Bweramvura	4a0cf4b6-acdf-4112-afb0-459df542af36
4a6bc4d3-7884-4b9a-b0f5-01c1d1b63b93	t	Gitinda	4a0cf4b6-acdf-4112-afb0-459df542af36
870d657e-4083-44ce-a06d-991cbfaac552	t	Kirwa	4a0cf4b6-acdf-4112-afb0-459df542af36
5f8d5d7d-0616-4a45-85ec-6f8912f5260d	t	Muyunzwe	4a0cf4b6-acdf-4112-afb0-459df542af36
0bd4ebe7-077b-4b87-8c8d-1354c00ed0ce	t	Nyakogo	4a0cf4b6-acdf-4112-afb0-459df542af36
39b2d6ac-ce66-4244-bba7-2e48137481cc	t	Rukina	4a0cf4b6-acdf-4112-afb0-459df542af36
b7c7356c-08ee-45b0-b75f-211b9860336c	t	Cyanza	b01cacb7-78df-4f72-ade6-7a6cdb43f05b
d1b28895-c90f-4bf5-860d-9b4c8ceaac09	t	Gisanga	b01cacb7-78df-4f72-ade6-7a6cdb43f05b
be050979-b617-4cb0-a9c2-cddddc5f947b	t	Kabuga	b01cacb7-78df-4f72-ade6-7a6cdb43f05b
ba5570fd-72c8-4904-b79d-68d030473577	t	Kizibere	b01cacb7-78df-4f72-ade6-7a6cdb43f05b
b34a5c1a-5737-4925-bda8-9185baebd439	t	Mbuye	b01cacb7-78df-4f72-ade6-7a6cdb43f05b
c9cacc22-12d0-4acd-aa2f-e7b53ecb3c97	t	Mwendo	b01cacb7-78df-4f72-ade6-7a6cdb43f05b
7dc65a49-b555-43f0-848b-142ce14ee10d	t	Nyakarekare	b01cacb7-78df-4f72-ade6-7a6cdb43f05b
190c5af3-3790-4d6d-a1f8-7ec47627d767	t	Gafunzo	481d5717-917c-4e57-b170-89eb05bb57c0
be796056-9f4b-4fd1-9f0f-6aaecb3d915b	t	Gishweru	481d5717-917c-4e57-b170-89eb05bb57c0
e3ddce41-1a83-46b6-a196-9c31e39ba3fd	t	Kamujisho	481d5717-917c-4e57-b170-89eb05bb57c0
9e2548cc-6e81-4404-a7ff-46ef65b4ac3a	t	Kigarama	481d5717-917c-4e57-b170-89eb05bb57c0
b8154035-a9c6-458a-bec4-646012d90985	t	Mutara	481d5717-917c-4e57-b170-89eb05bb57c0
89503110-c967-452b-92c1-9979001f1dd3	t	Nyabibugu	481d5717-917c-4e57-b170-89eb05bb57c0
eca181e4-820c-4f59-aa36-93347fd1cf3f	t	Saruheshyi	481d5717-917c-4e57-b170-89eb05bb57c0
ea27a6db-e3cc-4f63-bc74-a4c14ae1c9b0	t	Gako	5ecfc649-4d73-46ab-8feb-86a81ec6b8bd
b3c43786-2b71-4190-87cd-6181f358d1c9	t	Kareba	5ecfc649-4d73-46ab-8feb-86a81ec6b8bd
3072fe55-b919-42dd-aa4b-b8dae9d7c69a	t	Kayenzi	5ecfc649-4d73-46ab-8feb-86a81ec6b8bd
62ab9544-a719-44bd-9dee-3538bb0f7dec	t	Kebero	5ecfc649-4d73-46ab-8feb-86a81ec6b8bd
037f4336-432c-46d1-931e-a5749cd71fcd	t	Nyagisozi	5ecfc649-4d73-46ab-8feb-86a81ec6b8bd
b1f3ede6-85e3-4fa7-84d6-98fdb746f97f	t	Nyakabungo	5ecfc649-4d73-46ab-8feb-86a81ec6b8bd
374d8ced-f809-46a8-b70f-c5543e840959	t	Nyarurama	5ecfc649-4d73-46ab-8feb-86a81ec6b8bd
7d238fcd-29ac-4cb5-9234-37c5c2b6ffd4	t	Buhoro	9dcb05a0-7c1c-4646-8d0e-0b306a272f93
0bc3f8d5-870f-4d72-8447-9888779674bd	t	Bunyogombe	9dcb05a0-7c1c-4646-8d0e-0b306a272f93
63ac65a1-469a-476a-a6a1-58a7998bece8	t	Gikoma	9dcb05a0-7c1c-4646-8d0e-0b306a272f93
1d287df2-81d7-4d95-948c-47af9547622e	t	Munini	9dcb05a0-7c1c-4646-8d0e-0b306a272f93
a505dbf3-ed45-4c4b-bf91-fd559c588998	t	Musamo	9dcb05a0-7c1c-4646-8d0e-0b306a272f93
e9dab837-94f2-4b2c-ab54-a1f8e7723499	t	Nyamagana	9dcb05a0-7c1c-4646-8d0e-0b306a272f93
8b26437b-bfd4-497c-8d61-02ec399943b6	t	Rwoga	9dcb05a0-7c1c-4646-8d0e-0b306a272f93
1c8a1a89-0f86-44a5-95fe-d7856ae7210f	t	Tambwe	9dcb05a0-7c1c-4646-8d0e-0b306a272f93
a1a2610e-0bfd-4351-8718-325b31188d90	t	Burunga	168cd725-218f-4100-bfe7-746484acf398
7e1b44dd-4448-4e36-8a30-51d7dbe0ffde	t	Gasura	168cd725-218f-4100-bfe7-746484acf398
2fbecc76-7f8e-4893-bdb6-c82efeeac967	t	Gitarama	168cd725-218f-4100-bfe7-746484acf398
bbb77c40-d170-47d5-99d6-2abc67239432	t	Kayenzi	168cd725-218f-4100-bfe7-746484acf398
8e516801-3d41-438c-988c-415a78b15a33	t	Kibuye	168cd725-218f-4100-bfe7-746484acf398
0ada106c-43fe-4d3b-b07b-18df1e80c29e	t	Kiniha	168cd725-218f-4100-bfe7-746484acf398
4f5c1f6f-fd6d-41c1-a736-e033ab055d35	t	Nyarusazi	168cd725-218f-4100-bfe7-746484acf398
e5697647-3b41-43d1-9b0f-9f2c31bd8756	t	Birambo	f4b50f56-56d3-418a-bbe7-c7242f823037
21f7c73a-faf7-4b35-bd3c-1e5ee0ac9ed2	t	Tongati	f4b50f56-56d3-418a-bbe7-c7242f823037
aee20241-9cb5-429d-b6d3-0989ecae8973	t	Buhoro	05936640-7843-4772-8b07-8a9431faee34
6950f2e9-b0a2-4044-9f93-4a36d96c4df8	t	Cyanya	05936640-7843-4772-8b07-8a9431faee34
4a3856b7-50b9-4f66-b9ba-2dc3ec60255b	t	Kigarama	05936640-7843-4772-8b07-8a9431faee34
a587e91a-3479-4a3f-bd56-889d9dab98fb	t	Munanira	05936640-7843-4772-8b07-8a9431faee34
eb1f9b71-efbf-40be-b2f1-547ae3f3e026	t	Musasa	05936640-7843-4772-8b07-8a9431faee34
4f609228-37a8-4042-a4ae-2fc55b4f46ba	t	Ngoma	05936640-7843-4772-8b07-8a9431faee34
edb2cf30-357d-4484-9218-90cc103a26a5	t	Kanunga	5f6492f1-8599-4764-a9cf-3dc8b2de67a4
7b80887f-f074-4e71-95d4-add4c7bbde42	t	Kirambo	5f6492f1-8599-4764-a9cf-3dc8b2de67a4
961859cb-c394-4c46-8c71-9f4db27c0566	t	Munanira	5f6492f1-8599-4764-a9cf-3dc8b2de67a4
cdf76c16-33dc-4da4-8f65-7aaad698c2bb	t	Ruhinga	5f6492f1-8599-4764-a9cf-3dc8b2de67a4
716b504b-c9ea-4537-a94e-5b3da851f077	t	Rwariro	5f6492f1-8599-4764-a9cf-3dc8b2de67a4
369522c6-3b95-454b-b654-57c13855d428	t	Kagabiro	7fe291b0-c18b-4dd7-8fb1-f1c6ec329580
57d7453c-dca1-42d6-8c80-5098740da788	t	Murangara	7fe291b0-c18b-4dd7-8fb1-f1c6ec329580
fef68f0f-81bb-4192-b4d8-a68ea3afbca2	t	Nyagatovu	7fe291b0-c18b-4dd7-8fb1-f1c6ec329580
e04625d0-6a9f-4350-bad0-1f478528d4a1	t	Ryaruhanga	7fe291b0-c18b-4dd7-8fb1-f1c6ec329580
d7cfc690-7f95-41e1-83c2-6064b80d7f4c	t	Mubuga	66ae525a-ac64-4c73-a2d2-17b5845ccc8b
04bcc49f-6c91-48ab-8215-09ff84cbef43	t	Muhororo	66ae525a-ac64-4c73-a2d2-17b5845ccc8b
6c55528f-0268-4f3c-b0ff-3acc43726a14	t	Nyarunyinya	66ae525a-ac64-4c73-a2d2-17b5845ccc8b
dced12d4-7410-41c9-aa9b-886f63a6239d	t	Shyembe	66ae525a-ac64-4c73-a2d2-17b5845ccc8b
0b17fe2a-adde-4dee-8c50-53cb95f25d1e	t	Kamina	183337ec-99c4-4873-9826-7a1e487277b6
9976c491-d469-4595-848e-4afabb5cc3fb	t	Kareba	183337ec-99c4-4873-9826-7a1e487277b6
3ce13115-661b-47a1-a1d8-897f074bfb71	t	Byogo	891b67bf-72dc-4c85-a7a3-9f5acb8ef43c
5c7fe6cd-5ad5-4457-b59a-7e4565fbd289	t	Bubazi	3d5fb398-2e1f-4ce4-b0fb-e5430925a968
f0236418-cbba-4872-9583-800d184b3e49	t	Gacaca	3d5fb398-2e1f-4ce4-b0fb-e5430925a968
e011897f-bc01-497e-a4e7-d929ed341dce	t	Gatovu	57607db9-256e-4892-877a-c613cf1d57d7
5aee636a-a373-4967-93cf-d0b92dbdceb1	t	Gisanze	3d5fb398-2e1f-4ce4-b0fb-e5430925a968
3d43dfc4-6dba-4350-b7fd-5f080eeb7d88	t	Gitwa	3d5fb398-2e1f-4ce4-b0fb-e5430925a968
53a54859-2a6c-4c02-ad05-d85e8207ebe3	t	Kibirizi	3d5fb398-2e1f-4ce4-b0fb-e5430925a968
194062d1-c07a-4393-821b-bd1745b6fe91	t	Nyarugenge	3d5fb398-2e1f-4ce4-b0fb-e5430925a968
0ece2f0d-9820-4324-bd78-ca049f89a888	t	Ruragwe	3d5fb398-2e1f-4ce4-b0fb-e5430925a968
3c60820f-28c5-4c4e-87a7-32a6b2e42699	t	Gisiza	49550c5b-f2c4-4e94-820e-4778f92f5b82
39e39bdb-75f0-4a0a-80a3-bf7d73a66967	t	Mucyimba	49550c5b-f2c4-4e94-820e-4778f92f5b82
30d91813-3fe4-4d1d-9dd0-10af37dd48f0	t	Rufungo	49550c5b-f2c4-4e94-820e-4778f92f5b82
b254af28-51fa-4228-855b-76fa1b462759	t	Kinyovu	8be37a89-f287-412d-8eb7-2cc3e38bf246
98d12a73-6f8d-46e6-ab77-7f3bef67f22f	t	Rubona	8be37a89-f287-412d-8eb7-2cc3e38bf246
da16bbad-62af-449a-911d-56d4b47fe7a4	t	Bigugu	1b22007a-5457-422c-a4fd-c56b2cfec080
1fa7472c-81fa-47ed-aaf5-fe983c1ed409	t	Bisesero	1b22007a-5457-422c-a4fd-c56b2cfec080
adc492f6-22fa-41c0-b195-f37ba403394a	t	Gasata	1b22007a-5457-422c-a4fd-c56b2cfec080
fcd3d68d-6a88-4dda-bca6-36c25e6f0861	t	Munini	1b22007a-5457-422c-a4fd-c56b2cfec080
7ea9bb8d-efdb-47d2-a91b-95403096ef36	t	Nyakamira	1b22007a-5457-422c-a4fd-c56b2cfec080
1e981cbf-12fa-40fa-b50a-511f39975320	t	Nyarusanga	1b22007a-5457-422c-a4fd-c56b2cfec080
fd67a8f6-1bd6-4a31-9dd8-1db77741b524	t	Rubazo	1b22007a-5457-422c-a4fd-c56b2cfec080
f30b1f77-936f-4e15-bd10-25496606e275	t	Bihumbe	f3121ce5-5544-4728-8b32-116e721fec6c
63942efb-44b9-44dc-8446-0e5ca55c3060	t	Gakuta	f3121ce5-5544-4728-8b32-116e721fec6c
b1c57b2a-81df-4c95-ba9b-40d3793b07f6	t	Gisovu	f3121ce5-5544-4728-8b32-116e721fec6c
3c47d9b3-bead-4e8b-b17e-42e9a6d95371	t	Gitabura	f3121ce5-5544-4728-8b32-116e721fec6c
9c67f3a8-a41b-4360-8770-cf72436e09f7	t	Murehe	f3121ce5-5544-4728-8b32-116e721fec6c
813f3a3c-0c5d-4dc7-b9a0-abc009fa6274	t	Bungwe	45c8a8ab-dd4e-4f4b-b208-f807d4bfd2fb
b98c0fac-7e67-4980-8e3c-9e8658860cf0	t	Gashubi	45c8a8ab-dd4e-4f4b-b208-f807d4bfd2fb
7f956bc2-b371-47a2-8b23-bddb0db77c26	t	Kabarondo	45c8a8ab-dd4e-4f4b-b208-f807d4bfd2fb
6920d7e3-cfb3-483d-b7ea-ca20d0014548	t	Cyome	ddeaf674-7089-41e9-b4b0-6babb690f1a1
2381c1be-80b8-4d16-90e7-8cb3ef2456fd	t	Gatsibo	ddeaf674-7089-41e9-b4b0-6babb690f1a1
6bd41cd8-5a7f-423d-83e1-84a0c6bb8203	t	Kamasiga	ddeaf674-7089-41e9-b4b0-6babb690f1a1
cba5469b-2047-4848-97d2-e3dabb9ce457	t	Karambo	ddeaf674-7089-41e9-b4b0-6babb690f1a1
f88b8cfe-9532-44b8-a7cd-64761ee74093	t	Ruhanga	ddeaf674-7089-41e9-b4b0-6babb690f1a1
74675155-d944-48c3-9b35-c3db69d234df	t	Rusumo	ddeaf674-7089-41e9-b4b0-6babb690f1a1
4363a6ca-6c9a-4f39-8492-d3a86892bbab	t	Gatare	bdcc5e40-9f63-4b72-b29b-66108210e7c0
271158e3-e7c1-4100-9d91-432a458ed60c	t	Gatega	bdcc5e40-9f63-4b72-b29b-66108210e7c0
642c4cda-6803-4290-bee6-dd11c467260f	t	Kajinge	bdcc5e40-9f63-4b72-b29b-66108210e7c0
64a01bb8-e198-4852-bf18-cc5f71bb04bd	t	Marantima	bdcc5e40-9f63-4b72-b29b-66108210e7c0
7ca81046-73ba-466e-83ac-d970eafb904c	t	Rugendabari	bdcc5e40-9f63-4b72-b29b-66108210e7c0
e659cc48-ee11-48ef-8a3a-7d628307e798	t	Busunzu	23965fcc-fe5c-4536-8bd0-d58f03fd0294
67713534-fcd0-4cb4-98b2-52b862a581f4	t	Gaseke	23965fcc-fe5c-4536-8bd0-d58f03fd0294
73bb030b-7183-4879-b4dd-3b1e79a4b828	t	Kabaya	23965fcc-fe5c-4536-8bd0-d58f03fd0294
5c77f2b7-bb57-422c-8a93-917e72a6595f	t	Mwendo	23965fcc-fe5c-4536-8bd0-d58f03fd0294
a3445f1f-2c66-4363-b7c8-14156dd12a0b	t	Ngoma	23965fcc-fe5c-4536-8bd0-d58f03fd0294
abb86429-4372-44d6-bbbf-0e46b4aa7375	t	Nyenyeri	23965fcc-fe5c-4536-8bd0-d58f03fd0294
a9693b4d-acb0-47a6-b602-18ab910906b9	t	Kageshi	603c45e5-c473-444a-8ec2-a7613b0cb900
1d4060e4-1826-481b-a3e8-26ff00c9331f	t	Mukore	603c45e5-c473-444a-8ec2-a7613b0cb900
112bc3b4-87ca-4539-9eef-508b8a09ff62	t	Muramba	603c45e5-c473-444a-8ec2-a7613b0cb900
9aeb455a-8d90-4e2f-8281-56d350f81eb0	t	Nyamata	603c45e5-c473-444a-8ec2-a7613b0cb900
02ef05d2-eda2-4e02-b456-1e7817ebf401	t	Rwamamara	603c45e5-c473-444a-8ec2-a7613b0cb900
e636fd0a-eaab-45c9-ab2f-4fb541286409	t	Birembo	ac3179c9-9654-468a-bf16-6b2a85ff689b
ca9ca699-960b-4885-a953-a9810e984ee8	t	Gitwa	ac3179c9-9654-468a-bf16-6b2a85ff689b
6500bd67-ecef-4bb2-8f86-3c0add773842	t	Murinzi	ac3179c9-9654-468a-bf16-6b2a85ff689b
0b22a1a4-0283-4ab9-860d-2544a957c4e7	t	Nyamugeyo	ac3179c9-9654-468a-bf16-6b2a85ff689b
18be4ae8-5597-4a1e-8868-98282d0f81ea	t	Rugeshi	ac3179c9-9654-468a-bf16-6b2a85ff689b
e5e90259-8993-45d9-99e1-82a190025fb3	t	Tetero	ac3179c9-9654-468a-bf16-6b2a85ff689b
4d6f6348-cee0-467b-99b2-e12d36464642	t	Binana	3916bd06-bf74-43dd-a29e-689f0d3dfbe6
a510f891-bcd1-469e-93e6-46ea3e893f35	t	Gitega	3916bd06-bf74-43dd-a29e-689f0d3dfbe6
f8505d8b-646e-4f96-9acd-2afef346d2a4	t	Matare	3916bd06-bf74-43dd-a29e-689f0d3dfbe6
85c0102c-e1a5-4f34-9194-c70dc1fd8551	t	Rutare	3916bd06-bf74-43dd-a29e-689f0d3dfbe6
7ee4ce06-fab5-4b58-9e01-ed84141009ca	t	Rwamiko	3916bd06-bf74-43dd-a29e-689f0d3dfbe6
e90389b3-7d62-4d2c-bb97-9b6bd6ebc0fc	t	Bugarura	960d39de-1837-436a-920f-dab9c072a63c
3fb18cbd-9962-491a-8ed3-bea12a8642e9	t	Gasiza	960d39de-1837-436a-920f-dab9c072a63c
9a209c5f-04aa-46ef-83cf-cce1e790776b	t	Mashya	960d39de-1837-436a-920f-dab9c072a63c
4387a6e1-8c54-4921-b077-4ea46892cf86	t	Nganzo	960d39de-1837-436a-920f-dab9c072a63c
02bdd6ec-8800-4d0e-b2be-2af14b7d8529	t	Ngoma	960d39de-1837-436a-920f-dab9c072a63c
b6f88ab6-1e4c-44b1-9d5b-7c12beb7c0f0	t	Rutagara	960d39de-1837-436a-920f-dab9c072a63c
3a05f6a5-3337-4457-8618-781bdaffd530	t	Mubuga	eb36cc64-0291-4be7-beb4-8ec8527616a2
81ee50aa-0b6e-420b-9422-f14fda982054	t	Rugogwe	eb36cc64-0291-4be7-beb4-8ec8527616a2
10f3fa04-8e18-4032-a9de-0d4d7a236d7a	t	Rusororo	eb36cc64-0291-4be7-beb4-8ec8527616a2
94262c17-86cf-415f-a088-fb3e6e179770	t	Sanza	eb36cc64-0291-4be7-beb4-8ec8527616a2
6ca9a516-b29c-4416-b3eb-d6ea1cc6e9b8	t	Bijyojyo	2f1e0f0f-200f-48d8-9ac6-225735d4d813
f0c4b0bb-a02e-4d16-bca7-6ff623a9c8ce	t	Bitabage	2f1e0f0f-200f-48d8-9ac6-225735d4d813
038a6745-fd96-4ebb-bc33-d2893e9cc3a8	t	Kabageshi	2f1e0f0f-200f-48d8-9ac6-225735d4d813
b11a0d8e-5fe1-458b-a99e-8a9d15d87f7f	t	Kibanda	2f1e0f0f-200f-48d8-9ac6-225735d4d813
254de8de-08b5-498f-a9fb-9ac350ea3e6b	t	Kinyovi	2f1e0f0f-200f-48d8-9ac6-225735d4d813
5b43e7a4-618b-44ca-8efb-3dc6dc312938	t	RKaseke	037704ca-a246-4148-b76d-05724117e827
efbe40bd-0ac9-43a7-a827-38ddec500537	t	RKazabe	037704ca-a246-4148-b76d-05724117e827
6f7e5ac3-865d-40f3-b892-a65ddeb6a5f4	t	RMugano	037704ca-a246-4148-b76d-05724117e827
a984ec7d-92fe-4003-abfb-708130dd08a7	t	RRususa	037704ca-a246-4148-b76d-05724117e827
27b7b308-640f-4e68-b890-b30ee32e0b2b	t	RTorero	037704ca-a246-4148-b76d-05724117e827
3c5eb52b-2092-4bd9-8d9f-c9967d416556	t	Bambiro	b6b9d12d-2321-4025-93a2-623beb2a44e6
39fcafd2-511f-4137-bffb-97b8a7d37127	t	Gaseke	b6b9d12d-2321-4025-93a2-623beb2a44e6
e5a8966f-eeeb-45a9-a21d-7f6e8834a0a3	t	Nsibo	b6b9d12d-2321-4025-93a2-623beb2a44e6
c60cb082-c02e-476d-9ae4-ef4cf8804a10	t	Vuganyana	b6b9d12d-2321-4025-93a2-623beb2a44e6
26c9ef73-1468-4cbc-9f67-46e5952994de	t	Birembo	8deb2942-40cf-4ea9-8bef-5dce04371026
2d0fbb8a-6358-4f18-a1b6-ec2730462158	t	Kagano	8deb2942-40cf-4ea9-8bef-5dce04371026
2c3d0d5c-2f9d-43bb-b409-84b36eeba849	t	Nyabipfura	8deb2942-40cf-4ea9-8bef-5dce04371026
c57b6210-d8f4-4cc7-982c-f1c3de92a4f4	t	Arusha	f0e8fe31-82ee-4e76-a488-1ed1dbc5b58b
23603f8e-5080-45b6-a60f-fc0fe9c18ffd	t	Basumba	f0e8fe31-82ee-4e76-a488-1ed1dbc5b58b
fb1c8ac6-a7e3-48f7-afa3-827d0b155bfb	t	Kijote	f0e8fe31-82ee-4e76-a488-1ed1dbc5b58b
9ff34bdd-ec6f-49f3-8e06-98f8f2068557	t	Kora	f0e8fe31-82ee-4e76-a488-1ed1dbc5b58b
c44b3e8d-8e42-46aa-b3f8-4f13cff30361	t	Muhe	f0e8fe31-82ee-4e76-a488-1ed1dbc5b58b
99194158-59a8-453d-a7ee-0af09c7636f8	t	Rega	f0e8fe31-82ee-4e76-a488-1ed1dbc5b58b
a11f4f70-1875-4861-bf54-e0056f93fe23	t	Bukinanyana	7c045500-e163-4d9e-a16f-7f78b267def5
dc0a1308-fb25-4a9f-8b0c-3c425517c2cc	t	Gasizi	7c045500-e163-4d9e-a16f-7f78b267def5
ec5d5472-7151-4c49-a767-5ad3e31e8dd2	t	Kabatezi	7c045500-e163-4d9e-a16f-7f78b267def5
6cb64c1d-8b54-4470-a9da-8d2db888cd29	t	Kareba	7c045500-e163-4d9e-a16f-7f78b267def5
9f626d6e-2fe9-416a-8d2b-4577e0a6eec8	t	Nyirakigugu	7c045500-e163-4d9e-a16f-7f78b267def5
7e64fec9-e35b-4c6e-b73f-5b1cadf1dc31	t	Rega	7c045500-e163-4d9e-a16f-7f78b267def5
39afb0ec-5d0b-4f61-a493-8685c2573ec4	t	Gasiza	b3c876f0-9e9c-49ff-8aea-2b1e8affc36d
09f43ea5-34c9-467b-ba28-7d8f0548dd7e	t	Gasura	b3c876f0-9e9c-49ff-8aea-2b1e8affc36d
be4b7a03-9e2e-4f59-b99a-ba8e66032942	t	Gisizi	b3c876f0-9e9c-49ff-8aea-2b1e8affc36d
55e16192-ffe7-4a4b-b53f-09225713ada8	t	Guriro	b3c876f0-9e9c-49ff-8aea-2b1e8affc36d
e417739d-0e57-40e0-879a-c99f9694750c	t	Kavumu	b3c876f0-9e9c-49ff-8aea-2b1e8affc36d
ce71c23d-f419-4a65-a2ff-4f9dcaebf785	t	Nyamitanzi	b3c876f0-9e9c-49ff-8aea-2b1e8affc36d
e8bcbcf0-8c3c-4d56-a6d3-b8d6b5a0fd89	t	Batikoti	bdd48167-3708-47c8-99ee-38088e7bf3ce
4811cf04-48ee-4a66-8546-38f1bfcaf799	t	Cyamvumba	bdd48167-3708-47c8-99ee-38088e7bf3ce
35fb5aeb-3f7a-403b-b9c1-08847de2b9bf	t	Gihorwe	bdd48167-3708-47c8-99ee-38088e7bf3ce
4eda8bc3-b564-48fb-bcb1-6295890a46f7	t	Myuga	bdd48167-3708-47c8-99ee-38088e7bf3ce
6177382b-0c30-4842-a732-46da8126a510	t	Ngando	bdd48167-3708-47c8-99ee-38088e7bf3ce
7c6e62f0-9236-48dd-b2ad-0fee17f46c63	t	Rugarama	bdd48167-3708-47c8-99ee-38088e7bf3ce
b2cce3ab-4771-4652-87a0-c0fa82bf560a	t	Cyamabuye	91609478-5e71-4c51-8f15-d157f857e281
a3ca0281-3230-470c-8e2c-08df206cd144	t	Gihirwa	91609478-5e71-4c51-8f15-d157f857e281
593b6208-501b-414e-b5f5-1c314965d476	t	Kadahenda	91609478-5e71-4c51-8f15-d157f857e281
20da6224-5075-4786-a815-1623692ad4da	t	Rukondo	57607db9-256e-4892-877a-c613cf1d57d7
2f4b1110-6349-4ea8-ab0e-b813c69a80d5	t	Gasizi	2ceb096e-2c7d-4c6b-8f4b-82ababac91c6
795a57f2-3705-4561-87ad-72604518eb6a	t	Jaba	2ceb096e-2c7d-4c6b-8f4b-82ababac91c6
bc6d3888-1544-453d-a91c-f05c170a88bb	t	Kanyove	2ceb096e-2c7d-4c6b-8f4b-82ababac91c6
7596791a-b05a-4537-8e48-f9999d4cf995	t	Rubaya	2ceb096e-2c7d-4c6b-8f4b-82ababac91c6
16b363ee-0f87-4fda-a18c-7cd1d794296b	t	Rugeshi	2ceb096e-2c7d-4c6b-8f4b-82ababac91c6
5881aa54-e10d-4bf7-831c-18b2a43e644f	t	Rurengeri	2ceb096e-2c7d-4c6b-8f4b-82ababac91c6
8bbea048-1bb6-4a50-a42c-214d7e6d45e3	t	Gisizi	fa29754b-84ea-4aae-bef9-9691f00e0b85
785a9524-bd2a-48ef-b7d0-b0414bd5cbb9	t	Mulinga	fa29754b-84ea-4aae-bef9-9691f00e0b85
93d72785-8679-4690-a4e4-be5afaecb085	t	Mwiyanike	fa29754b-84ea-4aae-bef9-9691f00e0b85
94324c6f-b52c-40e1-820a-81cf71f723d9	t	Nkomane	fa29754b-84ea-4aae-bef9-9691f00e0b85
78f34c32-65ad-4354-a6d4-cecdec7e8e3e	t	Nyamasheke	fa29754b-84ea-4aae-bef9-9691f00e0b85
34a99935-8e62-46dd-8902-a52155c4ee32	t	Rwantobo	fa29754b-84ea-4aae-bef9-9691f00e0b85
2e06f4b8-9642-44a6-ae6a-a83e514e2a3d	t	Birembo	75b6e3fa-25a8-4e80-9735-5f18aad5dad8
7fdd2752-1b04-4a0f-8854-cad3951a3948	t	Kibisabo	75b6e3fa-25a8-4e80-9735-5f18aad5dad8
1e88f35d-607f-4c3f-bffe-f272363d86b9	t	Mutaho	75b6e3fa-25a8-4e80-9735-5f18aad5dad8
89fb280f-7deb-4a52-8e1f-154476d64d14	t	Nyundo	75b6e3fa-25a8-4e80-9735-5f18aad5dad8
0f8eda98-f64c-4af6-949d-105b03d22a40	t	Rugamba	75b6e3fa-25a8-4e80-9735-5f18aad5dad8
89b06d1b-b065-492d-8ad3-0038ec60e08e	t	Gakoro	31865536-efc2-48d1-90cd-f389f043ba62
41800604-c84f-48ec-a481-d471e5918fd4	t	Nyagahondo	31865536-efc2-48d1-90cd-f389f043ba62
6763039a-65cb-4f5d-b672-ccb4091d003a	t	Nyarutembe	31865536-efc2-48d1-90cd-f389f043ba62
da61cc04-5278-4537-b25b-a75321d1c434	t	Rurembo	31865536-efc2-48d1-90cd-f389f043ba62
88ad1d02-dba6-4db4-ac0a-04d7ac29e9b6	t	Tyazo	31865536-efc2-48d1-90cd-f389f043ba62
9ce690c1-e718-4da8-a3cd-d754819ab663	t	Gitega	b97251c1-d584-469e-9b27-924cf5fc8578
806520cd-4b6d-4605-bdf1-16c5dbe151df	t	Murambi	b97251c1-d584-469e-9b27-924cf5fc8578
fd77533d-35a0-42f0-b664-87a0258e9f0e	t	Mwana	b97251c1-d584-469e-9b27-924cf5fc8578
8f202e5d-cbb3-4d8a-a8ac-e0c81c200436	t	Rwaza	b97251c1-d584-469e-9b27-924cf5fc8578
d92ed8de-305d-400e-8fdd-96ec27ae336a	t	Cyimanzovu	35aaeb95-8ae7-40ae-819f-80a78c318957
3fd9abe2-8d4f-4317-a9d0-65524bc101cf	t	Kanyamitana	35aaeb95-8ae7-40ae-819f-80a78c318957
d23c20bd-d72a-4995-b5ea-0e6458e6121e	t	Kintarure	35aaeb95-8ae7-40ae-819f-80a78c318957
94237609-fbc8-4eb8-89d6-12877e0319fe	t	Mpinga	35aaeb95-8ae7-40ae-819f-80a78c318957
611f74a4-b9d8-4f80-ac72-b0ca1326a5a8	t	Mutanda	35aaeb95-8ae7-40ae-819f-80a78c318957
b8c76a83-783b-4c7b-aea4-a3b17ad1645a	t	Shaki	35aaeb95-8ae7-40ae-819f-80a78c318957
fe3c3e87-ec07-44f8-b328-aa631ae9ddbe	t	Buvungira	0c15012c-bc73-43d7-b87c-e9ebbcc715bb
f37bc102-2ca0-40d5-96e7-60335886ba26	t	Nyarusange	0c15012c-bc73-43d7-b87c-e9ebbcc715bb
c8f47213-cee0-4e88-8d89-adaaaf6b9fbf	t	Gasheke	1c96345c-cfae-4fb1-b283-b186708793dd
601a6c2b-c97c-4004-bee5-7f90b7f3c777	t	Impala	1c96345c-cfae-4fb1-b283-b186708793dd
676c88fe-0abb-40df-ac92-826645885e2b	t	Kagatamu	1c96345c-cfae-4fb1-b283-b186708793dd
0a434d0f-fadb-42b6-87d0-6fdeee734a24	t	Karusimbi	1c96345c-cfae-4fb1-b283-b186708793dd
3d031c18-4e80-496e-8952-fa306c20c301	t	Murambi	34c88d06-7bca-4eba-8c14-d03868e63d10
b3664ee6-7797-4fdc-bdda-229a1ee0848e	t	Mutongo	34c88d06-7bca-4eba-8c14-d03868e63d10
bd47c359-a342-4bf3-9443-ae926cb4be8b	t	Butare	ba40d50f-5034-4e48-8e51-3c0940b898b1
a9903b8e-513f-478e-9b26-dc0c3e6bff3c	t	Gitwa	ba40d50f-5034-4e48-8e51-3c0940b898b1
a9516b92-a71d-43ce-bc82-25f7724ddf15	t	Jarama	ba40d50f-5034-4e48-8e51-3c0940b898b1
0ce7e40b-5158-4635-80c6-58ec3964263a	t	Kibingo	ba40d50f-5034-4e48-8e51-3c0940b898b1
e767b78e-2eaa-4164-98b0-968595de4d6d	t	Mubuga	ba40d50f-5034-4e48-8e51-3c0940b898b1
a4c6c532-209d-4e77-90ff-d760220395b1	t	Gako	8fae484d-ed53-47c2-bef3-752b5b9c5041
1e7a9731-2e6b-413a-a2ca-9688fa4e6e67	t	Mubumbano	8fae484d-ed53-47c2-bef3-752b5b9c5041
bd04897e-0f0d-479b-9c90-0bf7db780a9d	t	Ninzi	8fae484d-ed53-47c2-bef3-752b5b9c5041
58dca7d0-9ab1-4c87-8792-80047528dd67	t	Rwesero	8fae484d-ed53-47c2-bef3-752b5b9c5041
eced6135-4535-475c-b5e6-02ae59ba8050	t	Shara	8fae484d-ed53-47c2-bef3-752b5b9c5041
b97d13f8-0046-4f52-b5b7-c45de6ecb37e	t	Kibogora	a78a269e-ebfb-4245-a8d9-dea4ae0093c7
d4e85e5c-f39e-46f3-b48e-e8aa48d13fd2	t	Kigarama	a78a269e-ebfb-4245-a8d9-dea4ae0093c7
4ff511e3-9c25-42dd-8ad0-32a01f2d0dbe	t	Kigoya	a78a269e-ebfb-4245-a8d9-dea4ae0093c7
183533f2-d963-450b-a8f0-42c3d2ff550e	t	Raro	a78a269e-ebfb-4245-a8d9-dea4ae0093c7
5d77062e-9125-407e-b3dd-59b835a26e72	t	Susa	a78a269e-ebfb-4245-a8d9-dea4ae0093c7
00a80437-75fe-43aa-9c3b-8614be7da055	t	Gasovu	fa2b020c-6469-42aa-bbac-b48d7ef0610f
5d108697-761c-439b-983b-cae735c65365	t	Kabuga	fa2b020c-6469-42aa-bbac-b48d7ef0610f
0ff77264-9fa1-499d-859e-684ea019e0f2	t	Kagarama	fa2b020c-6469-42aa-bbac-b48d7ef0610f
32e38a6e-dda0-4b06-9694-1d2f4e1ca62a	t	Rushyarara	fa2b020c-6469-42aa-bbac-b48d7ef0610f
bc79cf8f-2af9-459c-80a9-47dd01e876ef	t	Gasayo	fdd86016-c6a1-4bbc-bae8-42644113bb08
f5edb227-9297-40fa-98c9-24ea604fefba	t	Gashashi	fdd86016-c6a1-4bbc-bae8-42644113bb08
683ae5b0-b648-4136-a72e-f879a696ba3d	t	Higiro	fdd86016-c6a1-4bbc-bae8-42644113bb08
1cce383e-5e3d-4526-9598-65873fb79f2e	t	Miko	fdd86016-c6a1-4bbc-bae8-42644113bb08
add2333c-f6ac-4741-91d0-8c5ad8156abd	t	Mwezi	fdd86016-c6a1-4bbc-bae8-42644113bb08
37585658-0b1f-4ee8-bcb1-346ee205efba	t	Cyimpindu	a6a41a87-58fd-4c50-938f-1da748e0bbbb
6e36f2c6-d328-4adc-b5a0-0e08a1c2fc0e	t	Karengera	a6a41a87-58fd-4c50-938f-1da748e0bbbb
a75d72f9-4acd-4d66-9a7d-a0d2c78dcdcf	t	Nyarusange	a6a41a87-58fd-4c50-938f-1da748e0bbbb
b7940bb0-f13d-4ec8-b4f0-5e161b821b0d	t	Gatare	3dbfa027-a5c4-46e0-9b8f-0bd870fa9a86
61470d11-9d1e-4dca-973a-4c50960f908b	t	Mutongo	3dbfa027-a5c4-46e0-9b8f-0bd870fa9a86
98024a17-44f3-4833-8185-1940e0388ebb	t	Nyakabingo	3dbfa027-a5c4-46e0-9b8f-0bd870fa9a86
6340b9ed-b34b-4106-8017-bd69b5b168fc	t	Rugari	3dbfa027-a5c4-46e0-9b8f-0bd870fa9a86
e31a4fd7-743f-45cc-a203-168dad4e6395	t	Vugangoma	3dbfa027-a5c4-46e0-9b8f-0bd870fa9a86
b4220075-5256-482b-8b6e-1f67b01a6e44	t	Gisoke	de422ab3-9d5a-406f-8d69-9b1a7480f0ec
b38b1874-6b15-4b35-81f0-aaaa4816ad5e	t	Kagarama	de422ab3-9d5a-406f-8d69-9b1a7480f0ec
e653d43b-7385-4d07-98fe-9e4e7cfd94b7	t	Nyagatare	de422ab3-9d5a-406f-8d69-9b1a7480f0ec
803ad87b-3851-4afb-9861-1b29142fdafa	t	Nyakavumu	de422ab3-9d5a-406f-8d69-9b1a7480f0ec
e9d27c59-17a8-4106-bd2f-ec9fc4f3558b	t	Kigabiro	e71ad559-76b7-4eb1-8081-4c782072d478
b7372b90-ee30-4df7-bae0-6d57c9298b6d	t	Kinunga	e71ad559-76b7-4eb1-8081-4c782072d478
e30256a3-ae46-4623-a9a0-c17e2d8851fa	t	Mariba	e71ad559-76b7-4eb1-8081-4c782072d478
f858803f-6f75-43c2-8c1c-997ce15d3f92	t	Muyange	e71ad559-76b7-4eb1-8081-4c782072d478
b53c04c2-2091-4c5d-bbe4-e791a35b5e7b	t	Ntango	e71ad559-76b7-4eb1-8081-4c782072d478
d0e6e6ed-f7bd-4a5a-a9e0-5e2d0e580eb2	t	Jurwe	443d2833-d9a6-404f-ad3f-dc9fa6bb4580
b5912a28-9e3f-463c-9fd3-89781613b4cb	t	Murambi	443d2833-d9a6-404f-ad3f-dc9fa6bb4580
63ae5c7d-3f0c-46e9-9b26-86abbc24182f	t	Kanazi	bd98ecf7-f502-432c-8dc8-7b9a7ba8d773
112b0f94-debf-4622-837b-13acd0c710a6	t	Ntendezi	bd98ecf7-f502-432c-8dc8-7b9a7ba8d773
0e61c404-fd73-47ed-a8f6-0bb8e82774de	t	Save	bd98ecf7-f502-432c-8dc8-7b9a7ba8d773
8f125b74-7e48-4f47-a441-d4935f800447	t	Wimana	bd98ecf7-f502-432c-8dc8-7b9a7ba8d773
13f209f3-944a-4c60-b479-9d86510c2c22	t	Burimba	9663600e-fb25-427e-b533-ef0348c5d887
fd9f6cc5-f2b6-4443-84dd-b893de9e8a7f	t	Mataba	9663600e-fb25-427e-b533-ef0348c5d887
13007d5e-18a6-4560-b6b8-c9445427c261	t	Mugera	9663600e-fb25-427e-b533-ef0348c5d887
ad0b62d3-06ab-4504-b78d-5fc7b9c01aaa	t	Nyamugari	9663600e-fb25-427e-b533-ef0348c5d887
625250ac-f81c-4910-a009-70b1014eb782	t	Shangi	9663600e-fb25-427e-b533-ef0348c5d887
f0aef44c-2614-4c18-95e8-f706587a49f9	t	Buringo	fdbc9437-65d4-4c6d-8a3b-aa6f8f6b398b
ca12dcb3-bf11-491b-92d0-952fe15fd60d	t	Butaka	fdbc9437-65d4-4c6d-8a3b-aa6f8f6b398b
d02a2295-4ee4-4717-b8a8-ad4191ff6311	t	Hehu	fdbc9437-65d4-4c6d-8a3b-aa6f8f6b398b
66e2291a-5583-467c-8eb1-bd96f5195d6d	t	Kabumba	fdbc9437-65d4-4c6d-8a3b-aa6f8f6b398b
64737479-7b11-46dd-ab76-5e81de0b548a	t	Mutovu	fdbc9437-65d4-4c6d-8a3b-aa6f8f6b398b
3fe3107d-0849-4261-85b0-6efa3a6dadd2	t	Nsherima	fdbc9437-65d4-4c6d-8a3b-aa6f8f6b398b
47a3d96c-412e-4bee-82f3-62666379dfa6	t	Rusiza	fdbc9437-65d4-4c6d-8a3b-aa6f8f6b398b
046b13ef-539f-4f5d-9bc2-13386043a6f8	t	Gacurabwenge	baf0825b-5e00-45b1-93d8-5d2893eeaefa
f50f84b7-bd30-426f-a701-2b7af50e5639	t	Gasiza	baf0825b-5e00-45b1-93d8-5d2893eeaefa
f8620234-37f7-4d21-8a36-fb2d092ad3df	t	Gihonga	baf0825b-5e00-45b1-93d8-5d2893eeaefa
e1a360c0-b3db-4eb7-971c-03e22303e4f5	t	Kageshi	baf0825b-5e00-45b1-93d8-5d2893eeaefa
0b8be820-541c-4130-8f72-c4fa35a74636	t	Makoro	baf0825b-5e00-45b1-93d8-5d2893eeaefa
9549337f-64b3-457a-9c49-5f08194bbf96	t	Nyacyonga	baf0825b-5e00-45b1-93d8-5d2893eeaefa
3944c94e-b7a8-4b47-9d09-ed915a6778c7	t	Rusura	baf0825b-5e00-45b1-93d8-5d2893eeaefa
b2516476-691c-4258-afa5-234c7aebd602	t	Busigari	1d6da4bf-0f65-40bf-9ba3-53f85b27c5e9
95d542e9-96ef-49e7-b876-50e670a42bf8	t	Cyanzarwe	1d6da4bf-0f65-40bf-9ba3-53f85b27c5e9
0afb2c0e-0f47-4e89-bc00-2471d15c7a7b	t	Gora	1d6da4bf-0f65-40bf-9ba3-53f85b27c5e9
a010d84d-2c98-424f-af42-2cfa3f69e788	t	Kinyanzovu	1d6da4bf-0f65-40bf-9ba3-53f85b27c5e9
8a497a5b-f961-4cf9-acf8-3266a7de403d	t	Makurizo	1d6da4bf-0f65-40bf-9ba3-53f85b27c5e9
51c8f2a9-982d-4702-a640-9b351b2e68b1	t	Rwangara	1d6da4bf-0f65-40bf-9ba3-53f85b27c5e9
cb44bf3a-17c5-4e11-a75d-c47eaf70a7f6	t	Rwanzekuma	1d6da4bf-0f65-40bf-9ba3-53f85b27c5e9
acf32b9b-c703-473b-ae0f-98b7b65e7e6d	t	Ryabizige	1d6da4bf-0f65-40bf-9ba3-53f85b27c5e9
07c29d23-6d19-41d1-bb9b-67c0ee5ebe69	t	Amahoro	acb3fdb9-431e-4deb-9699-0f5042632921
bc7a7cdf-2430-458d-9287-d34a6424bd3b	t	Bugoyi	acb3fdb9-431e-4deb-9699-0f5042632921
17abf15e-f3c3-42cc-865e-f7ad96eff72b	t	Kivumu	acb3fdb9-431e-4deb-9699-0f5042632921
05e3c14f-16ff-41b4-99ec-4dc454cb5078	t	Mbugangari	acb3fdb9-431e-4deb-9699-0f5042632921
19ac3dda-5423-48e2-b80b-0625761514b5	t	Nengo	acb3fdb9-431e-4deb-9699-0f5042632921
1f168d3e-f4c2-4347-91b5-f4f48bb8d97d	t	Rubavu	acb3fdb9-431e-4deb-9699-0f5042632921
d984bf69-35ae-4c94-84ef-a8258b691b0e	t	Umuganda	acb3fdb9-431e-4deb-9699-0f5042632921
cba7b5ad-b1f0-486d-921f-0760ae980df2	t	Kamuhoza	57150771-4ce4-4d0d-a359-db7a3d781324
d3f31190-fd7e-4919-adfb-269adf9bc8b2	t	Karambo	57150771-4ce4-4d0d-a359-db7a3d781324
fd14a4ea-49c3-493b-90ad-493384e229da	t	Mahoko	57150771-4ce4-4d0d-a359-db7a3d781324
ec5be326-4da6-4d21-8199-df85b363de0a	t	Musabike	57150771-4ce4-4d0d-a359-db7a3d781324
ce2c7d7f-e68e-4bd6-9e01-a08444791616	t	Nkomane	57150771-4ce4-4d0d-a359-db7a3d781324
85218469-472d-475f-b589-128ef51f72a9	t	Rusongati	57150771-4ce4-4d0d-a359-db7a3d781324
07777457-d44b-4128-9363-416b113e6a09	t	Yungwe	57150771-4ce4-4d0d-a359-db7a3d781324
2e71e202-6e2b-4435-8fd1-fd0b2aa3e610	t	Kanyirabigogo	cb414f4e-1937-4dc4-9445-bf6b6a68c9dd
19ea61a2-bea8-4799-94da-5551736b9a0e	t	Kirerema	cb414f4e-1937-4dc4-9445-bf6b6a68c9dd
9076588e-549c-4e10-8196-cb88fdad79dc	t	Nyamikongi	cb414f4e-1937-4dc4-9445-bf6b6a68c9dd
eb5a6b5e-abc4-41f7-af22-531c3b2c85a0	t	Nyamirango	cb414f4e-1937-4dc4-9445-bf6b6a68c9dd
3d322349-a72e-4e63-b2db-56ccaf5a038f	t	Nyaruteme	cb414f4e-1937-4dc4-9445-bf6b6a68c9dd
f6c669d5-b65c-4fdf-abf7-d42bf3ef7a58	t	Bihungwe	b99eecbe-3781-4a9f-95d8-3eff74a06a2a
6f82bb92-0ce5-499f-8849-bf9e8e92863b	t	Kanyundo	b99eecbe-3781-4a9f-95d8-3eff74a06a2a
29a1a435-545d-4811-889d-63ae6ddd53ad	t	Micinyiro	b99eecbe-3781-4a9f-95d8-3eff74a06a2a
cd9f5085-2fd5-4e0f-988c-3d1c0e715de5	t	Mirindi	b99eecbe-3781-4a9f-95d8-3eff74a06a2a
c41d6fcd-ab21-4cd9-bfda-b339e353154a	t	Ndoranyi	b99eecbe-3781-4a9f-95d8-3eff74a06a2a
083ecedb-6826-4e3e-ae71-c15a91f37d8b	t	Rungu	b99eecbe-3781-4a9f-95d8-3eff74a06a2a
fb43a00e-e68c-4407-842d-d65f32a2feed	t	Rwanyakayaga	b99eecbe-3781-4a9f-95d8-3eff74a06a2a
d2478036-0056-48c6-9475-c777552a12bc	t	Bisizi	c102aa5d-39ef-4127-aa3d-1a1b39144aeb
994c0e51-8f0b-41a3-acd1-e5f10a275cec	t	Gikombe	c102aa5d-39ef-4127-aa3d-1a1b39144aeb
d3e40b7e-af43-427c-9aa8-475fca49efa8	t	Kanyefurwe	c102aa5d-39ef-4127-aa3d-1a1b39144aeb
28b1dbd8-d6f6-426f-8655-213b8e418026	t	Nyarushyamba	c102aa5d-39ef-4127-aa3d-1a1b39144aeb
53c6c763-ec05-4b8c-9786-f86f06394fea	t	Burushya	6b67e86a-d919-4364-8fb5-0f81ebe7d912
03c8ba3d-4fff-4f95-9d3e-2bd0b03806f4	t	Busoro	6b67e86a-d919-4364-8fb5-0f81ebe7d912
e0f1fe25-c33f-4083-9166-9f5930e5cd92	t	Kinigi	6b67e86a-d919-4364-8fb5-0f81ebe7d912
99ad7e71-4b25-4d4c-a4f2-d8d8003cfd5c	t	Kiraga	6b67e86a-d919-4364-8fb5-0f81ebe7d912
dce72dfd-b523-4494-8294-e632eeabb39e	t	Munanira	6b67e86a-d919-4364-8fb5-0f81ebe7d912
8bdd1e92-bccb-4b4d-ad77-10a2544263f6	t	Rubona	6b67e86a-d919-4364-8fb5-0f81ebe7d912
e775cb07-a792-4652-a06e-439a31806b14	t	Bahimba	d5cd644c-2f50-4463-98dd-38c29f125b9f
50689146-b7a0-49ef-920b-caaacf5ce1f1	t	Gatovu	d5cd644c-2f50-4463-98dd-38c29f125b9f
2f67b846-8cdb-4077-8f4b-8060117a7555	t	Kavomo	d5cd644c-2f50-4463-98dd-38c29f125b9f
7372b477-f7ef-45f9-93c7-7ffd03acbf5e	t	Kigarama	d5cd644c-2f50-4463-98dd-38c29f125b9f
9abe4384-2581-4046-b777-30ca972fbbcb	t	Mukondo	d5cd644c-2f50-4463-98dd-38c29f125b9f
4b23c811-d320-476e-afbb-ed7c42d7b36c	t	Nyundo	d5cd644c-2f50-4463-98dd-38c29f125b9f
5b1d1449-b5cc-4981-a29b-141abc85b85f	t	Terimbere	d5cd644c-2f50-4463-98dd-38c29f125b9f
a240105f-2343-44d8-af07-30fa01de47e2	t	Buhaza	71267c4e-21ee-4953-a803-c16e5f00d94d
8fb5a8cf-7501-4412-9557-1000cb5dd969	t	Burinda	71267c4e-21ee-4953-a803-c16e5f00d94d
609c9180-2d39-4765-91cb-117d1481ee01	t	Byahi	71267c4e-21ee-4953-a803-c16e5f00d94d
9ac16377-66b4-40f8-a062-2df9e206e0c0	t	Gikombe	71267c4e-21ee-4953-a803-c16e5f00d94d
bf15291c-2992-4366-b8dd-850395234022	t	Murambi	71267c4e-21ee-4953-a803-c16e5f00d94d
14d35cd1-968c-4b11-a41f-ee1f40bc512e	t	Murara	71267c4e-21ee-4953-a803-c16e5f00d94d
04ae368e-7a94-4d77-be33-6ef0809f73c0	t	Rukoko	71267c4e-21ee-4953-a803-c16e5f00d94d
95db6b75-8f30-4f20-ac21-06ab76886c4c	t	Basa	30100b4a-372a-4185-858a-730c4e8aec67
9ee47418-1846-4895-bed9-f339f1f6fbac	t	Gisa	30100b4a-372a-4185-858a-730c4e8aec67
00c4dd27-c15d-474a-940b-190f06f40202	t	Kabilizi	30100b4a-372a-4185-858a-730c4e8aec67
9a7548f6-f72d-4085-a8c1-67efa0585d28	t	Muhira	30100b4a-372a-4185-858a-730c4e8aec67
08847e4a-7966-42bf-9ede-caa0c2ae0d4e	t	Rugerero	30100b4a-372a-4185-858a-730c4e8aec67
301c0653-74d5-4339-b3c7-2ca4c7a3869f	t	Rushubi	30100b4a-372a-4185-858a-730c4e8aec67
d05650e5-1d3b-49bd-af9b-66034f4041ac	t	Rwaza	30100b4a-372a-4185-858a-730c4e8aec67
bb7b6e4e-53ea-45c8-b9c9-94a1d4592b55	t	Nyange	c488b8ad-4789-4958-ae7c-cf78e61c564f
a56f8700-1d62-4f2e-ba01-d6d407e51751	t	Pera	c488b8ad-4789-4958-ae7c-cf78e61c564f
b2ebee26-a2de-42f7-b812-857ad241a5b8	t	Ryankana	c488b8ad-4789-4958-ae7c-cf78e61c564f
d3442f98-1aa8-4588-92ca-5dfb76e5482e	t	Butanda	929a8634-d37d-4cd2-b911-882dc3427616
b7c4c55e-6d30-4538-b4a8-3cc19e7386cb	t	Gatereri	929a8634-d37d-4cd2-b911-882dc3427616
ec9f4588-765e-43c4-858a-2a8548a011e8	t	Nyamihanda	929a8634-d37d-4cd2-b911-882dc3427616
8fe3be73-f5a7-4170-8b8a-794e64fcecc7	t	Rwambogo	929a8634-d37d-4cd2-b911-882dc3427616
9961911b-a226-42b7-b13a-8ed406d7988a	t	Gikungu	51aead6f-b42d-4ba9-b15a-4676972e45a3
ec6d586b-a22a-4baf-be7c-60ff503baa1a	t	Kiyabo	51aead6f-b42d-4ba9-b15a-4676972e45a3
6279d3fc-1a27-4560-a442-69b66daafea2	t	Murwa	51aead6f-b42d-4ba9-b15a-4676972e45a3
0044600a-1bf1-4ebc-9bb5-df070006d9a0	t	Nyamuzi	51aead6f-b42d-4ba9-b15a-4676972e45a3
8e97ffa5-026a-4fad-b74f-5f14bc21b04d	t	Rasano	51aead6f-b42d-4ba9-b15a-4676972e45a3
b269f09c-2d61-4028-b72f-3e80d22994cb	t	Birembo	41b1e982-f892-4296-a763-59afde2cc604
7f901605-2ed7-44bb-bede-eba91541087a	t	Buhokoro	41b1e982-f892-4296-a763-59afde2cc604
5045f2ee-f455-4051-ae89-44d790ed9327	t	Kabakobwa	41b1e982-f892-4296-a763-59afde2cc604
8a96eb3a-0df8-4f20-8016-4a0dfe5f18c0	t	Kacyuma	41b1e982-f892-4296-a763-59afde2cc604
a4d0fae6-c0b0-458e-94ff-19eba840a195	t	Kamurehe	41b1e982-f892-4296-a763-59afde2cc604
d78897ea-87c2-4dec-b942-1dfabd029434	t	Karemereye	41b1e982-f892-4296-a763-59afde2cc604
a0cd7e69-682b-4bc7-b647-72443d9199ee	t	Muti	41b1e982-f892-4296-a763-59afde2cc604
1a820ecd-a0f6-458f-8e0a-692cf974fb27	t	Rusayo	41b1e982-f892-4296-a763-59afde2cc604
b961fe67-bb1f-41a1-a101-e1e21970408c	t	Cyendajuru	46163c74-8f0d-4617-9100-01e8f368fb52
a979f880-c762-4d18-95ea-ba5b7b093698	t	Gakomeye	46163c74-8f0d-4617-9100-01e8f368fb52
1e572898-2ca3-4e6a-916a-0059aae96a16	t	Giheke	46163c74-8f0d-4617-9100-01e8f368fb52
57ed43a2-dc2b-4326-975e-4268f9d24fd1	t	Kamashangi	46163c74-8f0d-4617-9100-01e8f368fb52
5cb4f129-a4f7-40aa-822d-b81997bf54c3	t	Kigenge	46163c74-8f0d-4617-9100-01e8f368fb52
950e8eb7-3114-47a6-97d3-f4ae0a5724bc	t	Ntura	46163c74-8f0d-4617-9100-01e8f368fb52
390db8f7-8c8d-4db2-8092-d29a4be8ae5a	t	Turambi	46163c74-8f0d-4617-9100-01e8f368fb52
bccf2b9a-9365-4438-97d8-30528f9f636a	t	Burunga	5f903826-7269-4c92-8d20-2a49e188030b
6f1a4590-f41d-4250-802a-e0a5412eac2c	t	Gatsiro	5f903826-7269-4c92-8d20-2a49e188030b
7f241109-05b0-4b08-84af-35044bffa1ea	t	Kagara	5f903826-7269-4c92-8d20-2a49e188030b
f25e3ea5-c283-4771-b77e-5c4d9bc6cd1a	t	Kamatita	5f903826-7269-4c92-8d20-2a49e188030b
f24b82d7-2eb4-4b52-b811-0fcdfb23e3b4	t	Shagasha	5f903826-7269-4c92-8d20-2a49e188030b
5c9d6080-4d34-4bc3-983b-52cf7f078008	t	Kizura	13d3eeab-8f86-4896-9eff-4e35edb45fcf
bf74a90a-09d8-4580-ba31-92519a64a47d	t	Mpinga	13d3eeab-8f86-4896-9eff-4e35edb45fcf
66d07483-7a68-403d-932d-3f11c88ceebe	t	Nyamigina	13d3eeab-8f86-4896-9eff-4e35edb45fcf
471654ec-d68e-4119-9b31-374707b67c1a	t	Cyingwa	6cbd0b79-8f73-41b9-96c4-475bf4042933
7301230b-a844-411e-ba96-f8700ed61469	t	Gahungeri	6cbd0b79-8f73-41b9-96c4-475bf4042933
bef97db3-4977-4c6f-b9c5-1d2d5604e348	t	Hangabashi	6cbd0b79-8f73-41b9-96c4-475bf4042933
5831d6a9-b0d3-450d-bb2c-a9a1c0a05222	t	Mashesha	6cbd0b79-8f73-41b9-96c4-475bf4042933
51dc72ca-7747-4344-967c-7dbd0387f236	t	Cyangugu	55bd4f74-6268-4d04-b505-8f520787acfe
5d0a239f-5479-47a2-8f77-e15e84492aa1	t	Gihundwe	55bd4f74-6268-4d04-b505-8f520787acfe
e867d99d-4b4c-4f1d-b3ed-c8c8aa6f5341	t	Kamashangi	55bd4f74-6268-4d04-b505-8f520787acfe
c2fdf37d-de33-4993-a084-b6bed04f56da	t	Kamurera	55bd4f74-6268-4d04-b505-8f520787acfe
eec6a513-9fae-4ded-910b-486abca7ccb7	t	Ruganda	55bd4f74-6268-4d04-b505-8f520787acfe
74759906-5247-48c8-b00b-415eebdeee42	t	Cyarukara	b174e6ff-1556-44ad-9959-3ad741251d6b
dba6aa22-a8f5-410a-96b3-33b123dd8742	t	Gakoni	b174e6ff-1556-44ad-9959-3ad741251d6b
80900522-edee-4eed-8db5-06d0a8cff589	t	Shara	b174e6ff-1556-44ad-9959-3ad741251d6b
7169f1c0-c5b1-49cd-9b2e-6167ab7846b3	t	Gahinga	02180150-6917-465c-afb6-31b461171820
f187391f-77a9-4ca8-adbb-ba39454ced96	t	Kabahinda	02180150-6917-465c-afb6-31b461171820
0aa5ba64-c805-4a2b-ada8-119c4d45940e	t	Kabasigirira	02180150-6917-465c-afb6-31b461171820
54a9268b-a6e6-4995-960a-65c3d4ddf9be	t	Kagarama	02180150-6917-465c-afb6-31b461171820
da454de4-73cf-458d-9f32-aacb0ab28011	t	Karambi	02180150-6917-465c-afb6-31b461171820
7ea22e08-12f9-42d8-824f-5b1f9f1bf76a	t	Miko	02180150-6917-465c-afb6-31b461171820
76cae6b4-ea3d-4e2f-a13a-4b4e9b22b7a8	t	Tara	02180150-6917-465c-afb6-31b461171820
b9ede99c-2267-47a8-a8cd-6f3de41822bb	t	Gitwa	b7430d29-1da7-4917-bdf4-57683ba88d24
ee8cc566-a8d1-4dc3-ae7e-0316744e10cd	t	Kamanyenga	b7430d29-1da7-4917-bdf4-57683ba88d24
88fc687f-70d0-4d78-827a-5bb52a32852a	t	Kangazi	b7430d29-1da7-4917-bdf4-57683ba88d24
891866a4-4208-4dca-9c1e-4b935c026ab2	t	Kinyaga	b7430d29-1da7-4917-bdf4-57683ba88d24
69072db4-2615-436d-8863-18edb6b3493e	t	Rugabano	b7430d29-1da7-4917-bdf4-57683ba88d24
5874d3a1-e0bc-4e90-a73a-5d4bf7e722a2	t	Bigoga	269ab3da-d472-4a5b-b23e-accb268a57aa
1f320edd-86f5-4c85-b847-0084c899af5e	t	Bugarura	269ab3da-d472-4a5b-b23e-accb268a57aa
13559db4-10a7-49cd-9056-31da26e8cb7b	t	Ishywa	269ab3da-d472-4a5b-b23e-accb268a57aa
ad95d60a-4269-4421-9795-82ea67705bb2	t	Kamagimbo	269ab3da-d472-4a5b-b23e-accb268a57aa
41f03953-3306-4838-ab4a-96de917024cb	t	Rwenje	269ab3da-d472-4a5b-b23e-accb268a57aa
4a1bc50c-ae4d-45de-8cad-123f8a597891	t	Gatare	41714618-7a64-4c00-8a98-6ee1236257c7
4335f50a-08c2-4bf4-95f0-04f6e4eb877c	t	Kiziguro	41714618-7a64-4c00-8a98-6ee1236257c7
7ea5e250-55a3-4dd9-b9e7-082b80f95051	t	Mataba	41714618-7a64-4c00-8a98-6ee1236257c7
89a563d9-4cda-453a-b5ae-44c848de4d41	t	Ryamuhirwa	41714618-7a64-4c00-8a98-6ee1236257c7
ae5288ab-a14c-4735-bdcb-2165bc8504b3	t	Gasebeya	0b1f46d3-aea9-4c29-9e43-8407193cdc89
d37e1396-a3ed-4e5d-8ce6-74e26413a572	t	Gaseke	0b1f46d3-aea9-4c29-9e43-8407193cdc89
20f8a10e-c2d5-4f80-a109-d30171e8fb98	t	Kamanu	0b1f46d3-aea9-4c29-9e43-8407193cdc89
95400147-30c3-45f5-a6c3-f095af484194	t	Kiziho	0b1f46d3-aea9-4c29-9e43-8407193cdc89
40924256-731f-43dc-9bfa-5ef7889b3134	t	Mashyuza	0b1f46d3-aea9-4c29-9e43-8407193cdc89
675a18c9-62d4-43e7-ab7b-3dad8a1ec8ae	t	Nyabintare	0b1f46d3-aea9-4c29-9e43-8407193cdc89
8888249e-21de-4b8e-879b-b6f9042a97fb	t	Gatare	96be866e-6b21-43fd-86e9-174ef49defcd
83d035b5-30a6-47d9-8ee0-52bb7dacfa56	t	Kabagina	96be866e-6b21-43fd-86e9-174ef49defcd
cb53cd40-05c6-4b41-9f7b-6d3b533f738e	t	Kabuye	96be866e-6b21-43fd-86e9-174ef49defcd
a465811c-e2fc-48f2-86ba-841b1b14468b	t	Kanoga	96be866e-6b21-43fd-86e9-174ef49defcd
62d5472d-028b-4219-a8cb-4a50cc7f2fb5	t	Karangiro	96be866e-6b21-43fd-86e9-174ef49defcd
2d02901e-b607-4f1d-a68b-9be4da86182f	t	Murambi	96be866e-6b21-43fd-86e9-174ef49defcd
f23359a7-a922-4503-910a-bc476abf98c2	t	Rusambu	96be866e-6b21-43fd-86e9-174ef49defcd
4181f3ec-8347-42d4-84f8-36330f793ad9	t	Butambamo	2ad2ef62-cd24-482e-bb09-41593accfee7
4de5e66c-4c2a-47c8-87fb-888b56256fe6	t	Murya	2ad2ef62-cd24-482e-bb09-41593accfee7
94814656-fdd0-4627-9719-ac1255df8a1b	t	Rwinzuki	2ad2ef62-cd24-482e-bb09-41593accfee7
039e664b-5411-41a6-b664-5e5c46862a09	t	Karenge	c8b2fc5b-cc6b-45e7-acee-df8abf3d16ba
4feabf56-2a22-4d91-b523-5ffd578f1b76	t	Mushaka	c8b2fc5b-cc6b-45e7-acee-df8abf3d16ba
3aa4579f-56e6-4fc8-b854-707dd7793060	t	Rubugu	c8b2fc5b-cc6b-45e7-acee-df8abf3d16ba
9386b8a3-e848-4719-bd09-d5ae8c2b3c87	t	Bushaka	5e7f9e6c-0eff-4ef4-8b50-fa0776c43626
03d93a99-306e-4ff0-8843-97b39bfeadd8	t	Kabihogo	5e7f9e6c-0eff-4ef4-8b50-fa0776c43626
c5602675-35cd-4abd-b652-025e11e57585	t	Nkira	5e7f9e6c-0eff-4ef4-8b50-fa0776c43626
439f61d3-6904-4dcd-8780-79d633b65fc8	t	Remera	5e7f9e6c-0eff-4ef4-8b50-fa0776c43626
25637fae-624c-41d6-aa39-ab48bdf4b97c	t	Bugina	f016cea7-074d-481f-9736-4fa523ec46ba
b336470f-6d4c-4805-b099-4e6f03d739c7	t	Congo-nil	f016cea7-074d-481f-9736-4fa523ec46ba
facaaa94-ac35-4293-b3d1-9de2d14102f1	t	Mataba	f016cea7-074d-481f-9736-4fa523ec46ba
4f5ce870-f46e-40ef-9977-591733f22e77	t	Murambi	f016cea7-074d-481f-9736-4fa523ec46ba
6829636f-67fe-4dd1-a521-c64d45801250	t	Ruhingo	f016cea7-074d-481f-9736-4fa523ec46ba
938c13a6-3ef7-47f1-a121-653ba8d3737b	t	Shyembe	f016cea7-074d-481f-9736-4fa523ec46ba
ef63dfe3-6aad-40c7-a197-5293788ec352	t	Teba	f016cea7-074d-481f-9736-4fa523ec46ba
91307fd4-0e85-4a55-be79-cc0600c7cfd9	t	Buhindure	2a79c0d7-62e9-46cf-9540-1e7d787fe6a0
9f8f7092-5a37-4a82-885c-c873d4bf8713	t	Nkora	2a79c0d7-62e9-46cf-9540-1e7d787fe6a0
aa500ba2-1d9a-4ce4-83b3-03eca944add4	t	Nyagahinika	2a79c0d7-62e9-46cf-9540-1e7d787fe6a0
e2d47e05-ce7a-4374-9823-8e221b3e38bf	t	Rukaragata	2a79c0d7-62e9-46cf-9540-1e7d787fe6a0
d876c0da-6e35-4899-992d-20718b1aeaf3	t	Bunyoni	bde1f348-3f02-42c7-98f4-348b4b5364a6
4be2f1cc-ae26-4fce-bf8d-160479fff6b0	t	Bunyunju	bde1f348-3f02-42c7-98f4-348b4b5364a6
88f3b3ca-7d3f-46bd-8fe4-ee9bd67f0c25	t	Kabere	bde1f348-3f02-42c7-98f4-348b4b5364a6
d6a4380d-76da-46eb-b090-a07aea58ebd6	t	Kabujenje	bde1f348-3f02-42c7-98f4-348b4b5364a6
b1fc0d3e-7389-4bd9-a702-c595a485fb1e	t	Karambi	bde1f348-3f02-42c7-98f4-348b4b5364a6
d1a8e075-3a52-4479-9048-a641368f0499	t	Nganzo	bde1f348-3f02-42c7-98f4-348b4b5364a6
c4029e8a-3a79-4310-97e6-e6b9f8f02c76	t	Haniro	986c2789-458f-4e80-9d16-46786a8949e6
13e5ab56-1573-4b28-8b74-4ceee6058942	t	Muyira	986c2789-458f-4e80-9d16-46786a8949e6
076e7033-1e35-48d9-af51-888d6d262ff6	t	Tangabo	986c2789-458f-4e80-9d16-46786a8949e6
49502fe0-540f-4483-a203-e601d04b0380	t	Kagano	a4752cdd-1ec3-4774-9ed2-0a097d68cfe2
ec0172fd-a18c-428d-93ba-a08383f34064	t	Kageyo	a4752cdd-1ec3-4774-9ed2-0a097d68cfe2
4036fd79-8a44-486d-b0ec-cc4202f77178	t	Karambo	a4752cdd-1ec3-4774-9ed2-0a097d68cfe2
2bfce96b-5aa6-418a-aba1-dd4600c12b31	t	Mwendo	a4752cdd-1ec3-4774-9ed2-0a097d68cfe2
eec018f0-955c-41b5-877b-dd8ce81bbf28	t	Kirwa	99531413-e404-4fd7-9515-de58cb1b32ad
e21c6362-b560-48fc-8f4b-d1fecfc2924b	t	Mburamazi	99531413-e404-4fd7-9515-de58cb1b32ad
d4021150-186f-4a8e-b0fa-626cc2909988	t	Rugeyo	99531413-e404-4fd7-9515-de58cb1b32ad
eae278e4-15e9-4338-9b16-28e9aca17250	t	Twabugezi	99531413-e404-4fd7-9515-de58cb1b32ad
06cb41e0-f0bf-43b1-80f3-6fb012a143fe	t	Gabiro	7cdbd544-ca80-4a2d-992a-4cee9edfc0d6
6ba675a1-b3ee-475e-9f2d-fcc1dfa43ccb	t	Gisiza	7cdbd544-ca80-4a2d-992a-4cee9edfc0d6
db1e308d-5e7f-472d-aaab-99a449a4f7ab	t	Murambi	7cdbd544-ca80-4a2d-992a-4cee9edfc0d6
714a68f5-c53f-460b-97d3-79c84c3c29e1	t	Nyarubuye	7cdbd544-ca80-4a2d-992a-4cee9edfc0d6
c7604c88-50e9-4003-93ad-90c7f75b1702	t	Biruyi	127d24a5-c997-47b4-b953-16ceae3cccd3
d99fe649-66e7-415e-bc1a-dfd605f3adb6	t	Kaguriro	127d24a5-c997-47b4-b953-16ceae3cccd3
9b5e47b8-6082-4bf3-be77-c179f271bb8f	t	Magaba	127d24a5-c997-47b4-b953-16ceae3cccd3
7295729a-1383-4c51-9816-b5993ccf6648	t	Rurara	127d24a5-c997-47b4-b953-16ceae3cccd3
647da765-a878-41d5-9e94-bc3fd0660b64	t	Bumba	96c94317-77ad-4f9c-8f66-7e34b02185ac
778c162d-986f-4cc3-8aea-49f2414f9a18	t	Cyarusera	96c94317-77ad-4f9c-8f66-7e34b02185ac
b02ab216-0a3d-435e-adc0-8e962fe1393c	t	Gitwa	96c94317-77ad-4f9c-8f66-7e34b02185ac
6acaf836-a392-4444-a764-78e61b9c8f35	t	Mageragere	96c94317-77ad-4f9c-8f66-7e34b02185ac
a9df307e-4deb-451a-b0c5-0f1385d849f2	t	Sure	96c94317-77ad-4f9c-8f66-7e34b02185ac
dd77a42c-7bb9-44d0-8492-558ae59a29bf	t	Busuku	2a142330-81f0-4efd-9c7e-180e6cb7d171
9403bcda-8ad4-4582-9421-9dedbd5246fe	t	Cyivugiza	2a142330-81f0-4efd-9c7e-180e6cb7d171
f1fff4ef-03d8-41ea-9784-be96eed98d2f	t	Ngoma	2a142330-81f0-4efd-9c7e-180e6cb7d171
3860dc7a-8b6f-45b9-a0a5-fc17f90c1614	t	Terimbere	2a142330-81f0-4efd-9c7e-180e6cb7d171
ad7eee21-d12e-43f0-8848-6077d15169a7	t	Gatare	e041aed9-9e23-4f6d-b189-802c90a3d322
a8a60341-324b-4d99-8719-f10c9461bef1	t	Gihira	e041aed9-9e23-4f6d-b189-802c90a3d322
a625e24f-3313-442e-9485-1d5ea6de3c63	t	Kavumu	e041aed9-9e23-4f6d-b189-802c90a3d322
3bdab947-c466-45c7-b45f-de9351db6d78	t	Nyakarera	e041aed9-9e23-4f6d-b189-802c90a3d322
cc0f5c48-0e9f-4b38-95cd-4291c36558f9	t	Rugasa	e041aed9-9e23-4f6d-b189-802c90a3d322
af7657e3-3336-4a87-b898-da2b7157f557	t	Rundoyi	e041aed9-9e23-4f6d-b189-802c90a3d322
56f98323-ec46-4517-a6f9-24a30632fbd2	t	Kabona	8a72f0cd-0f30-44fe-9ebe-2b5b4c6227a0
ed493ba4-255a-4f9a-b8d8-a46530211766	t	Mberi	8a72f0cd-0f30-44fe-9ebe-2b5b4c6227a0
c1dff4f9-9818-4f3f-b2fe-1f15593d8cdf	t	Remera	8a72f0cd-0f30-44fe-9ebe-2b5b4c6227a0
fc251c5b-4880-4262-98b9-5dfe6d971c72	t	Ruronde	8a72f0cd-0f30-44fe-9ebe-2b5b4c6227a0
027f77ea-0365-4864-b890-3dc496e26648	t	Bungwe	534d5e23-fe7f-498b-9608-46ef7a58f27c
afb3564c-b207-4e26-b9ca-ac1c91897980	t	Bushenya	534d5e23-fe7f-498b-9608-46ef7a58f27c
000addb1-63cb-4c03-9133-552e4c14b673	t	Mudugari	534d5e23-fe7f-498b-9608-46ef7a58f27c
31984cbe-06dc-4980-b7e1-0e9a90fd6fe7	t	Tumba	534d5e23-fe7f-498b-9608-46ef7a58f27c
e019059a-1b77-4d5f-bac5-54c7416c115f	t	Gatsibo	f30bf7ce-6647-4c1b-9deb-a9b593e1d36b
2711bcc0-1427-4f7c-9fc5-0be202c637be	t	Mubuga	f30bf7ce-6647-4c1b-9deb-a9b593e1d36b
22a7f001-029f-4124-a7d9-464e3cd682b5	t	Muhotora	f30bf7ce-6647-4c1b-9deb-a9b593e1d36b
0c0a3921-c8d6-4345-ae45-384cca022745	t	Nyamicucu	f30bf7ce-6647-4c1b-9deb-a9b593e1d36b
e5dc8ce9-c24e-4ff1-818b-7ea58b65a07a	t	Rusumo	f30bf7ce-6647-4c1b-9deb-a9b593e1d36b
4dcb6c8e-89dd-4664-8c16-d3b3e9d16d1f	t	Gasiza	5948213e-20e5-4658-8e7b-a9132741e95f
cfca5c1b-2dea-431e-8ddd-2df4a22df73e	t	Gisovu	5948213e-20e5-4658-8e7b-a9132741e95f
6663c01b-acb2-4214-ae0e-be83d7d9e78f	t	Kabyiniro	5948213e-20e5-4658-8e7b-a9132741e95f
f7b93e5a-8c3b-4384-82bf-5249fae4e9af	t	Kagitega	5948213e-20e5-4658-8e7b-a9132741e95f
30b3c500-e543-40b0-a356-b024162fc8ab	t	Kamanyana	5948213e-20e5-4658-8e7b-a9132741e95f
b877312e-2432-44b6-bfee-8f715fa3925a	t	Nyagahinga	5948213e-20e5-4658-8e7b-a9132741e95f
ac4e7e82-1011-460b-9d38-1f9e646e9485	t	Butare	c33568bb-940e-467e-83fb-2f5acadc0ff8
7032361f-c026-46a3-b550-88b745226f33	t	Ndongozi	c33568bb-940e-467e-83fb-2f5acadc0ff8
1b13b82d-c5ec-4e84-8254-1cb0409a146f	t	Ruyange	c33568bb-940e-467e-83fb-2f5acadc0ff8
1fcaea69-5569-4fe0-84ba-be78714984e5	t	Buramba	056788d7-2649-4077-808d-8fbd011750b8
3d8645e8-2f46-4842-b8a8-642254e390b3	t	Gisizi	056788d7-2649-4077-808d-8fbd011750b8
690d97b6-0716-40b5-8eac-ffcb81aaed16	t	Kidakama	056788d7-2649-4077-808d-8fbd011750b8
608f4c5d-4f07-44c0-8d08-a3a8b14557e4	t	Nyangwe	056788d7-2649-4077-808d-8fbd011750b8
c8e6f7c8-8f36-4e42-a9d9-c5b0ee8ce607	t	Rwasa	056788d7-2649-4077-808d-8fbd011750b8
b59798c4-84d2-4203-b126-1039ff23d381	t	Gabiro	73c62420-1a56-4e97-b6e4-877db88baf37
76fcab97-9732-4c48-96eb-4e6d31652241	t	Musenda	73c62420-1a56-4e97-b6e4-877db88baf37
73c98605-70ea-4f71-ba0e-4fb9a98de833	t	Rwambogo	73c62420-1a56-4e97-b6e4-877db88baf37
0987d2da-fe21-49c6-ab6a-8c39d519b69d	t	Rwasa	73c62420-1a56-4e97-b6e4-877db88baf37
b4d113b0-0973-4918-93d8-911f11888aed	t	Mariba	24aaa132-99c7-4d6f-842d-126666f4102b
616ef015-5789-4a07-bc66-04df8d0a7f98	t	Musasa	24aaa132-99c7-4d6f-842d-126666f4102b
10136c49-0564-4014-8d4a-0f42fe90eb62	t	Runoga	24aaa132-99c7-4d6f-842d-126666f4102b
3ee21c0d-83af-4ed9-aedb-127ec0050ef2	t	Kabaya	b2bb8ba9-2b04-4f0c-a6bf-6bce7e263e74
7c3210ab-9cc4-41b8-85e2-3aa01b56202a	t	Kayenzi	b2bb8ba9-2b04-4f0c-a6bf-6bce7e263e74
99ecd4ff-1afc-4b40-a298-cf8fa4041542	t	Kiringa	b2bb8ba9-2b04-4f0c-a6bf-6bce7e263e74
1be28b7f-92cb-470f-9bd6-fd1dc323fa04	t	Nyamabuye	b2bb8ba9-2b04-4f0c-a6bf-6bce7e263e74
b6d89e42-a9cc-422a-a7c3-601afa839def	t	Gafuka	eaa770c5-7603-4a39-9e33-86411d01fe6e
2a3219f8-4c8d-4dd2-9086-c2c4497cae5a	t	Nkenke	eaa770c5-7603-4a39-9e33-86411d01fe6e
36df21fb-34eb-4936-8149-8fa2940f353a	t	Nkumba	eaa770c5-7603-4a39-9e33-86411d01fe6e
263419cd-5744-45d5-8c32-7d24c4ac66b1	t	Ntaruka	eaa770c5-7603-4a39-9e33-86411d01fe6e
62ea92ec-6177-4432-bc42-56fedd8796e9	t	Bugamba	2b6713d7-bbbe-4322-9e36-01afef4f266b
782937cb-aad3-411e-a2ac-320fe4b856f7	t	Kaganda	2b6713d7-bbbe-4322-9e36-01afef4f266b
abacca77-f0a0-4d04-90cc-4aed4d526008	t	Musasa	2b6713d7-bbbe-4322-9e36-01afef4f266b
5be684ee-db34-48f4-8157-24159ec15abe	t	Rutovu	2b6713d7-bbbe-4322-9e36-01afef4f266b
abdf1509-400d-419f-817c-69609f7d46b4	t	Bukwashuri	37233d09-30f3-48bc-8391-a56e1f7eac35
b7be74f9-f972-4d8f-8e8b-43830ca50752	t	Gashanje	37233d09-30f3-48bc-8391-a56e1f7eac35
5e6e8f3e-17c8-46a5-bda9-2a13764cfa23	t	Murwa	37233d09-30f3-48bc-8391-a56e1f7eac35
4e0f1fbe-003e-4d2f-a7de-ff79073225a1	t	Nyirataba	37233d09-30f3-48bc-8391-a56e1f7eac35
88d084b3-3163-49dc-9bc7-9a581cf31d37	t	Kivumu	c0eb9006-8bde-4370-aa96-cbed2479a730
883e3fee-c8a8-4258-a1d0-86fadabc7436	t	Nyamugari	c0eb9006-8bde-4370-aa96-cbed2479a730
6d63bd11-bfbd-47ee-8ea1-14fb3ba30115	t	Rubona	c0eb9006-8bde-4370-aa96-cbed2479a730
a5f1afd6-9868-43fb-9b9d-53a42656ef21	t	Rushara	c0eb9006-8bde-4370-aa96-cbed2479a730
30eafe21-4720-4f10-9f1a-5f8dd53fe26a	t	Cyahi	85dbc9f0-fcc0-47f7-a4d7-aa56bdab8629
7c76f6e8-06ae-487a-9892-472ac30e277d	t	Gafumba	85dbc9f0-fcc0-47f7-a4d7-aa56bdab8629
21619e7f-2ae8-472a-8c3e-e0346b72517e	t	Karangara	85dbc9f0-fcc0-47f7-a4d7-aa56bdab8629
7b01159d-b9ea-4a07-af4a-ee3302d02ff8	t	Rurembo	85dbc9f0-fcc0-47f7-a4d7-aa56bdab8629
e5a157eb-a7ec-4818-952b-76564dbf5568	t	Kilibata	95b917c7-ee25-492c-8e6b-782e792457e2
b2a88ad9-7368-4157-a1b5-a16b0ae3e7e2	t	Mucaca	95b917c7-ee25-492c-8e6b-782e792457e2
7c974f67-7f90-4e6a-b16d-1ddf410b3c39	t	Nyanamo	95b917c7-ee25-492c-8e6b-782e792457e2
4d9c242f-f574-4b2a-9365-5d80044fb933	t	Rukandabyum	95b917c7-ee25-492c-8e6b-782e792457e2
98f08225-e5b0-47eb-8d3b-ee0d15695343	t	Gaseke	7ba979fb-9d2e-4a66-b62a-2d7efb855086
e03018ae-a2b4-4349-ad7a-a32f11737785	t	Gatare	7ba979fb-9d2e-4a66-b62a-2d7efb855086
d92f01fa-2eba-41a9-abef-3b2d8b19c9b0	t	Gitovu	7ba979fb-9d2e-4a66-b62a-2d7efb855086
477f8cf5-ef2e-4c59-9a0e-dc275a7b3f4c	t	Rusekera	7ba979fb-9d2e-4a66-b62a-2d7efb855086
8f0714dd-da92-4d70-9628-23de582a172b	t	Kabona	f6651c3e-3eee-44bf-a823-da274fcc08e5
62316bcf-5893-4fac-bb09-ab6277d7d524	t	Ndago	f6651c3e-3eee-44bf-a823-da274fcc08e5
2362ca94-6ef8-4009-b9e0-b3cb53e8f2a5	t	Ruhanga	f6651c3e-3eee-44bf-a823-da274fcc08e5
d4a936e0-1bf3-4b50-a0c2-b6688810c777	t	Gacundura	1f03c5b6-3e48-4a4e-a487-5abd386cbe6e
e8de8ade-6d1a-4a98-9cfe-f098043eeaf1	t	Gashoro	1f03c5b6-3e48-4a4e-a487-5abd386cbe6e
6d1d7118-6b92-49d0-b17d-e5950be2b984	t	Ruconsho	1f03c5b6-3e48-4a4e-a487-5abd386cbe6e
6befbb69-09aa-496b-b408-3109386a8dbc	t	Rugari	1f03c5b6-3e48-4a4e-a487-5abd386cbe6e
4b983608-2a46-4d29-ad62-dd2face05f9e	t	Birambo	c04be066-4f7c-4223-845d-5a80a60b652b
d93f86cf-2124-4df2-9042-32cebcb043c0	t	Butereri	c04be066-4f7c-4223-845d-5a80a60b652b
fe65939b-f553-48b0-8c82-fc7ac10fd3dd	t	Kamina	c04be066-4f7c-4223-845d-5a80a60b652b
e1320956-542d-4297-aab1-0db0f158bd16	t	Kirabo	c04be066-4f7c-4223-845d-5a80a60b652b
ed88ba87-58b7-47f6-ba32-75fecca347d5	t	Mwumba	c04be066-4f7c-4223-845d-5a80a60b652b
afb2ba7c-464b-416a-9352-543afe356e42	t	Ruhanga	c04be066-4f7c-4223-845d-5a80a60b652b
80a011ea-84d9-481e-8afe-f5342b4c72fc	t	Kiruku	8cd0d9b7-8b00-4a6d-9b50-dcfbb5163d90
1f18ca93-dc94-4883-bb68-ad390e6416c7	t	Mbirima	8cd0d9b7-8b00-4a6d-9b50-dcfbb5163d90
fe6eb7d8-2abc-4b63-94fc-ffcf6c09982e	t	Nyange	8cd0d9b7-8b00-4a6d-9b50-dcfbb5163d90
43063249-0e1c-4d77-b0ab-3da651a2130a	t	Nyanza	8cd0d9b7-8b00-4a6d-9b50-dcfbb5163d90
770219e9-8d7c-4311-ad1a-8d1f0c648f28	t	Muhaza	84ae3338-b01d-443a-92a4-23bf236ffcd9
22cfccb4-e290-40c6-9da2-8f6d2a856e54	t	Muhororo	84ae3338-b01d-443a-92a4-23bf236ffcd9
4ca65170-2d7e-48c8-a064-1cb45878406a	t	Muramba	84ae3338-b01d-443a-92a4-23bf236ffcd9
275a40c6-e9ff-480d-851e-8446df00f20a	t	Mutanda	84ae3338-b01d-443a-92a4-23bf236ffcd9
93b9fa09-4ae6-400d-bfb8-bd76770f47f2	t	Rukore	84ae3338-b01d-443a-92a4-23bf236ffcd9
4a8f1cab-899b-4d57-8d87-e633fb713764	t	Buheta	e7224f80-b8eb-4ba6-b5a9-261d6ab05078
eeab8207-73e1-4bc7-bd49-4789de7349e7	t	Kagoma	e7224f80-b8eb-4ba6-b5a9-261d6ab05078
b7eef486-0f59-4895-8d24-b8ec8dd0dcbb	t	Nganzo	e7224f80-b8eb-4ba6-b5a9-261d6ab05078
cbbaf75e-ee69-4538-be60-b1086822f096	t	Rusagara	e7224f80-b8eb-4ba6-b5a9-261d6ab05078
3019db8f-4eb0-4076-8b0e-387a4f792115	t	Nyacyina	6ca384f6-d90e-4a01-9609-547722a6cf51
6eabb731-78cd-4ce8-826a-b7ca263ed0fa	t	Rukura	6ca384f6-d90e-4a01-9609-547722a6cf51
f58745df-75ce-4788-b8d6-f51429c73722	t	Rutenderi	6ca384f6-d90e-4a01-9609-547722a6cf51
14016797-ac5a-41bf-9863-e9feacbc6d3b	t	Taba	6ca384f6-d90e-4a01-9609-547722a6cf51
c781a188-1297-41c9-bc1f-7d6dfbe50e3a	t	Gakindo	ccb170b2-9862-4585-9e96-fff2fa8f420b
15381976-08d5-4fcb-af33-43bfebe428d9	t	Gatwa	ccb170b2-9862-4585-9e96-fff2fa8f420b
238c506f-8880-4528-bc99-34f797ad77d2	t	Karukungu	ccb170b2-9862-4585-9e96-fff2fa8f420b
ad6f8751-2e8d-4bdd-8d53-459b93af6e40	t	Kamubuga	a1725d30-641f-4d9e-b504-1f4eed771ea3
1984ec2c-1b07-49bb-b9a7-e4cab66c6f10	t	Kidomo	a1725d30-641f-4d9e-b504-1f4eed771ea3
b05d2ef0-ece3-4301-9840-327c3920959c	t	Mbatabata	a1725d30-641f-4d9e-b504-1f4eed771ea3
1a58b3a0-f3c8-417c-8b7b-b07ebf8b6b64	t	Rukore	a1725d30-641f-4d9e-b504-1f4eed771ea3
46b2f50d-2287-4e5f-9634-30c7048b41cd	t	Kanyanza	6d7e31d5-a99e-4918-b32c-5e5bbcec9cef
553ef2a5-cfcb-4b35-9e3d-a1166fa8109b	t	Karambo	6d7e31d5-a99e-4918-b32c-5e5bbcec9cef
d694e50e-185c-4425-8008-284824cc7ebe	t	Kirebe	6d7e31d5-a99e-4918-b32c-5e5bbcec9cef
2c3e101b-b66b-4134-864c-c5b0c1384b39	t	Cyintare	608151e4-8644-43c0-8808-daf4d3786707
3af8489a-fc66-4557-8f30-e91a1ba41272	t	Gasiza	608151e4-8644-43c0-8808-daf4d3786707
f3001f02-ea92-43c8-b4d9-798c041530a6	t	Rugimbu	608151e4-8644-43c0-8808-daf4d3786707
4349a211-413d-4e32-b75d-a817d644e7f4	t	Sereri	608151e4-8644-43c0-8808-daf4d3786707
ede7f785-9621-45a1-82df-77cc097db31b	t	Buyange	0af3d233-bf07-4f2b-b24e-b036f2b40dc3
6214cb76-cc01-4ce9-8478-778ed4f0cb1f	t	Gikombe	0af3d233-bf07-4f2b-b24e-b036f2b40dc3
a9c48de0-bb09-4a70-8e49-7469191004c6	t	Nyundo	0af3d233-bf07-4f2b-b24e-b036f2b40dc3
75531138-cc58-4605-9905-0d8527b29ebf	t	Gasiho	44b7c8bd-8ecb-49e3-b47a-6cc94c00bf73
f232fc49-5421-4359-87a0-9b42c32f6543	t	Munyana	44b7c8bd-8ecb-49e3-b47a-6cc94c00bf73
11f69e85-f736-488a-aa2e-47cc986d0843	t	Murambi	44b7c8bd-8ecb-49e3-b47a-6cc94c00bf73
c7596155-6a94-41b8-9983-45d0d4b26c96	t	Raba	44b7c8bd-8ecb-49e3-b47a-6cc94c00bf73
fd6b0692-62ef-40b7-b239-e53f72c1df67	t	Gahinga	c393c45e-fa62-4197-a136-ce183d1231a0
1779ba7d-0c56-4ff9-9aa8-441ec991bb0c	t	Munyana	c393c45e-fa62-4197-a136-ce183d1231a0
0bc7fdb3-a73e-481e-89a4-581d2b4da194	t	Nkomane	c393c45e-fa62-4197-a136-ce183d1231a0
eaa8326b-690d-4b5e-88bb-6c05277f58ec	t	Rutabo	c393c45e-fa62-4197-a136-ce183d1231a0
e4748691-f00c-44ad-9082-b376512f3d66	t	Rwamambe	c393c45e-fa62-4197-a136-ce183d1231a0
d4155d30-233f-4b6d-87dd-c5f41172475c	t	Busake	627ffe3b-81dd-43eb-9121-b29e24223ad4
527c4906-26d5-425e-b798-bdd4092bbb2e	t	Bwenda	627ffe3b-81dd-43eb-9121-b29e24223ad4
e30aa655-4c5a-41d5-a63e-b255b3ec376d	t	Gasiza	627ffe3b-81dd-43eb-9121-b29e24223ad4
c13c1cba-c0e2-4ee8-bb7f-61dc87bf8c54	t	Gihinga	627ffe3b-81dd-43eb-9121-b29e24223ad4
84308b13-6498-44ff-a977-0d2d7556ffaf	t	Huro	627ffe3b-81dd-43eb-9121-b29e24223ad4
c1971109-6aec-4cb0-ab53-af9536671811	t	Musagara	627ffe3b-81dd-43eb-9121-b29e24223ad4
35ab2ca0-d41e-48c6-aff2-db43bc713c82	t	Musenyi	627ffe3b-81dd-43eb-9121-b29e24223ad4
f8be8150-9adc-452a-bc53-55d6bf57558d	t	Ruganda	627ffe3b-81dd-43eb-9121-b29e24223ad4
a3dee1d7-776d-4de5-967b-3a7213e07869	t	Bumba	71883d0e-ae22-435a-af2f-0077daf43755
d0e33319-ca2d-4d22-a18b-304e1fd525f7	t	Gisiza	71883d0e-ae22-435a-af2f-0077daf43755
bab512f0-da47-4d54-a3ce-1c1ab72687cb	t	Nganzo	71883d0e-ae22-435a-af2f-0077daf43755
5f049e8b-cdd2-4e64-b478-b031cd7855dd	t	Kabatezi	33b185d5-aa9c-40c9-9569-5c19282f0b3d
d8fdecb7-aa25-4164-9467-80a9203dbbac	t	Mubuga	33b185d5-aa9c-40c9-9569-5c19282f0b3d
6236ee92-8166-464d-9c11-0f63eaa98350	t	Rwa	33b185d5-aa9c-40c9-9569-5c19282f0b3d
1057368c-3c84-40b8-a709-5bef1d34c7b0	t	Buranga	49b1e673-4fe7-418c-8e59-fe6d833ef532
863ee5ef-7f08-49c0-b69e-a1846ec91127	t	Gahinga	49b1e673-4fe7-418c-8e59-fe6d833ef532
486d8b80-ba4e-432a-9f8e-8d48772fb2f9	t	Gisozi	49b1e673-4fe7-418c-8e59-fe6d833ef532
2d1b99b9-de80-4111-ba76-01d3d3b1245c	t	Mucaca	49b1e673-4fe7-418c-8e59-fe6d833ef532
6a414e21-29fe-42ac-ae97-a0edd5e8cf64	t	Busoro	e6e51ced-1a07-434c-b9a4-c602c36451c1
8b6bb3ea-1b1e-422b-a622-aa0b974273b1	t	Gikingo	e6e51ced-1a07-434c-b9a4-c602c36451c1
577e50e0-81a7-495a-9389-e46bf54c2e1d	t	Jango	e6e51ced-1a07-434c-b9a4-c602c36451c1
0bd6943e-d4b6-41bc-8562-b6084fc29d6a	t	Ruli	e6e51ced-1a07-434c-b9a4-c602c36451c1
01ccf2d5-0abd-4c28-b265-9538c0286dd3	t	Rwesero	e6e51ced-1a07-434c-b9a4-c602c36451c1
9804a62e-89ec-4903-aaed-00ee76714c5e	t	Gataba	226f929c-a82f-4fd2-b1bd-4a44f2b4e302
40b081f0-1997-4663-9ed4-068237ed475d	t	Kamonyi	226f929c-a82f-4fd2-b1bd-4a44f2b4e302
ebdb87b6-51f7-426d-8792-d8a71a2b52f3	t	Murambi	226f929c-a82f-4fd2-b1bd-4a44f2b4e302
b1b07e27-f959-4607-a6d3-044845fc85cd	t	Nyundo	226f929c-a82f-4fd2-b1bd-4a44f2b4e302
e52388a6-2561-467e-9da0-2593a1747040	t	Rumbi	226f929c-a82f-4fd2-b1bd-4a44f2b4e302
97cc1ec9-6508-4c88-a697-74a059a9d120	t	Burimba	04ad5498-1b0d-4ab4-8f88-77ea68145f57
ef4d5d01-d5a3-42d2-9211-234f8fe03163	t	Busanane	04ad5498-1b0d-4ab4-8f88-77ea68145f57
5ff50620-61ff-469e-a50c-b5d57754ce7c	t	Joma	04ad5498-1b0d-4ab4-8f88-77ea68145f57
aaccd332-027e-431b-97a8-2256b476a68b	t	Kageyo	04ad5498-1b0d-4ab4-8f88-77ea68145f57
1d93d814-d565-4520-b1b1-ce18c0334278	t	Mbogo	04ad5498-1b0d-4ab4-8f88-77ea68145f57
02b571c8-7495-45fc-90f0-a57782757449	t	Razi	04ad5498-1b0d-4ab4-8f88-77ea68145f57
4ff566f7-ff2e-46ac-8343-fb8bec29a1a5	t	Rwankuba	04ad5498-1b0d-4ab4-8f88-77ea68145f57
f13bb61b-0a0f-40cf-8348-d75b7738ebbc	t	Shyombwe	04ad5498-1b0d-4ab4-8f88-77ea68145f57
969ba40f-1be3-42dd-a758-627f1809a122	t	Karenge	c7dce37f-dd4b-49bf-af62-2555171ebea8
5651ce20-000e-470a-945d-7265dd2a6703	t	Kigabiro	c7dce37f-dd4b-49bf-af62-2555171ebea8
f83a067b-f304-40ae-bdd1-17ad4a7fb192	t	Kivumu	c7dce37f-dd4b-49bf-af62-2555171ebea8
06f9f747-138c-418a-a8c7-08a3db5679c7	t	Rwesero	c7dce37f-dd4b-49bf-af62-2555171ebea8
d8d96dea-c532-4bcf-8459-f36ff9c15a90	t	Bwisige	2c80975d-ed3e-44d6-8904-efa57e9b9ded
3cd56c2d-35c6-4062-aa62-34fbd6471dc8	t	Gihuke	2c80975d-ed3e-44d6-8904-efa57e9b9ded
525b6d1e-2041-4782-82db-164477f8895f	t	Nyabushingitw	2c80975d-ed3e-44d6-8904-efa57e9b9ded
9aa68b9c-d10b-4951-b9cb-bd3f5ee03202	t	Gacurabwenge	ae52ffc1-7fc8-4a3b-8ec7-30c9e08ac7fa
5ffac60e-7953-4b5a-9640-f8d3c1f6b0bd	t	Gisuna	ae52ffc1-7fc8-4a3b-8ec7-30c9e08ac7fa
1c5ef23e-8987-43bd-953d-9310ab6d66f6	t	Kibali	ae52ffc1-7fc8-4a3b-8ec7-30c9e08ac7fa
346c17ee-f3b5-4973-8ce8-a1c0d71bfe9b	t	Kivugiza	ae52ffc1-7fc8-4a3b-8ec7-30c9e08ac7fa
f55929a6-b83b-45de-b758-0fae6206abf6	t	Murama	ae52ffc1-7fc8-4a3b-8ec7-30c9e08ac7fa
ce006494-2dbb-4733-911b-8c30ebd3d986	t	Ngondore	ae52ffc1-7fc8-4a3b-8ec7-30c9e08ac7fa
c5a7f03d-9027-4dab-884d-f0723ca81187	t	Nyamabuye	ae52ffc1-7fc8-4a3b-8ec7-30c9e08ac7fa
767132b4-d82e-4c18-9fcc-f60e70b993af	t	Nyarutarama	ae52ffc1-7fc8-4a3b-8ec7-30c9e08ac7fa
f81387a7-21c0-4b04-b788-378d774f6281	t	Gasunzu	773f9722-f7a8-4e24-a440-044d9849aae5
fc6589f2-670f-435c-bfe9-1922083d4d1a	t	Muhambo	773f9722-f7a8-4e24-a440-044d9849aae5
54f79320-3bd8-40ef-80f9-1053e3820689	t	Nyakabungo	773f9722-f7a8-4e24-a440-044d9849aae5
38741ace-4d83-4fe7-ae8e-ccd2a5410356	t	Nyambare	773f9722-f7a8-4e24-a440-044d9849aae5
3aa99b86-62af-4e50-a05d-f82591a5e1f5	t	Nyaruka	773f9722-f7a8-4e24-a440-044d9849aae5
d4600111-7078-4de8-bbff-c36ce383d5ca	t	Rwankonjo	773f9722-f7a8-4e24-a440-044d9849aae5
7646ad1b-8f0c-4063-b098-1760d673ca88	t	Gatobotobo	9de7df69-6639-487f-b4da-132b0898ee16
762cc91b-9136-49e5-ab5b-c75a403a88ba	t	Murehe	9de7df69-6639-487f-b4da-132b0898ee16
5728ce62-09d6-44f4-89f2-bb1be43f82f6	t	Tanda	9de7df69-6639-487f-b4da-132b0898ee16
fd577728-64ea-4e2d-b65b-2d7b708e6c8f	t	Gihembe	37f36029-7bae-4d21-a528-9b954d9ffd5a
2bc0ffdd-9157-42df-8118-143d3671c60d	t	Horezo	37f36029-7bae-4d21-a528-9b954d9ffd5a
b730cefe-2cec-4ff5-b2c4-a5f3630ace5e	t	Kabuga	37f36029-7bae-4d21-a528-9b954d9ffd5a
522cfb61-9412-48ad-a8d4-67e4924dd11e	t	Muhondo	37f36029-7bae-4d21-a528-9b954d9ffd5a
fc2bde2b-428b-4c71-a595-e218dea7193d	t	Bugomba	8c6ecb42-2cd9-4295-9ac1-efcb677bda17
331e4665-f41f-4620-bc6a-4baa65c86719	t	Gatoma	8c6ecb42-2cd9-4295-9ac1-efcb677bda17
ea64961b-8427-439d-99fd-1bbdd58bb08a	t	Mulindi	8c6ecb42-2cd9-4295-9ac1-efcb677bda17
e2af9f11-fea0-4b15-a5a9-4557ded897f4	t	Nyarwambu	8c6ecb42-2cd9-4295-9ac1-efcb677bda17
a6dea50f-5162-43ab-8764-86682334b66a	t	Rukurura	8c6ecb42-2cd9-4295-9ac1-efcb677bda17
50717da0-e62b-4f7c-9a52-e07a87e7409e	t	Kabuga	5dd4589d-3d35-4c87-a577-8cc7b80d6c75
4f50661a-b737-43bd-b420-3ec477306b47	t	Nyiragifumba	5dd4589d-3d35-4c87-a577-8cc7b80d6c75
9754844c-db9e-4a0d-8b88-a63271b7e575	t	Nyiravugiza	5dd4589d-3d35-4c87-a577-8cc7b80d6c75
2aa45062-71d8-48b2-a0da-139dff0cda8c	t	Remera	5dd4589d-3d35-4c87-a577-8cc7b80d6c75
de75e078-955a-41db-826c-e536149f52ae	t	Rusekera	5dd4589d-3d35-4c87-a577-8cc7b80d6c75
5b865088-721e-4227-986d-b6536cb39bf2	t	Ryaruyumba	5dd4589d-3d35-4c87-a577-8cc7b80d6c75
c3337660-3a8d-4b64-8210-39c56bee22ca	t	Gakenke	d3c2191d-c917-409f-9c2e-34135e90967f
785a1670-b396-4351-8f11-15d14a98e282	t	Miyove	d3c2191d-c917-409f-9c2e-34135e90967f
37b4b330-3f8e-4895-aa0c-160c950566ed	t	Mubuga	d3c2191d-c917-409f-9c2e-34135e90967f
87642154-a3ac-4dfd-9570-3df064135dae	t	Cyamuganga	4cf5a683-64b7-48ab-a448-28c835635522
bdc76189-6253-45b4-ae01-086fe10bfe40	t	Gatenga	4cf5a683-64b7-48ab-a448-28c835635522
759b73dd-f263-4720-840f-dfe53850bc37	t	Kiruhura	4cf5a683-64b7-48ab-a448-28c835635522
a7842880-d1f6-4c92-8ef9-8c190c44723b	t	Mutarama	4cf5a683-64b7-48ab-a448-28c835635522
b16cfb48-e0cd-4137-b804-8d8ab8d82d5c	t	Rugerero	4cf5a683-64b7-48ab-a448-28c835635522
44604946-e538-4102-8a3e-d853f7f99022	t	Rusambya	4cf5a683-64b7-48ab-a448-28c835635522
1c5bb7be-7f4a-4d53-adb6-71172a273ecf	t	Cyamuhinda	dafa2b14-4baa-44a5-9d30-dd859f06020f
45f235d0-a8bc-4edd-8019-f7aaf73f4e6b	t	Kigoma	dafa2b14-4baa-44a5-9d30-dd859f06020f
eb06cb09-1f8b-4f6c-b0c6-de398aa93814	t	Mwendo	dafa2b14-4baa-44a5-9d30-dd859f06020f
77402a37-9dc1-4f65-a25e-81ae6ccc6233	t	Ngange	dafa2b14-4baa-44a5-9d30-dd859f06020f
9eba78f5-dcf1-467f-8592-50e70346a243	t	Rebero	dafa2b14-4baa-44a5-9d30-dd859f06020f
06878d59-0101-4c4e-8f4b-86a0fa1226cf	t	Gaseke	0d6ede8a-5c86-4acf-acba-43e1a6a24a00
f451f556-a4ef-402e-a02f-6eff12aeced0	t	Kabeza	0d6ede8a-5c86-4acf-acba-43e1a6a24a00
166a0a08-a8f9-4782-8fce-4165f5c1b940	t	Musenyi	0d6ede8a-5c86-4acf-acba-43e1a6a24a00
8907878d-92ab-4354-b222-f4b0a95f7ac1	t	Mutandi	0d6ede8a-5c86-4acf-acba-43e1a6a24a00
3bd3f01b-4426-49a0-bbb0-e5bef63e85c5	t	Nyarubuye	0d6ede8a-5c86-4acf-acba-43e1a6a24a00
1ebe7cbf-33c6-4ef5-a796-b59070741096	t	Gahumuliza	f6fbdf92-5363-4b9a-b3d8-430c147b7398
27b71d82-ed4f-4cd7-a88e-bc60c8c68e2d	t	Jamba	f6fbdf92-5363-4b9a-b3d8-430c147b7398
f1a7bd8a-570f-475f-911c-22bd39925cfc	t	Kabeza	f6fbdf92-5363-4b9a-b3d8-430c147b7398
3d883348-dd88-492f-8e89-a6402464c4f4	t	Kabuga	f6fbdf92-5363-4b9a-b3d8-430c147b7398
a77a3434-082c-4d9d-8831-4b9220d530ca	t	Kiziba	f6fbdf92-5363-4b9a-b3d8-430c147b7398
d6f66521-2f19-485a-bc71-49d0c06eb2ed	t	Mataba	f6fbdf92-5363-4b9a-b3d8-430c147b7398
8ebc6ad3-3c46-4062-ac81-bcc7211fc993	t	Butare	725dac54-413d-40f1-9b30-072c934e29a5
46058a80-7d2b-4a63-a673-d5c050634958	t	Rusasa	725dac54-413d-40f1-9b30-072c934e29a5
d4697b70-5ccc-44c6-824b-4d02aec9ad64	t	Rwagihura	725dac54-413d-40f1-9b30-072c934e29a5
36ed2922-ff0e-47b7-adc2-17429d75f7c9	t	Yaramba	725dac54-413d-40f1-9b30-072c934e29a5
3e2016bc-23ee-4c26-919e-9269920ebac6	t	Gihanga	9f6b40c5-b1ff-4f57-97f0-7b2ad17fc7e1
50574999-9ac9-4d9a-b10c-3b88b270d45d	t	Gishari	9f6b40c5-b1ff-4f57-97f0-7b2ad17fc7e1
3abfc4f0-dd77-4a83-bf60-0d73f490543a	t	Muguramo	9f6b40c5-b1ff-4f57-97f0-7b2ad17fc7e1
d5b6cda6-d51a-4849-b80c-9470c15668d2	t	Cyuru	22f2522f-33d9-4cbd-967f-3556fa86e012
ec99c069-a266-4564-ab4d-b85aedceb8bd	t	Gisiza	22f2522f-33d9-4cbd-967f-3556fa86e012
aeeb9bf0-e4ac-4fc1-90c3-0e4e300c4520	t	Kinyami	22f2522f-33d9-4cbd-967f-3556fa86e012
12a7db16-29f0-4e30-af74-a2ea9ed1d196	t	Mabare	22f2522f-33d9-4cbd-967f-3556fa86e012
936ccd99-f4e4-48d9-91af-0ea2885c5c9e	t	Munyinya	22f2522f-33d9-4cbd-967f-3556fa86e012
258b0041-9b06-4110-973f-c530fd3cd7bf	t	Gitega	cf1ae086-af5b-410f-8150-769aecbe29ce
7d0f4a35-f46b-4e34-a73c-be93ed531674	t	Kamutora	cf1ae086-af5b-410f-8150-769aecbe29ce
50c264f9-35d1-49f2-be14-2ee926903896	t	Karurama	cf1ae086-af5b-410f-8150-769aecbe29ce
36f9866d-55c0-41b9-9480-5f0efd0db57b	t	Bikumba	7d778528-d939-4566-94f4-14eefaa744eb
55530ad5-3109-41fd-8ac0-ab3d6cb94b98	t	Gasharu	7d778528-d939-4566-94f4-14eefaa744eb
16fa3f6b-515c-48f2-988c-b5e6ebbaeb2a	t	Gatwaro	7d778528-d939-4566-94f4-14eefaa744eb
5a19ed33-0f94-47cd-a242-593ea0757920	t	Kigabiro	7d778528-d939-4566-94f4-14eefaa744eb
42e09e9a-9304-4d7d-bbfa-3cff07a45290	t	Munanira	7d778528-d939-4566-94f4-14eefaa744eb
c966304c-442b-4e1b-bad4-6590bd056261	t	Nkoto	7d778528-d939-4566-94f4-14eefaa744eb
8f05b81e-48a6-468e-9260-460cdee06123	t	Cyandaro	319134a8-0181-4122-aa77-f59b79f7cfd6
9bb53cb1-3461-4790-ad3e-3d20901515be	t	Gasambya	319134a8-0181-4122-aa77-f59b79f7cfd6
f306f59c-fc3d-4485-9882-ce602af1dc92	t	Gashirira	319134a8-0181-4122-aa77-f59b79f7cfd6
c9692846-980c-4dc6-b6dc-7212cee63cb3	t	Kabare	319134a8-0181-4122-aa77-f59b79f7cfd6
f4222de6-9cbb-4f70-bb4e-bca6671e3ae9	t	Rebero	319134a8-0181-4122-aa77-f59b79f7cfd6
42379f4c-7cec-4c77-9de8-9a9834ca6ead	t	Ruhondo	319134a8-0181-4122-aa77-f59b79f7cfd6
72dd2c0a-9b48-430f-a24e-0ced20c007d5	t	Cyeru	b4d3e0d9-db9f-4eb5-9f61-f3416a4abd6a
ea727ffa-cca1-40d0-98f7-e0f7c46a6c0f	t	Kigabiro	b4d3e0d9-db9f-4eb5-9f61-f3416a4abd6a
1a0431b4-1b3d-4e1c-ae82-85c6728270a1	t	Nyagahinga	b4d3e0d9-db9f-4eb5-9f61-f3416a4abd6a
ca4abb0f-ec2f-4a94-9923-2acc1eb73ef3	t	Bushara	83bffdce-2942-4e89-ae0d-fedccd2d398b
04cec478-f7d1-42f2-89dc-aadf0dcc85e1	t	Shangasha	83bffdce-2942-4e89-ae0d-fedccd2d398b
5279c3bb-22e9-4e72-8333-56b62979230a	t	Gisesero	5f0ee037-467b-4cd8-83ee-33d4c0d7832c
90cf4335-c6b1-475a-938e-e22ce046ce27	t	Sahara	5f0ee037-467b-4cd8-83ee-33d4c0d7832c
7f94c380-5c1a-4b56-9d6a-bea2742ed23b	t	Bukinanyana	851d6b48-2354-4fe8-b70e-92da468feda6
d2a17279-d096-459f-bf0f-a6943b65a3ec	t	Buruba	851d6b48-2354-4fe8-b70e-92da468feda6
010279e4-6d4e-4e58-bc11-f798bb312775	t	Cyanya	851d6b48-2354-4fe8-b70e-92da468feda6
87be187c-0066-4e02-b8b4-3e20e91e57ff	t	Kabeza	851d6b48-2354-4fe8-b70e-92da468feda6
6845f4a8-8e10-4b6c-bb90-7742baa7e574	t	Migeshi	851d6b48-2354-4fe8-b70e-92da468feda6
a4e16940-6e16-46d9-9f72-44fd68e5658f	t	Rwebeya	851d6b48-2354-4fe8-b70e-92da468feda6
9987f54c-db38-41ea-a071-944e968ea52d	t	Gakoro	de8b7483-273c-4aa2-b27c-a35052a4a5d3
40896fb8-2158-4375-868c-d61166f46216	t	Gasakuza	de8b7483-273c-4aa2-b27c-a35052a4a5d3
484c6724-3ef1-4410-a4d5-87ca2afaccc4	t	Kabirizi	de8b7483-273c-4aa2-b27c-a35052a4a5d3
e30f0bd5-b5a9-4d48-a863-e2660086610f	t	Karwasa	de8b7483-273c-4aa2-b27c-a35052a4a5d3
92a89d17-8490-40d9-845b-1ddc2cc6bd65	t	Kigabiro	2bb9f492-d2fd-42f9-96e8-d32ac2c572f7
2152f233-39cf-4b7f-992d-4142bf5c46e4	t	Kivumu	2bb9f492-d2fd-42f9-96e8-d32ac2c572f7
da2b15d7-2d1c-4f42-82e7-0f02190fa495	t	Mbwe	2bb9f492-d2fd-42f9-96e8-d32ac2c572f7
6ec0f17d-59b0-4806-8b46-e4dbcbb07303	t	Muharuro	2bb9f492-d2fd-42f9-96e8-d32ac2c572f7
844fea57-b6e7-410d-be15-539e935d0c3e	t	Mudakama	d2246348-2d8e-4527-8b91-fae7d49be351
ef6c887f-586e-417b-95c3-626bd730d68d	t	Murago	d2246348-2d8e-4527-8b91-fae7d49be351
694373ca-f548-4427-967e-dc7cf8cb8f2f	t	Rubindi	d2246348-2d8e-4527-8b91-fae7d49be351
8fb0981a-68f4-4f16-bd6f-0ae76cf02449	t	Rungu	d2246348-2d8e-4527-8b91-fae7d49be351
1caf3922-7c83-4e30-bbd2-3033d0823d5e	t	Birira	7d561d14-d875-4487-be91-a523253ae391
ff4449c9-a11c-4075-87d9-cd439dfbf55b	t	Buramira	7d561d14-d875-4487-be91-a523253ae391
42837584-b0c0-42c6-b0e5-7ef7fa3c235c	t	Kivumu	7d561d14-d875-4487-be91-a523253ae391
897b0509-7051-4518-9d65-49fcffab3174	t	Kaguhu	95d24f4e-abed-4e05-8c1e-62d1b94c733e
22e76f6b-65e5-46f4-933e-1c057572c07c	t	Kampanga	95d24f4e-abed-4e05-8c1e-62d1b94c733e
441aa91d-53a3-4c31-917c-bc6038dbae36	t	Nyabigoma	95d24f4e-abed-4e05-8c1e-62d1b94c733e
d2bd8a78-98ad-4119-800f-ad245f204478	t	Nyonirima	95d24f4e-abed-4e05-8c1e-62d1b94c733e
f7bfe497-39af-4473-9ddd-99feb708183f	t	Cyabararika	49e6746a-d9c8-4d31-9a86-398fbd30191f
6e4ed059-57e0-4a38-81d7-6a71a1b8c7e5	t	Kigombe	49e6746a-d9c8-4d31-9a86-398fbd30191f
75de8a78-fa55-4d7c-a5fc-1a143a0db32e	t	Mpenge	49e6746a-d9c8-4d31-9a86-398fbd30191f
44b8db83-6a76-40e1-b724-9e50cb09e07b	t	Ruhengeri	49e6746a-d9c8-4d31-9a86-398fbd30191f
4143ade8-2fc5-42d6-b319-7340ddfe3224	t	Cyivugiza	b2b249ac-1a33-448c-b099-70e6350d3b19
10c60500-d4c7-48f3-a903-51fc432ffa2e	t	Cyogo	b2b249ac-1a33-448c-b099-70e6350d3b19
f2f7d079-0351-4257-84dd-44004c459a4f	t	Mburabuturo	b2b249ac-1a33-448c-b099-70e6350d3b19
fbb8894c-be6d-42dc-9916-7503fb6b7d99	t	Cyabagarura	bd1759be-e8b3-4e4f-a328-8db937460ef5
2015cf52-9abf-467c-a2fa-cf520769d2f6	t	Garuka	bd1759be-e8b3-4e4f-a328-8db937460ef5
cff8c68b-51ea-4f79-8618-5b110bbdbc5f	t	Kabazungu	bd1759be-e8b3-4e4f-a328-8db937460ef5
474bf0b0-b4f6-4453-96c1-841e48d64e80	t	Nyarubuye	bd1759be-e8b3-4e4f-a328-8db937460ef5
ec90d9c6-4cc5-42f1-8c95-876f0a6a8827	t	Rwambogo	bd1759be-e8b3-4e4f-a328-8db937460ef5
bedb3d64-605b-4fd9-9e36-a6e7da7985f1	t	Bikara	e3716a6e-eba2-4245-b587-facdfb15e208
541b5196-4042-4ac6-83cd-7b26ae51957b	t	Cyivugiza	8a73f3cf-cc7b-4943-8988-530f91c8be99
ee4c3eaf-c420-439b-823f-6890f0078cb1	t	Kabeza	8a73f3cf-cc7b-4943-8988-530f91c8be99
5f3e945e-dcb6-4631-af1c-ce1b092a8a7a	t	Kamwumba	8a73f3cf-cc7b-4943-8988-530f91c8be99
91b5c68e-77b3-4d6d-aabf-a82dd41b0d3c	t	Muhabura	8a73f3cf-cc7b-4943-8988-530f91c8be99
604daecb-b76d-4400-b8cb-817e6ab533a8	t	Ninda	8a73f3cf-cc7b-4943-8988-530f91c8be99
27e3c200-efbb-483b-a5e6-2365b2f1dda3	t	Gasongero	50b93d9f-4e3e-4261-9f72-7ae7c24801d7
ca5c4f82-f5c2-443f-b250-7f445db9b1c7	t	Kamisave	50b93d9f-4e3e-4261-9f72-7ae7c24801d7
0bf3e6dd-b6ce-4a57-b4e4-f9b7910a49b9	t	Murandi	50b93d9f-4e3e-4261-9f72-7ae7c24801d7
35c431bd-507c-49ab-8102-6e3ea0e7c605	t	Murwa	50b93d9f-4e3e-4261-9f72-7ae7c24801d7
0ed845be-f15d-4b69-9725-b4272107c78e	t	Rurambo	50b93d9f-4e3e-4261-9f72-7ae7c24801d7
beb7b5a6-2f43-4043-a8f0-838b7bed28da	t	Bumara	7d1d82ce-2543-4216-90fe-40d706f0b769
c502e37e-fb67-43d2-8696-b173f8848293	t	Kabushinge	7d1d82ce-2543-4216-90fe-40d706f0b769
a7e96b34-4ff0-4072-8f15-1e0d7922b7e6	t	Musezero	7d1d82ce-2543-4216-90fe-40d706f0b769
b35546ea-9434-4386-93cf-94c3466d9cc9	t	Nturo	7d1d82ce-2543-4216-90fe-40d706f0b769
712e5a31-8747-4aca-9855-c946f869c8c1	t	Nyarubuye	7d1d82ce-2543-4216-90fe-40d706f0b769
6bb18c52-c483-44c5-8549-b9dbe5a69c0e	t	Gakingo	3030ca78-8030-446c-9a38-74db88bcf526
b4b03b28-178c-428d-9f47-07f11e9e4b3f	t	Kibuguzo	3030ca78-8030-446c-9a38-74db88bcf526
eb1baa76-7f64-4f67-942b-80903510f37e	t	Mudende	3030ca78-8030-446c-9a38-74db88bcf526
4166203a-99ba-47a4-a867-dbce63b5dd72	t	Cyohoha	2688949c-44ab-40c3-8806-e516807983a0
38d11c6d-7c70-46e0-8800-f9b7a3b7eb25	t	Gitare	2688949c-44ab-40c3-8806-e516807983a0
0c85251a-a4c7-4fd9-8557-c995ff71f47f	t	Rwamahwa	2688949c-44ab-40c3-8806-e516807983a0
4bf71803-f6b8-40b0-8e5e-802511e3cccb	t	Butangampund	d0cebf1f-f4bc-4f90-a990-96cd5739601d
77e41bb8-be61-4766-bbaa-25de2b1d4359	t	Karengeri	d0cebf1f-f4bc-4f90-a990-96cd5739601d
05ca1fe4-5b7e-4095-99da-a83471b771bb	t	Taba	d0cebf1f-f4bc-4f90-a990-96cd5739601d
c7c9fc9d-3c31-430f-826b-48f057c49494	t	Gasiza	9906aa7b-6f69-4de0-8f89-026b2d8866fe
29b422eb-d42c-4ec6-be7b-cd00de5ea043	t	Giko	9906aa7b-6f69-4de0-8f89-026b2d8866fe
9fed2a9d-f360-434c-9ef6-dd8468811c8b	t	Kayenzi	9906aa7b-6f69-4de0-8f89-026b2d8866fe
2f0b2860-dded-4018-a12d-095f70b97ed7	t	Mukoto	9906aa7b-6f69-4de0-8f89-026b2d8866fe
3381232b-fef6-4114-a482-f022af5988e8	t	Nyirangarama	9906aa7b-6f69-4de0-8f89-026b2d8866fe
cfa5678c-7e3d-4f8d-9aeb-fe5c657c10c3	t	Busoro	6c65b9e8-a1bc-44e2-b10c-0e53153ce0ca
6a7325a6-6ea1-4299-9ad4-7489501f130e	t	Butare	6c65b9e8-a1bc-44e2-b10c-0e53153ce0ca
1414838e-80d6-4738-bde2-dd59ca79d1f7	t	Gahororo	6c65b9e8-a1bc-44e2-b10c-0e53153ce0ca
a68c540b-e1f7-400c-9527-8d6ef6046cf7	t	Gitumba	6c65b9e8-a1bc-44e2-b10c-0e53153ce0ca
e352e57a-d9b8-4948-b9db-b30e8e5dbfdd	t	Karama	6c65b9e8-a1bc-44e2-b10c-0e53153ce0ca
689e06f6-6367-4a71-b88c-7652a0861866	t	Mwumba	6c65b9e8-a1bc-44e2-b10c-0e53153ce0ca
183f5b01-7946-40e4-b4ba-12f1b734f4e9	t	Budakiranya	93f67cc9-aa3f-40fe-98d2-350f21a018e4
5bd4c108-a6eb-4b65-9bb0-175caf157d83	t	Migendezo	93f67cc9-aa3f-40fe-98d2-350f21a018e4
565bdd72-71bc-435a-b263-362a182a792a	t	Rudogo	93f67cc9-aa3f-40fe-98d2-350f21a018e4
4a53b407-e8fc-4b2c-a32b-9916e54fb380	t	Burehe	f7f282e2-ab2e-417a-aca7-ee00b01a1bad
6badbe13-8938-4287-b9aa-1812c3a8fd20	t	Marembo	f7f282e2-ab2e-417a-aca7-ee00b01a1bad
20d576a3-daa7-4b04-a9d0-8146938a4eda	t	Rwili	f7f282e2-ab2e-417a-aca7-ee00b01a1bad
b5eaa4ee-e6ce-439d-a95e-e0e459a8fb6e	t	Butunzi	da20730a-9f54-429d-baf6-cf72d8a3954a
9fb0920e-b3d6-4d01-9a35-4b7b37ca71b6	t	Karegamazi	da20730a-9f54-429d-baf6-cf72d8a3954a
3d613313-9886-4e3f-9d27-cb1b22dbdf29	t	Marembo	da20730a-9f54-429d-baf6-cf72d8a3954a
98943a91-5819-4813-af44-7a7afead6575	t	Rebero	da20730a-9f54-429d-baf6-cf72d8a3954a
d71a462f-e0db-4077-a396-1ff724405285	t	Kamushenyi	a466274a-f244-4805-aff4-34003f627000
3c672005-39ff-4afd-add7-9fe6d0f56021	t	Kigarama	a466274a-f244-4805-aff4-34003f627000
d132f66e-c258-4022-967b-01504e18a6bd	t	Mubuga	a466274a-f244-4805-aff4-34003f627000
5edd5baa-bc35-432c-93d4-a740b41d2108	t	Murama	a466274a-f244-4805-aff4-34003f627000
d0f4f482-32c4-4536-bb26-d518342c5c74	t	Sayo	a466274a-f244-4805-aff4-34003f627000
6e53d6e7-fb75-4680-ba4e-ce2e8db8cb3d	t	Kabuga	3dd91bae-158c-4a5d-a604-334132d7a3c4
58187818-902b-409e-93b0-c81a5b0cd12e	t	Kigarama	3dd91bae-158c-4a5d-a604-334132d7a3c4
cedd8bca-f4fb-445e-90dc-9b877efff046	t	Kivugiza	3dd91bae-158c-4a5d-a604-334132d7a3c4
f203b56d-e06c-4f47-b310-2ca2f4c3a54a	t	Nyamyumba	3dd91bae-158c-4a5d-a604-334132d7a3c4
4d2e3f95-6213-4eb7-9846-58fe2631026e	t	Shengampuli	3dd91bae-158c-4a5d-a604-334132d7a3c4
12d8088b-4444-47f3-afa0-6b7e0d82b3ee	t	Bukoro	f72c7e3c-6f21-421c-892a-2d0682bd333b
c409fa2b-6a67-41b6-b1ff-e5bfe3f3d9d9	t	Mushari	f72c7e3c-6f21-421c-892a-2d0682bd333b
868029ac-39d4-43f4-9a49-30f0467a56f3	t	Ngiramazi	f72c7e3c-6f21-421c-892a-2d0682bd333b
95f6c8ab-fdcb-4637-8b2f-79db1155a4d4	t	Rurenge	f72c7e3c-6f21-421c-892a-2d0682bd333b
43088db0-3e83-4118-9c04-c3b015130efd	t	Bubangu	346afb2b-dc00-4e81-9998-6c8ea0ffb030
b7c608f9-d61c-4238-9ce7-898b81ab39f8	t	Gatwa	346afb2b-dc00-4e81-9998-6c8ea0ffb030
f54f7db8-33ae-4e4e-9028-59a4bca25a10	t	Mugambazi	346afb2b-dc00-4e81-9998-6c8ea0ffb030
507505ed-52b3-4ea7-a551-ae189e8847d0	t	Mvuzo	346afb2b-dc00-4e81-9998-6c8ea0ffb030
e6456dcd-fdc1-4e5a-975e-106705c8bc8d	t	Kabuga	6aa1c7b9-0458-421f-9c1b-be6435113f59
42c95346-8f42-400e-b817-0a686bd5a557	t	Karambo	6aa1c7b9-0458-421f-9c1b-be6435113f59
1b1a7266-7238-4777-9649-59d891363a96	t	Mugote	6aa1c7b9-0458-421f-9c1b-be6435113f59
d4eaab27-157a-475d-ac13-bd330a013d27	t	Munyarwanda	6aa1c7b9-0458-421f-9c1b-be6435113f59
30c3f72f-e0f9-4af4-b3cd-d1055ce65055	t	NKajevuba	e33328b9-40fb-48e8-bebc-61aa470934b2
011a2ef0-1c3c-4244-aacc-78a471eb21a9	t	NKiyanza	e33328b9-40fb-48e8-bebc-61aa470934b2
77bd2c78-eabe-4aee-bbc8-726b7bcb706d	t	NMahaza	e33328b9-40fb-48e8-bebc-61aa470934b2
ef02abea-0e61-4221-946d-64cca10c9fd6	t	Buraro	f716f4d3-2f0c-4924-8e32-6675819043a1
e1324e40-d184-4a62-86cd-855c5c7efd17	t	Bwimo	f716f4d3-2f0c-4924-8e32-6675819043a1
5b7365b1-eade-40be-9648-7fbc4bf7728f	t	Mberuka	f716f4d3-2f0c-4924-8e32-6675819043a1
b2524828-ae85-4ff2-ae79-10bebebc1bca	t	Mbuye	f716f4d3-2f0c-4924-8e32-6675819043a1
8e825355-5fe0-4086-9a63-1266673a4079	t	Gako	a2545883-9c4e-4dcc-83ce-4278b453f193
1115052f-123e-450b-83ba-18caafb3279b	t	Kirenge	a2545883-9c4e-4dcc-83ce-4278b453f193
5f7dd11c-bd65-4bd8-bcb1-6aa8f17fd087	t	Taba	a2545883-9c4e-4dcc-83ce-4278b453f193
8e8e72b0-1487-47ff-a94d-851467f85bd1	t	Bugaragara	df3d7a4d-2ec8-4479-a0b4-7d8f18242091
35199414-34b9-4b97-b0da-e3a7900ca4a7	t	Kijabagwe	df3d7a4d-2ec8-4479-a0b4-7d8f18242091
d538357f-bb46-463b-a114-65fea6e79a8b	t	Muvumu	df3d7a4d-2ec8-4479-a0b4-7d8f18242091
eb6de0f3-1e91-4543-bf58-64cdbcf48e88	t	Rubona	df3d7a4d-2ec8-4479-a0b4-7d8f18242091
f845b1c2-e9f3-4457-995b-09141eeacc17	t	Rutonde	df3d7a4d-2ec8-4479-a0b4-7d8f18242091
f074c9ae-f281-4b72-88c0-9266f38e312a	t	Barari	b221e249-93a6-464d-936e-39e54e3af868
bbe75d05-9ca9-408d-8ffa-87db7ae24fb4	t	Gahabwa	b221e249-93a6-464d-936e-39e54e3af868
a0f1a14a-ce80-4644-b226-0fbac7ef039c	t	Misezero	b221e249-93a6-464d-936e-39e54e3af868
04dd0fbe-3bfd-4d42-b2c3-eb8c51d740c3	t	Nyirabirori	b221e249-93a6-464d-936e-39e54e3af868
b12ca72a-227a-401a-aeba-985790fc38e1	t	Taba	b221e249-93a6-464d-936e-39e54e3af868
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_messages (id, created_at, created_by, updated_at, updated_by, message, sender_id, session_id) FROM stdin;
\.


--
-- Data for Name: chat_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_sessions (id, created_at, created_by, updated_at, updated_by, status, subject, agent_id, customer_id) FROM stdin;
\.


--
-- Data for Name: communication_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_logs (id, created_at, created_by, updated_at, updated_by, channel, notes, outcome, reference_id, reference_type, subject, customer_id, handled_by_id) FROM stdin;
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coupons (id, created_at, created_by, updated_at, updated_by, active, amount, code, current_usage, expiry_date, minimum_order_amount, type, usage_limit) FROM stdin;
\.


--
-- Data for Name: customer_addresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_addresses (id, created_at, created_by, updated_at, updated_by, cell, default_address, delivery_instructions, delivery_phone_number, district, label, province, sector, village, customer_id) FROM stdin;
\.


--
-- Data for Name: customer_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_metrics (id, created_at, created_by, updated_at, updated_by, average_order_value, engagement_score, return_rate_percentage, customer_id) FROM stdin;
\.


--
-- Data for Name: customer_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_profiles (id, created_at, created_by, updated_at, updated_by, last_purchase_date, total_purchases, total_spent, customer_id, segment_id) FROM stdin;
\.


--
-- Data for Name: customer_segments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_segments (id, created_at, created_by, updated_at, updated_by, description, name) FROM stdin;
\.


--
-- Data for Name: discounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discounts (id, created_at, created_by, updated_at, updated_by, active, description, discount_percentage, end_date, name, start_date) FROM stdin;
\.


--
-- Data for Name: districts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.districts (id, enabled, name, province_id) FROM stdin;
d21706fc-3505-490a-8399-6a0c4a2d4dac	t	Gasabo	14cc57bd-a7bb-4ea7-a0a0-58a866e8df1a
c3135047-cb9a-4b5f-bb1e-427fb26d662f	t	Kicukiro	14cc57bd-a7bb-4ea7-a0a0-58a866e8df1a
fad5e0b0-a1e5-45a3-bb82-b8312bcf47dc	t	Nyarugenge	14cc57bd-a7bb-4ea7-a0a0-58a866e8df1a
4bb684cf-9f5c-4810-b553-17458299fcac	t	Gisagara	ed1b4c44-3320-4e2d-9e91-8754d7b9745a
37658c8e-cfef-4b9c-aebc-dad9e2e9ccac	t	Huye	ed1b4c44-3320-4e2d-9e91-8754d7b9745a
d9d6a5b9-c393-4a07-b999-7e2bceda6405	t	Kamonyi	ed1b4c44-3320-4e2d-9e91-8754d7b9745a
e3e750a7-551e-4dc7-8680-f3e35481888e	t	Muhanga	ed1b4c44-3320-4e2d-9e91-8754d7b9745a
f24f231c-d435-4d0b-b560-7a9dcf2d6f0e	t	Nyamagabe	ed1b4c44-3320-4e2d-9e91-8754d7b9745a
c38e472d-5791-433b-8403-7f9fde27e29f	t	Nyanza	ed1b4c44-3320-4e2d-9e91-8754d7b9745a
8adc1b65-cb6a-4913-a7b8-7b17b28a19b2	t	Nyaruguru	ed1b4c44-3320-4e2d-9e91-8754d7b9745a
ade8bc38-0702-4cc8-81ba-8db040213801	t	Ruhango	ed1b4c44-3320-4e2d-9e91-8754d7b9745a
4c81705e-9112-46cd-a102-b32c465114d0	t	Karongi	fe0bb96e-0574-4b05-92e3-43bbf16babd6
453a8e19-c917-4cdf-b47d-c01b022a111d	t	Ngororero	fe0bb96e-0574-4b05-92e3-43bbf16babd6
ac3125f6-35c7-4ca8-bcd5-341c07678801	t	Nyabihu	fe0bb96e-0574-4b05-92e3-43bbf16babd6
76c6b5b1-055c-47bb-951f-3588ef207d75	t	Nyamasheke	fe0bb96e-0574-4b05-92e3-43bbf16babd6
9fe34352-b9bc-4056-92ab-0cd07301fc41	t	Rubavu	fe0bb96e-0574-4b05-92e3-43bbf16babd6
324f96d8-cc57-4467-9ce6-40f274853c37	t	Rusizi	fe0bb96e-0574-4b05-92e3-43bbf16babd6
7192da88-3baa-47b6-ae1c-4f4e6c874e36	t	Rutsiro	fe0bb96e-0574-4b05-92e3-43bbf16babd6
a07690e6-91a0-4177-aea5-9359653694f4	t	Burera	b3a2a564-5efc-4ecb-8f4d-13cd7c2f58df
558828f5-3ba7-4e72-85b5-295da86e566f	t	Gakenke	b3a2a564-5efc-4ecb-8f4d-13cd7c2f58df
9e3a438c-7d31-4cba-8f3c-74edaa07b76a	t	Gicumbi	b3a2a564-5efc-4ecb-8f4d-13cd7c2f58df
d254aedc-8dfa-40bf-9ccf-36d964e226d9	t	Musanze	b3a2a564-5efc-4ecb-8f4d-13cd7c2f58df
6b37c75b-e6f0-4e21-92a8-31fc214808b2	t	Rulindo	b3a2a564-5efc-4ecb-8f4d-13cd7c2f58df
20bfbe27-b9e0-45a7-97a2-1ddbd283f183	t	Bugesera	5054b185-b0a0-40df-b726-69e4099dea6d
90d71c2d-c8c2-4773-a08f-c818b071bf99	t	Gatsibo	5054b185-b0a0-40df-b726-69e4099dea6d
165105e6-bfab-4667-a644-b5cd80eb7626	t	Kayonza	5054b185-b0a0-40df-b726-69e4099dea6d
4236b9b6-7c03-4d80-b3e9-c9295d42940f	t	Kirehe	5054b185-b0a0-40df-b726-69e4099dea6d
ab25ec0a-f152-4540-b9d9-058e0cbe2f51	t	Ngoma	5054b185-b0a0-40df-b726-69e4099dea6d
42549013-2bba-4b8f-b8bb-30e5f9198d69	t	Nyagatare	5054b185-b0a0-40df-b726-69e4099dea6d
68e190a7-4b5d-4760-a469-7599f97a81d8	t	Rwamagana	5054b185-b0a0-40df-b726-69e4099dea6d
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, created_at, created_by, updated_at, updated_by, amount, category, description, expense_date, status) FROM stdin;
\.


--
-- Data for Name: faq_articles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.faq_articles (id, created_at, created_by, updated_at, updated_by, answer, category, published, question) FROM stdin;
\.


--
-- Data for Name: feedbacks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedbacks (id, created_at, created_by, updated_at, updated_by, category, comments, rating, reference_id, customer_id) FROM stdin;
\.


--
-- Data for Name: financial_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_reports (id, created_at, created_by, updated_at, updated_by, generated_date, net_profit, report_period, total_expenses, total_revenue) FROM stdin;
\.


--
-- Data for Name: fulfillment_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fulfillment_orders (id, created_at, created_by, updated_at, updated_by, completed_at, dispatched_at, packed_at, picked_at, status, order_id, shipment_id) FROM stdin;
\.


--
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_items (id, created_at, created_by, updated_at, updated_by, location, low_stock_threshold, product_name, quantity, sku, unit_cost) FROM stdin;
a5f584ce-55ac-4b83-a7e3-647754313f64	2026-07-13 20:36:22.800208	\N	2026-07-13 20:39:26.616257	\N	Main Warehouse	5	Cisco Catalyst 8200 Series (C8200L-1N-4T)	30	CISCO-ROUTER	3800000.00
\.


--
-- Data for Name: kpi_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kpi_records (id, created_at, created_by, updated_at, updated_by, description, metric_name, metric_value, record_date) FROM stdin;
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_attempts (id, created_at, created_by, updated_at, updated_by, email, failure_reason, ip_address, success) FROM stdin;
\.


--
-- Data for Name: mfa_otps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mfa_otps (id, created_at, created_by, updated_at, updated_by, code_hash, expiry_date, mfa_token, used, user_id) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, created_at, created_by, updated_at, updated_by, message, read, related_id, title, type, user_id) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, created_at, created_by, updated_at, updated_by, applied_tax_code, applied_tax_name, applied_tax_rate, line_cost, line_tax_amount, line_total_including_tax, quantity, sub_total, unit_cost, unit_price, unit_price_including_tax, unit_tax_amount, order_id, product_id) FROM stdin;
\.


--
-- Data for Name: order_tracking_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_tracking_events (id, created_at, created_by, updated_at, updated_by, note, status, order_id) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, created_at, created_by, updated_at, updated_by, billing_address, coupon_code, delivery_instructions, delivery_phone_number, discount_amount, order_channel, order_number, payment_method, payment_reference, shipping_address, shipping_cell, shipping_district, shipping_province, shipping_sector, shipping_village, status, sub_total_amount, tax_amount, tax_rate, total_amount, cashier_id, customer_id, shipping_address_id) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (id, created_at, created_by, updated_at, updated_by, expiry_date, token, used, user_id) FROM stdin;
\.


--
-- Data for Name: payment_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_transactions (id, created_at, created_by, updated_at, updated_by, amount, payment_reference, provider, reconciled_at, reconciliation_notes, reconciliation_status, status, transaction_type, order_id) FROM stdin;
\.


--
-- Data for Name: procurement_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.procurement_orders (id, created_at, created_by, updated_at, updated_by, expected_delivery_date, quantity_ordered, quantity_received, status, total_cost, unit_cost, inventory_item_id, product_id, supplier_id) FROM stdin;
dc760987-1cd1-4cb5-8801-f596c8b14e61	2026-07-13 20:39:18.192069	\N	2026-07-13 20:39:26.585161	\N	2026-07-13	30	30	RECEIVED	114000000.00	3800000.00	a5f584ce-55ac-4b83-a7e3-647754313f64	9014ebea-5b8e-4653-850f-02c7307669cf	e7cc01f1-6c93-4bba-8948-ccdc89d8f79f
\.


--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_images (id, created_at, created_by, updated_at, updated_by, alt_text, is_primary, url, product_id) FROM stdin;
468c1023-edca-4c8d-a2b4-895087330010	2026-07-13 20:36:22.790908	\N	2026-07-13 20:36:22.790908	\N		t	/uploads/products/325f89f0-58ac-4f87-9388-ef4e79fc9679.jfif	9014ebea-5b8e-4653-850f-02c7307669cf
\.


--
-- Data for Name: product_reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_reviews (id, created_at, created_by, updated_at, updated_by, comment, rating, verified_purchase, product_id, user_id) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, created_at, created_by, updated_at, updated_by, average_rating, cost_price, description, featured, name, price, sku, status, category_id, discount_id, inventory_item_id, tax_rate_id) FROM stdin;
9014ebea-5b8e-4653-850f-02c7307669cf	2026-07-13 20:36:22.755582	\N	2026-07-13 20:36:22.957765	\N	0.00	0.00	: A compact 1RU cloud-edge platform built for small-to-medium enterprise branch offices. It includes 4 built-in Gigabit Ethernet WAN ports, 1 NIM expansion slot, and hardware-accelerated IPsec VPN throughput up to 500 Mbps to natively drive Cisco Catalyst SD-WAN architectures	f	Cisco Catalyst 8200 Series (C8200L-1N-4T)	3800000.00	CISCO-ROUTER	ACTIVE	5c43f8cd-7892-4f9d-809d-67f380990110	\N	a5f584ce-55ac-4b83-a7e3-647754313f64	a5c8e047-f802-4211-86fc-0dfb423ddcb7
\.


--
-- Data for Name: provinces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.provinces (id, enabled, name) FROM stdin;
14cc57bd-a7bb-4ea7-a0a0-58a866e8df1a	t	Kigali City
ed1b4c44-3320-4e2d-9e91-8754d7b9745a	t	Southern Province
fe0bb96e-0574-4b05-92e3-43bbf16babd6	t	Western Province
b3a2a564-5efc-4ecb-8f4d-13cd7c2f58df	t	Northern Province
5054b185-b0a0-40df-b726-69e4099dea6d	t	Eastern Province
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, created_at, created_by, updated_at, updated_by, expiry_date, revoked, token, user_id) FROM stdin;
\.


--
-- Data for Name: return_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.return_requests (id, created_at, created_by, updated_at, updated_by, admin_notes, approved_at, completed_at, reason, refund_provider, refund_reference, refund_requested_at, refund_status, refunded_amount, requested_amount, status, order_id) FROM stdin;
\.


--
-- Data for Name: revenues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.revenues (id, created_at, created_by, updated_at, updated_by, amount, reference_id, revenue_date, source) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, created_at, created_by, updated_at, updated_by, description, name) FROM stdin;
28bc92be-c46a-4eac-b3a3-371abb3d58de	2026-07-13 20:31:25.364075	\N	2026-07-13 20:31:25.364075	\N	Default role: ROLE_ADMIN	ROLE_ADMIN
f7150686-fd23-43a2-bf6d-4b221bd6f21c	2026-07-13 20:31:25.376629	\N	2026-07-13 20:31:25.376629	\N	Default role: ROLE_EMPLOYEE	ROLE_EMPLOYEE
34707fd3-cb6c-4b60-99b1-0a74da0f1d5c	2026-07-13 20:31:25.380156	\N	2026-07-13 20:31:25.380156	\N	Default role: ROLE_CUSTOMER	ROLE_CUSTOMER
9a85aeb0-b614-422e-b8c7-c968ce74bed4	2026-07-13 20:31:25.390149	\N	2026-07-13 20:31:25.390149	\N	Default role: ROLE_SUPPORT_AGENT	ROLE_SUPPORT_AGENT
\.


--
-- Data for Name: sales_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_reports (id, created_at, created_by, updated_at, updated_by, active_customers, report_date, report_period, total_orders, total_revenue) FROM stdin;
\.


--
-- Data for Name: satisfaction_surveys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.satisfaction_surveys (id, created_at, created_by, updated_at, updated_by, feedback, rating, ticket_id) FROM stdin;
\.


--
-- Data for Name: sectors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sectors (id, enabled, name, district_id) FROM stdin;
0a01c67c-79a6-4e1f-b613-b959c0a28eaa	t	Bumbogo	d21706fc-3505-490a-8399-6a0c4a2d4dac
46edd343-b0ed-4378-8f21-22fa3b301e0e	t	Gatsata	d21706fc-3505-490a-8399-6a0c4a2d4dac
a5f9264d-6549-486b-b3d7-525e4553c91a	t	Gikomero	d21706fc-3505-490a-8399-6a0c4a2d4dac
fb3a3004-29da-48b2-81f7-7ff489fda9be	t	Gisozi	d21706fc-3505-490a-8399-6a0c4a2d4dac
86beaf47-4afe-4ef7-8d70-6859a4a01f6e	t	Jabana	d21706fc-3505-490a-8399-6a0c4a2d4dac
e038b050-139c-4942-bc38-02031f6d7485	t	Jali	d21706fc-3505-490a-8399-6a0c4a2d4dac
d4418fab-308b-4a3d-8e5d-0de1f2e5ea6f	t	Kacyiru	d21706fc-3505-490a-8399-6a0c4a2d4dac
7f2423ee-15cd-4e71-8d53-9000a6b484bb	t	Kimihurura	d21706fc-3505-490a-8399-6a0c4a2d4dac
e8316911-3b59-47d5-bc45-f105b8bddf79	t	Kimironko	d21706fc-3505-490a-8399-6a0c4a2d4dac
696f0053-5267-4519-85f1-039a4e86b9f0	t	Kinyinya	d21706fc-3505-490a-8399-6a0c4a2d4dac
056b7138-83dd-40de-b68f-c2e57127c7b9	t	Ndera	d21706fc-3505-490a-8399-6a0c4a2d4dac
f6364dce-8346-4f60-9891-7eeb0fdecd24	t	Nduba	d21706fc-3505-490a-8399-6a0c4a2d4dac
0d66bb51-af25-4590-b407-677477455237	t	Remera	d21706fc-3505-490a-8399-6a0c4a2d4dac
0d99660e-b9e4-4d71-8371-e01cbcb6f99f	t	Rusororo	d21706fc-3505-490a-8399-6a0c4a2d4dac
cafc6a44-96e8-479e-a262-980c4be228d1	t	Rutunga	d21706fc-3505-490a-8399-6a0c4a2d4dac
463b76a8-b47a-4150-8bf8-55514590bf24	t	Gahanga	c3135047-cb9a-4b5f-bb1e-427fb26d662f
2fc73e48-56c6-4602-91bf-bd03282a5103	t	Gatenga	c3135047-cb9a-4b5f-bb1e-427fb26d662f
d695f8cf-e75d-4c62-867f-01098492c16d	t	Gikondo	c3135047-cb9a-4b5f-bb1e-427fb26d662f
54c6a1d5-656d-4bbd-8be8-3695e6ee1f68	t	Kagarama	c3135047-cb9a-4b5f-bb1e-427fb26d662f
d3b6a9e9-7881-4ab0-8115-5f8c2ba8cc46	t	Kanombe	c3135047-cb9a-4b5f-bb1e-427fb26d662f
92098a18-31b9-4685-b312-8b609e88f3e1	t	Kicukiro	c3135047-cb9a-4b5f-bb1e-427fb26d662f
b537b3f9-5bb8-43ad-bc09-9b37b7d91bfb	t	Kigarama	c3135047-cb9a-4b5f-bb1e-427fb26d662f
bc63d289-0931-4774-9e79-5289e1d7a400	t	Masaka	c3135047-cb9a-4b5f-bb1e-427fb26d662f
905d0f84-b829-4147-9d77-0a2b42161f2b	t	Niboye	c3135047-cb9a-4b5f-bb1e-427fb26d662f
44587844-75e9-4940-9581-7f2e57c09ce3	t	Nyarugunga	c3135047-cb9a-4b5f-bb1e-427fb26d662f
b35070ee-8b2f-44f7-96d1-8267d667db37	t	Gitega	fad5e0b0-a1e5-45a3-bb82-b8312bcf47dc
fce63fef-f05b-427c-ba0c-614d7aba9bf6	t	Kanyinya	fad5e0b0-a1e5-45a3-bb82-b8312bcf47dc
f4a0ffe2-5bbe-488c-89f6-238f41af88cb	t	Kigali	fad5e0b0-a1e5-45a3-bb82-b8312bcf47dc
fe6cac85-61e9-4a2d-ae2e-96df1b32fae8	t	Kimisagara	fad5e0b0-a1e5-45a3-bb82-b8312bcf47dc
21c19b30-7a64-4fb7-9522-9a9bfee41143	t	Mageragere	fad5e0b0-a1e5-45a3-bb82-b8312bcf47dc
1695dc25-13c8-40cf-9065-0f2f47859406	t	Muhima	fad5e0b0-a1e5-45a3-bb82-b8312bcf47dc
68a376c7-4361-4647-a010-bfc953c4792a	t	Nyakabanda	fad5e0b0-a1e5-45a3-bb82-b8312bcf47dc
382b2b54-f769-4797-9ce6-a0dc01efabfb	t	Nyamirambo	fad5e0b0-a1e5-45a3-bb82-b8312bcf47dc
7c08603e-9442-4982-a8cd-ffa014a28aed	t	Nyarugenge	fad5e0b0-a1e5-45a3-bb82-b8312bcf47dc
55ef0dd7-13f9-464d-98ba-03867acfcdc0	t	Rwezamenyo	fad5e0b0-a1e5-45a3-bb82-b8312bcf47dc
0388e717-d8d7-430b-9740-5c96eea98be4	t	Gikonko	4bb684cf-9f5c-4810-b553-17458299fcac
173351f7-bd8a-40e1-8ccf-a43ded755495	t	Gishubi	4bb684cf-9f5c-4810-b553-17458299fcac
2a1735bd-d3b0-4365-977c-0429f08639b3	t	Kansi	4bb684cf-9f5c-4810-b553-17458299fcac
1e81c6d2-0300-4dee-a708-b34f99d7ff4a	t	Kibirizi	4bb684cf-9f5c-4810-b553-17458299fcac
fee2b6f7-71b4-4f55-8ca9-95a3dac5419f	t	Kigembe	4bb684cf-9f5c-4810-b553-17458299fcac
dbab57fc-6c0e-401f-b811-cc2f6117ca39	t	Mamba	4bb684cf-9f5c-4810-b553-17458299fcac
c6d80118-a045-42b9-932a-1875a0ba71c1	t	Muganza	4bb684cf-9f5c-4810-b553-17458299fcac
1cc29f55-8cbd-4c61-8ddf-66ba642b222a	t	Mugombwa	4bb684cf-9f5c-4810-b553-17458299fcac
832e97ce-7d2d-42ab-b662-bbd3186223cd	t	Mukindo	4bb684cf-9f5c-4810-b553-17458299fcac
92a426b1-93fc-4c2f-99c4-fe5d163ef3b7	t	Musha	4bb684cf-9f5c-4810-b553-17458299fcac
e3c32754-1f94-4f3a-9a79-b68713120efb	t	Ndora	4bb684cf-9f5c-4810-b553-17458299fcac
93fd566c-a728-46d2-a5e1-1f2ff93cfa54	t	Nyanza	4bb684cf-9f5c-4810-b553-17458299fcac
9f6dd92e-9268-4732-8a97-6beff211d63c	t	Save	4bb684cf-9f5c-4810-b553-17458299fcac
8decb1c5-e7c5-4d71-9799-f1f33c6c5052	t	Gishamvu	37658c8e-cfef-4b9c-aebc-dad9e2e9ccac
3bf7db48-2a6b-43c1-98c5-c42e7b597ecf	t	Huye	37658c8e-cfef-4b9c-aebc-dad9e2e9ccac
03ed83e7-4262-4dcb-a3e0-832ef23adcc8	t	Karama	37658c8e-cfef-4b9c-aebc-dad9e2e9ccac
147901ff-7128-442a-a8bf-be1b3c76fb3b	t	Kigoma	37658c8e-cfef-4b9c-aebc-dad9e2e9ccac
30dff643-a15d-4c96-8d0b-8b2b6be49885	t	Kinazi	37658c8e-cfef-4b9c-aebc-dad9e2e9ccac
1aa3017a-9d93-4da0-bdc4-fab703cc8535	t	Maraba	37658c8e-cfef-4b9c-aebc-dad9e2e9ccac
ccd9089b-6b99-4830-a8e2-379b74185850	t	Mbazi	37658c8e-cfef-4b9c-aebc-dad9e2e9ccac
ee906b05-e5ea-4ec8-a17f-5b71f202a394	t	Mukura	37658c8e-cfef-4b9c-aebc-dad9e2e9ccac
506ac159-d250-4145-a6b6-864e04511b5f	t	Ngoma	37658c8e-cfef-4b9c-aebc-dad9e2e9ccac
e2cede17-bdb0-459e-be35-bf3c33e7697f	t	Ruhashya	37658c8e-cfef-4b9c-aebc-dad9e2e9ccac
000f5dbb-a7fb-4440-bb35-0d710ba30402	t	Rusatira	37658c8e-cfef-4b9c-aebc-dad9e2e9ccac
bcab62b5-d5a9-4081-814b-a814a14b5814	t	Rwaniro	37658c8e-cfef-4b9c-aebc-dad9e2e9ccac
6e8e6a50-5878-47e5-971f-21a01973b5f4	t	Simbi	37658c8e-cfef-4b9c-aebc-dad9e2e9ccac
f9160dcf-e616-4322-929f-c08b2bcaddae	t	Tumba	37658c8e-cfef-4b9c-aebc-dad9e2e9ccac
e1ddb632-2743-4015-82a2-e7ad86185aeb	t	Gacurabwenge	d9d6a5b9-c393-4a07-b999-7e2bceda6405
1e942e78-188b-43ea-af3b-9db80092362e	t	Karama	d9d6a5b9-c393-4a07-b999-7e2bceda6405
d78eb1ab-9316-412e-a902-e03dd21a6393	t	Kayenzi	d9d6a5b9-c393-4a07-b999-7e2bceda6405
45619d8b-bdd4-4ad2-8cf2-6f2371469cf0	t	Kayumbu	d9d6a5b9-c393-4a07-b999-7e2bceda6405
810f3764-a776-4a17-99ac-c23b05881981	t	Mugina	d9d6a5b9-c393-4a07-b999-7e2bceda6405
8c4377c7-6574-4d0b-a4fa-99c89867519c	t	Musambira	d9d6a5b9-c393-4a07-b999-7e2bceda6405
92c56d3d-f84b-4565-b738-a964486ad874	t	Ngamba	d9d6a5b9-c393-4a07-b999-7e2bceda6405
5c2599bd-04a2-4b83-b544-9e896ce401f2	t	Nyamiyaga	d9d6a5b9-c393-4a07-b999-7e2bceda6405
124248c8-a5ef-40ae-86fb-7963144679c5	t	Nyarubaka	d9d6a5b9-c393-4a07-b999-7e2bceda6405
c837e9b2-fcf0-4bd4-86e2-d5235ff0991e	t	Rugarika	d9d6a5b9-c393-4a07-b999-7e2bceda6405
6cc922a5-8a2b-4015-97f7-b51400fdf160	t	Rukoma	d9d6a5b9-c393-4a07-b999-7e2bceda6405
bfcb5fa8-2c7c-4f05-a76d-0b3014225511	t	Runda	d9d6a5b9-c393-4a07-b999-7e2bceda6405
df558d77-e1ef-4dcf-ac50-c25082fcb266	t	Cyeza	e3e750a7-551e-4dc7-8680-f3e35481888e
8a255b7f-de97-4e14-a5e8-a131c56f68f3	t	Kabacuzi	e3e750a7-551e-4dc7-8680-f3e35481888e
af7cf2cf-30aa-4006-ba78-30ee4cdabd82	t	Kiyumba	e3e750a7-551e-4dc7-8680-f3e35481888e
5da48229-5960-4cd4-ac4f-3f75891c8608	t	Muhanga	e3e750a7-551e-4dc7-8680-f3e35481888e
21f9b004-2024-4667-8723-cb34421b644d	t	Mushishiro	e3e750a7-551e-4dc7-8680-f3e35481888e
f954ac85-b496-4a48-aa49-39221c0b430f	t	Nyabinoni	e3e750a7-551e-4dc7-8680-f3e35481888e
1e7eeac4-1cdc-4a62-a43a-b326be6765aa	t	Nyamabuye	e3e750a7-551e-4dc7-8680-f3e35481888e
1c488690-8603-462f-b566-2b74078889c7	t	Nyarusange	e3e750a7-551e-4dc7-8680-f3e35481888e
ef727609-2ad5-4cba-b606-b1233f8cac22	t	Rongi	e3e750a7-551e-4dc7-8680-f3e35481888e
c58ab6ee-3cc9-4987-93bd-2e8f34e7fb7c	t	Rugendabari	e3e750a7-551e-4dc7-8680-f3e35481888e
c35c516f-75af-4f21-9d90-2ef526b081f9	t	Shyogwe	e3e750a7-551e-4dc7-8680-f3e35481888e
f3fab009-b08b-4264-8a05-b9c04e5614ac	t	Buruhukiro	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
e5a56ded-c6d2-423f-acf4-529ac7d3ef6f	t	Cyanika	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
7e55dffb-19a0-4ddd-90de-ad1a211b785c	t	Gasaka	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
36392606-af11-4079-9726-fd9387a278fe	t	Gatare	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
a7930067-6b4b-4aea-a5e8-0c76006378e7	t	Kaduha	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
aab32ff2-9eb2-4703-8588-a02eb5fa1fbd	t	Kamegeri	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
b817a162-0fa7-4de9-b700-7b04a80a2cbf	t	Kibirizi	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
063f8e59-1906-41b3-9ee0-98803cf55590	t	Kibumbwe	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
4a26588a-6428-410b-a20d-4733a8ac21c9	t	Kitabi	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
2ccbb7a7-eb28-492c-abc7-bec2def9c543	t	Mbazi	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
b34952d4-5f81-48ac-b89b-46e37b9b6d69	t	Mugano	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
2f03368c-d03e-43f9-923c-006b95ae6c35	t	Musange	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
bf9b9f60-23ab-4ac9-80e9-7e2e9cc0e9c8	t	Musebeya	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
5329a5d2-6dfe-4b86-8819-f0d747d0d289	t	Mushubi	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
a6ab9c00-5563-4ed4-adf8-b68f4929b798	t	Nkomane	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
81e298b0-7e57-41b4-ab37-1e156e4e356e	t	Tare	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
61d1ee6d-f5b0-4d20-8b87-704e9fd2eba6	t	Uwinkingi	f24f231c-d435-4d0b-b560-7a9dcf2d6f0e
a5c86c1a-34f6-4365-aa1a-c8a401d5772b	t	Busasamana	c38e472d-5791-433b-8403-7f9fde27e29f
0eb382ca-8bbc-448c-89c8-b33258169f0a	t	Busoro	c38e472d-5791-433b-8403-7f9fde27e29f
a6fef9d4-bd7e-42c9-b60b-874aa8d55e75	t	Cyabakamyi	c38e472d-5791-433b-8403-7f9fde27e29f
79272797-385c-4ee0-bba3-de14c2540a8e	t	Kibilizi	c38e472d-5791-433b-8403-7f9fde27e29f
e7ddc72f-3d07-4c1d-9e27-c9f55991c9ad	t	Kigoma	c38e472d-5791-433b-8403-7f9fde27e29f
331147fa-756b-4d35-99ea-9325baa75f16	t	Mukingo	c38e472d-5791-433b-8403-7f9fde27e29f
e28c2906-de98-4e04-b506-04721c145428	t	Muyira	c38e472d-5791-433b-8403-7f9fde27e29f
4bc1711a-2655-4fd2-be1b-92ede8f59a1a	t	Ntyazo	c38e472d-5791-433b-8403-7f9fde27e29f
50f6acf7-0c12-432d-80fa-c2bc7ed2c2bb	t	Nyagisozi	c38e472d-5791-433b-8403-7f9fde27e29f
8ab43af9-8a55-4a36-bab6-63947ec93baa	t	Rwabicuma	c38e472d-5791-433b-8403-7f9fde27e29f
b79c3f95-c2c2-449f-a4fd-719c9c56e22b	t	Busanze	8adc1b65-cb6a-4913-a7b8-7b17b28a19b2
8810bdb3-6135-4632-be88-6d1effd62365	t	Cyahinda	8adc1b65-cb6a-4913-a7b8-7b17b28a19b2
b5bd1b18-0ee2-4e6f-850b-6c53b9f39cb2	t	Kibeho	8adc1b65-cb6a-4913-a7b8-7b17b28a19b2
841f69cd-9c8e-481e-a44e-1c596aad9eec	t	Kivu	8adc1b65-cb6a-4913-a7b8-7b17b28a19b2
00819b8f-b3c5-47fc-af18-a50170640e55	t	Mata	8adc1b65-cb6a-4913-a7b8-7b17b28a19b2
07b5ce7b-816b-4c69-b16f-da28747371f6	t	Muganza	8adc1b65-cb6a-4913-a7b8-7b17b28a19b2
5d51b7f1-4c7e-4185-9d0a-f3a844a648c2	t	Munini	8adc1b65-cb6a-4913-a7b8-7b17b28a19b2
72ad81d6-fa2b-4a93-ab8f-c3e3790343de	t	Ngera	8adc1b65-cb6a-4913-a7b8-7b17b28a19b2
eff5a0cf-18f3-4c04-9f3e-b3cddaec8ec9	t	Ngoma	8adc1b65-cb6a-4913-a7b8-7b17b28a19b2
32a1d3c3-1fd3-43ca-8f29-d4639901951a	t	Nyabimata	8adc1b65-cb6a-4913-a7b8-7b17b28a19b2
77ea66d6-ff5b-4eac-abcb-ee08086ebe4e	t	Nyagisozi	8adc1b65-cb6a-4913-a7b8-7b17b28a19b2
c4c4b347-d051-4b48-b63d-071f2e990b7c	t	Ruheru	8adc1b65-cb6a-4913-a7b8-7b17b28a19b2
89a81ad5-fdfb-4496-816d-05ea50b312f4	t	Ruramba	8adc1b65-cb6a-4913-a7b8-7b17b28a19b2
4eb1003f-ed6e-4cd3-8cb9-17723d737e08	t	Rusenge	8adc1b65-cb6a-4913-a7b8-7b17b28a19b2
e9a9d307-b6a1-4989-9a96-59e376b11db5	t	Bweramana	ade8bc38-0702-4cc8-81ba-8db040213801
7b90fa53-8c1e-4a13-be6b-0eb3abc65131	t	Byimana	ade8bc38-0702-4cc8-81ba-8db040213801
47840b0b-9f86-4833-9906-19692413a49d	t	Kabagali	ade8bc38-0702-4cc8-81ba-8db040213801
8f93049b-c929-4a9d-a836-d00e6579deb9	t	Kinazi	ade8bc38-0702-4cc8-81ba-8db040213801
4a0cf4b6-acdf-4112-afb0-459df542af36	t	Kinihira	ade8bc38-0702-4cc8-81ba-8db040213801
b01cacb7-78df-4f72-ade6-7a6cdb43f05b	t	Mbuye	ade8bc38-0702-4cc8-81ba-8db040213801
481d5717-917c-4e57-b170-89eb05bb57c0	t	Mwendo	ade8bc38-0702-4cc8-81ba-8db040213801
5ecfc649-4d73-46ab-8feb-86a81ec6b8bd	t	Ntongwe	ade8bc38-0702-4cc8-81ba-8db040213801
9dcb05a0-7c1c-4646-8d0e-0b306a272f93	t	Ruhango	ade8bc38-0702-4cc8-81ba-8db040213801
168cd725-218f-4100-bfe7-746484acf398	t	Bwishyura	4c81705e-9112-46cd-a102-b32c465114d0
f4b50f56-56d3-418a-bbe7-c7242f823037	t	Gashari	4c81705e-9112-46cd-a102-b32c465114d0
05936640-7843-4772-8b07-8a9431faee34	t	Gishyita	4c81705e-9112-46cd-a102-b32c465114d0
5f6492f1-8599-4764-a9cf-3dc8b2de67a4	t	Gitesi	4c81705e-9112-46cd-a102-b32c465114d0
7fe291b0-c18b-4dd7-8fb1-f1c6ec329580	t	Mubuga	4c81705e-9112-46cd-a102-b32c465114d0
66ae525a-ac64-4c73-a2d2-17b5845ccc8b	t	Murambi	4c81705e-9112-46cd-a102-b32c465114d0
183337ec-99c4-4873-9826-7a1e487277b6	t	Murundi	4c81705e-9112-46cd-a102-b32c465114d0
891b67bf-72dc-4c85-a7a3-9f5acb8ef43c	t	Mutuntu	4c81705e-9112-46cd-a102-b32c465114d0
3d5fb398-2e1f-4ce4-b0fb-e5430925a968	t	Rubengera	4c81705e-9112-46cd-a102-b32c465114d0
49550c5b-f2c4-4e94-820e-4778f92f5b82	t	Rugabano	4c81705e-9112-46cd-a102-b32c465114d0
8be37a89-f287-412d-8eb7-2cc3e38bf246	t	Ruganda	4c81705e-9112-46cd-a102-b32c465114d0
1b22007a-5457-422c-a4fd-c56b2cfec080	t	Rwankuba	4c81705e-9112-46cd-a102-b32c465114d0
f3121ce5-5544-4728-8b32-116e721fec6c	t	Twumba	4c81705e-9112-46cd-a102-b32c465114d0
45c8a8ab-dd4e-4f4b-b208-f807d4bfd2fb	t	BWIRA	453a8e19-c917-4cdf-b47d-c01b022a111d
ddeaf674-7089-41e9-b4b0-6babb690f1a1	t	GATUMBA	453a8e19-c917-4cdf-b47d-c01b022a111d
bdcc5e40-9f63-4b72-b29b-66108210e7c0	t	HINDIRO	453a8e19-c917-4cdf-b47d-c01b022a111d
23965fcc-fe5c-4536-8bd0-d58f03fd0294	t	KABAYA	453a8e19-c917-4cdf-b47d-c01b022a111d
603c45e5-c473-444a-8ec2-a7613b0cb900	t	KAGEYO	453a8e19-c917-4cdf-b47d-c01b022a111d
ac3179c9-9654-468a-bf16-6b2a85ff689b	t	KAVUMU	453a8e19-c917-4cdf-b47d-c01b022a111d
3916bd06-bf74-43dd-a29e-689f0d3dfbe6	t	MATYAZO	453a8e19-c917-4cdf-b47d-c01b022a111d
960d39de-1837-436a-920f-dab9c072a63c	t	MUHANDA	453a8e19-c917-4cdf-b47d-c01b022a111d
eb36cc64-0291-4be7-beb4-8ec8527616a2	t	MUHOROR	453a8e19-c917-4cdf-b47d-c01b022a111d
2f1e0f0f-200f-48d8-9ac6-225735d4d813	t	NDARO	453a8e19-c917-4cdf-b47d-c01b022a111d
037704ca-a246-4148-b76d-05724117e827	t	NGORORE	453a8e19-c917-4cdf-b47d-c01b022a111d
b6b9d12d-2321-4025-93a2-623beb2a44e6	t	NYANGE	453a8e19-c917-4cdf-b47d-c01b022a111d
8deb2942-40cf-4ea9-8bef-5dce04371026	t	SOVU	453a8e19-c917-4cdf-b47d-c01b022a111d
f0e8fe31-82ee-4e76-a488-1ed1dbc5b58b	t	Bigogwe	ac3125f6-35c7-4ca8-bcd5-341c07678801
7c045500-e163-4d9e-a16f-7f78b267def5	t	Jenda	ac3125f6-35c7-4ca8-bcd5-341c07678801
b3c876f0-9e9c-49ff-8aea-2b1e8affc36d	t	Jomba	ac3125f6-35c7-4ca8-bcd5-341c07678801
bdd48167-3708-47c8-99ee-38088e7bf3ce	t	Kabatwa	ac3125f6-35c7-4ca8-bcd5-341c07678801
91609478-5e71-4c51-8f15-d157f857e281	t	Karago	ac3125f6-35c7-4ca8-bcd5-341c07678801
57607db9-256e-4892-877a-c613cf1d57d7	t	Kintobo	ac3125f6-35c7-4ca8-bcd5-341c07678801
2ceb096e-2c7d-4c6b-8f4b-82ababac91c6	t	Mukamira	ac3125f6-35c7-4ca8-bcd5-341c07678801
fa29754b-84ea-4aae-bef9-9691f00e0b85	t	Muringa	ac3125f6-35c7-4ca8-bcd5-341c07678801
75b6e3fa-25a8-4e80-9735-5f18aad5dad8	t	Rambura	ac3125f6-35c7-4ca8-bcd5-341c07678801
31865536-efc2-48d1-90cd-f389f043ba62	t	Rugera	ac3125f6-35c7-4ca8-bcd5-341c07678801
b97251c1-d584-469e-9b27-924cf5fc8578	t	Rurembo	ac3125f6-35c7-4ca8-bcd5-341c07678801
35aaeb95-8ae7-40ae-819f-80a78c318957	t	Shyira	ac3125f6-35c7-4ca8-bcd5-341c07678801
0c15012c-bc73-43d7-b87c-e9ebbcc715bb	t	Bushekeri	76c6b5b1-055c-47bb-951f-3588ef207d75
1c96345c-cfae-4fb1-b283-b186708793dd	t	Bushenge	76c6b5b1-055c-47bb-951f-3588ef207d75
34c88d06-7bca-4eba-8c14-d03868e63d10	t	Cyato	76c6b5b1-055c-47bb-951f-3588ef207d75
ba40d50f-5034-4e48-8e51-3c0940b898b1	t	Gihombo	76c6b5b1-055c-47bb-951f-3588ef207d75
8fae484d-ed53-47c2-bef3-752b5b9c5041	t	Kagano	76c6b5b1-055c-47bb-951f-3588ef207d75
a78a269e-ebfb-4245-a8d9-dea4ae0093c7	t	Kanjongo	76c6b5b1-055c-47bb-951f-3588ef207d75
fa2b020c-6469-42aa-bbac-b48d7ef0610f	t	Karambi	76c6b5b1-055c-47bb-951f-3588ef207d75
fdd86016-c6a1-4bbc-bae8-42644113bb08	t	Karengera	76c6b5b1-055c-47bb-951f-3588ef207d75
a6a41a87-58fd-4c50-938f-1da748e0bbbb	t	Kirimbi	76c6b5b1-055c-47bb-951f-3588ef207d75
3dbfa027-a5c4-46e0-9b8f-0bd870fa9a86	t	Macuba	76c6b5b1-055c-47bb-951f-3588ef207d75
de422ab3-9d5a-406f-8d69-9b1a7480f0ec	t	Mahembe	76c6b5b1-055c-47bb-951f-3588ef207d75
e71ad559-76b7-4eb1-8081-4c782072d478	t	Nyabitekeri	76c6b5b1-055c-47bb-951f-3588ef207d75
443d2833-d9a6-404f-ad3f-dc9fa6bb4580	t	Rangiro	76c6b5b1-055c-47bb-951f-3588ef207d75
bd98ecf7-f502-432c-8dc8-7b9a7ba8d773	t	Ruharambuga	76c6b5b1-055c-47bb-951f-3588ef207d75
9663600e-fb25-427e-b533-ef0348c5d887	t	Shangi	76c6b5b1-055c-47bb-951f-3588ef207d75
fdbc9437-65d4-4c6d-8a3b-aa6f8f6b398b	t	Bugeshi	9fe34352-b9bc-4056-92ab-0cd07301fc41
baf0825b-5e00-45b1-93d8-5d2893eeaefa	t	Busasamana	9fe34352-b9bc-4056-92ab-0cd07301fc41
1d6da4bf-0f65-40bf-9ba3-53f85b27c5e9	t	Cyanzarwe	9fe34352-b9bc-4056-92ab-0cd07301fc41
acb3fdb9-431e-4deb-9699-0f5042632921	t	Gisenyi	9fe34352-b9bc-4056-92ab-0cd07301fc41
57150771-4ce4-4d0d-a359-db7a3d781324	t	Kanama	9fe34352-b9bc-4056-92ab-0cd07301fc41
cb414f4e-1937-4dc4-9445-bf6b6a68c9dd	t	Kanzenze	9fe34352-b9bc-4056-92ab-0cd07301fc41
b99eecbe-3781-4a9f-95d8-3eff74a06a2a	t	Mudende	9fe34352-b9bc-4056-92ab-0cd07301fc41
c102aa5d-39ef-4127-aa3d-1a1b39144aeb	t	Nyakiriba	9fe34352-b9bc-4056-92ab-0cd07301fc41
6b67e86a-d919-4364-8fb5-0f81ebe7d912	t	Nyamyumba	9fe34352-b9bc-4056-92ab-0cd07301fc41
d5cd644c-2f50-4463-98dd-38c29f125b9f	t	Nyundo	9fe34352-b9bc-4056-92ab-0cd07301fc41
71267c4e-21ee-4953-a803-c16e5f00d94d	t	Rubavu	9fe34352-b9bc-4056-92ab-0cd07301fc41
30100b4a-372a-4185-858a-730c4e8aec67	t	Rugerero	9fe34352-b9bc-4056-92ab-0cd07301fc41
c488b8ad-4789-4958-ae7c-cf78e61c564f	t	Bugarama	324f96d8-cc57-4467-9ce6-40f274853c37
929a8634-d37d-4cd2-b911-882dc3427616	t	Butare	324f96d8-cc57-4467-9ce6-40f274853c37
51aead6f-b42d-4ba9-b15a-4676972e45a3	t	Bweyeye	324f96d8-cc57-4467-9ce6-40f274853c37
41b1e982-f892-4296-a763-59afde2cc604	t	Gashonga	324f96d8-cc57-4467-9ce6-40f274853c37
46163c74-8f0d-4617-9100-01e8f368fb52	t	Giheke	324f96d8-cc57-4467-9ce6-40f274853c37
5f903826-7269-4c92-8d20-2a49e188030b	t	Gihundwe	324f96d8-cc57-4467-9ce6-40f274853c37
13d3eeab-8f86-4896-9eff-4e35edb45fcf	t	Gikundamvu	324f96d8-cc57-4467-9ce6-40f274853c37
6cbd0b79-8f73-41b9-96c4-475bf4042933	t	Gitambi	324f96d8-cc57-4467-9ce6-40f274853c37
55bd4f74-6268-4d04-b505-8f520787acfe	t	Kamembe	324f96d8-cc57-4467-9ce6-40f274853c37
b174e6ff-1556-44ad-9959-3ad741251d6b	t	Muganza	324f96d8-cc57-4467-9ce6-40f274853c37
02180150-6917-465c-afb6-31b461171820	t	Mururu	324f96d8-cc57-4467-9ce6-40f274853c37
b7430d29-1da7-4917-bdf4-57683ba88d24	t	Nkanka	324f96d8-cc57-4467-9ce6-40f274853c37
269ab3da-d472-4a5b-b23e-accb268a57aa	t	Nkombo	324f96d8-cc57-4467-9ce6-40f274853c37
41714618-7a64-4c00-8a98-6ee1236257c7	t	Nkungu	324f96d8-cc57-4467-9ce6-40f274853c37
0b1f46d3-aea9-4c29-9e43-8407193cdc89	t	Nyakabuye	324f96d8-cc57-4467-9ce6-40f274853c37
96be866e-6b21-43fd-86e9-174ef49defcd	t	Nyakarenzo	324f96d8-cc57-4467-9ce6-40f274853c37
2ad2ef62-cd24-482e-bb09-41593accfee7	t	Nzahaha	324f96d8-cc57-4467-9ce6-40f274853c37
c8b2fc5b-cc6b-45e7-acee-df8abf3d16ba	t	Rwimbogo	324f96d8-cc57-4467-9ce6-40f274853c37
5e7f9e6c-0eff-4ef4-8b50-fa0776c43626	t	Boneza	7192da88-3baa-47b6-ae1c-4f4e6c874e36
f016cea7-074d-481f-9736-4fa523ec46ba	t	Gihango	7192da88-3baa-47b6-ae1c-4f4e6c874e36
2a79c0d7-62e9-46cf-9540-1e7d787fe6a0	t	Kigeyo	7192da88-3baa-47b6-ae1c-4f4e6c874e36
bde1f348-3f02-42c7-98f4-348b4b5364a6	t	Kivumu	7192da88-3baa-47b6-ae1c-4f4e6c874e36
986c2789-458f-4e80-9d16-46786a8949e6	t	Manihira	7192da88-3baa-47b6-ae1c-4f4e6c874e36
a4752cdd-1ec3-4774-9ed2-0a097d68cfe2	t	Mukura	7192da88-3baa-47b6-ae1c-4f4e6c874e36
99531413-e404-4fd7-9515-de58cb1b32ad	t	Murunda	7192da88-3baa-47b6-ae1c-4f4e6c874e36
7cdbd544-ca80-4a2d-992a-4cee9edfc0d6	t	Musasa	7192da88-3baa-47b6-ae1c-4f4e6c874e36
127d24a5-c997-47b4-b953-16ceae3cccd3	t	Mushonyi	7192da88-3baa-47b6-ae1c-4f4e6c874e36
96c94317-77ad-4f9c-8f66-7e34b02185ac	t	Mushubati	7192da88-3baa-47b6-ae1c-4f4e6c874e36
2a142330-81f0-4efd-9c7e-180e6cb7d171	t	Nyabirasi	7192da88-3baa-47b6-ae1c-4f4e6c874e36
e041aed9-9e23-4f6d-b189-802c90a3d322	t	Ruhango	7192da88-3baa-47b6-ae1c-4f4e6c874e36
8a72f0cd-0f30-44fe-9ebe-2b5b4c6227a0	t	Rusebeya	7192da88-3baa-47b6-ae1c-4f4e6c874e36
534d5e23-fe7f-498b-9608-46ef7a58f27c	t	Bungwe	a07690e6-91a0-4177-aea5-9359653694f4
f30bf7ce-6647-4c1b-9deb-a9b593e1d36b	t	Butaro	a07690e6-91a0-4177-aea5-9359653694f4
5948213e-20e5-4658-8e7b-a9132741e95f	t	Cyanika	a07690e6-91a0-4177-aea5-9359653694f4
c33568bb-940e-467e-83fb-2f5acadc0ff8	t	Cyeru	a07690e6-91a0-4177-aea5-9359653694f4
056788d7-2649-4077-808d-8fbd011750b8	t	Gahunga	a07690e6-91a0-4177-aea5-9359653694f4
73c62420-1a56-4e97-b6e4-877db88baf37	t	Gatebe	a07690e6-91a0-4177-aea5-9359653694f4
24aaa132-99c7-4d6f-842d-126666f4102b	t	Gitovu	a07690e6-91a0-4177-aea5-9359653694f4
b2bb8ba9-2b04-4f0c-a6bf-6bce7e263e74	t	Kagogo	a07690e6-91a0-4177-aea5-9359653694f4
eaa770c5-7603-4a39-9e33-86411d01fe6e	t	Kinoni	a07690e6-91a0-4177-aea5-9359653694f4
2b6713d7-bbbe-4322-9e36-01afef4f266b	t	Kinyababa	a07690e6-91a0-4177-aea5-9359653694f4
37233d09-30f3-48bc-8391-a56e1f7eac35	t	Kivuye	a07690e6-91a0-4177-aea5-9359653694f4
c0eb9006-8bde-4370-aa96-cbed2479a730	t	Nemba	a07690e6-91a0-4177-aea5-9359653694f4
85dbc9f0-fcc0-47f7-a4d7-aa56bdab8629	t	Rugarama	a07690e6-91a0-4177-aea5-9359653694f4
95b917c7-ee25-492c-8e6b-782e792457e2	t	Rugengabari	a07690e6-91a0-4177-aea5-9359653694f4
7ba979fb-9d2e-4a66-b62a-2d7efb855086	t	Ruhunde	a07690e6-91a0-4177-aea5-9359653694f4
f6651c3e-3eee-44bf-a823-da274fcc08e5	t	Rusarabuye	a07690e6-91a0-4177-aea5-9359653694f4
1f03c5b6-3e48-4a4e-a487-5abd386cbe6e	t	Rwerere	a07690e6-91a0-4177-aea5-9359653694f4
c04be066-4f7c-4223-845d-5a80a60b652b	t	Busengo	558828f5-3ba7-4e72-85b5-295da86e566f
8cd0d9b7-8b00-4a6d-9b50-dcfbb5163d90	t	Coko	558828f5-3ba7-4e72-85b5-295da86e566f
84ae3338-b01d-443a-92a4-23bf236ffcd9	t	Cyabingo	558828f5-3ba7-4e72-85b5-295da86e566f
e7224f80-b8eb-4ba6-b5a9-261d6ab05078	t	Gakenke	558828f5-3ba7-4e72-85b5-295da86e566f
6ca384f6-d90e-4a01-9609-547722a6cf51	t	Gashenyi	558828f5-3ba7-4e72-85b5-295da86e566f
ccb170b2-9862-4585-9e96-fff2fa8f420b	t	Janja	558828f5-3ba7-4e72-85b5-295da86e566f
a1725d30-641f-4d9e-b504-1f4eed771ea3	t	Kamubuga	558828f5-3ba7-4e72-85b5-295da86e566f
6d7e31d5-a99e-4918-b32c-5e5bbcec9cef	t	Karambo	558828f5-3ba7-4e72-85b5-295da86e566f
608151e4-8644-43c0-8808-daf4d3786707	t	Kivuruga	558828f5-3ba7-4e72-85b5-295da86e566f
0af3d233-bf07-4f2b-b24e-b036f2b40dc3	t	Mataba	558828f5-3ba7-4e72-85b5-295da86e566f
44b7c8bd-8ecb-49e3-b47a-6cc94c00bf73	t	Minazi	558828f5-3ba7-4e72-85b5-295da86e566f
c393c45e-fa62-4197-a136-ce183d1231a0	t	Mugunga	558828f5-3ba7-4e72-85b5-295da86e566f
627ffe3b-81dd-43eb-9121-b29e24223ad4	t	Muhondo	558828f5-3ba7-4e72-85b5-295da86e566f
71883d0e-ae22-435a-af2f-0077daf43755	t	Muyongwe	558828f5-3ba7-4e72-85b5-295da86e566f
33b185d5-aa9c-40c9-9569-5c19282f0b3d	t	Muzo	558828f5-3ba7-4e72-85b5-295da86e566f
49b1e673-4fe7-418c-8e59-fe6d833ef532	t	Nemba	558828f5-3ba7-4e72-85b5-295da86e566f
e6e51ced-1a07-434c-b9a4-c602c36451c1	t	Ruli	558828f5-3ba7-4e72-85b5-295da86e566f
226f929c-a82f-4fd2-b1bd-4a44f2b4e302	t	Rusasa	558828f5-3ba7-4e72-85b5-295da86e566f
04ad5498-1b0d-4ab4-8f88-77ea68145f57	t	Rushashi	558828f5-3ba7-4e72-85b5-295da86e566f
c7dce37f-dd4b-49bf-af62-2555171ebea8	t	Bukure	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
2c80975d-ed3e-44d6-8904-efa57e9b9ded	t	Bwisige	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
ae52ffc1-7fc8-4a3b-8ec7-30c9e08ac7fa	t	Byumba	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
773f9722-f7a8-4e24-a440-044d9849aae5	t	Cyumba	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
9de7df69-6639-487f-b4da-132b0898ee16	t	Giti	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
37f36029-7bae-4d21-a528-9b954d9ffd5a	t	Kageyo	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
8c6ecb42-2cd9-4295-9ac1-efcb677bda17	t	Kaniga	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
5dd4589d-3d35-4c87-a577-8cc7b80d6c75	t	Manyagiro	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
d3c2191d-c917-409f-9c2e-34135e90967f	t	Miyove	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
4cf5a683-64b7-48ab-a448-28c835635522	t	Mukarange	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
dafa2b14-4baa-44a5-9d30-dd859f06020f	t	Muko	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
0d6ede8a-5c86-4acf-acba-43e1a6a24a00	t	Mutete	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
f6fbdf92-5363-4b9a-b3d8-430c147b7398	t	Nyamiyaga	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
725dac54-413d-40f1-9b30-072c934e29a5	t	Nyankenke	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
9f6b40c5-b1ff-4f57-97f0-7b2ad17fc7e1	t	Rubaya	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
22f2522f-33d9-4cbd-967f-3556fa86e012	t	Rukomo	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
cf1ae086-af5b-410f-8150-769aecbe29ce	t	Rushaki	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
7d778528-d939-4566-94f4-14eefaa744eb	t	Rutare	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
319134a8-0181-4122-aa77-f59b79f7cfd6	t	Ruvune	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
b4d3e0d9-db9f-4eb5-9f61-f3416a4abd6a	t	Rwamiko	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
83bffdce-2942-4e89-ae0d-fedccd2d398b	t	Shangasha	9e3a438c-7d31-4cba-8f3c-74edaa07b76a
5f0ee037-467b-4cd8-83ee-33d4c0d7832c	t	Busogo	d254aedc-8dfa-40bf-9ccf-36d964e226d9
851d6b48-2354-4fe8-b70e-92da468feda6	t	Cyuve	d254aedc-8dfa-40bf-9ccf-36d964e226d9
de8b7483-273c-4aa2-b27c-a35052a4a5d3	t	Gacaca	d254aedc-8dfa-40bf-9ccf-36d964e226d9
2bb9f492-d2fd-42f9-96e8-d32ac2c572f7	t	Gashaki	d254aedc-8dfa-40bf-9ccf-36d964e226d9
d2246348-2d8e-4527-8b91-fae7d49be351	t	Gataraga	d254aedc-8dfa-40bf-9ccf-36d964e226d9
7d561d14-d875-4487-be91-a523253ae391	t	Kimonyi	d254aedc-8dfa-40bf-9ccf-36d964e226d9
95d24f4e-abed-4e05-8c1e-62d1b94c733e	t	Kinigi	d254aedc-8dfa-40bf-9ccf-36d964e226d9
49e6746a-d9c8-4d31-9a86-398fbd30191f	t	Muhoza	d254aedc-8dfa-40bf-9ccf-36d964e226d9
b2b249ac-1a33-448c-b099-70e6350d3b19	t	Muko	d254aedc-8dfa-40bf-9ccf-36d964e226d9
bd1759be-e8b3-4e4f-a328-8db937460ef5	t	Musanze	d254aedc-8dfa-40bf-9ccf-36d964e226d9
e3716a6e-eba2-4245-b587-facdfb15e208	t	Nkotsi	d254aedc-8dfa-40bf-9ccf-36d964e226d9
8a73f3cf-cc7b-4943-8988-530f91c8be99	t	Nyange	d254aedc-8dfa-40bf-9ccf-36d964e226d9
50b93d9f-4e3e-4261-9f72-7ae7c24801d7	t	Remera	d254aedc-8dfa-40bf-9ccf-36d964e226d9
7d1d82ce-2543-4216-90fe-40d706f0b769	t	Rwaza	d254aedc-8dfa-40bf-9ccf-36d964e226d9
3030ca78-8030-446c-9a38-74db88bcf526	t	Shingiro	d254aedc-8dfa-40bf-9ccf-36d964e226d9
2688949c-44ab-40c3-8806-e516807983a0	t	BASE	6b37c75b-e6f0-4e21-92a8-31fc214808b2
d0cebf1f-f4bc-4f90-a990-96cd5739601d	t	BUREGA	6b37c75b-e6f0-4e21-92a8-31fc214808b2
9906aa7b-6f69-4de0-8f89-026b2d8866fe	t	BUSHOKI	6b37c75b-e6f0-4e21-92a8-31fc214808b2
6c65b9e8-a1bc-44e2-b10c-0e53153ce0ca	t	BUYOGA	6b37c75b-e6f0-4e21-92a8-31fc214808b2
93f67cc9-aa3f-40fe-98d2-350f21a018e4	t	CYINZUZI	6b37c75b-e6f0-4e21-92a8-31fc214808b2
f7f282e2-ab2e-417a-aca7-ee00b01a1bad	t	CYUNGO	6b37c75b-e6f0-4e21-92a8-31fc214808b2
da20730a-9f54-429d-baf6-cf72d8a3954a	t	KINIHIRA	6b37c75b-e6f0-4e21-92a8-31fc214808b2
a466274a-f244-4805-aff4-34003f627000	t	KISARO	6b37c75b-e6f0-4e21-92a8-31fc214808b2
3dd91bae-158c-4a5d-a604-334132d7a3c4	t	MASORO	6b37c75b-e6f0-4e21-92a8-31fc214808b2
f72c7e3c-6f21-421c-892a-2d0682bd333b	t	MBOGO	6b37c75b-e6f0-4e21-92a8-31fc214808b2
346afb2b-dc00-4e81-9998-6c8ea0ffb030	t	MURAMBI	6b37c75b-e6f0-4e21-92a8-31fc214808b2
6aa1c7b9-0458-421f-9c1b-be6435113f59	t	NGOMA	6b37c75b-e6f0-4e21-92a8-31fc214808b2
e33328b9-40fb-48e8-bebc-61aa470934b2	t	NTARABA	6b37c75b-e6f0-4e21-92a8-31fc214808b2
f716f4d3-2f0c-4924-8e32-6675819043a1	t	RUKOZO	6b37c75b-e6f0-4e21-92a8-31fc214808b2
a2545883-9c4e-4dcc-83ce-4278b453f193	t	RUSIGA	6b37c75b-e6f0-4e21-92a8-31fc214808b2
df3d7a4d-2ec8-4479-a0b4-7d8f18242091	t	SHYORONG	6b37c75b-e6f0-4e21-92a8-31fc214808b2
b221e249-93a6-464d-936e-39e54e3af868	t	TUMBA	6b37c75b-e6f0-4e21-92a8-31fc214808b2
\.


--
-- Data for Name: security_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.security_settings (id, created_at, created_by, updated_at, updated_by, lockout_duration_minutes, max_failed_login_attempts, mfa_required, password_min_length, password_require_digit, password_require_lowercase, password_require_special_character, password_require_uppercase, session_timeout_minutes) FROM stdin;
\.


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipments (id, created_at, created_by, updated_at, updated_by, actual_delivery_date, carrier, estimated_delivery_date, status, tracking_number, order_id) FROM stdin;
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_movements (id, created_at, created_by, updated_at, updated_by, quantity, reason, reference_id, type, inventory_item_id) FROM stdin;
fa1e3374-2d8c-465a-b746-14d44dc7c42f	2026-07-13 20:39:26.611038	\N	2026-07-13 20:39:26.611038	\N	30	Procurement received	dc760987-1cd1-4cb5-8801-f596c8b14e61	PROCUREMENT	a5f584ce-55ac-4b83-a7e3-647754313f64
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, created_at, created_by, updated_at, updated_by, active, address, contact_email, contact_phone, name, notes, performance_rating) FROM stdin;
e7cc01f1-6c93-4bba-8948-ccdc89d8f79f	2026-07-13 20:38:44.020143	\N	2026-07-13 20:38:44.020143	\N	t	KN 501 AVE	kwizeraolivier06@gmail.com	0788997766	Kwizera Olivier	He supplier cisco devices	4
\.


--
-- Data for Name: support_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_messages (id, created_at, created_by, updated_at, updated_by, message, sender_id, ticket_id) FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_tickets (id, created_at, created_by, updated_at, updated_by, description, priority, status, title, assigned_agent_id, customer_id) FROM stdin;
\.


--
-- Data for Name: system_backups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_backups (id, created_at, created_by, updated_at, updated_by, completed_at, file_path, message, name, restored_at, size_bytes, status) FROM stdin;
\.


--
-- Data for Name: system_configurations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_configurations (id, created_at, created_by, updated_at, updated_by, category, config_key, config_value, description, sensitive) FROM stdin;
\.


--
-- Data for Name: tax_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_rates (id, created_at, created_by, updated_at, updated_by, active, code, description, name, rate) FROM stdin;
a5c8e047-f802-4211-86fc-0dfb423ddcb7	2026-07-13 20:31:26.09757	\N	2026-07-13 20:31:26.09757	\N	t	VAT_18	Standard VAT rate	VAT 18%	0.1800
3830711d-dcbc-4ffb-9a55-14605f4fe19c	2026-07-13 20:31:26.09757	\N	2026-07-13 20:31:26.09757	\N	t	REDUCED_10	Reduced tax rate	Reduced tax 10%	0.1000
89f2b011-fabb-423a-bc8e-a01ef336d287	2026-07-13 20:31:26.09757	\N	2026-07-13 20:31:26.09757	\N	t	NO_VAT	Tax exempt	No VAT	0.0000
\.


--
-- Data for Name: tax_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_records (id, created_at, created_by, updated_at, updated_by, amount, filing_date, order_id, order_number, reference_id, status, tax_date, tax_rate, tax_type, taxable_amount) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role_id) FROM stdin;
ca8a45f5-e369-4eb8-8109-cccf938ac60c	28bc92be-c46a-4eac-b3a3-371abb3d58de
371962da-cc79-449a-843b-84e5798da411	28bc92be-c46a-4eac-b3a3-371abb3d58de
79ba1a3a-6aa3-4253-82d0-fc49e0e9934f	f7150686-fd23-43a2-bf6d-4b221bd6f21c
70eb9fd4-cdea-4f2b-a195-760ad574054a	34707fd3-cb6c-4b60-99b1-0a74da0f1d5c
bd7046a6-0501-4f9e-bbb1-523721fd0165	9a85aeb0-b614-422e-b8c7-c968ce74bed4
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, created_at, created_by, updated_at, updated_by, address, email, email_verified, enabled, first_name, force_password_change, last_login_date, last_name, locked, password, phone_number) FROM stdin;
ca8a45f5-e369-4eb8-8109-cccf938ac60c	2026-07-13 20:31:25.525171	\N	2026-07-13 20:31:25.525171	\N	\N	admin@luztech.com	t	t	System	f	\N	Administrator	f	$2a$10$WPVjPQmKSQ5cBl5WxdCkUe31MZPT4HbG6B0gXJhj77UiupHCqhHBy	\N
371962da-cc79-449a-843b-84e5798da411	2026-07-13 20:31:25.653027	\N	2026-07-13 20:31:25.653027	\N	\N	ishimwedivin2@gmail.com	t	t	Divin	f	\N	Ishimwe	f	$2a$10$8y0QzyKRgOsh4EDqk.6GsOj23UK/ccUtx5hZHbhryPyKMEkGveH5e	\N
79ba1a3a-6aa3-4253-82d0-fc49e0e9934f	2026-07-13 20:31:25.780066	\N	2026-07-13 20:31:25.780066	\N	\N	ishimwedivin01@gmail.com	t	t	Divin	f	\N	Ishimwe	f	$2a$10$WgwRtBx53Cf1zxOL7MZoAOWAV9oAddy5ftJTf4THYHYJa3elifz.e	\N
70eb9fd4-cdea-4f2b-a195-760ad574054a	2026-07-13 20:31:25.943566	\N	2026-07-13 20:31:25.943566	\N	\N	ishimdivin2019@gmail.com	t	t	Divin	f	\N	Ishimwe	f	$2a$10$f/kVmV3ag27g1dWfstXvKeN7dyxoSfrtr3ZnBEm1aRzIg2i06gTjC	\N
bd7046a6-0501-4f9e-bbb1-523721fd0165	2026-07-13 20:31:26.0575	\N	2026-07-13 20:31:26.0575	\N	\N	idivin44@gmail.com	t	t	Divin	f	\N	Ishimwe	f	$2a$10$xDBk/Xbknyb6U75.DYa.AeSJlTxbU6kgHWHPv.1B5kSe/mL0dTZdS	\N
\.


--
-- Data for Name: villages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.villages (id, enabled, name, cell_id) FROM stdin;
dce0c434-350d-4b2e-858a-5254c98f4fc0	t	Akakaza	ca44860c-fe25-405f-8065-992a58dd6489
e3f12c3d-eb79-494c-bb33-0680ecc61401	t	Muhozi	ca44860c-fe25-405f-8065-992a58dd6489
b7cc8b65-91b5-4a39-bda4-5afe91733f2d	t	Rubungo	ca44860c-fe25-405f-8065-992a58dd6489
9749b705-525d-4543-bad1-62e87471b75e	t	Ryakigogo	ca44860c-fe25-405f-8065-992a58dd6489
6102c2d2-825a-4136-bce0-fcc3abe75cfc	t	Zindiro	ca44860c-fe25-405f-8065-992a58dd6489
db2fadfa-f826-4147-833b-1f5950a9af03	t	Kagarama	f96eb74a-336d-4301-b29c-81ffae09729b
39290d49-58fa-4ad3-8d34-4b1f5210bb1c	t	Kayumba	f96eb74a-336d-4301-b29c-81ffae09729b
1e2dd2a0-7887-4e5e-a9d0-9871af2cc212	t	Ramba	f96eb74a-336d-4301-b29c-81ffae09729b
4d290476-03a0-40fb-8f67-f534c33db5e9	t	Rebero	f96eb74a-336d-4301-b29c-81ffae09729b
987851f2-8036-4e14-890f-d2394bf5bf90	t	Rugando	f96eb74a-336d-4301-b29c-81ffae09729b
32aab676-48b6-4565-b77e-4eb1234709f7	t	Kigabiro	cc8970f6-b373-4bd9-b9af-476c7dca60e0
ebcb443f-52a9-4e29-beef-c1cb12447bac	t	Kiyoro	cc8970f6-b373-4bd9-b9af-476c7dca60e0
b08b0ff4-d606-4fe1-ac11-ebbb33425bec	t	Murarambo	cc8970f6-b373-4bd9-b9af-476c7dca60e0
6324014e-8e5a-4927-809b-8175ccefd716	t	Nkona	cc8970f6-b373-4bd9-b9af-476c7dca60e0
a466b642-205f-492e-99d5-e2bb7371a571	t	Nyakabingo	cc8970f6-b373-4bd9-b9af-476c7dca60e0
3e35220d-a0d5-4165-b3f5-382eab32e787	t	Rukoma	cc8970f6-b373-4bd9-b9af-476c7dca60e0
3ecc0fcc-d63f-49d1-8789-e9df3a93d614	t	Birembo	8d174020-c8e0-41bf-8323-e6f35cebfb3a
6c6305a0-8e2a-4956-a8c5-c796d5f5e3d7	t	Gisasa	8d174020-c8e0-41bf-8323-e6f35cebfb3a
43c8ee6b-a1ef-4224-8aa2-a1a91c8bd69f	t	Munini	8d174020-c8e0-41bf-8323-e6f35cebfb3a
751ba462-c616-4ce9-bcc8-bdc3b425e22f	t	Ruhinga	8d174020-c8e0-41bf-8323-e6f35cebfb3a
821416be-2dff-4767-988a-633edc626a76	t	Uwaruraza	8d174020-c8e0-41bf-8323-e6f35cebfb3a
0ff49212-6a39-4b03-a649-9d75e10ab2cd	t	Akabenejuru	2567f7db-d121-4516-a33f-3b4ba4ded5de
3e70dbaf-b2ca-44ea-ba9d-f6a0633e2142	t	Akasedogo	2567f7db-d121-4516-a33f-3b4ba4ded5de
1b5514d8-f414-4e5a-9fb9-cd503bc7e8b6	t	Akimpama	2567f7db-d121-4516-a33f-3b4ba4ded5de
085a3d0d-477e-4bec-b92b-79f4bdef5267	t	Burima	2567f7db-d121-4516-a33f-3b4ba4ded5de
cacf2e07-ffd5-4f66-8e76-aed09d51e6c2	t	Kityazo	2567f7db-d121-4516-a33f-3b4ba4ded5de
9965d06d-f74a-4e89-bbbf-c477b1179a7a	t	Bushya	f1df1f42-6f02-4436-8833-69fbbb3a5c1e
67cc574b-46f1-41fd-8777-164547cb39e1	t	Gikumba	f1df1f42-6f02-4436-8833-69fbbb3a5c1e
822b411e-32cf-4e2b-b8de-76f8ff94afba	t	Kamutamu	f1df1f42-6f02-4436-8833-69fbbb3a5c1e
bb22e9b4-046b-4058-8355-eb433de94201	t	Karama	f1df1f42-6f02-4436-8833-69fbbb3a5c1e
84560e2b-4e8e-4ff0-9989-dcc7b4feb486	t	Kayenzi	f1df1f42-6f02-4436-8833-69fbbb3a5c1e
546e2043-b529-416f-ac91-bf3c076e5f44	t	Kigara	f1df1f42-6f02-4436-8833-69fbbb3a5c1e
49d8599b-3a3d-4ee4-ab89-72d9285efc9e	t	Kiriza	f1df1f42-6f02-4436-8833-69fbbb3a5c1e
8d885c3c-7077-40b8-90d1-c3c60a1eaa72	t	Masizi	f1df1f42-6f02-4436-8833-69fbbb3a5c1e
23af8959-5a86-40ee-a27d-4fe7bcc88eb5	t	Mbogo	f1df1f42-6f02-4436-8833-69fbbb3a5c1e
a070f6d5-dec3-4d9d-9334-d8ebf276c1c9	t	Nyampamo	f1df1f42-6f02-4436-8833-69fbbb3a5c1e
3d038be6-295d-472d-8a44-051694b55965	t	Akanyiramuga	f58b81fb-2e46-4b29-a977-f48ed18a1410
e8a241c9-fd15-45ec-a806-433aab5b37ff	t	Akigabiro	f58b81fb-2e46-4b29-a977-f48ed18a1410
7998380d-5677-4dfa-bec0-e7f2238ceec3	t	Gishaka	f58b81fb-2e46-4b29-a977-f48ed18a1410
c14b0077-7782-49cb-99b9-36fb79ec07dd	t	Kabuye	f58b81fb-2e46-4b29-a977-f48ed18a1410
7b08ac6a-ac8a-4daa-b546-0dd3b70fb9e2	t	Mpabwa	f58b81fb-2e46-4b29-a977-f48ed18a1410
6360ee62-0af0-4cd6-bca5-ab2f849f2fc9	t	Nyagasambu	f58b81fb-2e46-4b29-a977-f48ed18a1410
11712571-fad9-4cb3-b260-e86c2d5a71ad	t	Urutarishonga	f58b81fb-2e46-4b29-a977-f48ed18a1410
300f4bc0-4b30-4b4f-90d2-b89b16e5e293	t	Akamamana	110eb0bd-1144-4f29-a2bd-e536bb5a8693
ea68db93-2087-40cf-8b40-2419a310417e	t	Akimihigo	110eb0bd-1144-4f29-a2bd-e536bb5a8693
8b175bdb-f78b-4f08-a899-18f11bb0da0c	t	Bigega	110eb0bd-1144-4f29-a2bd-e536bb5a8693
5df8ee70-dfd7-46a0-a533-1ac7af5de18d	t	Busasamana	110eb0bd-1144-4f29-a2bd-e536bb5a8693
dce99b5e-d6d2-4461-b2f4-c542f2b6343a	t	Kingasire	110eb0bd-1144-4f29-a2bd-e536bb5a8693
7a766350-db0a-489f-ba82-9ff467b9f9e0	t	Kumuyange	110eb0bd-1144-4f29-a2bd-e536bb5a8693
acb9c750-f527-43a5-bf1b-ccd09fc7f93f	t	Muremera	110eb0bd-1144-4f29-a2bd-e536bb5a8693
18e2f964-dd64-4247-bb7c-94b403b31c1d	t	Nyagasozi	110eb0bd-1144-4f29-a2bd-e536bb5a8693
4923b28f-edea-4084-b086-5d9e8e0516d2	t	Rugoro	110eb0bd-1144-4f29-a2bd-e536bb5a8693
6cf3dd28-71ee-4553-884d-11702450b7a8	t	Rwesero	110eb0bd-1144-4f29-a2bd-e536bb5a8693
ecc81863-8434-4e1d-8dd8-e3d96fa46280	t	Tetero	110eb0bd-1144-4f29-a2bd-e536bb5a8693
273df56b-598b-4925-9f13-b02fe9a31c54	t	Agakomeye	f70e2931-2f2e-40fa-9381-0968c470561a
548f90a6-cb17-4984-90dc-114a1e8a49a1	t	Gashubi	f70e2931-2f2e-40fa-9381-0968c470561a
de896a2f-2ee4-4a5a-8dd5-e6f033303c7e	t	Gisiza	f70e2931-2f2e-40fa-9381-0968c470561a
f086f199-ae3d-4886-9e81-6ea77248d7ee	t	Hanika	f70e2931-2f2e-40fa-9381-0968c470561a
0a5d38f2-3df0-443e-af8c-e5fafb8f5230	t	Juru	f70e2931-2f2e-40fa-9381-0968c470561a
0a15aebe-0034-4eb8-b391-6393f0c258ec	t	Kibaya	f70e2931-2f2e-40fa-9381-0968c470561a
21ed90d0-3e6e-483b-9cdf-3243ddb1b77f	t	Mpakabavu	f70e2931-2f2e-40fa-9381-0968c470561a
a19cd2bd-2558-450e-89c0-944f17a4bcae	t	Musango	f70e2931-2f2e-40fa-9381-0968c470561a
e073eed9-1756-4aa8-907f-4335537c7d43	t	Ndengo	f70e2931-2f2e-40fa-9381-0968c470561a
5d981507-3e06-4cee-9b8a-5ef154f5db82	t	Nyakabande	f70e2931-2f2e-40fa-9381-0968c470561a
0ea0e29c-6b20-43c2-942d-57e3f58c9165	t	Nyakanunga	f70e2931-2f2e-40fa-9381-0968c470561a
3244e5c4-404d-4e39-a238-cb871c8e47d7	t	Rubonobono	f70e2931-2f2e-40fa-9381-0968c470561a
08f22ec8-b6ab-4c8d-baa5-82dc35b9ea7c	t	Runyonza	f70e2931-2f2e-40fa-9381-0968c470561a
5b7a7039-e1e8-4311-9fff-8319a5ae9391	t	Rusoro	f70e2931-2f2e-40fa-9381-0968c470561a
16c224ef-ceab-4d48-b63f-5e590d344954	t	Ruvumero	f70e2931-2f2e-40fa-9381-0968c470561a
14aedd2b-a657-4871-ae2d-ad1db490062a	t	Uwagatovu	f70e2931-2f2e-40fa-9381-0968c470561a
862759bb-6835-4b46-8638-8db2937fad8c	t	Agataramo	20e8f80a-ac72-4438-bbf6-58ea6d6f1201
402a0ad9-99f5-4690-b234-37e8419b4279	t	Akamwunguz	20e8f80a-ac72-4438-bbf6-58ea6d6f1201
64ef598b-ea25-4856-ac1c-6c68ddb33e7c	t	Akarubimbura	20e8f80a-ac72-4438-bbf6-58ea6d6f1201
cc45f920-a024-4853-b474-d4d1c77bab3b	t	Akisoko	20e8f80a-ac72-4438-bbf6-58ea6d6f1201
a800adc3-fca8-4d6c-862a-1990ea20d69a	t	Amarembo	20e8f80a-ac72-4438-bbf6-58ea6d6f1201
d4a127a7-94c4-4ec5-acbf-8a5d686a3f82	t	Amizero	20e8f80a-ac72-4438-bbf6-58ea6d6f1201
554493b0-8873-460b-b2be-6123dd108287	t	Bwiza	20e8f80a-ac72-4438-bbf6-58ea6d6f1201
f34364cd-a05c-4917-af6a-99ceef94fce9	t	Ihuriro	20e8f80a-ac72-4438-bbf6-58ea6d6f1201
eca048f9-3537-4192-8648-06f70564b23d	t	Isangano	20e8f80a-ac72-4438-bbf6-58ea6d6f1201
82cdaa9e-c16d-4d2e-834d-41787dee68fe	t	Kanyonyomba	20e8f80a-ac72-4438-bbf6-58ea6d6f1201
365f51e7-9b0d-4399-b6fc-d062ad4ff38b	t	Nyakariba	20e8f80a-ac72-4438-bbf6-58ea6d6f1201
47fe20ba-deb4-402a-9357-68617320f20e	t	Rwakarihejuru	20e8f80a-ac72-4438-bbf6-58ea6d6f1201
2e7ee559-94d0-4e2d-aca9-2dcb5be70a2d	t	Bwimiyange	a22b6540-9de0-4b32-9c57-5a4d6fbff460
c02f163b-4302-456a-9d22-611f7f1c0231	t	Bwingeyo	a22b6540-9de0-4b32-9c57-5a4d6fbff460
61d3c201-0a27-47c9-9d35-28b9d59cc2b0	t	Gasagara	a22b6540-9de0-4b32-9c57-5a4d6fbff460
cec27af1-78a6-4d3e-b18a-6642ba16f73b	t	Rugwiza	a22b6540-9de0-4b32-9c57-5a4d6fbff460
98d1f200-9081-41c9-96f9-0377c7e59fb7	t	Ntaganzwa	439f0a77-91e5-4c96-b699-709f125827d0
84054254-0648-4920-ab9a-041a7b358558	t	Nyagasozi	439f0a77-91e5-4c96-b699-709f125827d0
3c11d091-2664-40b7-ae4d-9309574f1965	t	Nyagisozi	439f0a77-91e5-4c96-b699-709f125827d0
53bfd1e5-d5be-4f2c-a4c1-e20229021c7b	t	Ruganda	439f0a77-91e5-4c96-b699-709f125827d0
1dfa09da-54dc-415a-983a-86be63eb8e85	t	Gahinga	40aae848-8dd8-4b20-a688-1a519bb71382
9e72cec3-cbf0-4e0f-9ede-7c0a960374cc	t	Gasharu	40aae848-8dd8-4b20-a688-1a519bb71382
f7050cfb-4288-4412-858c-66b4041d3f7b	t	Kibobo	40aae848-8dd8-4b20-a688-1a519bb71382
99954548-524a-4278-959e-3470d4670f29	t	Nombe	40aae848-8dd8-4b20-a688-1a519bb71382
705f73cc-4619-4d45-b51b-1a5ebd73f0ee	t	Munini	f5d0d715-c214-4e81-ad93-058790b75ae6
89867574-88ff-4305-afe6-5521aa1b23a1	t	Mutokerezwa	f5d0d715-c214-4e81-ad93-058790b75ae6
e1d1abfb-1ab0-4beb-bb71-c01786baf14e	t	Rudakabukirwa	f5d0d715-c214-4e81-ad93-058790b75ae6
9d3ebcf4-75a9-4f8f-8662-3d24349907d0	t	Runyinya	f5d0d715-c214-4e81-ad93-058790b75ae6
b02bc957-7132-4228-ae95-7c9045622ef5	t	Kimisebeya	c2c22331-4623-4507-870e-0806ff871a64
ce526d94-bbd5-4d9d-90f7-5c5e68beb422	t	Kivugiza	c2c22331-4623-4507-870e-0806ff871a64
333c30f9-bd31-44a4-92f6-f6608fa7cf38	t	Rugarama	c2c22331-4623-4507-870e-0806ff871a64
9851ca38-13cb-4a1d-b227-ccace75c3a7d	t	Twina	c2c22331-4623-4507-870e-0806ff871a64
31147975-f2c4-4ac8-9261-f67d20245472	t	Amajyambere	8bf23434-6812-459e-9ee9-5b87445bced3
f71ca536-b330-44c8-8d8e-6241769dff2d	t	Amarembo	8bf23434-6812-459e-9ee9-5b87445bced3
58989dac-c7c4-44b6-90dd-ee4fa08f999a	t	Byimana	8bf23434-6812-459e-9ee9-5b87445bced3
5ad1aab1-cf0c-4dbb-8a22-aee5569c5423	t	Gasave	8bf23434-6812-459e-9ee9-5b87445bced3
863c0483-f6cc-4241-9d27-d35d06ce5290	t	Gasharu	8bf23434-6812-459e-9ee9-5b87445bced3
89774f4d-329f-40e3-be49-02f1954ee0ef	t	Kagara	8bf23434-6812-459e-9ee9-5b87445bced3
481b777a-d61a-4dfe-8081-113772a92fe5	t	Nyakariba	8bf23434-6812-459e-9ee9-5b87445bced3
95324110-2f33-45ad-9e4f-2f69cc29a8bf	t	Rwinyana	8bf23434-6812-459e-9ee9-5b87445bced3
c38c180e-e0f0-4170-8a3c-f6bdf0c89eba	t	Masoro	280f4a22-137f-4773-8dac-680282411da0
77c97614-ea92-4e77-bef9-6f5eb2cb58e5	t	Kanyinya	d9dd88cd-f19a-427a-ada2-fe8d6dc603e3
3a5db141-666b-4c83-bef9-8090670b6e2f	t	Kumukenke	d9dd88cd-f19a-427a-ada2-fe8d6dc603e3
f32bc0fd-f141-4ee8-a4a8-a55cc2d23051	t	Murambi	d9dd88cd-f19a-427a-ada2-fe8d6dc603e3
252b7302-8e26-4102-b975-e0dcd6b03a54	t	Ntora	d9dd88cd-f19a-427a-ada2-fe8d6dc603e3
d6b5d57a-e976-487d-ac14-6ea9c8b8b19f	t	Rukeri	d9dd88cd-f19a-427a-ada2-fe8d6dc603e3
92400c84-036b-4482-a5c6-16868d95e816	t	Umurava	d9dd88cd-f19a-427a-ada2-fe8d6dc603e3
189262ea-fd4c-4de1-aa72-ed7c6916fb80	t	Akamatamu	a4ccd460-c75e-488c-be3a-44c4afc3eff9
c07c4f47-84b2-4adb-909e-7c0e67a3e60d	t	Cyeyere	a4ccd460-c75e-488c-be3a-44c4afc3eff9
3c24329e-e1e6-498a-a092-26c5c2e7ac33	t	Murehe	a4ccd460-c75e-488c-be3a-44c4afc3eff9
1801d499-04c4-462c-b016-699e9f20d73e	t	Nyacyonga	a4ccd460-c75e-488c-be3a-44c4afc3eff9
1db302d4-0a3b-43ba-a0bf-cc1a2eaf231d	t	Nyagasozi	a4ccd460-c75e-488c-be3a-44c4afc3eff9
fdc44bb0-cafc-4cbd-b5e7-93acdf62ee75	t	Nyarukurazo	a4ccd460-c75e-488c-be3a-44c4afc3eff9
46d32272-158a-43cf-a17d-1eba1196d290	t	Agakenke	35d338ce-9b0e-41ba-be87-790a26f51115
7a675654-5f91-491a-b9b6-be2105008a3c	t	Agatare	35d338ce-9b0e-41ba-be87-790a26f51115
af71c9c9-780b-48b3-bbdd-8fe403c90a78	t	Akinyana	35d338ce-9b0e-41ba-be87-790a26f51115
dc73446f-ba2a-441d-9921-c193b03a2810	t	Gikingo	35d338ce-9b0e-41ba-be87-790a26f51115
5bd90a06-0db0-4c31-b485-dd417bc50a3c	t	Gitega	35d338ce-9b0e-41ba-be87-790a26f51115
e1b59bf3-0eff-4473-8774-b153b3186a17	t	Gitenga	35d338ce-9b0e-41ba-be87-790a26f51115
57dedc16-b5ef-42cf-b0da-a86cc04148ad	t	Nyakabingo	35d338ce-9b0e-41ba-be87-790a26f51115
549da595-8a89-48fe-810b-b01b1f1a843d	t	Nyarurama	35d338ce-9b0e-41ba-be87-790a26f51115
1a023187-7625-43fd-9d9a-a9929b68acb7	t	Rugogwe	35d338ce-9b0e-41ba-be87-790a26f51115
f76ea966-5538-4e97-a8e9-a6b8e664d70c	t	Taba	35d338ce-9b0e-41ba-be87-790a26f51115
80eec38f-c3d3-425a-8211-cedec970c0aa	t	Amakawa	a6874be7-2b98-41e3-ae83-47e857879530
c10cd0cd-3be2-456c-a700-08ad4ea05930	t	Amasangano	a6874be7-2b98-41e3-ae83-47e857879530
7702a9d9-9026-4540-a30b-dba405e69d69	t	Buliza	a6874be7-2b98-41e3-ae83-47e857879530
4c21b3c0-eb69-49cc-a75a-7063d013c9bc	t	Ihuriro	a6874be7-2b98-41e3-ae83-47e857879530
9cf919f1-9dd6-47a0-ac58-6630be1d9baf	t	Kabeza	a6874be7-2b98-41e3-ae83-47e857879530
1b1cad60-5c11-478f-bb3f-ec1febfe3e12	t	Karuruma	a6874be7-2b98-41e3-ae83-47e857879530
c7b3dd8d-c510-4d8d-a189-5b258cffc471	t	Murama	a6874be7-2b98-41e3-ae83-47e857879530
a7c47f97-e3d4-4790-ac35-dc2a9d6c483f	t	Nyagasozi	a6874be7-2b98-41e3-ae83-47e857879530
3a3606c2-af7e-4a68-b561-0d545e470643	t	Rebero	a6874be7-2b98-41e3-ae83-47e857879530
fccc3cb5-59d1-4163-8ae1-a4a2b6099785	t	Rugarama	a6874be7-2b98-41e3-ae83-47e857879530
ab5da12d-762b-40c6-b54d-54735a8af9ac	t	Tetero	a6874be7-2b98-41e3-ae83-47e857879530
88488e9a-6d4b-4e2d-8130-faa9ab1661a3	t	Agasekabuye	4556cec7-239c-45eb-a49e-8faad6b18533
6ee4abc0-ac01-43d2-be94-f3b7ac1f7616	t	Agatare	4556cec7-239c-45eb-a49e-8faad6b18533
7fe6a1c9-f88c-49c5-b752-3de8bd101632	t	Amasangano	4556cec7-239c-45eb-a49e-8faad6b18533
c65a3b28-c455-49fb-b9c5-b6236bfeec27	t	Mubuga	4556cec7-239c-45eb-a49e-8faad6b18533
bfbb0731-2984-4361-b4bb-22e413aa2a50	t	Nyamweru	4556cec7-239c-45eb-a49e-8faad6b18533
741f2069-31c8-497d-93c6-522bdd54497a	t	Agahama	374583ef-89b6-441c-9700-58ea8cc035d5
37a4d805-b382-4eca-a75b-c2c628a9892a	t	Agasharu	374583ef-89b6-441c-9700-58ea8cc035d5
cc1f3a4f-3091-46a0-9edb-d237a2a0ec00	t	Akabuga	374583ef-89b6-441c-9700-58ea8cc035d5
cf0e0bb8-e804-49b5-96f3-3358b91696e0	t	Jurwe	374583ef-89b6-441c-9700-58ea8cc035d5
d109f9a8-9f14-4ce7-b81c-3297fa418bdf	t	Kiberinka	374583ef-89b6-441c-9700-58ea8cc035d5
df750ca9-2785-43c6-aa77-c1979cf58afb	t	Nyakirehe	374583ef-89b6-441c-9700-58ea8cc035d5
dbe688d6-c363-426c-a5ec-ef101c598648	t	Nyarubuye	374583ef-89b6-441c-9700-58ea8cc035d5
8825890c-bb0c-4604-b9eb-13a40c92de95	t	Rubona	374583ef-89b6-441c-9700-58ea8cc035d5
bb8da934-aa09-46f9-842b-eeabe64325b7	t	Rwanyanza	374583ef-89b6-441c-9700-58ea8cc035d5
7d17aa1b-3217-4a7c-9968-3a5e4ea72305	t	Uwanyange	374583ef-89b6-441c-9700-58ea8cc035d5
700fe239-f7c9-4c8c-9c1c-4ac58997cac8	t	Bugarama	bc0028fa-3773-4b09-9636-e863b39cffd7
02d30ff1-9288-4de2-b234-71f2e0454874	t	Bukamba	bc0028fa-3773-4b09-9636-e863b39cffd7
754ba375-6ecd-4ef9-b1a6-7788d117a9dd	t	Byimana	bc0028fa-3773-4b09-9636-e863b39cffd7
728bb333-1a4d-4350-aa2a-df3a40134d8a	t	Kabizoza	bc0028fa-3773-4b09-9636-e863b39cffd7
af7c166d-2ab3-4596-a77c-012e8ef945d9	t	Kinunga	bc0028fa-3773-4b09-9636-e863b39cffd7
80453cba-5892-46d9-9006-cb97595e3f6b	t	Urunyinya	bc0028fa-3773-4b09-9636-e863b39cffd7
a1cbcdb4-bd4b-4da6-8838-cc0c6658e62d	t	Rwankuba	bc0028fa-3773-4b09-9636-e863b39cffd7
2e09a167-30b6-4bea-a775-85d889660223	t	Kabande	30302e5a-3d8d-4bf1-a985-b83a21b35f7f
8de0733b-f8da-49b3-8ef0-decebe579c46	t	Gatare	30302e5a-3d8d-4bf1-a985-b83a21b35f7f
7afa7256-e7c8-4c74-a492-f946e6339766	t	Nyamugali	30302e5a-3d8d-4bf1-a985-b83a21b35f7f
9f83ce7d-4de3-41ca-8818-a50c2383951e	t	Nyarubuye	30302e5a-3d8d-4bf1-a985-b83a21b35f7f
5c331711-3119-48d0-ad76-ab64a03f4ec6	t	Gahinga	439c14f8-a353-4fb3-a659-a4e52289445b
204b4a04-a60f-4f50-a486-d32dd686e14d	t	Gatare	439c14f8-a353-4fb3-a659-a4e52289445b
d2bf0a7d-e91d-48ce-9b6e-1614deac861c	t	Umunyinya	439c14f8-a353-4fb3-a659-a4e52289445b
f4e9c4d8-c238-450c-bb7c-ddb83eda05b4	t	Agatwa	56431de6-c761-4f0e-bb3f-0c02a1ee1245
7a47a884-160b-4011-8c26-79ad706644ac	t	Kabagina	56431de6-c761-4f0e-bb3f-0c02a1ee1245
4b6d0f01-d7f4-423d-bc87-92030dcde3bb	t	Kajevuba	56431de6-c761-4f0e-bb3f-0c02a1ee1245
58f274f5-38fe-4d9e-9acd-899cf42539ec	t	Kigarama	56431de6-c761-4f0e-bb3f-0c02a1ee1245
246d9a1b-7830-428a-a17c-e2e56964d987	t	Nyagasayo	56431de6-c761-4f0e-bb3f-0c02a1ee1245
afeb2d80-6fd8-4731-b291-cd99d449f52d	t	Nyaburira	6c03c460-44d7-479e-a903-274f04e84121
dea57b66-3858-4c62-8fa7-eff4a897ea7f	t	Kirehe	6c03c460-44d7-479e-a903-274f04e84121
be2bed05-db0e-484c-9d1c-7372124eec49	t	Mataba	6c03c460-44d7-479e-a903-274f04e84121
2d233d2c-cf40-4016-a097-b27ed1c68afd	t	Nyarurembo	6c03c460-44d7-479e-a903-274f04e84121
5eb6e186-a0dd-479c-b8f8-8f77c8dee76c	t	Rubona	6c03c460-44d7-479e-a903-274f04e84121
856bb50e-2851-4914-b093-35802f05108f	t	Bwocya	e72e4726-7fd2-41f0-b856-45d93a61d1aa
580e2de3-041d-4a63-b3bc-3b55a7fece20	t	Gitaba	e72e4726-7fd2-41f0-b856-45d93a61d1aa
4b5698de-ce96-4c32-a159-2606d538b259	t	Karenge	e72e4726-7fd2-41f0-b856-45d93a61d1aa
36ad66b8-4351-4539-9b34-509d4f3841d5	t	Rugina	e72e4726-7fd2-41f0-b856-45d93a61d1aa
fbba94a4-7433-4254-91c4-a0ec84081fbd	t	Ruhihi	e72e4726-7fd2-41f0-b856-45d93a61d1aa
64b14c70-b1c3-4425-8c3f-7dd8d0911cc0	t	Agasharu	8635fd03-0563-4601-b550-05ecf747ec59
c455cb9e-483e-4e19-a34c-a82306cfd9c1	t	Agatare	8635fd03-0563-4601-b550-05ecf747ec59
565d2f42-66f9-45e6-8d91-62cb12f9c9d7	t	Kabuga	8635fd03-0563-4601-b550-05ecf747ec59
fabdf920-6aeb-4b6d-bf98-7cd29e33f430	t	Runyinya	8635fd03-0563-4601-b550-05ecf747ec59
c667c57f-865e-45f8-990b-2ce305b86bad	t	Amajyambere	4810bbb7-29f2-4d9c-a625-27a958b73e6c
0785d600-f13c-4b53-9845-44c2e6631fed	t	Bukinanyana	4810bbb7-29f2-4d9c-a625-27a958b73e6c
32acb9b5-f4bc-46c0-b2bb-d124d444ad60	t	Cyimana	4810bbb7-29f2-4d9c-a625-27a958b73e6c
7cd8357c-ca34-49fd-8245-84d4be78234d	t	Gataba	4810bbb7-29f2-4d9c-a625-27a958b73e6c
7d1066b1-8133-4f0c-9d4c-107604af48cc	t	Itetero	4810bbb7-29f2-4d9c-a625-27a958b73e6c
15d2a912-48a6-4f91-8d10-53cbfc4c48b9	t	Kabare	4810bbb7-29f2-4d9c-a625-27a958b73e6c
622a3903-ffe6-4b72-b92e-9f336cbb908b	t	Kamuhire	4810bbb7-29f2-4d9c-a625-27a958b73e6c
278192a2-abbf-4093-9c93-d2f7d3c66d69	t	Karukamba	4810bbb7-29f2-4d9c-a625-27a958b73e6c
f87f4200-51dc-4ed3-a5eb-3aa930a890b5	t	Nyagacyamo	4810bbb7-29f2-4d9c-a625-27a958b73e6c
b246c814-da49-4728-a39c-b35512993104	t	Rwinzovu	4810bbb7-29f2-4d9c-a625-27a958b73e6c
6cb2abb5-4460-4974-882b-61b39b950f5f	t	Urugwiro	4810bbb7-29f2-4d9c-a625-27a958b73e6c
b0d9b3ef-cb0d-4536-a7ee-75c714485dbb	t	Uruhongore	4810bbb7-29f2-4d9c-a625-27a958b73e6c
2b0964dc-3dfc-4907-96f3-23617fadd0c2	t	Agasaro	29f3b4e1-dcca-409c-bd08-7c48465a1fa4
93ecb915-a719-48db-bb5a-dc5dfe0186ff	t	Gasharu	29f3b4e1-dcca-409c-bd08-7c48465a1fa4
da7f0dde-1dac-485a-85a8-e46089cd2ae0	t	Inkingi	29f3b4e1-dcca-409c-bd08-7c48465a1fa4
311158f2-6426-4259-8519-051a68a5d4f9	t	Kanserege	29f3b4e1-dcca-409c-bd08-7c48465a1fa4
98fbdeeb-c349-4ffc-aa42-f697a2363b96	t	Kigugu	29f3b4e1-dcca-409c-bd08-7c48465a1fa4
9595aa77-1905-49ca-9f9d-14077978e520	t	Ruganwa	29f3b4e1-dcca-409c-bd08-7c48465a1fa4
6744f06c-bc4a-44d5-8522-02e2691df66b	t	Umuco	29f3b4e1-dcca-409c-bd08-7c48465a1fa4
8de6dc56-b723-45af-954c-946570ee566c	t	Urugero	29f3b4e1-dcca-409c-bd08-7c48465a1fa4
02b77269-90a2-4a23-be38-fd2907265288	t	Urwibutso	29f3b4e1-dcca-409c-bd08-7c48465a1fa4
50a8c167-ce19-4bfc-a495-0d183f559cd4	t	Amahoro	497d4cf1-0de8-4574-afd9-c875d25c3860
fed49340-576b-43de-a25e-fb33651a67dd	t	Bwiza	497d4cf1-0de8-4574-afd9-c875d25c3860
54f28101-c9ab-4b42-99c1-17571fa34de6	t	Ihuriro	497d4cf1-0de8-4574-afd9-c875d25c3860
b977cc3d-37b7-48e2-9b0d-fdeca248f7e4	t	Ineza	497d4cf1-0de8-4574-afd9-c875d25c3860
719d5d02-4ff3-41fa-bbe3-26d230ebff2c	t	Inyange	497d4cf1-0de8-4574-afd9-c875d25c3860
2ebe353c-4c0b-40f0-b353-efd4f92e32a1	t	Iriba	497d4cf1-0de8-4574-afd9-c875d25c3860
bf2e427f-f3a6-4576-8d03-20834548edea	t	Kabagari	497d4cf1-0de8-4574-afd9-c875d25c3860
49156fb9-601f-4e75-8178-ab8e291ca3f4	t	Ubumwe	497d4cf1-0de8-4574-afd9-c875d25c3860
455051b8-ad5c-4ddf-9894-0d0ab7c2b19b	t	Umutako	497d4cf1-0de8-4574-afd9-c875d25c3860
b4e4c8a3-1a8f-41c2-be74-9d3cbe761d83	t	Urukundo	497d4cf1-0de8-4574-afd9-c875d25c3860
9232a318-b28c-45a9-9858-d9576c0d6c49	t	Virunga	497d4cf1-0de8-4574-afd9-c875d25c3860
02ba4a11-f73e-47f0-b0d3-dc7799461579	t	Inyamibwa	5b9e8df2-d771-4a00-8ece-73f25d905f18
0fcb04ec-3d89-4a9e-b154-3a3b75b25027	t	Isangano	5b9e8df2-d771-4a00-8ece-73f25d905f18
f76d909e-0f3b-4e74-8422-8994bbdb87af	t	Isano	5b9e8df2-d771-4a00-8ece-73f25d905f18
dd6cabef-598e-4f53-90fc-2ab9bd396301	t	Ituze	5b9e8df2-d771-4a00-8ece-73f25d905f18
3a2b148c-9765-41de-9420-72b60bc15031	t	Izuba	5b9e8df2-d771-4a00-8ece-73f25d905f18
d77e80f4-c7be-4cf0-9db1-0765375c9a99	t	Juru	5b9e8df2-d771-4a00-8ece-73f25d905f18
ab191d26-802c-446a-9c22-16188d8527ad	t	Nyenyeri	5b9e8df2-d771-4a00-8ece-73f25d905f18
5ed6e177-e79e-46df-84a8-f5b2fa9c2338	t	Umurava	5b9e8df2-d771-4a00-8ece-73f25d905f18
42cbf345-14c1-46ad-afdd-ed5ed2c6f5c9	t	Urumuri	5b9e8df2-d771-4a00-8ece-73f25d905f18
8b48834e-e95e-4602-b1eb-51462c0e98be	t	Amahoro	859046a6-0bc5-4d33-b6fc-e85bcb8c9d7d
20ccfa8e-1d49-4862-a203-989556b3aa10	t	Amajyambere	859046a6-0bc5-4d33-b6fc-e85bcb8c9d7d
351d616f-275a-4db3-a18b-a587c9b9d43a	t	Imihigo	859046a6-0bc5-4d33-b6fc-e85bcb8c9d7d
c7a0acdf-c708-4c87-84c5-831d5efadb2a	t	Intambwe	859046a6-0bc5-4d33-b6fc-e85bcb8c9d7d
89df87a5-b7d1-4b7e-9956-18c9f8f29714	t	Mutara	859046a6-0bc5-4d33-b6fc-e85bcb8c9d7d
74d42664-bf26-4fbd-9fa4-1ca303ab464f	t	Rugarama	859046a6-0bc5-4d33-b6fc-e85bcb8c9d7d
9a0a059c-aa4a-4cc9-a0c8-cb279c3c96db	t	Ubumwe	859046a6-0bc5-4d33-b6fc-e85bcb8c9d7d
05226639-f644-4974-80d1-aa3bf3824c16	t	Umutekano	859046a6-0bc5-4d33-b6fc-e85bcb8c9d7d
66dfe331-1ae4-4d7e-92de-cb15140abba7	t	Urwego	859046a6-0bc5-4d33-b6fc-e85bcb8c9d7d
6b71a8f0-29a5-4ceb-8053-78e4eff6f4d6	t	Gasange	04a1de20-a2a8-4b62-a818-2b2b75add013
8e5f9934-0d4f-4fbe-a5e5-1a06f5acaf67	t	Gasasa	04a1de20-a2a8-4b62-a818-2b2b75add013
d43b6ffa-6a0a-428e-894b-41fd20417ece	t	Rebero	04a1de20-a2a8-4b62-a818-2b2b75add013
88562aae-f2c5-42f7-ad6b-d0b66c341944	t	Taba	04a1de20-a2a8-4b62-a818-2b2b75add013
3ec60c0b-4c47-47f6-bd2e-d17f04bf6cc6	t	Abatuje	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
de94888c-0345-4857-ae13-f61745b10466	t	Amariza	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
8210341a-d35b-40b2-b14e-1ae531235e32	t	Imanzi	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
1c3ee329-c26b-47f9-a2dd-1789c6141bb4	t	Imena	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
2a51b38e-e6c9-4920-872f-4493259bdab3	t	Imitari	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
0cda68b4-ceae-46b2-973e-ad16617e22b3	t	Inganji	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
a1ed87b2-6e55-4c43-8e39-3dfbfe6b5c36	t	Ingenzi	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
9ec36489-f5de-4244-9420-e7e8ea228d0d	t	Ingeri	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
ae6162bd-a3cc-4b89-9f56-e76a35b0a96f	t	Inshuti	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
69871200-5980-45c1-9818-ef0e2bf7ddc5	t	Intashyo	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
5627439d-8230-4c55-9977-9536d4fd98e9	t	Intwari	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
bfff6d95-861d-4eb1-860f-9f3580b204b9	t	Inyamibwa	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
15ec0db1-0dc5-4430-bd90-b5abce9e9a6e	t	Inyange	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
d77beb91-4296-4471-a8cf-3c55e80b6135	t	Ubwiza	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
00aa74d7-62a9-490c-ba55-0a6f8ee9a492	t	Umwezi	62e7f31f-e34e-4595-9375-a90e0a2cbc5e
dbfb9f96-e225-4a72-acc9-40fb3cea9a05	t	Akintwari	19897d72-9104-4174-8115-948a94b94849
7c85ea91-6206-471e-83d4-5c6248fae9fd	t	Buranga	19897d72-9104-4174-8115-948a94b94849
36dc7c4c-828b-4914-947f-d44f3c00dc80	t	Gasharu	19897d72-9104-4174-8115-948a94b94849
4cfaedd5-93f6-4343-90bd-d5b5381ec574	t	Ibuhoro	19897d72-9104-4174-8115-948a94b94849
decd1518-e728-4d2c-96a2-2812a223cac9	t	Kageyo	19897d72-9104-4174-8115-948a94b94849
289deb75-69fd-458e-ad53-033183973daa	t	Kamahinda	19897d72-9104-4174-8115-948a94b94849
2ad6318d-98b8-4683-9334-57394890e735	t	Karisimbi	19897d72-9104-4174-8115-948a94b94849
9e1c6083-b713-4301-8fe8-132f155330d9	t	Karongi	19897d72-9104-4174-8115-948a94b94849
cdb1c152-0ead-4d4e-9375-56e79377e4f2	t	Nyirabwana	19897d72-9104-4174-8115-948a94b94849
7d1cdc3e-630c-4c8f-b784-88ae98cdcafa	t	Ramiro	19897d72-9104-4174-8115-948a94b94849
f4d467b2-dbdc-4159-ba4d-9e958f79f989	t	Rindiro	19897d72-9104-4174-8115-948a94b94849
48b5257b-ffb8-4003-9702-772e1b72c276	t	Rugero	19897d72-9104-4174-8115-948a94b94849
3dc22421-5fb2-47b9-9284-2efd53858b23	t	Rukurazo	19897d72-9104-4174-8115-948a94b94849
2957ec4d-8a75-4460-97a5-e5fd37bbcb59	t	Urumuri	19897d72-9104-4174-8115-948a94b94849
45b71ec5-e996-44a3-a5bb-8ed8cf5f324f	t	Ibukinanyana	78a13b66-c34d-45db-9aa8-2e0efbc4f75b
3f8a8691-6b0f-455d-8c98-6d80f602d05b	t	Ibuhoro	78a13b66-c34d-45db-9aa8-2e0efbc4f75b
487363fd-50a9-410f-8c00-91203653c406	t	Ijabiro	78a13b66-c34d-45db-9aa8-2e0efbc4f75b
823fde6d-28e7-4fad-87d8-ddfa8d3ec017	t	Isangano	78a13b66-c34d-45db-9aa8-2e0efbc4f75b
97be49eb-f704-4f7a-9354-16785c0a0a02	t	Itetero	78a13b66-c34d-45db-9aa8-2e0efbc4f75b
4943fd68-30e0-4607-b6a3-684808cd3b10	t	Urugwiro	78a13b66-c34d-45db-9aa8-2e0efbc4f75b
ed45d911-1ecb-4ffb-8028-5cb482f41319	t	Akarambo	39241f3f-54ba-4f89-ade8-677e002da6ce
1b7d643b-f501-4217-b401-78d9cf6450ae	t	Akaruvusha	39241f3f-54ba-4f89-ade8-677e002da6ce
0fe451d4-0b32-4104-be15-8d66959c10b4	t	Estate 2020	39241f3f-54ba-4f89-ade8-677e002da6ce
af2fb6c1-d9cb-415f-ade4-f4d0ff4b2b84	t	Kabuhunde II	39241f3f-54ba-4f89-ade8-677e002da6ce
21148b69-07d6-4120-85aa-d1a96fc509fd	t	Urugarama	39241f3f-54ba-4f89-ade8-677e002da6ce
92197cb9-af95-4701-9053-b70923b4c08d	t	Ururembo	39241f3f-54ba-4f89-ade8-677e002da6ce
97df6180-38cb-4e86-a884-161d4e956cf9	t	Umucyo	39241f3f-54ba-4f89-ade8-677e002da6ce
974d7e11-0220-45b9-ab3e-f5968ab968c2	t	Agatare	9cc8abdd-4a50-4f6e-ba2f-156a4221a172
270b0580-4aef-42d1-94a3-0d9d75b2728e	t	Gasharu	9cc8abdd-4a50-4f6e-ba2f-156a4221a172
4168e650-2c0f-46b8-95aa-bf96e4634975	t	Kami	9cc8abdd-4a50-4f6e-ba2f-156a4221a172
0fa6144f-9580-4977-91df-30a68794f528	t	Rwankuba	9cc8abdd-4a50-4f6e-ba2f-156a4221a172
f292cc73-a34a-4e13-9482-6da2a6daad07	t	Dusenyi	aa8b2480-d27f-4071-8185-1882f7067b0c
e13f62d8-4502-4a05-a7ae-3385aa232f93	t	Gicikiza	aa8b2480-d27f-4071-8185-1882f7067b0c
30a36261-81f8-4200-b905-448ef7dfd2b8	t	Giheka	aa8b2480-d27f-4071-8185-1882f7067b0c
20cbe9f3-a9c2-43b4-be5d-80bad01cf54a	t	Kabuhunde I	aa8b2480-d27f-4071-8185-1882f7067b0c
ecc2d67a-dd95-4f70-b4cc-14d243932e83	t	Kadobogo	aa8b2480-d27f-4071-8185-1882f7067b0c
1e170a96-d4a8-48e1-a6cb-f22378f00ba4	t	Kagarama	aa8b2480-d27f-4071-8185-1882f7067b0c
3c8bbc68-f52f-415a-bf5b-8d6ab33c2576	t	Muhororo	aa8b2480-d27f-4071-8185-1882f7067b0c
e822cec1-3c25-4070-be86-ea61e20be3a6	t	Nyakabungo	aa8b2480-d27f-4071-8185-1882f7067b0c
2f890712-397c-4e85-ae21-ebbcd20e3865	t	Rukingu	aa8b2480-d27f-4071-8185-1882f7067b0c
2b322675-e17e-4bae-85a3-bff43879f9da	t	Binunga	65a4d6b1-1681-4cb3-be3f-cd9ef4f9c927
78cd9ca4-7bf9-49f9-a6ba-275732a82d18	t	Ngaruyinka	65a4d6b1-1681-4cb3-be3f-cd9ef4f9c927
e27c2161-59b8-439d-905e-0742563e7a90	t	Rusenyi	65a4d6b1-1681-4cb3-be3f-cd9ef4f9c927
1bfe359c-abec-489a-b5cb-f7faa8a014f2	t	Taba	65a4d6b1-1681-4cb3-be3f-cd9ef4f9c927
a3ea55a3-5a52-4d01-8fb1-653ba3859248	t	Akarwasa	5f8dbda1-d6af-45ad-a194-a27bcd1c0f26
86b18b22-ed01-49fa-be37-3256b3a203b3	t	Akasemurombo	5f8dbda1-d6af-45ad-a194-a27bcd1c0f26
512f7958-732d-45ee-91cf-4d8825b18c53	t	Bucyemba	5f8dbda1-d6af-45ad-a194-a27bcd1c0f26
b91fa79b-0fd8-41fe-b5f3-e4e29750ac50	t	Gasharu	5f8dbda1-d6af-45ad-a194-a27bcd1c0f26
dfabfb76-ae61-402a-9c1f-b42af174ed6d	t	Mukagarama	5f8dbda1-d6af-45ad-a194-a27bcd1c0f26
6a644345-b1ed-4acd-b808-b0fb0124f868	t	Ruhangare	5f8dbda1-d6af-45ad-a194-a27bcd1c0f26
5d3089ab-c121-43e0-8c70-bf0b27ac943f	t	Ayabakora	46adcc7b-3011-445d-8fb0-889c15ed8284
1dae8788-e171-4037-a1ab-4683b1aad02a	t	Cyaruzinge	46adcc7b-3011-445d-8fb0-889c15ed8284
7078dc72-0b88-49e6-8b8c-a5b8282d597f	t	Gashure	46adcc7b-3011-445d-8fb0-889c15ed8284
4b4d2db5-1dcd-4d1a-9a44-f8ffc933023e	t	Gatare	46adcc7b-3011-445d-8fb0-889c15ed8284
79915884-264f-4139-941a-37dfe8cc2064	t	Gisura	46adcc7b-3011-445d-8fb0-889c15ed8284
1a880343-f187-41d6-b24c-1984f53aed43	t	Karubibi	46adcc7b-3011-445d-8fb0-889c15ed8284
bbd1ff6e-9d5e-4961-be2d-b3bce916db4c	t	Mulindi	46adcc7b-3011-445d-8fb0-889c15ed8284
5ccbef9b-6344-4ec6-aa5a-adf9d7b20f55	t	Bahoze	fed05088-2c1b-43f4-9eb6-776246f06150
8ab2b359-2156-489b-a28b-4e45fb178297	t	Berwa	fed05088-2c1b-43f4-9eb6-776246f06150
8c012f7d-56da-4d6a-8303-124724759e8f	t	Buhoro	fed05088-2c1b-43f4-9eb6-776246f06150
655be3bb-8b47-4b05-ba76-a7914c7d6474	t	Burunga	fed05088-2c1b-43f4-9eb6-776246f06150
d1e2481a-f228-427f-866a-248b10bfb98f	t	Gitaraga	fed05088-2c1b-43f4-9eb6-776246f06150
999a689a-c05a-42b3-96d8-628c00b43d29	t	Kira	fed05088-2c1b-43f4-9eb6-776246f06150
46dcedd3-d001-43b6-bd8d-9d3b85395538	t	Nezerwa	fed05088-2c1b-43f4-9eb6-776246f06150
6fa64dad-2480-4213-91e2-07f66ff6f41f	t	Rugazi	fed05088-2c1b-43f4-9eb6-776246f06150
f8cf7abc-77c4-4ed1-aa9c-9656ef87c623	t	Runyonza	fed05088-2c1b-43f4-9eb6-776246f06150
6a8142bc-eeb0-4e4d-bbf8-2d00aa1101b9	t	Tumurere	fed05088-2c1b-43f4-9eb6-776246f06150
810e50e5-6263-43e4-b0fe-a992aefe0034	t	Ururembo	fed05088-2c1b-43f4-9eb6-776246f06150
bb0ff66b-9406-442c-a924-d9823aa61612	t	Byimana	280f4a22-137f-4773-8dac-680282411da0
6beb457d-1797-4df2-ad45-862a2519df81	t	Kabeza	280f4a22-137f-4773-8dac-680282411da0
bdb4a75e-3787-4e6b-9cec-421c7f857761	t	Matwari	280f4a22-137f-4773-8dac-680282411da0
eb36278f-47fb-4c12-b697-9cfed8918c3c	t	Mubuga	280f4a22-137f-4773-8dac-680282411da0
f5f1dc8a-4f40-496a-acf7-61500e8cd6fe	t	Munini	280f4a22-137f-4773-8dac-680282411da0
cddd73f8-6c93-4d62-b5b9-61456ddc4033	t	Akamusare	e90b6a67-3b90-409d-a24e-91b467d3b698
c83d0465-993c-43b6-b7f9-2a2106be9bbc	t	Akimana	e90b6a67-3b90-409d-a24e-91b467d3b698
a4048a40-97b9-4c0a-8b1d-77b0d41e3d26	t	Gasharu	e90b6a67-3b90-409d-a24e-91b467d3b698
18b0092d-0cf6-4651-8e7d-0458e6e2e34c	t	Jurwe	e90b6a67-3b90-409d-a24e-91b467d3b698
08e3495c-cd4d-4153-a973-5b00e8ba5d4e	t	Karambo	e90b6a67-3b90-409d-a24e-91b467d3b698
246c98bd-cd30-41ac-8567-5c2c3c41619a	t	Kigabiro	e90b6a67-3b90-409d-a24e-91b467d3b698
57d84e75-1a2b-4651-b998-2fda280c794e	t	Ruseno	e90b6a67-3b90-409d-a24e-91b467d3b698
59f3e870-5965-4c3c-947f-805635d235ca	t	Kacyinyaga	93b50513-f3f8-4f12-a6bc-d12eb154ee86
585887a6-8990-41a5-a0b2-e8572e7c8916	t	Kamahoro	93b50513-f3f8-4f12-a6bc-d12eb154ee86
4d8ea49e-b82d-4ff8-b44c-033c8e282d51	t	Munini	93b50513-f3f8-4f12-a6bc-d12eb154ee86
f52ad27d-f405-4f7d-a64d-fd06ea536845	t	Nyakagezi	93b50513-f3f8-4f12-a6bc-d12eb154ee86
b1ea881f-cb5e-44bc-a7c1-673551d85979	t	Ruhangare	93b50513-f3f8-4f12-a6bc-d12eb154ee86
644051ad-ba12-4238-9888-313f86dd2232	t	Ruhogo	93b50513-f3f8-4f12-a6bc-d12eb154ee86
081976cf-9d94-44de-83fa-255d173aeec8	t	Kanani	f6f1f309-e671-40ee-b5b3-7e9691ef4d4a
5cbf2fff-7f3f-4048-ac91-9d1a19c8f6e9	t	Kidahe	f6f1f309-e671-40ee-b5b3-7e9691ef4d4a
cd164e02-714b-416c-8b83-025c2b02e756	t	Kigabiro	f6f1f309-e671-40ee-b5b3-7e9691ef4d4a
3ba5a769-93ce-42f4-91af-0c017cfcf96d	t	Nyamurambi	f6f1f309-e671-40ee-b5b3-7e9691ef4d4a
9ee1eabe-f613-446e-8acd-46be0e35b281	t	Nyarubuye	f6f1f309-e671-40ee-b5b3-7e9691ef4d4a
d75be3f1-6023-4b64-a601-016b8acbd5a9	t	Nyura	f6f1f309-e671-40ee-b5b3-7e9691ef4d4a
4df08639-a97d-418f-90fa-aa947055ba74	t	Gatagara	861aaf4f-9746-4dfe-be63-14d0e5275f47
8d4d7876-5428-4c71-addf-58430aec8967	t	Kagarama	861aaf4f-9746-4dfe-be63-14d0e5275f47
401fc9ef-43fb-4a16-a1a8-0fd6ac19ee28	t	Nyabitare	861aaf4f-9746-4dfe-be63-14d0e5275f47
298b5b10-3952-4530-9e02-ce9f09eb67a7	t	Nyakabungo	861aaf4f-9746-4dfe-be63-14d0e5275f47
f20f0d37-d8f7-4744-a7e8-b29b8bc50301	t	Nyarubande	861aaf4f-9746-4dfe-be63-14d0e5275f47
ad2e7fcc-02e0-4770-980e-e5f2a5023910	t	Uruhetse	861aaf4f-9746-4dfe-be63-14d0e5275f47
5ef69a04-c0ab-4747-820e-77a63abec50d	t	Agacyamo	10d1229d-3d92-42da-ade9-4fce6c7a0903
e4ef9a16-3a7a-43f7-a83e-de866c50fafd	t	Gashinya	10d1229d-3d92-42da-ade9-4fce6c7a0903
7380742c-974f-46f8-9f4b-95faf3781860	t	Gikombe	10d1229d-3d92-42da-ade9-4fce6c7a0903
bf7a665d-9dd1-41ce-bcc7-8bbc77ff08e9	t	Kazi	10d1229d-3d92-42da-ade9-4fce6c7a0903
f90657e6-f5dc-4e3d-a763-134ea848a54d	t	Kigufi	10d1229d-3d92-42da-ade9-4fce6c7a0903
aaabb785-8545-48f1-afb4-1097c7b79913	t	Nyirakibehe	10d1229d-3d92-42da-ade9-4fce6c7a0903
da0d1c90-1ebd-4435-bc50-097854a41cc3	t	Uruhahiro	10d1229d-3d92-42da-ade9-4fce6c7a0903
a1c018bb-a3ba-4093-aab8-868139bc3875	t	Agasharu	b5a337ce-b2c5-409d-b748-632ce74c50b6
e7fa3eeb-ddda-4b3f-a79e-2baff12210a5	t	Amataba	b5a337ce-b2c5-409d-b748-632ce74c50b6
fa85ea0e-f578-4bde-bea8-03b023d4634a	t	Burungero	b5a337ce-b2c5-409d-b748-632ce74c50b6
d57ae67e-69e1-4c1b-b184-59744be56f5e	t	Karama	b5a337ce-b2c5-409d-b748-632ce74c50b6
c11bcd39-7a44-4c26-86b0-d994cc0204ed	t	Nyange	b5a337ce-b2c5-409d-b748-632ce74c50b6
b2d3077c-ab16-41d4-b5c7-88cf5216ddd8	t	Rebero	b5a337ce-b2c5-409d-b748-632ce74c50b6
6aacfeeb-4262-4de4-89d7-26a68a5b966c	t	Uruyange	b5a337ce-b2c5-409d-b748-632ce74c50b6
80ea05f5-363f-48b0-ae9b-4b45380b38fb	t	Gatobotobo	fab27b58-d78e-4756-9df8-1599a7ddd1a8
13cb2616-1c53-4332-8da6-8ad9de922e9a	t	Kibungo	fab27b58-d78e-4756-9df8-1599a7ddd1a8
e370ac9b-8958-4153-8194-5ddc0453121f	t	Musezero	fab27b58-d78e-4756-9df8-1599a7ddd1a8
d08895f9-ace6-4c82-83a6-ee89307eeefa	t	Nyaburoro	fab27b58-d78e-4756-9df8-1599a7ddd1a8
50021b85-2d2c-4bd6-9d3d-621e4edd81f1	t	Taba	fab27b58-d78e-4756-9df8-1599a7ddd1a8
be2adc03-46cb-4ab3-afbd-1f8283ef8322	t	Bikumba	3f27e1a1-fe5d-45f8-b7a5-09e0caee2866
56f055b8-697c-49bd-8c11-dd6c63d7f6f1	t	Gakizi	3f27e1a1-fe5d-45f8-b7a5-09e0caee2866
e1359f97-c386-4aad-af88-c357d85318c9	t	Gatare	3f27e1a1-fe5d-45f8-b7a5-09e0caee2866
23bdae62-9b60-4c2e-8e5d-db566fcc19fd	t	Kamuyange	3f27e1a1-fe5d-45f8-b7a5-09e0caee2866
19298cde-1f8d-4643-873a-80d4543be194	t	Kigarama	3f27e1a1-fe5d-45f8-b7a5-09e0caee2866
deb50978-f550-4d0f-b69a-9bcd9ad5fbb6	t	Ngara	3f27e1a1-fe5d-45f8-b7a5-09e0caee2866
d4a1597d-9c65-45b8-8e46-258bd08df2ff	t	Akazi	82f4fb2e-abd4-4409-9e53-4789ddc99687
4d3b4709-cbe1-4d5f-bc2f-e5f75a1cecce	t	Kaduha	82f4fb2e-abd4-4409-9e53-4789ddc99687
fe689e61-a2b3-4c32-8857-f45a732e8286	t	Kamuhoza	82f4fb2e-abd4-4409-9e53-4789ddc99687
5a500b1c-b2b8-4875-8e39-98dddc28dc90	t	Mirambi	82f4fb2e-abd4-4409-9e53-4789ddc99687
880ab130-49bb-4c69-82f7-27ecef49c1d4	t	Munini	82f4fb2e-abd4-4409-9e53-4789ddc99687
42cdcb4e-179d-47d9-b0fc-dbb5a664f53b	t	Ndanyoye	82f4fb2e-abd4-4409-9e53-4789ddc99687
1a3e69be-93db-43b4-8d01-436eb346816c	t	Nyamigina	82f4fb2e-abd4-4409-9e53-4789ddc99687
e7a6c8cb-b522-4d18-b579-e0f2e9b042a3	t	Rugarama	82f4fb2e-abd4-4409-9e53-4789ddc99687
79708ac8-d01a-44f7-b176-57522e2a5d0b	t	Amarembo I	0965d705-f129-45bf-9377-dbab02b986ea
4dfa401f-3279-488a-aff3-812aaed4d7f5	t	Amarembo II	0965d705-f129-45bf-9377-dbab02b986ea
f5cb0e61-366a-4327-89c1-04a0fbdf2791	t	Gihogere	0965d705-f129-45bf-9377-dbab02b986ea
9ed7149b-4a83-4b8c-8c19-fda9da1391e9	t	Kagara	0965d705-f129-45bf-9377-dbab02b986ea
079a25a0-9d68-497d-ba8b-1110f04742f1	t	Kinunga	0965d705-f129-45bf-9377-dbab02b986ea
32de6f1a-8b16-4f4b-a596-3062bb23f3e2	t	Nyabisindu	0965d705-f129-45bf-9377-dbab02b986ea
eb3428e5-8fce-4fa4-82b0-9acb5c376227	t	Rugarama	0965d705-f129-45bf-9377-dbab02b986ea
ba3bf590-1da9-448d-9cd0-eec09fbee66f	t	Gishushu	cbf6f0be-44b8-4db1-9e54-c66f201dc002
08af5412-921d-4927-9f03-e9c1855e4117	t	Juru	cbf6f0be-44b8-4db1-9e54-c66f201dc002
97aea35f-ceeb-4f14-bb72-d77a8efbc29f	t	Kamahwa	cbf6f0be-44b8-4db1-9e54-c66f201dc002
f6a6adfc-2531-4957-897d-8af4b61f6275	t	Kangondo I	cbf6f0be-44b8-4db1-9e54-c66f201dc002
6a05e670-6fcf-4845-af4b-4a405a34522c	t	Kangondo II	cbf6f0be-44b8-4db1-9e54-c66f201dc002
77225b36-869a-48e7-bb1c-ffa24b2feb8d	t	Kibiraro I	cbf6f0be-44b8-4db1-9e54-c66f201dc002
17f35bea-1e30-4c29-9033-d8e7f1bf78cc	t	Kibiraro II	cbf6f0be-44b8-4db1-9e54-c66f201dc002
ef4e497e-0ae1-4e3f-a387-293ac876740e	t	Agashyitsi	541c433c-f62c-45cf-9cb6-0fd0751826d2
a84b0981-8bc1-4f4d-b0ac-c1aa12a7c40e	t	Amajyambere	541c433c-f62c-45cf-9cb6-0fd0751826d2
184958b4-49f7-4c48-bd94-81f0933ca3ec	t	Izuba	541c433c-f62c-45cf-9cb6-0fd0751826d2
815fab9c-8173-436c-b3c7-abe49c63bcd4	t	Gisimenti	541c433c-f62c-45cf-9cb6-0fd0751826d2
be77a15f-034b-4ace-97e1-6be1408ba585	t	Ubumwe	541c433c-f62c-45cf-9cb6-0fd0751826d2
5d2af799-21c2-4b8d-88f9-d9530d092329	t	Ukwezi	541c433c-f62c-45cf-9cb6-0fd0751826d2
ae70586d-b039-4da1-acbe-5f92b03d43bc	t	Urumuri	541c433c-f62c-45cf-9cb6-0fd0751826d2
f4213e37-9974-4639-8ee9-a41b87f4040a	t	Amahoro	af73e10f-0dd7-4bf2-9275-73cf03c9371f
39ff8e29-ec37-4cf6-8c8a-b8b880b90f63	t	Rebero	af73e10f-0dd7-4bf2-9275-73cf03c9371f
3d32efa4-0f78-4073-845d-c04856887278	t	Ruturusu I	af73e10f-0dd7-4bf2-9275-73cf03c9371f
faae6faa-95c8-48b4-a1a3-9219197a7e21	t	Ruturusu II	af73e10f-0dd7-4bf2-9275-73cf03c9371f
6f8ae733-712a-4261-97fc-3c58532382fc	t	Ubumwe	af73e10f-0dd7-4bf2-9275-73cf03c9371f
74fe2482-a366-4de1-b371-6b72fabccfe9	t	Bisenga	17d3d9af-40db-4ec4-bad0-61101c1e4ed3
a6e2da05-a54b-4466-9ab1-0b6cacc3b92f	t	Gakenyeri	17d3d9af-40db-4ec4-bad0-61101c1e4ed3
cb4dfbb9-9235-4102-ad26-8df161547e00	t	Gasiza	17d3d9af-40db-4ec4-bad0-61101c1e4ed3
cea61cb7-c396-4bef-ab63-89ca4a0ed7b4	t	Kidogo	17d3d9af-40db-4ec4-bad0-61101c1e4ed3
bacdf981-8e6c-41b3-be73-0536f2e95ab8	t	Agatare	1ddb5dfe-32f3-4493-beea-c2d38d0448eb
bc453544-70a2-47cc-8dbe-b60d8a59bb6a	t	Gasagara	1ddb5dfe-32f3-4493-beea-c2d38d0448eb
c643281b-3a83-4732-a46d-30f65dacf0be	t	Kamasasa	1ddb5dfe-32f3-4493-beea-c2d38d0448eb
a236c698-44ec-44d7-b1ae-6d3dc511be1f	t	Rugagi	1ddb5dfe-32f3-4493-beea-c2d38d0448eb
062a64d3-4063-451a-a5f1-516f3a2bcc44	t	Ryabazana	1ddb5dfe-32f3-4493-beea-c2d38d0448eb
091715ce-b31b-4e12-958b-5464bd6ed7ca	t	Abatangampu	09eff11b-f56f-4466-9de8-9a863d4006c2
358fcfc9-a9f1-4ad3-bf66-1399376b6c53	t	Amahoro	09eff11b-f56f-4466-9de8-9a863d4006c2
3bff0cfd-a3ba-43df-8d13-5bed52933b29	t	Isangano	09eff11b-f56f-4466-9de8-9a863d4006c2
80a9e1cb-4fd7-4a4e-b611-c28c493518d9	t	Kabeza	09eff11b-f56f-4466-9de8-9a863d4006c2
34be763c-9704-435b-84be-f105f40e7479	t	Kalisimbi	09eff11b-f56f-4466-9de8-9a863d4006c2
f6347821-06af-4556-8684-23a9f3eea3e9	t	Masango	09eff11b-f56f-4466-9de8-9a863d4006c2
9284fa4b-499c-4b7b-965b-9b32a6efbc57	t	Bwiza	4c792132-700e-47b9-9ed8-12d8fbd949b1
91729488-60e4-4a5e-a658-c7a7dd09df24	t	Cyanamo	4c792132-700e-47b9-9ed8-12d8fbd949b1
53ac8c5b-8ea2-4b0e-913f-ffb78f5fb82f	t	Gatare	4c792132-700e-47b9-9ed8-12d8fbd949b1
feee4e0c-54c3-400b-8537-cfb4c56f4061	t	Kamashashi	4c792132-700e-47b9-9ed8-12d8fbd949b1
714aae6d-a3f7-4032-a6b0-1f6fe18ddc38	t	Mataba	4c792132-700e-47b9-9ed8-12d8fbd949b1
0e88f345-c973-43b2-a9f5-f11428714467	t	Nyagakombe	4c792132-700e-47b9-9ed8-12d8fbd949b1
06dd45b8-70e3-43db-963c-19d2e24cb028	t	Ruhangare	4c792132-700e-47b9-9ed8-12d8fbd949b1
2fb2ba34-c223-4732-a415-ec50e13c9eaf	t	Busenyi	1f85d947-5b6c-43a8-a70e-2279ad869422
ea29501d-8610-4f66-962e-3d234a733f6b	t	Kigabiro	1f85d947-5b6c-43a8-a70e-2279ad869422
f1abc61c-9034-41ec-8db7-ecd893e27428	t	Kinyana	1f85d947-5b6c-43a8-a70e-2279ad869422
087a9381-4b60-45d6-b853-fbb1fa85c0af	t	Nyagisozi	1f85d947-5b6c-43a8-a70e-2279ad869422
70e1c9f3-5207-4b21-9782-7b4cd8d096ff	t	Cyeru	accf61af-3eaf-41a3-a0cb-52c1cf2c13d8
099b4e7f-85ff-4f6c-ab22-ee86ea906183	t	Karambo	accf61af-3eaf-41a3-a0cb-52c1cf2c13d8
e1cf1361-443b-4d93-91a9-bb00d0401042	t	Kataruha	accf61af-3eaf-41a3-a0cb-52c1cf2c13d8
81aac703-afa1-450d-8c79-6bea2a942926	t	Mugeyo	accf61af-3eaf-41a3-a0cb-52c1cf2c13d8
1879317d-e508-4e40-87c4-9600de22e23c	t	Rugarama	accf61af-3eaf-41a3-a0cb-52c1cf2c13d8
52d14b8d-7675-46b6-942e-d65199d8d99b	t	Samuduha	accf61af-3eaf-41a3-a0cb-52c1cf2c13d8
634bd12a-0bf6-46e6-bf1e-bacf6434c723	t	Gisharara	8aff94b0-e5d1-4535-b27c-c9572afaca22
b4e267eb-d9a8-41f6-8f7d-8eb90de85103	t	Kabutare	8aff94b0-e5d1-4535-b27c-c9572afaca22
5159028a-065c-4323-939b-bb8e9dec8583	t	Kanyinya	8aff94b0-e5d1-4535-b27c-c9572afaca22
3c619a5a-8082-49cd-8936-4ec62c54a17a	t	Kigarama	8aff94b0-e5d1-4535-b27c-c9572afaca22
a7dc6ea2-c8de-42d6-8093-a518286d95c9	t	Nyarucundura	8aff94b0-e5d1-4535-b27c-c9572afaca22
a72c110e-d231-42d2-9c78-ed292f22bbf0	t	Runyonza	8aff94b0-e5d1-4535-b27c-c9572afaca22
298f481f-6c41-4f79-a124-e6a31ab35e74	t	Urumuri	8aff94b0-e5d1-4535-b27c-c9572afaca22
35b1e291-3d0a-479a-a67a-03d57bfbefa9	t	Kinyaga	14b4580b-b674-4fc2-92d5-9d856e1dd61a
ee07ff0e-3f9a-4b6a-896b-91a689c2e76e	t	Mirama	14b4580b-b674-4fc2-92d5-9d856e1dd61a
b653a623-a66a-42c2-a83e-094beb9f27a6	t	Nyagacyamo	14b4580b-b674-4fc2-92d5-9d856e1dd61a
272e4c80-3ff3-4c72-a19d-bda92b391bc4	t	Rugende	14b4580b-b674-4fc2-92d5-9d856e1dd61a
f699ec62-6d63-4602-a4b7-3ca36f32d7a2	t	Ruhanga	14b4580b-b674-4fc2-92d5-9d856e1dd61a
cdfbc765-2fd0-47ad-a976-6680f61b16a3	t	Gasharu	626a5fd0-2d1b-4aff-a386-546b45dcc4ca
5267ff54-f24a-4146-9773-6bc24084cec1	t	Mulindi	626a5fd0-2d1b-4aff-a386-546b45dcc4ca
791b8d17-c142-49fd-956d-05b712de51bc	t	Vugavuge	626a5fd0-2d1b-4aff-a386-546b45dcc4ca
afc5c5ed-804c-4da4-9e2d-c2dbc22c6a7c	t	Kabarera	5748c81d-fed8-4335-babe-ec7c1923c5d0
5e066e3f-811a-4d83-81a9-d2a75a669275	t	Kamusengo	5748c81d-fed8-4335-babe-ec7c1923c5d0
aaf427d8-fc15-4d92-b1ad-2b8f82fd1712	t	Karekare	5748c81d-fed8-4335-babe-ec7c1923c5d0
4e3e1a00-a577-409f-948d-effa7da65332	t	Karuranga	5748c81d-fed8-4335-babe-ec7c1923c5d0
54e8deea-459f-4afd-844c-b79db4f4d6e9	t	Nyakabande	5748c81d-fed8-4335-babe-ec7c1923c5d0
5baa3b06-fabf-4f5e-8144-2d3b3c557864	t	Kabaliza	46a983a0-f8e0-42d0-b10c-142ae3516fe4
e89cf610-94ae-4e94-a6ea-8f494e4ffdd2	t	Nyamise	46a983a0-f8e0-42d0-b10c-142ae3516fe4
97f4e8cd-afdc-4f70-830e-5b69c1667b69	t	Rwanyanza	46a983a0-f8e0-42d0-b10c-142ae3516fe4
a41a34fb-4603-42fb-b03d-af0e74d55c44	t	Cyili	a1df1363-df9a-4f34-b1a2-a1505c671be0
e5de6e5e-143d-4365-9b0a-198a79d6d035	t	Kacyatwa	a1df1363-df9a-4f34-b1a2-a1505c671be0
472f831d-a3ee-4740-b246-13e0a1660395	t	Kandamira	a1df1363-df9a-4f34-b1a2-a1505c671be0
94be98e7-6576-457b-83e2-845855d0c991	t	Kantabana	a1df1363-df9a-4f34-b1a2-a1505c671be0
edf44c6f-13c3-4b0a-8fbe-292dd380550f	t	Munini	a1df1363-df9a-4f34-b1a2-a1505c671be0
8601a77e-149a-48a6-80c0-779a54edb74c	t	Abanyangeyo	2bbc125e-c287-4209-822c-7807632f98d0
c6cc9f27-43fe-4726-ac15-b36d0dc832b7	t	Kibenga	2bbc125e-c287-4209-822c-7807632f98d0
740441de-d1a5-41c5-850c-cf9da258f67c	t	Nyamvumvu	2bbc125e-c287-4209-822c-7807632f98d0
3b752edb-06fa-4d1a-ac03-ed1cd7967bd6	t	Kamusare	13d65481-9011-425e-94f4-e9ffc9ce3738
37cecc70-3a85-4223-83b9-b033fd8da0eb	t	Karwiru	13d65481-9011-425e-94f4-e9ffc9ce3738
344c7e9e-5de1-4549-873e-174462422e89	t	Kigabiro	13d65481-9011-425e-94f4-e9ffc9ce3738
af7a9e87-b0ee-47b8-8eab-2128bbd6b2bb	t	Rukerereza	13d65481-9011-425e-94f4-e9ffc9ce3738
82f29c53-de2c-4f47-ae5e-de38620bdf45	t	Rwintare	13d65481-9011-425e-94f4-e9ffc9ce3738
23d165d8-0946-44fe-a973-8ee6f79308d1	t	Gahanga	7b3f273d-de89-4ee4-a794-470fa497abc9
954c127d-4916-41fc-815c-32aa55990bad	t	Gatare	7b3f273d-de89-4ee4-a794-470fa497abc9
4769f78a-892e-40f6-89a4-34d1f6f78959	t	Gatovu	7b3f273d-de89-4ee4-a794-470fa497abc9
d6439e50-cbae-41ff-b926-b659f282b8d8	t	Rinini	7b3f273d-de89-4ee4-a794-470fa497abc9
6ffb8a45-9059-46aa-bfeb-1f83e06f70bb	t	Rwinanka	7b3f273d-de89-4ee4-a794-470fa497abc9
e39d152d-0e1d-4892-b6ed-190278c2fb00	t	Ubumwe	7b3f273d-de89-4ee4-a794-470fa497abc9
40df8adc-7d71-4988-85be-1f52cc0f143a	t	Kabeza	cda083a8-c40d-4cd1-b7b8-cc60fc98e4ae
d6d03e4a-2197-4efa-9a1c-5e4ba27296d5	t	Kabidandi	cda083a8-c40d-4cd1-b7b8-cc60fc98e4ae
dea6eac2-5d3a-4ef5-a7e3-3d28f3d4ef92	t	Kiyanja	cda083a8-c40d-4cd1-b7b8-cc60fc98e4ae
7c711f12-20a6-4646-b572-33e7529d9450	t	Nyacyonga	cda083a8-c40d-4cd1-b7b8-cc60fc98e4ae
0c2ba434-6685-4211-bb83-fe792e4a0fe9	t	Nyagafunzo	cda083a8-c40d-4cd1-b7b8-cc60fc98e4ae
4b8d7908-dc2d-491b-a87c-f20187246e86	t	Nyakuguma	cda083a8-c40d-4cd1-b7b8-cc60fc98e4ae
ed3836a5-1863-43ce-b4c9-deea55353cbd	t	Rugando II	cda083a8-c40d-4cd1-b7b8-cc60fc98e4ae
1e830e89-a7a2-48cf-b648-e917ecd6fa1a	t	Amahoro	de6795ae-be79-449d-8efc-fd5c0c557641
63e59337-e40f-4045-b5f1-ca6119f04564	t	Bigo	de6795ae-be79-449d-8efc-fd5c0c557641
4949c141-5be3-4e5e-8405-3691511ddd6f	t	Kabeza	de6795ae-be79-449d-8efc-fd5c0c557641
debc1e55-800b-4eb7-9512-057a1f15f542	t	Kamuyinga	de6795ae-be79-449d-8efc-fd5c0c557641
931fed6b-ce10-4e19-91d3-342c73f173e9	t	Karembure	de6795ae-be79-449d-8efc-fd5c0c557641
e5d55b01-c7b5-4aa7-b511-1314a4e14458	t	Kimena	de6795ae-be79-449d-8efc-fd5c0c557641
e5aad1f3-5c73-4fd0-a617-18cfef5017fc	t	Mubuga	de6795ae-be79-449d-8efc-fd5c0c557641
5bf7bf2b-1a10-4241-a840-7bd10bead6e5	t	Rwamaya	de6795ae-be79-449d-8efc-fd5c0c557641
cd910951-9522-48df-baef-b6ef5c3b530a	t	Kampuro	c96d6cca-f88b-4d8a-bb57-d54ad9771b37
cba1f253-f688-4c82-8633-0e41119c0f5c	t	Kigasa	c96d6cca-f88b-4d8a-bb57-d54ad9771b37
1abeba5a-bf08-479a-9468-32ba17a1fdf7	t	Mashyiga	c96d6cca-f88b-4d8a-bb57-d54ad9771b37
a969afca-f5a7-4921-bf04-73f803d3b6ed	t	Nyabigugu	c96d6cca-f88b-4d8a-bb57-d54ad9771b37
6fa919da-636a-42ba-b5b2-e58d4c14ce5f	t	Nyamuharaza	c96d6cca-f88b-4d8a-bb57-d54ad9771b37
654ec347-4cc7-48e1-82b6-f8f7447b2e95	t	Rukore	c96d6cca-f88b-4d8a-bb57-d54ad9771b37
b174da9b-c19f-45af-86a9-cd2ab292cd22	t	Runyoni	c96d6cca-f88b-4d8a-bb57-d54ad9771b37
ff58aa0c-8193-429a-80af-e0b3dcc7713d	t	Sabununga	c96d6cca-f88b-4d8a-bb57-d54ad9771b37
b3fd556c-0029-4409-8e08-d2d1b8c0c7c3	t	Kigarama	cc95bbe5-1172-4850-a614-0a12ec504acb
bda723da-ddad-4134-9393-0c5fd72fe75e	t	Kinyana	cc95bbe5-1172-4850-a614-0a12ec504acb
cdb59e16-f8c0-481c-a24b-633e473f19ca	t	Mugendo	cc95bbe5-1172-4850-a614-0a12ec504acb
00309c3c-1ced-472e-bdee-a3e9bb257159	t	Nunga I	cc95bbe5-1172-4850-a614-0a12ec504acb
422fac34-4fa6-440f-b0e2-e8b35090cf6e	t	Nunga II	cc95bbe5-1172-4850-a614-0a12ec504acb
9b4934bc-1051-412b-a3c4-83a91e277c4a	t	Rugasa	cc95bbe5-1172-4850-a614-0a12ec504acb
3ba40169-e464-4fb5-8df4-dd4dc9481d59	t	Gahosha	8c9817ab-49f1-4b6d-993c-23005052b147
9f3875e5-bed5-415e-b588-856ef51e3c76	t	Gashubi	8c9817ab-49f1-4b6d-993c-23005052b147
b8068db9-4e3d-4117-869e-0f39a176a8c9	t	Kaboshya	8c9817ab-49f1-4b6d-993c-23005052b147
f2185e63-22df-4883-ae7c-41fb46abdad7	t	Karambo	8c9817ab-49f1-4b6d-993c-23005052b147
9532b65d-aec5-4d9b-8c51-fb631df5004e	t	Rebero	8c9817ab-49f1-4b6d-993c-23005052b147
6e342823-18c6-42f7-a22c-b2e3dd9f4024	t	Rugando I	8c9817ab-49f1-4b6d-993c-23005052b147
df59dd48-962b-4901-949c-c9067dc86d81	t	Amahoro	dc215096-c8cd-4e47-8c1d-954d7d015aaf
5661d73a-8114-4c22-a739-d583f0b042f6	t	Gakoki	dc215096-c8cd-4e47-8c1d-954d7d015aaf
e2455bd1-60e8-4f1f-841c-359dc88d787b	t	Gatenga	dc215096-c8cd-4e47-8c1d-954d7d015aaf
0e9c8d75-afb2-4cdb-be1b-3efd742c188e	t	Ihuriro	dc215096-c8cd-4e47-8c1d-954d7d015aaf
b5d3c393-eb1f-46ae-9a09-1adb47503d25	t	Isangano	dc215096-c8cd-4e47-8c1d-954d7d015aaf
bd718d5a-234d-437a-a801-0f4953f47621	t	Rugari	dc215096-c8cd-4e47-8c1d-954d7d015aaf
e7417fe5-7068-42fa-9853-ecaf6f64bc97	t	Gwiza	16d010c2-af73-404e-b790-78370604ffb2
99dc0e12-1c7a-4d36-bfef-ff73d118bf44	t	Ihuriro	16d010c2-af73-404e-b790-78370604ffb2
3fa439b6-0c13-43f3-8da7-9262d0483991	t	Jyambere	16d010c2-af73-404e-b790-78370604ffb2
e122d6bf-c9d1-4179-b1cd-ce014f6097d4	t	Kamabuye	16d010c2-af73-404e-b790-78370604ffb2
81801745-8f79-427d-b0e3-7309c5105d2c	t	Mahoro	16d010c2-af73-404e-b790-78370604ffb2
77ab837e-b0ea-4079-be1f-7ca6ed95e5b8	t	Ramiro	16d010c2-af73-404e-b790-78370604ffb2
25ddb786-183a-4939-b41e-ae006179860b	t	Rebero	16d010c2-af73-404e-b790-78370604ffb2
1416baa1-f7b4-44e0-b616-c0e71312bffa	t	Rugwiro	16d010c2-af73-404e-b790-78370604ffb2
18f4ec9f-90d5-4685-883f-2a76a1aaf5cb	t	Ruhuka	16d010c2-af73-404e-b790-78370604ffb2
dda44106-e374-456d-9306-e7dfda8edb9f	t	Sangwa	16d010c2-af73-404e-b790-78370604ffb2
7d3ed4ca-b0d8-4282-adf1-516f9dbe6c8a	t	Bwiza	77410805-c85a-4a40-81e7-3fe8163acde6
a4d6b4d6-ef05-439d-bbd7-73e9b7ae511a	t	Cyeza	77410805-c85a-4a40-81e7-3fe8163acde6
ab54c083-180e-4e4e-829f-1a83e8ededdb	t	Gasabo	77410805-c85a-4a40-81e7-3fe8163acde6
850796ac-75a7-46f9-a1d0-7a1376d06ba0	t	Ihuriro	77410805-c85a-4a40-81e7-3fe8163acde6
e0396202-0818-40f1-901f-e02886dd08ec	t	Isonga	77410805-c85a-4a40-81e7-3fe8163acde6
0d64756e-13bf-4802-9654-2c6e4d41602a	t	Juru	77410805-c85a-4a40-81e7-3fe8163acde6
dc32e713-62fb-4298-8eb7-3e4b6a34fbd5	t	Marembo	77410805-c85a-4a40-81e7-3fe8163acde6
61f24968-02d1-472b-8d02-6128b3d0be14	t	Murambi	77410805-c85a-4a40-81e7-3fe8163acde6
d7569cd6-d7b6-47fe-8e2a-2ab30c62c722	t	Nyanza	77410805-c85a-4a40-81e7-3fe8163acde6
35ca1bc0-24c3-445a-8425-e6048e1c6776	t	Rebero	77410805-c85a-4a40-81e7-3fe8163acde6
43caecfb-5547-4f9a-b2a5-3f0201c9b79f	t	Rusororo	77410805-c85a-4a40-81e7-3fe8163acde6
b85daf4a-325c-49a8-9fe6-ff81feb8f4d1	t	Sabaganga	77410805-c85a-4a40-81e7-3fe8163acde6
520bb487-a8a7-4cf8-a150-0da02571c802	t	Taba	77410805-c85a-4a40-81e7-3fe8163acde6
e57b079a-596c-4207-b3ee-196f60ef4d73	t	Bigo	5867fdb6-d64d-44ca-86fa-fd942551b4f9
6c522e40-3db6-415a-93e7-9d363c42cebe	t	Bisambu	5867fdb6-d64d-44ca-86fa-fd942551b4f9
380a74ca-34b7-4c63-9c02-9c8078b8409e	t	Kabeza	5867fdb6-d64d-44ca-86fa-fd942551b4f9
b52956e0-4a01-4146-bae1-97a9cb1c6f6f	t	Nyabikenke	5867fdb6-d64d-44ca-86fa-fd942551b4f9
119e70fd-5f51-4231-be2d-64896deef842	t	Gatare	d99a8e06-98d5-49d0-83a7-4ed2e921e768
7773c1f2-3a4f-439e-832e-f12d34c160b9	t	Kabuye I	d99a8e06-98d5-49d0-83a7-4ed2e921e768
0b8d3234-55a1-42ad-9434-2f6b9e98da80	t	Kabuye II	d99a8e06-98d5-49d0-83a7-4ed2e921e768
928755ac-44a9-447d-9af3-ed80db752e07	t	Kagunga I	d99a8e06-98d5-49d0-83a7-4ed2e921e768
d426b75c-d5af-4798-80e7-1c475fc5cdc0	t	Kagunga II	d99a8e06-98d5-49d0-83a7-4ed2e921e768
482f1a63-0fdf-4cc2-802b-304af0ea2dde	t	Rebero	d99a8e06-98d5-49d0-83a7-4ed2e921e768
e233f0ac-e842-4306-be36-eca5920adcca	t	Kanserege I	580e2d20-e905-4019-84fc-cd494e9abfeb
3216a166-e092-4e9b-812e-14131ed5e372	t	Kanserege II	580e2d20-e905-4019-84fc-cd494e9abfeb
2ff01411-305b-450b-bf13-9f4a02d46b28	t	Kanserege III	580e2d20-e905-4019-84fc-cd494e9abfeb
e441cb61-90d9-4623-a351-7a61373c981c	t	Marembo I	580e2d20-e905-4019-84fc-cd494e9abfeb
de9b2d44-70d7-477b-940b-da044830e8c9	t	Marembo II	580e2d20-e905-4019-84fc-cd494e9abfeb
2c16f400-1ba2-4c20-88d1-f5c8057b8911	t	Marembo III	580e2d20-e905-4019-84fc-cd494e9abfeb
ccc60483-7c39-4c7e-8c51-2857c2377c59	t	Kigugu I	67da26b0-5214-43bf-85ee-aafb66c1fb56
bf9cfd24-f6eb-481d-b0ce-d34396bbb5ae	t	Kigugu II	67da26b0-5214-43bf-85ee-aafb66c1fb56
e25510cf-7d81-4cfc-8b93-168a1f7c0290	t	Kigugu III	67da26b0-5214-43bf-85ee-aafb66c1fb56
4134dbad-1fab-44d7-9486-65604211664d	t	Kinunga	67da26b0-5214-43bf-85ee-aafb66c1fb56
3252ad60-6943-47ab-b58b-cd90d115016e	t	Ruganwa I	67da26b0-5214-43bf-85ee-aafb66c1fb56
3998bd62-45cd-4162-86fe-4ad9dac19051	t	Ruganwa II	67da26b0-5214-43bf-85ee-aafb66c1fb56
c56a6e61-f193-4f2a-8017-f6370ce10747	t	Ruganwa III	67da26b0-5214-43bf-85ee-aafb66c1fb56
209a20a9-1207-4e45-a901-34cf783022b0	t	Bwiza	face7c94-4223-407e-af5b-a54f615f0d0f
616cfa0e-5613-498f-9e14-23c395a79b76	t	Byimana	face7c94-4223-407e-af5b-a54f615f0d0f
11b07227-96d1-4e23-8779-3fcedd5101e7	t	Ituze	face7c94-4223-407e-af5b-a54f615f0d0f
0bdca2e8-dc2f-4c25-9137-d45fbb9b818b	t	Kanserege	face7c94-4223-407e-af5b-a54f615f0d0f
a5bef8bf-5690-48c6-adcb-a22373ca9289	t	Kinunga	face7c94-4223-407e-af5b-a54f615f0d0f
5be72ea2-7fc1-4a46-bdb1-18672e975d58	t	Kamuna	7f3133f0-15a1-4922-b43f-4e6b305576d3
ed5f5712-c418-4591-9ce3-6d7978c69f5a	t	Mugeyo	7f3133f0-15a1-4922-b43f-4e6b305576d3
dc44e1bb-40f8-4b12-931a-9a3c4121f765	t	Muyange	7f3133f0-15a1-4922-b43f-4e6b305576d3
a99d35d4-c003-46cd-b4b1-7f29c9c9a966	t	Rugunga	7f3133f0-15a1-4922-b43f-4e6b305576d3
178b0e0f-3d34-4845-9d6a-06497221a0ae	t	Inshuti	0261596c-e4b9-4dd8-ae36-70c93bde9632
6f5e97ed-a6da-4e8b-a9d7-0278412456f8	t	Mpingayanya	0261596c-e4b9-4dd8-ae36-70c93bde9632
c95efe2a-7d8f-44af-a451-f011ada25fc5	t	Nyacyonga	0261596c-e4b9-4dd8-ae36-70c93bde9632
41d7fa23-b809-4e77-9e51-f85748340b8c	t	Nyanza	0261596c-e4b9-4dd8-ae36-70c93bde9632
2299a70c-3684-40d8-9114-7f912b13c313	t	Rukatsa	0261596c-e4b9-4dd8-ae36-70c93bde9632
499ce979-67de-4d16-b516-901f41c6488d	t	Taba	0261596c-e4b9-4dd8-ae36-70c93bde9632
b343d68c-24c3-492f-8d72-66e905e36676	t	Amahoro	e7672eea-69dd-4efd-b832-63d80a6c2a38
5f6586ee-068f-4831-86ec-429afc259e7c	t	Antene	e7672eea-69dd-4efd-b832-63d80a6c2a38
b3b465c3-dc5f-451b-85f5-963eeba61c03	t	Bamporeze I	e7672eea-69dd-4efd-b832-63d80a6c2a38
82d6d9dc-eb5e-49a4-ac9d-3449c3735bac	t	Bamporeze II	e7672eea-69dd-4efd-b832-63d80a6c2a38
3b822133-070c-47da-be0c-83a1cd25654d	t	Gashyushya	e7672eea-69dd-4efd-b832-63d80a6c2a38
d33dd543-4a31-4364-a7e6-f1818db416e0	t	Gishikiri	e7672eea-69dd-4efd-b832-63d80a6c2a38
0e66059b-21b4-47a2-a20c-8e64b24db6e5	t	Hope	e7672eea-69dd-4efd-b832-63d80a6c2a38
32f636da-8984-4e47-b742-58a509f0d88a	t	Kariyeri	e7672eea-69dd-4efd-b832-63d80a6c2a38
1a501265-a37c-459e-9a07-da56af1ebb8a	t	Nyarugugu	e7672eea-69dd-4efd-b832-63d80a6c2a38
f17be5c8-7995-4c0f-ad39-a61548dd04e3	t	Radari	e7672eea-69dd-4efd-b832-63d80a6c2a38
b1e19dc1-fbc1-4995-abfa-dc765bde94d5	t	Rukore	e7672eea-69dd-4efd-b832-63d80a6c2a38
48625447-6aa3-461b-9a52-e5541b9063a9	t	Akagera	4246847c-8c6d-4b60-a32a-3161cdbf55a2
5ae1359c-c7e5-4070-bbba-c71a4a631b9f	t	Bwiza	4246847c-8c6d-4b60-a32a-3161cdbf55a2
913a606c-1a90-4dbc-95b6-00c4e71490f2	t	Gasabo	4246847c-8c6d-4b60-a32a-3161cdbf55a2
eeb7be1d-399e-4868-85b0-c830c9d0e0ee	t	Giporoso I	4246847c-8c6d-4b60-a32a-3161cdbf55a2
e5db598c-b737-4985-927f-a968931ea425	t	Giporoso II	4246847c-8c6d-4b60-a32a-3161cdbf55a2
6e194ca4-7fbd-4cda-85d1-3832bb7882a8	t	Juru	4246847c-8c6d-4b60-a32a-3161cdbf55a2
3758bb90-d6d9-41b7-a8b6-95b59e41f2ce	t	Kabeza	4246847c-8c6d-4b60-a32a-3161cdbf55a2
ee1a3930-b7d7-48bd-a718-b1e103152460	t	Karisimbi	4246847c-8c6d-4b60-a32a-3161cdbf55a2
5bd482ab-a737-4461-9d08-9d5d38f14040	t	Muhabura	4246847c-8c6d-4b60-a32a-3161cdbf55a2
0755fb6e-02ae-4b0e-b664-ca7b37d7ff39	t	Mulindi	4246847c-8c6d-4b60-a32a-3161cdbf55a2
6de1d35f-45cf-48c4-a4c9-bdc13dd3cb59	t	Nyarurembo	4246847c-8c6d-4b60-a32a-3161cdbf55a2
5d3d6542-9737-4d60-b952-f6e618f7def5	t	Nyenyeri	4246847c-8c6d-4b60-a32a-3161cdbf55a2
e92b7180-a2e5-4968-b9ac-050080bc8958	t	Rebero	4246847c-8c6d-4b60-a32a-3161cdbf55a2
9e64e23f-22b0-4d73-8ab8-b0f0be558451	t	Bitare	b242525d-1f72-452c-8515-2d898981fc67
1cf13887-1ec3-45c9-89cc-8e5adec340b6	t	Byimana	b242525d-1f72-452c-8515-2d898981fc67
0a40f45d-9448-4356-8a2f-50351db1ca4a	t	Cyurusagara	b242525d-1f72-452c-8515-2d898981fc67
4b066a02-fcef-4e6e-b5e6-b4a42671aabe	t	Gakorokombe	b242525d-1f72-452c-8515-2d898981fc67
4ce3774b-c7b4-4002-b786-b8be97fb159d	t	Gikundiro	b242525d-1f72-452c-8515-2d898981fc67
c6d86965-6f46-45e2-8e77-799403e70a48	t	Gitarama	b242525d-1f72-452c-8515-2d898981fc67
5575d967-f281-4291-b822-ddd7d5a0e313	t	Karama	b242525d-1f72-452c-8515-2d898981fc67
9c66e19f-9bfc-4c40-a1df-41f18a2235f8	t	Nyabyunyu	b242525d-1f72-452c-8515-2d898981fc67
55f13214-f50d-40b3-a673-230287cb4b1f	t	Nyarutovu	b242525d-1f72-452c-8515-2d898981fc67
ce943e32-1ab8-41fb-890c-780d91e94fb7	t	Urukundo	b242525d-1f72-452c-8515-2d898981fc67
2c1830c1-b70f-4a50-84bc-69dc0a5d8a93	t	Beninka	fd388ed9-b0ee-4508-8376-eac69f19a5c4
6fa9b3cb-7263-419e-82fe-d12986290a96	t	Bukunzi	fd388ed9-b0ee-4508-8376-eac69f19a5c4
69d6d039-58fa-4639-89f8-b17aab0f829a	t	Cyeru	fd388ed9-b0ee-4508-8376-eac69f19a5c4
e6a938cc-cfe2-407b-8160-a83ea66967b4	t	Intwari	fd388ed9-b0ee-4508-8376-eac69f19a5c4
4d144605-5440-43b5-a06e-6cd78f5405cb	t	Itunda	fd388ed9-b0ee-4508-8376-eac69f19a5c4
a61b0f4e-26e6-4c05-aff3-5ea719068a7b	t	Kavumu	fd388ed9-b0ee-4508-8376-eac69f19a5c4
4c356d45-8dcd-434c-b825-f3d930d62d23	t	Susuruka	fd388ed9-b0ee-4508-8376-eac69f19a5c4
c3b13e87-9a33-4a98-8338-9205c4d10205	t	Ubumwe	fd388ed9-b0ee-4508-8376-eac69f19a5c4
7bb05df4-6a8a-4fac-b60d-0308f6dc4af8	t	Umunara	fd388ed9-b0ee-4508-8376-eac69f19a5c4
9f57265d-8b58-48c3-93f2-7e32e360c716	t	Uwabarezi	fd388ed9-b0ee-4508-8376-eac69f19a5c4
c72034f0-1ee5-4736-9246-e8bbcef043ce	t	Zirakamwa	fd388ed9-b0ee-4508-8376-eac69f19a5c4
8f17c709-8866-42dd-ba64-f0d30a4d2bb6	t	Amajyambere	b39143f3-da6c-401c-afff-cec94c810c1f
e6a28b57-d485-4360-a541-383c4ab32d14	t	Gasharu	b39143f3-da6c-401c-afff-cec94c810c1f
bfe2e26f-e1b3-444c-9454-d94138bc7760	t	Sakirwa	b39143f3-da6c-401c-afff-cec94c810c1f
032b4b12-0550-48ea-9771-3d0c6bd5fcef	t	Umunyinya	b39143f3-da6c-401c-afff-cec94c810c1f
eb608ca9-cc9b-4f6c-8c38-3630c1393bd2	t	Gashiha	ce4e6dd7-412f-4820-bd01-0f1870fe9262
dbd0df9a-b430-4dd9-be79-8f48a8ca3309	t	Iriba	ce4e6dd7-412f-4820-bd01-0f1870fe9262
31724fe6-0986-4f31-8f6f-a3282bb468d6	t	Multimedia	ce4e6dd7-412f-4820-bd01-0f1870fe9262
fb7cefea-3e91-4973-a120-dae5627230d9	t	Umunyinya	ce4e6dd7-412f-4820-bd01-0f1870fe9262
0de0c08b-3ac5-4c69-af2b-be23162a3e25	t	Umuremure	ce4e6dd7-412f-4820-bd01-0f1870fe9262
c9929e72-1db2-43b9-a7a4-0f972d137219	t	Urugero	ce4e6dd7-412f-4820-bd01-0f1870fe9262
63e6bd45-5ef4-4fa3-b9ee-aabc6831a5b0	t	Gasave	6593c3d6-fbeb-4851-b3c7-47c2246a6a33
1f8d6b5d-9c2b-4ec4-9bd7-e761f603b61c	t	Isoko	6593c3d6-fbeb-4851-b3c7-47c2246a6a33
3e9eba77-7636-4afb-99df-c4cbde17b3f3	t	Karisimbi	6593c3d6-fbeb-4851-b3c7-47c2246a6a33
7723c9c6-202b-49bd-91cb-0e92eabad71c	t	Kicukiro	6593c3d6-fbeb-4851-b3c7-47c2246a6a33
d687062d-a885-46d5-9fa6-9cf0e4275b9f	t	Triangle	6593c3d6-fbeb-4851-b3c7-47c2246a6a33
f9d1bc7b-92a8-4319-8ca8-a91ca14ad29a	t	Ubumwe	6593c3d6-fbeb-4851-b3c7-47c2246a6a33
84e2f689-21af-4629-bece-94e4238e8560	t	Ahitegeye	d875650b-a248-4f5a-864f-b90da68b3739
a3771520-09f9-465e-a104-277b5fd44f38	t	Intaho	d875650b-a248-4f5a-864f-b90da68b3739
7d9e32cd-42d7-45ab-8101-891c19e60814	t	Iriba	d875650b-a248-4f5a-864f-b90da68b3739
4e815b7e-98ee-42f8-a48f-11f3ab6cafad	t	Isangano	d875650b-a248-4f5a-864f-b90da68b3739
8acb1dd7-f7d7-4e2c-afdb-814e57247fb6	t	Urugero	d875650b-a248-4f5a-864f-b90da68b3739
afb8b4b7-2698-4a2e-95d2-9c51660aba4d	t	Gakokobe	d4abc68d-5d54-4068-a76e-5706e18d9faa
6e2916cf-2a9b-4c36-b9e9-07d4fb1e7767	t	Gatare	d4abc68d-5d54-4068-a76e-5706e18d9faa
075fd8aa-aa23-4059-bd74-84d6b1113d12	t	Imena	d4abc68d-5d54-4068-a76e-5706e18d9faa
b6ccf9b0-fe7a-4cdd-a79b-0435edd12d76	t	Ituze	d4abc68d-5d54-4068-a76e-5706e18d9faa
409ecc15-25e1-44e8-9f68-69a23476ebfa	t	Kabutare	d4abc68d-5d54-4068-a76e-5706e18d9faa
b89b70f9-f98b-4611-a8bf-a3640618d688	t	Kimisange	d4abc68d-5d54-4068-a76e-5706e18d9faa
b337e65b-dbfa-43c0-971f-c53ba68c143f	t	Nyenyeri	d4abc68d-5d54-4068-a76e-5706e18d9faa
78b11edc-6311-4d12-82ce-9c566e858bf3	t	Ubumenyi	d4abc68d-5d54-4068-a76e-5706e18d9faa
ebb221c1-d8f2-494d-994c-022756599427	t	Ibuga	66781237-f052-4422-856b-a83724abdedb
91b293e3-e281-4c1d-a51d-154c7f992fa3	t	Ihuriro	66781237-f052-4422-856b-a83724abdedb
237c25bc-aab4-4211-9969-6d55cee33fa5	t	Murambi	66781237-f052-4422-856b-a83724abdedb
f2b35c52-81a3-4f12-bbea-310330eb0a45	t	Rutoki	66781237-f052-4422-856b-a83724abdedb
639d01db-5125-4a56-a512-6d68797d685a	t	Taba	66781237-f052-4422-856b-a83724abdedb
988ebf1d-13ab-4578-9700-911ad026217a	t	Terimbere	66781237-f052-4422-856b-a83724abdedb
1956c102-397f-4784-a745-e2695d3f9554	t	Ubutare	66781237-f052-4422-856b-a83724abdedb
f1f9e9bd-2c49-4504-b1f9-ebbae7693e27	t	Umurimo	66781237-f052-4422-856b-a83724abdedb
75e2f701-7325-410d-adc1-db2a536993a7	t	Akimana	acac8cdb-3da1-447d-a8e6-5f8a72cb57a8
1d3e846e-4204-46bc-bdbc-065a61387822	t	Amahoro	acac8cdb-3da1-447d-a8e6-5f8a72cb57a8
6e0a3403-e8cb-4112-bcae-758f78e4f73a	t	Byimana	acac8cdb-3da1-447d-a8e6-5f8a72cb57a8
9d73330b-92b0-41fa-90f1-0d7358bad0f2	t	Indatwa	acac8cdb-3da1-447d-a8e6-5f8a72cb57a8
640c64a3-bb0a-4779-8d44-1da1d5647c2a	t	Ingenzi	acac8cdb-3da1-447d-a8e6-5f8a72cb57a8
c77b7805-a605-40f8-ab8c-87e57b5b3257	t	Kabeza	acac8cdb-3da1-447d-a8e6-5f8a72cb57a8
54899f97-0611-4c7c-b0a1-6f40eaf4ce45	t	Karurayi	acac8cdb-3da1-447d-a8e6-5f8a72cb57a8
fece58d8-4d93-4b5d-9dba-b52cbad06be4	t	Mataba	acac8cdb-3da1-447d-a8e6-5f8a72cb57a8
b38d0228-4891-4a8c-aa52-7d08c6a54d12	t	Umucyo	acac8cdb-3da1-447d-a8e6-5f8a72cb57a8
338a5cc3-b29f-4a65-970a-cc4617c1b3af	t	Kamabuye	da74eb7a-da52-4515-8389-0d9715619e40
5d34d4fb-97fa-4f05-af44-7251f5e1302f	t	Karuyenzi	da74eb7a-da52-4515-8389-0d9715619e40
e74aeffe-858a-402b-8690-822a8f406398	t	Kivu	da74eb7a-da52-4515-8389-0d9715619e40
f66ef8b2-603e-4eec-ae5c-9aa6814a9f15	t	Rebero	da74eb7a-da52-4515-8389-0d9715619e40
a4e67527-7e29-4588-b94d-7db535aa6efa	t	Twishorezo	da74eb7a-da52-4515-8389-0d9715619e40
5b6d02ac-3124-4b70-83b5-a434e9d65d06	t	Zuba	da74eb7a-da52-4515-8389-0d9715619e40
9c2cfb2b-7c2b-4682-89f9-aa9e9fd368d9	t	Amajyambere	524ded00-f69a-4eea-920c-d859bca1f621
76ed70d5-8ccc-484d-9973-cc7b089d4ab4	t	Bwiza	524ded00-f69a-4eea-920c-d859bca1f621
1e240355-9b66-44b5-b61a-9c76a259a003	t	Nyarurembo	524ded00-f69a-4eea-920c-d859bca1f621
0bf01265-1704-4d87-be94-a544d930c364	t	Ubumwe	524ded00-f69a-4eea-920c-d859bca1f621
ef03d1bd-6f41-4fad-b54d-78fdf92efcbd	t	Umutekano	524ded00-f69a-4eea-920c-d859bca1f621
a114f532-abf1-4412-acbe-5b969cea764a	t	Urumuri	524ded00-f69a-4eea-920c-d859bca1f621
c8a0a6a0-2f15-4870-84a6-979a64b279ef	t	Uwateke	524ded00-f69a-4eea-920c-d859bca1f621
92f0e9f7-76ea-4503-b615-13cfbec30d6b	t	Kababyeyi	0b1cded7-1ce5-46cf-8115-0412826cf7f0
5fc714d0-b387-405f-8d61-e534c89b66a1	t	Ayabaraya	0b1cded7-1ce5-46cf-8115-0412826cf7f0
669630e0-2665-4595-84be-97c9c17d7b3c	t	Nyamico	0b1cded7-1ce5-46cf-8115-0412826cf7f0
932bf94c-8efe-4ff1-98a3-63e28bd04e75	t	Nyamyijima	0b1cded7-1ce5-46cf-8115-0412826cf7f0
b87d0e44-0365-481e-9310-2d821bfbba04	t	Nyirakavomo	0b1cded7-1ce5-46cf-8115-0412826cf7f0
0e4981ca-9567-4db5-a322-4b81d365623e	t	Rususa	0b1cded7-1ce5-46cf-8115-0412826cf7f0
f485edd9-5781-4e7a-970d-b8ae2e9210a5	t	Biryogo	ea4cf5fd-c64c-48c0-bc5e-47818cc4e108
db10a2a0-0422-47d7-8460-1f7b8ed4629d	t	Bwiza	ea4cf5fd-c64c-48c0-bc5e-47818cc4e108
b5352971-6c36-4c64-a527-46fb83f60b46	t	Cyimo	ea4cf5fd-c64c-48c0-bc5e-47818cc4e108
c9954485-dc51-483e-92d9-dd20e2efa852	t	Kabeza	ea4cf5fd-c64c-48c0-bc5e-47818cc4e108
8286fa2a-175f-480d-a6cd-2c9736059950	t	Kiyovu	ea4cf5fd-c64c-48c0-bc5e-47818cc4e108
2770a7d8-c78e-4c2c-90f1-5f4dea14142e	t	Masaka	ea4cf5fd-c64c-48c0-bc5e-47818cc4e108
8b474f9f-5330-4a6b-b291-5845c611d48f	t	Murambi	ea4cf5fd-c64c-48c0-bc5e-47818cc4e108
69435ac8-8388-4da3-bd72-9934a91806b1	t	Nyakagunga	ea4cf5fd-c64c-48c0-bc5e-47818cc4e108
8caa3288-f121-440d-807d-a1f5d9876bea	t	Urugwiro	ea4cf5fd-c64c-48c0-bc5e-47818cc4e108
58db83f9-7646-41d0-a161-22e4ad2a1ee9	t	Bamporeze	0619e879-1447-4fd5-b64f-025916638c9b
3756fb3f-2764-4ca2-888f-c6f68bc8dda9	t	Butangampun	0619e879-1447-4fd5-b64f-025916638c9b
f6644e00-e49e-4787-91d7-714aa3317347	t	Butare	0619e879-1447-4fd5-b64f-025916638c9b
92490f92-e3b8-4d43-9792-d84931dca142	t	Cyugamo	0619e879-1447-4fd5-b64f-025916638c9b
406ce581-4036-4f42-9354-943734439954	t	Gicaca	0619e879-1447-4fd5-b64f-025916638c9b
3c73b731-c3e6-40fb-bb60-6af4efbbc271	t	Gihuke	0619e879-1447-4fd5-b64f-025916638c9b
4b6ce114-8f3e-44f4-983f-ab2ccac16036	t	Kabeza	0619e879-1447-4fd5-b64f-025916638c9b
f808b5fe-4e3b-42ec-90a2-9ffb360c3eb9	t	Kibande	0619e879-1447-4fd5-b64f-025916638c9b
320e6a95-4299-4e4a-a44f-093df1149eed	t	Rebero	0619e879-1447-4fd5-b64f-025916638c9b
07ad90ee-8008-48ce-beb0-d567eabb8b86	t	Rugende	0619e879-1447-4fd5-b64f-025916638c9b
f7c44d89-f03f-4b2a-a0de-ab5fead57bad	t	Ruyaga	0619e879-1447-4fd5-b64f-025916638c9b
4bf9b5df-a1f6-4522-8480-dbd48912aa13	t	Gitaraga	28c81d10-915c-4021-907d-493c197da71f
7f24076e-4b3d-4ea2-81f9-a5d3e28a8685	t	Kabeza	28c81d10-915c-4021-907d-493c197da71f
eb0a69f8-0cb2-4f06-9c32-de9794076a02	t	Kajevuba	28c81d10-915c-4021-907d-493c197da71f
9c1bf368-f066-4d41-a6f1-3eaf1c408e56	t	Nyakarambi	28c81d10-915c-4021-907d-493c197da71f
f7b28819-7b61-4a6c-812a-dbdba063c941	t	Nyange	28c81d10-915c-4021-907d-493c197da71f
03ec5b12-7946-4937-8483-834840ce0c36	t	Ruhanga	28c81d10-915c-4021-907d-493c197da71f
4e0495cb-f9b4-4f48-970d-98cf15bcedcc	t	Rwintare	28c81d10-915c-4021-907d-493c197da71f
303c44b7-98e9-4b67-9112-c8235b486604	t	Kabeza	205fe746-f046-4710-9c33-84be55a4a404
b8a44e15-e616-4640-9dfa-1a840f9d09a2	t	Kamashashi	205fe746-f046-4710-9c33-84be55a4a404
dc488743-a06b-4bdc-81c2-f54a564ca7dc	t	Mbabe	205fe746-f046-4710-9c33-84be55a4a404
bad7f3a9-d3e1-4693-8b39-11b049cec1a8	t	Murambi	205fe746-f046-4710-9c33-84be55a4a404
7fbc514f-2349-4923-b9d8-0d456063ce5a	t	Ngarama	205fe746-f046-4710-9c33-84be55a4a404
4d9a4ef1-bc35-4106-a332-3a4e2313c738	t	Sangano	205fe746-f046-4710-9c33-84be55a4a404
f255f3ec-e2ae-46f4-947c-0dc7a38fc4cf	t	Cyankongi	52f1fee4-20fe-4776-a505-fc3e72455259
33677c37-cc63-4da2-88d3-492c748324c2	t	Cyeru	52f1fee4-20fe-4776-a505-fc3e72455259
398b7853-d9a5-4748-b084-3064499d9c0e	t	Gatare	52f1fee4-20fe-4776-a505-fc3e72455259
f9b490af-fdfb-4d43-96df-8976e1e382dd	t	Kagese	52f1fee4-20fe-4776-a505-fc3e72455259
a7ab1c21-a985-42f7-b899-972cf56b71b4	t	Kanyetabi	52f1fee4-20fe-4776-a505-fc3e72455259
c398a8ec-3b8c-4f2e-965c-0bb7acb93251	t	Mubano	52f1fee4-20fe-4776-a505-fc3e72455259
85171f93-325b-467c-8ecf-db090f58a0dc	t	Ruhosha	52f1fee4-20fe-4776-a505-fc3e72455259
f7b2b1af-e10a-4853-acca-b70bc3734d21	t	Byimana	8da92b40-5d48-45b7-99e3-12fc8e22ee6f
a686c3c7-11c0-47b6-8d9f-e50355a6098c	t	Gatare	8da92b40-5d48-45b7-99e3-12fc8e22ee6f
e0bbf597-b08b-4a67-8774-b68272f3093b	t	Imena	8da92b40-5d48-45b7-99e3-12fc8e22ee6f
4f3038c6-3666-4c8f-8431-c3c65dfd5090	t	Kamahoro	8da92b40-5d48-45b7-99e3-12fc8e22ee6f
cf9fedce-c9e7-4cdb-8634-21cd17bc939a	t	Kigarama	8da92b40-5d48-45b7-99e3-12fc8e22ee6f
2728c3e3-ac94-42f4-ab68-56850d015d0b	t	Rugunga	8da92b40-5d48-45b7-99e3-12fc8e22ee6f
4f67b424-0b24-4503-b16c-44bc5f8031cf	t	Rurembo	8da92b40-5d48-45b7-99e3-12fc8e22ee6f
515fdf11-a4ce-4afd-bd74-d51cd4b4b328	t	Taba	8da92b40-5d48-45b7-99e3-12fc8e22ee6f
cb036fe1-64fc-41ed-b4ee-5b3dd8201855	t	Buhoro	5daa8c47-5ef5-4797-9fa0-23960d441f4d
b7367e55-47c2-450f-8cfb-a6edea019113	t	Gaseke	5daa8c47-5ef5-4797-9fa0-23960d441f4d
10136f08-f3e7-4e0c-9636-2d8307f60339	t	Gateke	5daa8c47-5ef5-4797-9fa0-23960d441f4d
781dfe25-795b-479d-a126-32c4b3461819	t	Gorora	5daa8c47-5ef5-4797-9fa0-23960d441f4d
35157928-6eff-4575-b60d-c4b6c04b4244	t	Kigabiro	5daa8c47-5ef5-4797-9fa0-23960d441f4d
abd250f1-e0a9-4047-be86-d63e07827a09	t	Kinunga	5daa8c47-5ef5-4797-9fa0-23960d441f4d
31c8c529-fddb-45b3-b874-cb20a147d6af	t	Kiruhura	5daa8c47-5ef5-4797-9fa0-23960d441f4d
d3e4911e-f742-4a05-8815-c373ee021f91	t	Munini	5daa8c47-5ef5-4797-9fa0-23960d441f4d
94f6c1da-86e8-4a58-a560-967360294ff8	t	Murehe	5daa8c47-5ef5-4797-9fa0-23960d441f4d
83333036-71b1-4bb9-8685-df372edd9d1c	t	Mwijabo	5daa8c47-5ef5-4797-9fa0-23960d441f4d
35d9333e-cba5-4176-8dec-3397eeaa9d60	t	Mwijuto	5daa8c47-5ef5-4797-9fa0-23960d441f4d
5618a330-439d-42de-9bfe-c7fb95a0e612	t	Nyarubande	5daa8c47-5ef5-4797-9fa0-23960d441f4d
007edc14-c636-44ea-b47b-7271fe3b6081	t	Rwezamenyo	5daa8c47-5ef5-4797-9fa0-23960d441f4d
ad611afd-0443-447b-964c-bb0c83369a8a	t	Sovu	5daa8c47-5ef5-4797-9fa0-23960d441f4d
c232ceb5-ce47-40a6-9449-ce420acf42b0	t	Taba	5daa8c47-5ef5-4797-9fa0-23960d441f4d
3e68dbb2-5b2f-458d-8595-165357fe94d4	t	Amahoro	3e68c135-9438-4866-8c84-8df1e5b4b373
377e64ea-8d04-43bf-816d-1df6d88b0751	t	Amarebe	3e68c135-9438-4866-8c84-8df1e5b4b373
bc1e69f7-0358-4bcc-a7b3-1f6b93106443	t	Amarembo	3e68c135-9438-4866-8c84-8df1e5b4b373
f39f9341-14c4-41fa-830b-55c8e41dd3ad	t	Bigabiro	3e68c135-9438-4866-8c84-8df1e5b4b373
7549d06d-a793-4e26-b3f3-159485653661	t	Bukinanyana	3e68c135-9438-4866-8c84-8df1e5b4b373
e8af3c5d-d4e6-44a7-9ecd-157d82e85eda	t	Bumanzi	3e68c135-9438-4866-8c84-8df1e5b4b373
a7ee473b-faba-412a-a238-3f1c92ff0937	t	Bwiza	3e68c135-9438-4866-8c84-8df1e5b4b373
5291dae0-de5a-427d-95d5-55e68e62e15b	t	Gatsibo	3e68c135-9438-4866-8c84-8df1e5b4b373
78a59cdd-35ca-40ec-867a-04b8c108e12c	t	Gikundiro	3e68c135-9438-4866-8c84-8df1e5b4b373
8b151a49-5cbd-4b22-84c0-402e0315c353	t	Indakemwa	3e68c135-9438-4866-8c84-8df1e5b4b373
365fddb3-4afd-46b3-a9d8-8f09512a3481	t	Indamutsa	3e68c135-9438-4866-8c84-8df1e5b4b373
23e2f68f-c147-4d27-afe9-4474b5f1fb1b	t	Indatwa	3e68c135-9438-4866-8c84-8df1e5b4b373
b0bd2421-8f77-4d1d-8880-eb3691db4b59	t	Inyarurembo	3e68c135-9438-4866-8c84-8df1e5b4b373
673ae4cc-ee16-4de2-b7e8-143519e36f3a	t	Isangano	3e68c135-9438-4866-8c84-8df1e5b4b373
ce111c0b-3787-47a9-9d10-9a77b9c65e92	t	Karama	3e68c135-9438-4866-8c84-8df1e5b4b373
cca574cd-4dba-48db-af30-1bdee4fa2163	t	Kinyana	3e68c135-9438-4866-8c84-8df1e5b4b373
609d553a-e467-4518-83f8-6674fa9b056c	t	Rugwiro	3e68c135-9438-4866-8c84-8df1e5b4b373
0c7b6f58-0552-43f4-98f4-3fe79f001424	t	Umurava	3e68c135-9438-4866-8c84-8df1e5b4b373
0adc70bd-11be-4516-96b5-ded88b167c00	t	Akindege	1246e749-20e8-4ef9-83ed-da3e8ff8eb81
70fd7a73-76bf-46d4-b04c-100ab786f921	t	Indatwa	1246e749-20e8-4ef9-83ed-da3e8ff8eb81
36f67363-92c2-4648-9cb0-f84091a7da2a	t	Intwari	1246e749-20e8-4ef9-83ed-da3e8ff8eb81
c6d2383e-1b23-41bd-a417-6f4187831018	t	Kabagendwa	1246e749-20e8-4ef9-83ed-da3e8ff8eb81
fce431e7-77e3-4161-859f-494809b2b926	t	Kibaya	1246e749-20e8-4ef9-83ed-da3e8ff8eb81
0c33876b-f8c7-40b1-a535-02314a878054	t	Mukoni	1246e749-20e8-4ef9-83ed-da3e8ff8eb81
c00da0a5-3e15-440c-9d46-252815dd9760	t	Mulindi	1246e749-20e8-4ef9-83ed-da3e8ff8eb81
72f45b99-aefb-4045-b924-5521d91b9654	t	Umucyo	1246e749-20e8-4ef9-83ed-da3e8ff8eb81
56bc08c9-b787-4997-9d22-2ad67b8de909	t	Uruhongore	1246e749-20e8-4ef9-83ed-da3e8ff8eb81
a2263efc-8c7e-4789-afed-3bcf24213dbd	t	Gasaraba	7daa0499-e03f-4e82-9d6e-f84b9bb2468d
c68ee8c4-dfd6-4ba5-b8d4-9a2c65d58bf7	t	Gihanga	7daa0499-e03f-4e82-9d6e-f84b9bb2468d
0afe6597-e000-4ba4-8303-4fed6f483cfe	t	Gitara	7daa0499-e03f-4e82-9d6e-f84b9bb2468d
f2235062-b4d5-47a3-a98c-e406719690c9	t	Kavumu	7daa0499-e03f-4e82-9d6e-f84b9bb2468d
d65a6366-7ea2-4739-9412-f93a4dea6532	t	Mahoro	7daa0499-e03f-4e82-9d6e-f84b9bb2468d
7a2d343d-574d-438b-a04e-552a7323a6d6	t	Nyarutovu	7daa0499-e03f-4e82-9d6e-f84b9bb2468d
2ef5c1ff-9960-4ac6-9709-ba2df04129ff	t	Rugali	7daa0499-e03f-4e82-9d6e-f84b9bb2468d
42df5d37-e04e-4b9e-a361-00bf6319dd13	t	Runyonza	7daa0499-e03f-4e82-9d6e-f84b9bb2468d
bd30d657-fce0-476a-a238-4552470bde58	t	Gabiro	6218d840-469d-4dd2-81b5-2e1d0e1284e7
1c22da6c-e87f-4a77-99b2-739a3ef8ac1e	t	Kabaya	6218d840-469d-4dd2-81b5-2e1d0e1284e7
1f2028cf-c5fd-44ba-ad23-6ad15aceb552	t	Kanogo	6218d840-469d-4dd2-81b5-2e1d0e1284e7
c7cd17c2-88a2-4a9e-a101-f607be377a19	t	Marembo	6218d840-469d-4dd2-81b5-2e1d0e1284e7
fdca9b3b-677b-4d02-ac09-9977e117fa06	t	Umushumba M	6218d840-469d-4dd2-81b5-2e1d0e1284e7
d3e2bd7d-c230-41c1-b3ab-8a6ef6b97568	t	Nyandungu	6218d840-469d-4dd2-81b5-2e1d0e1284e7
cade15a4-8888-4c74-bf7f-05770b4c0699	t	Ruragendwa	6218d840-469d-4dd2-81b5-2e1d0e1284e7
5c38c6c9-5e9e-429b-a279-9f4cc8c56488	t	Rwinyana	6218d840-469d-4dd2-81b5-2e1d0e1284e7
19fe97d1-b884-4f0e-824f-33083eea5af2	t	Rwinyange	6218d840-469d-4dd2-81b5-2e1d0e1284e7
a7f0f587-c27f-44c2-9bb6-0b4255605d38	t	Rwiza	6218d840-469d-4dd2-81b5-2e1d0e1284e7
bdd66920-4f3f-4a63-bc7a-e009efba4788	t	Urwibutso	6218d840-469d-4dd2-81b5-2e1d0e1284e7
bc5bd71a-097d-42e5-88dc-7adb507b54b3	t	Gihanga	5fde4068-e18d-411e-ac8d-576a8dcd8b66
1fdb36b4-5b89-40b3-aa77-64d942c5700f	t	Iterambere	5fde4068-e18d-411e-ac8d-576a8dcd8b66
58cc3b37-51a2-4cb5-abd8-71f840c16f39	t	Izuba	5fde4068-e18d-411e-ac8d-576a8dcd8b66
ae1a560c-6dc0-4584-86ed-63763d59e844	t	Nyaburanga	5fde4068-e18d-411e-ac8d-576a8dcd8b66
76e02e56-c6bb-44bd-a3b6-d8b25adda332	t	Nyenyeri	5fde4068-e18d-411e-ac8d-576a8dcd8b66
41ff571a-3059-454f-88e2-d462e0fb06c2	t	Ubukorikori	5fde4068-e18d-411e-ac8d-576a8dcd8b66
8544d8cc-e61d-469d-b674-e6f117e95d34	t	Ubumwe	5fde4068-e18d-411e-ac8d-576a8dcd8b66
7b0a654d-de61-42ed-ad00-fa0749d219b1	t	Ubwiyunge	5fde4068-e18d-411e-ac8d-576a8dcd8b66
334fcf80-98f9-43db-b734-0b784ea8a777	t	Umucyo	5fde4068-e18d-411e-ac8d-576a8dcd8b66
1bad65e4-2101-4cc2-9c19-11f0640bdc8f	t	Umurabyo	5fde4068-e18d-411e-ac8d-576a8dcd8b66
18206b0d-abf7-46c7-af5c-a6d44b1e31dd	t	Umuseke	5fde4068-e18d-411e-ac8d-576a8dcd8b66
ecc28f98-eef0-46d5-be07-4b3f91a9b468	t	Vugizo	5fde4068-e18d-411e-ac8d-576a8dcd8b66
6ba5cba7-f606-4614-a473-c5a1dbe40d4a	t	Akinyambo	ca4aca4c-a74a-4879-98cd-b12d9c25828f
b3b9b74d-1ff9-4e24-aca2-a363a1df641c	t	Amayaga	ca4aca4c-a74a-4879-98cd-b12d9c25828f
41ed756a-5814-4b32-bcb4-dc5cdb038280	t	Gitwa	ca4aca4c-a74a-4879-98cd-b12d9c25828f
752f56b1-34b0-4caf-8b4a-d8eae8968b84	t	Ituze	ca4aca4c-a74a-4879-98cd-b12d9c25828f
e9e8d86e-0004-4716-955d-5bf9e00ba174	t	Mpazi	ca4aca4c-a74a-4879-98cd-b12d9c25828f
1b8ca6ce-9786-4508-adf3-2b52ba587ef3	t	Amahoro	9a23aaa7-e1ec-4109-940b-62b477cf772e
403c2b98-2d32-4605-aeb3-49b9c6132c65	t	Impuhwe	9a23aaa7-e1ec-4109-940b-62b477cf772e
b60c3c3e-6bf9-4d18-8c6c-367647caab74	t	Intsinzi	9a23aaa7-e1ec-4109-940b-62b477cf772e
85713b08-e491-4330-97ea-a1f1d63e0d14	t	Kivumu	9a23aaa7-e1ec-4109-940b-62b477cf772e
cfad9ecf-15b1-4048-88b5-46fae14ac2f6	t	Ubumwe	9a23aaa7-e1ec-4109-940b-62b477cf772e
cdc58f0b-425c-42e0-ad0f-0764bd6250c0	t	Urukundo	9a23aaa7-e1ec-4109-940b-62b477cf772e
180e1335-a767-4fc6-9981-76aa7cf69cd3	t	Ururembo	9a23aaa7-e1ec-4109-940b-62b477cf772e
5f8905f7-a5ca-4146-96ed-91fa7b788825	t	Ingenzi	56b2677a-05b3-4ce9-80ee-4096e2e730f3
d5c70a58-92ab-479b-aa2b-fb9a21d70bac	t	Sangwa	56b2677a-05b3-4ce9-80ee-4096e2e730f3
7bfcadbf-3968-401e-a3ed-78275d0533ce	t	Umubano	56b2677a-05b3-4ce9-80ee-4096e2e730f3
9f090284-ddbb-4e5f-be1e-571c9dc64d5e	t	Umucyo	56b2677a-05b3-4ce9-80ee-4096e2e730f3
fa23ed5b-e126-4780-a919-4e1f634c8b1c	t	Umuhoza	56b2677a-05b3-4ce9-80ee-4096e2e730f3
ae049c22-c78e-4080-81d7-223de4e4881c	t	Umurava	56b2677a-05b3-4ce9-80ee-4096e2e730f3
f054551d-dcca-476b-9ac2-09dc8a52ee53	t	Akabugenewe	6287c9b9-dc76-40d0-8f9a-9b593fb99445
4b6cef8b-6e80-43f7-aa66-1a52ff61c36c	t	Ihuriro	6287c9b9-dc76-40d0-8f9a-9b593fb99445
c4dc1200-1671-4f60-8976-ec555cf090fb	t	Isangano	6287c9b9-dc76-40d0-8f9a-9b593fb99445
f226eaf6-ac33-4961-bfd3-2a852804d91c	t	Isano	6287c9b9-dc76-40d0-8f9a-9b593fb99445
019d97c8-06c4-4164-b203-4e50c601ec53	t	Karitasi	6287c9b9-dc76-40d0-8f9a-9b593fb99445
8f652880-06e9-494e-8f2a-51484e5132b6	t	Ubumanzi	6287c9b9-dc76-40d0-8f9a-9b593fb99445
c2c8b3d2-bb99-4a46-a871-84b4b192e9e1	t	Uburezi	6287c9b9-dc76-40d0-8f9a-9b593fb99445
4942d07c-0124-442f-b482-36560c090dcd	t	Ubwiza	6287c9b9-dc76-40d0-8f9a-9b593fb99445
f1afcc63-ba72-4046-ae48-760f9677ba74	t	Umucyo	6287c9b9-dc76-40d0-8f9a-9b593fb99445
a1fa46ef-f70a-47ef-8965-7f61367a3e04	t	Umwembe	6287c9b9-dc76-40d0-8f9a-9b593fb99445
79c4f2d0-d7b9-4b75-8497-b4ae93474b7c	t	Urugano	6287c9b9-dc76-40d0-8f9a-9b593fb99445
7e45ab21-d38a-4eb8-a140-a84d5150da57	t	Isangano	d5ece781-f245-4303-a9e7-961d82fdeeed
cc3ec41b-91b1-417b-88fe-acb55111c549	t	Kanunga	d5ece781-f245-4303-a9e7-961d82fdeeed
841af09c-fd28-44b5-932f-12adc2a01606	t	Kinyambo	d5ece781-f245-4303-a9e7-961d82fdeeed
fd3b5db3-7102-40c8-94bf-2cc75ea112d1	t	Kivumu	d5ece781-f245-4303-a9e7-961d82fdeeed
e509d863-4b49-47d5-88ea-ef87b7586bbf	t	Kora	d5ece781-f245-4303-a9e7-961d82fdeeed
a8908fd3-aa6b-42c5-9b39-2b7188a00b95	t	Mpazi	d5ece781-f245-4303-a9e7-961d82fdeeed
27db5d59-a187-4011-a5be-92f5e5c65602	t	Rugano	d5ece781-f245-4303-a9e7-961d82fdeeed
43e329ab-38fb-40f5-b584-6db6d09c85a0	t	Rugari	d5ece781-f245-4303-a9e7-961d82fdeeed
84d1edc3-23fc-46ec-bdbe-3d1cb9121e64	t	Ubumwe	d5ece781-f245-4303-a9e7-961d82fdeeed
41932554-25d7-442d-ba70-4ebf9a813113	t	Bwimo	e8bb001d-c935-485e-b2ee-357b300b0f54
2a5f5332-6802-4d1a-bfae-807225187917	t	Gatare	e8bb001d-c935-485e-b2ee-357b300b0f54
4c0a2b64-cda1-417e-b008-775c35d4df1c	t	Mubuga	e8bb001d-c935-485e-b2ee-357b300b0f54
0234c16b-e8a5-4e20-93c7-a6c6dd355d83	t	Nyakirambi	e8bb001d-c935-485e-b2ee-357b300b0f54
00ffe422-c76d-476f-9360-9bb55382f653	t	Nyamweru	e8bb001d-c935-485e-b2ee-357b300b0f54
b50088ef-1e93-4e8e-82b8-3fa81cdc0fe1	t	Ruhengeri	e8bb001d-c935-485e-b2ee-357b300b0f54
c294f22d-6b66-494d-a701-41b363171974	t	Bibungo	b475d9d1-10ef-466e-bb56-5dc221009d43
c8311524-a3eb-4a46-9555-f0a548f49741	t	Bwiza	b475d9d1-10ef-466e-bb56-5dc221009d43
1d28c0f8-715b-416e-94da-51b9eff49268	t	Gateko	b475d9d1-10ef-466e-bb56-5dc221009d43
6e857ab3-6b20-43dc-8f97-efb2fc48815a	t	Kagasa	b475d9d1-10ef-466e-bb56-5dc221009d43
de1bdd98-e2c3-41b6-b1a7-384f13177a03	t	Nyabihu	b475d9d1-10ef-466e-bb56-5dc221009d43
3eee26fd-b709-4ddb-84d4-554137c48c0b	t	Rutagara I	b475d9d1-10ef-466e-bb56-5dc221009d43
9395a2a5-1fc4-44d4-8c38-016ff628c3a7	t	Rutagara II	b475d9d1-10ef-466e-bb56-5dc221009d43
a5882784-6581-43bd-aad4-7843995efbab	t	Ruyenzi	b475d9d1-10ef-466e-bb56-5dc221009d43
ca09a866-8e6a-4353-ae33-2ff46cd50f69	t	Kagaramira	894299bb-2beb-49a8-b5a6-4fd4bbb6fc1b
f5288ea3-b1c4-456b-a09c-7aad23694267	t	Ngendo	894299bb-2beb-49a8-b5a6-4fd4bbb6fc1b
86e8ff11-5ea9-421b-96b8-9aa382b9715b	t	Nyarurama	894299bb-2beb-49a8-b5a6-4fd4bbb6fc1b
4d43712d-3ab4-4f9a-8420-7ab6831f8e5e	t	Nyarusange	894299bb-2beb-49a8-b5a6-4fd4bbb6fc1b
aeae5d68-a990-435d-9f92-72da7eab4081	t	Rwakivumu	894299bb-2beb-49a8-b5a6-4fd4bbb6fc1b
27a82bdf-98a5-49f0-8abf-82ce00abbe34	t	Taba	894299bb-2beb-49a8-b5a6-4fd4bbb6fc1b
a9771408-e1a5-4565-bdb3-846211a96b1f	t	Akirwanda	8da563a1-d5c9-47ff-b33f-53821a136359
b3516766-7909-43b6-9b91-7d5a08f1e23a	t	Gisenga	8da563a1-d5c9-47ff-b33f-53821a136359
b3736992-7ab4-4f63-b894-becbefaba2ce	t	Kadobogo	8da563a1-d5c9-47ff-b33f-53821a136359
a6a2b2ed-29aa-4381-bb7a-4698ba8fd1b8	t	Kagarama	8da563a1-d5c9-47ff-b33f-53821a136359
18877321-8966-465e-be28-0f7d72c31dcd	t	Kibisogi	8da563a1-d5c9-47ff-b33f-53821a136359
8e741479-7218-4383-9df8-c172eba44eb1	t	Muganza	8da563a1-d5c9-47ff-b33f-53821a136359
e79c2710-6aa3-44a9-b415-53674753811f	t	Murama	8da563a1-d5c9-47ff-b33f-53821a136359
79b040ae-e32d-4f11-b700-a9102d6ae29c	t	Rubuye	8da563a1-d5c9-47ff-b33f-53821a136359
a12af33d-a3cd-4750-93e9-37a21b48157c	t	Ruhango	8da563a1-d5c9-47ff-b33f-53821a136359
f1e8a010-0072-453b-b03d-c6d8d3ee28f7	t	Ryasharangabo	8da563a1-d5c9-47ff-b33f-53821a136359
88ec6ddf-636d-438f-84ed-2e05fc3417c2	t	Agakomeye	458f75cf-ddc9-4c6f-b3fe-a35129ddd0af
793972a0-e050-41ab-90f5-851a0e9a4fa4	t	Akagugu	458f75cf-ddc9-4c6f-b3fe-a35129ddd0af
99ae8460-b109-4075-b0bf-f4243a38a628	t	Amahoro	458f75cf-ddc9-4c6f-b3fe-a35129ddd0af
9af5d17f-0431-46d6-8f13-f436c7f597cf	t	Amajyambere	458f75cf-ddc9-4c6f-b3fe-a35129ddd0af
a198ea4c-ffbe-43e1-a880-7d4a2f93ff33	t	Birambo	458f75cf-ddc9-4c6f-b3fe-a35129ddd0af
e3c49152-73d9-4fd0-938a-5e9978b511c6	t	Isangano	458f75cf-ddc9-4c6f-b3fe-a35129ddd0af
d519b7ab-79a7-433b-97e2-668bdf39a566	t	Kanyabami	458f75cf-ddc9-4c6f-b3fe-a35129ddd0af
8efd5c22-0068-49e1-b33e-841638d66dac	t	Karambo	458f75cf-ddc9-4c6f-b3fe-a35129ddd0af
425156c9-f201-4ac5-abc9-bd84bbcef2b7	t	Mwendo	458f75cf-ddc9-4c6f-b3fe-a35129ddd0af
9325aace-c1c7-4579-982b-077e35006832	t	Ruhuha	458f75cf-ddc9-4c6f-b3fe-a35129ddd0af
ebbfeaef-ce71-454b-87b2-db0336bf1d4c	t	Ubuzima	458f75cf-ddc9-4c6f-b3fe-a35129ddd0af
a23b701a-dd70-4c3d-b42c-99f5bc1803ce	t	Umutekano	458f75cf-ddc9-4c6f-b3fe-a35129ddd0af
49cd5554-10c1-426d-9eea-d6bf072308c0	t	Gakoni	8e2e6ebf-9353-47b1-ac84-97c294bef294
d9b167b8-65f4-480f-80c5-d97a469d36a0	t	Gatare	8e2e6ebf-9353-47b1-ac84-97c294bef294
63daa1d1-7dbe-42fa-9c62-42ce08bf56cb	t	Giticyinyoni	8e2e6ebf-9353-47b1-ac84-97c294bef294
501424eb-c8dc-4e07-a2ec-6fd827a616ff	t	Kadobogo	8e2e6ebf-9353-47b1-ac84-97c294bef294
e72dbf02-92fb-45a9-a01c-24df51966a75	t	Kamenge	8e2e6ebf-9353-47b1-ac84-97c294bef294
d05f7e66-8c39-4d9a-ba48-14d1c965b68a	t	Karama	8e2e6ebf-9353-47b1-ac84-97c294bef294
705e64d8-ef9f-4465-ad97-89de0a85155d	t	Kiruhura	8e2e6ebf-9353-47b1-ac84-97c294bef294
d1aef81e-2a37-44a0-a9c4-2c1a20f1558d	t	Nyabikoni	8e2e6ebf-9353-47b1-ac84-97c294bef294
2e555262-32a7-46f6-beb3-44d429c6e8eb	t	Nyabugogo	8e2e6ebf-9353-47b1-ac84-97c294bef294
600efa82-b5d4-497d-a97f-21ccb2127bcb	t	Ruhondo	8e2e6ebf-9353-47b1-ac84-97c294bef294
41c29158-9db3-47e2-b112-e7c1c0bc85f6	t	Misibya	c19bd981-69dc-49ef-a4e2-9e0263017d41
3832585b-6b1a-4405-8ab8-4780f8eb5954	t	Nyabitare	c19bd981-69dc-49ef-a4e2-9e0263017d41
434d59f9-273c-45cf-a9c7-39f357cc4f0d	t	Ruhango	c19bd981-69dc-49ef-a4e2-9e0263017d41
1e91fbc0-0ddf-48fc-9841-fe799bab3523	t	Ruharabuge	c19bd981-69dc-49ef-a4e2-9e0263017d41
7fd0ddff-a496-43a1-867a-dad453b1b8c6	t	Ruriba	c19bd981-69dc-49ef-a4e2-9e0263017d41
68ccb03f-9e8c-4340-8f0b-e3cd70aad354	t	Ruzigimbogo	c19bd981-69dc-49ef-a4e2-9e0263017d41
38fda06c-f157-44f2-9bd7-920bcab2c4fe	t	Ryamakomari	c19bd981-69dc-49ef-a4e2-9e0263017d41
2987fe53-427a-47ae-928a-778b8e7b4127	t	Tubungo	c19bd981-69dc-49ef-a4e2-9e0263017d41
bb852816-6af0-4910-b7cc-a13ad6e646be	t	Akanyamirambe	69ad2b06-8f9e-4edf-9359-f0184b4eff6b
004ba8ac-e553-4631-989d-3a87e9b69916	t	Akinama	69ad2b06-8f9e-4edf-9359-f0184b4eff6b
dc6e347d-0417-4388-b5ba-29ffd97f5c2a	t	Makaga	69ad2b06-8f9e-4edf-9359-f0184b4eff6b
40384115-7552-4482-8b55-3ca2b401078c	t	Musimba	69ad2b06-8f9e-4edf-9359-f0184b4eff6b
6fa6ee7e-0a87-4ce6-8d30-be329b12d65f	t	Ruhogo	69ad2b06-8f9e-4edf-9359-f0184b4eff6b
54e4bba3-de97-4d35-9323-7ef72188124d	t	Rwesero	69ad2b06-8f9e-4edf-9359-f0184b4eff6b
79bbc28a-1c10-4bea-a4fa-39a93d2eb64c	t	Rweza	69ad2b06-8f9e-4edf-9359-f0184b4eff6b
55cc81f5-4fc0-49fc-a7c8-0eee885515c2	t	Vuganyana	69ad2b06-8f9e-4edf-9359-f0184b4eff6b
82b618db-8227-4ef5-a913-42b3216e1b66	t	Buhoro	c94c188e-2930-4138-9e33-16852612da72
f5f7fe33-1357-49db-ba7b-7658f05911ac	t	Busasamana	c94c188e-2930-4138-9e33-16852612da72
1f65287f-8066-4336-b8b6-7cf4b23aee3d	t	Isimbi	c94c188e-2930-4138-9e33-16852612da72
5e0f2520-f1fe-4c4a-bf67-4a2dfeff1b0b	t	Ituze	c94c188e-2930-4138-9e33-16852612da72
6f12978e-7e3a-4444-8fc8-d0e5f637f4af	t	Karama	c94c188e-2930-4138-9e33-16852612da72
1e9e2bb6-fd2a-4a29-9c6e-f6c72560039d	t	Karwarugabo	c94c188e-2930-4138-9e33-16852612da72
9b624a4d-e09e-486f-b66d-1862bba4d3be	t	Kigabiro	c94c188e-2930-4138-9e33-16852612da72
6717465d-685b-4cc0-81a5-2bdf83d75a16	t	Mataba	c94c188e-2930-4138-9e33-16852612da72
0739f38b-cacf-48a9-a2b6-ebf788670793	t	Munini	c94c188e-2930-4138-9e33-16852612da72
c45f8ec1-cab6-452e-8b5e-59ebaae3dbe7	t	Ntaraga	c94c188e-2930-4138-9e33-16852612da72
40fa98d2-f0ce-4069-be2e-6657b4528f11	t	Nunga	c94c188e-2930-4138-9e33-16852612da72
17cb21b1-03d0-43e3-aafc-82b3eaed2e33	t	Rurama	c94c188e-2930-4138-9e33-16852612da72
8d5dfe9b-4759-4f65-8610-b724be0e38a5	t	Rutunga	c94c188e-2930-4138-9e33-16852612da72
b8f68805-68cf-4fd8-99a0-59d6007580c8	t	Tetero	c94c188e-2930-4138-9e33-16852612da72
b410863d-1abc-4062-bd2b-6077a2421a73	t	Akamahoro	b7819e46-f1a1-4c0d-9fef-51367161f825
f696b1ae-716f-4e01-be1b-e131786c22c1	t	Akishinge	b7819e46-f1a1-4c0d-9fef-51367161f825
f82c764e-bd54-48ba-93a7-b06665bf411b	t	Akishuri	b7819e46-f1a1-4c0d-9fef-51367161f825
b395c1b0-d367-480a-9aca-3a708c31163b	t	Amahumbezi	b7819e46-f1a1-4c0d-9fef-51367161f825
4ad0e554-9c3e-4fcd-ad36-f31e4c80bdae	t	Inganzo	b7819e46-f1a1-4c0d-9fef-51367161f825
f2e3c90a-e72e-4991-8886-86643cb4225b	t	Kigarama	b7819e46-f1a1-4c0d-9fef-51367161f825
85398955-525f-454a-a876-0bf36cf19766	t	Mpazi	b7819e46-f1a1-4c0d-9fef-51367161f825
d1c430bb-991d-493a-a536-42a9733eeb00	t	Mugina	b7819e46-f1a1-4c0d-9fef-51367161f825
6bc2ff53-1149-40c2-9fb0-0ff17099861e	t	Ubumwe	b7819e46-f1a1-4c0d-9fef-51367161f825
16fb7d46-323a-486b-9a6a-4aedd2d68c59	t	Ubusabane	b7819e46-f1a1-4c0d-9fef-51367161f825
9a89b707-1910-4195-88bc-859a251f0810	t	Umubano	b7819e46-f1a1-4c0d-9fef-51367161f825
2ef88d3e-89b9-47a8-9f26-6ad2aa167a9a	t	Umurinzi	b7819e46-f1a1-4c0d-9fef-51367161f825
98993205-d0ba-448d-b296-9999eb9a9ebb	t	Uruyange	b7819e46-f1a1-4c0d-9fef-51367161f825
cf8d6a6a-bc20-4d1d-89b3-807661456f85	t	Akabeza	70e9dd1c-4da5-4161-97df-2615ce84cb2c
e1f1b508-14bb-4be4-89b2-59393ad6398e	t	Amahoro	70e9dd1c-4da5-4161-97df-2615ce84cb2c
63725dc7-3531-4c36-90c8-f42d69c9b566	t	Birama	70e9dd1c-4da5-4161-97df-2615ce84cb2c
35c2795a-c1c9-4481-a210-340582890df3	t	Buhoro	70e9dd1c-4da5-4161-97df-2615ce84cb2c
ec875a19-fc71-49e1-84d7-c7a379b35ff6	t	Bwiza	70e9dd1c-4da5-4161-97df-2615ce84cb2c
df32bee7-dbfc-4adc-834a-57f706b3992a	t	Byimana	70e9dd1c-4da5-4161-97df-2615ce84cb2c
c08af8b7-3f98-438b-be58-f2f0f98d6d38	t	Gakaraza	70e9dd1c-4da5-4161-97df-2615ce84cb2c
af037799-b3ea-48b4-89a7-b5b3e3abab4d	t	Gaseke	70e9dd1c-4da5-4161-97df-2615ce84cb2c
646cbde6-c0a2-4b60-86e5-f49e167d057d	t	Ihuriro	70e9dd1c-4da5-4161-97df-2615ce84cb2c
d012e6dd-612a-498a-8cc4-418d7eaa28ca	t	Inkurunziza	70e9dd1c-4da5-4161-97df-2615ce84cb2c
a8b36153-a85f-4464-94f7-e5096ffbe9ce	t	Karambi	70e9dd1c-4da5-4161-97df-2615ce84cb2c
5a8edbcd-a5ca-4a43-bf7d-f5977cfcdbe1	t	Kigina	70e9dd1c-4da5-4161-97df-2615ce84cb2c
2259c236-651b-4740-aef4-55890591525d	t	Kimisagara	70e9dd1c-4da5-4161-97df-2615ce84cb2c
d8f5e057-440b-4cb6-8b28-a75d46813feb	t	Kove	70e9dd1c-4da5-4161-97df-2615ce84cb2c
5f335a06-c883-4e26-9feb-7b936b9af449	t	Muganza	70e9dd1c-4da5-4161-97df-2615ce84cb2c
607f5044-0af4-4a2b-8e4b-cca354242c62	t	Nyabugogo	70e9dd1c-4da5-4161-97df-2615ce84cb2c
f083fcc4-a2b7-4da5-866b-19925410b202	t	Nyagakoki	70e9dd1c-4da5-4161-97df-2615ce84cb2c
953128f8-4044-48ab-86b8-20a9341d7161	t	Nyakabingo	70e9dd1c-4da5-4161-97df-2615ce84cb2c
17e7c11d-bb07-4fdf-bd3d-0c8cc2a703b7	t	Nyamabuye	70e9dd1c-4da5-4161-97df-2615ce84cb2c
36fc5388-8cd3-48f6-88dc-761c0cfcc4ae	t	Sangwa	70e9dd1c-4da5-4161-97df-2615ce84cb2c
5fac16ee-4692-4d4b-abe4-cee992fd4f02	t	Sano	70e9dd1c-4da5-4161-97df-2615ce84cb2c
8e1fce56-7fb1-4c25-8c02-38b75eb1a104	t	Kamatamu	f67dde5d-0ad1-471e-8dba-e37cb006798d
f5954ae9-d686-405a-96ba-4093808f425d	t	Kankuba	f67dde5d-0ad1-471e-8dba-e37cb006798d
c5942ffa-03ad-4381-8695-da12b09284ff	t	Karukina	f67dde5d-0ad1-471e-8dba-e37cb006798d
935950e1-3b93-42a1-a3ec-00d7c237a900	t	Musave	f67dde5d-0ad1-471e-8dba-e37cb006798d
ada4ee68-eff4-460c-8021-da693db44faf	t	Nyarumanga	f67dde5d-0ad1-471e-8dba-e37cb006798d
6a6b76cb-5cf7-4c38-b152-99308e610ef3	t	Rugendabari	f67dde5d-0ad1-471e-8dba-e37cb006798d
c4b5996d-3b72-419a-bd60-dcc777c03e34	t	Ayabatanga	3a20595b-086c-46e6-903d-519f2e5e6c24
95099a70-f784-4e5d-b3b2-6614e1dcfef8	t	Kankurimba	3a20595b-086c-46e6-903d-519f2e5e6c24
efd1a5c2-958a-4089-8486-1d0565498821	t	Kavumu	3a20595b-086c-46e6-903d-519f2e5e6c24
5a6093e1-ecdf-4354-82a1-a56fa8dff7b7	t	Mubura	3a20595b-086c-46e6-903d-519f2e5e6c24
ebd100fb-af56-4985-bec3-d76d183a8ec7	t	Murondo	3a20595b-086c-46e6-903d-519f2e5e6c24
99ae815a-7d3c-4025-8dae-2aa8718d5230	t	Nyakabingo	3a20595b-086c-46e6-903d-519f2e5e6c24
ae2a7347-2ffa-4f65-8b2b-a9c0863054ad	t	Nyarubuye	3a20595b-086c-46e6-903d-519f2e5e6c24
259fd9a6-76de-41c8-865a-b5d4fb9247bb	t	Burema	cd3f776e-38c9-4afa-ad94-b04eb568bc47
fd8042bc-b7a5-4b62-8739-4df5aec99c1f	t	Gahombo	cd3f776e-38c9-4afa-ad94-b04eb568bc47
ab3782d2-548a-45c7-b17b-52581044bd7b	t	Kabeza	cd3f776e-38c9-4afa-ad94-b04eb568bc47
15ef5750-cf6e-4e85-b53c-f668a4df4d76	t	Karambi	cd3f776e-38c9-4afa-ad94-b04eb568bc47
baa0f42c-1e3b-465e-bf30-71f2f6beb1ec	t	Kwisanga	cd3f776e-38c9-4afa-ad94-b04eb568bc47
596130da-6657-41f4-8526-e49554270df0	t	Mageragere	cd3f776e-38c9-4afa-ad94-b04eb568bc47
47175e3d-8215-4809-a109-bccec9b60303	t	Mataba	cd3f776e-38c9-4afa-ad94-b04eb568bc47
93d11d96-eb06-47e4-a76e-ea75fbfadc83	t	Rushubi	cd3f776e-38c9-4afa-ad94-b04eb568bc47
362e6c39-34ec-4f42-925f-69b598643891	t	Akanakamage	05befc31-d3c3-4183-a1d3-cd85759b24c7
e796c521-1dd6-45f2-a69b-22061bc49e88	t	Gatovu	05befc31-d3c3-4183-a1d3-cd85759b24c7
5a6ab382-8009-448f-898d-641d1f096592	t	Nyabitare	05befc31-d3c3-4183-a1d3-cd85759b24c7
e4ccecee-b050-43e7-88f1-07d7483e83b3	t	Nyarubande	05befc31-d3c3-4183-a1d3-cd85759b24c7
1da4b969-3fb5-4bfa-8014-0108b664d9f6	t	Rubungo	05befc31-d3c3-4183-a1d3-cd85759b24c7
2a474c3b-6a27-4644-8a07-16cb24f662ac	t	Rwindonyi	05befc31-d3c3-4183-a1d3-cd85759b24c7
9baffc0b-1f98-4179-9288-76d72e3cd9c5	t	Akabungo	52923e99-df7d-48e1-ab39-a1dcf687e9e1
c039b4d2-0e11-46f0-b3dd-4a1df3f1c31a	t	Akamashinge	52923e99-df7d-48e1-ab39-a1dcf687e9e1
f52111f3-22bb-4f74-b14d-2b06896b4a6c	t	Maya	52923e99-df7d-48e1-ab39-a1dcf687e9e1
67bb2c02-e0a7-4343-8e27-fb53d288901e	t	Nyarufunzo	52923e99-df7d-48e1-ab39-a1dcf687e9e1
1671309d-92b7-4a85-8446-8cb7276fc42c	t	Nyarurama	52923e99-df7d-48e1-ab39-a1dcf687e9e1
56f1f0e3-61e9-4da2-9b46-29bfa05c1a23	t	Rubete	52923e99-df7d-48e1-ab39-a1dcf687e9e1
85816373-7f48-4283-a05d-14333b69df5e	t	Amahoro	0afe7964-795a-4b8d-bc39-1c8b6de6ee5b
0e7c5ca5-8297-490e-bdcd-14360222df04	t	Ayabaramba	0afe7964-795a-4b8d-bc39-1c8b6de6ee5b
4407fe93-a5ce-4ef1-90fc-ae826dea90f6	t	Gikuyu	0afe7964-795a-4b8d-bc39-1c8b6de6ee5b
c94e5085-410b-41db-a667-38ee8284ef4e	t	Iterambere	0afe7964-795a-4b8d-bc39-1c8b6de6ee5b
2cf159c1-8944-4063-bd62-592dad5eeef9	t	Nyabirondo	0afe7964-795a-4b8d-bc39-1c8b6de6ee5b
79757a94-412d-4c90-aa4c-620d012e46bb	t	Nyarurenzi	0afe7964-795a-4b8d-bc39-1c8b6de6ee5b
20d56b62-ab4d-411e-8156-aa988e4caa85	t	Gisunzu	c92ad023-972a-44e4-b045-11c2984ae341
139a0e5e-e99f-43fc-8d07-cf6511918e19	t	Mpanga	c92ad023-972a-44e4-b045-11c2984ae341
b5a3f48c-79f6-4ea6-9678-005e269867f8	t	Nkomero	c92ad023-972a-44e4-b045-11c2984ae341
6876ee88-90ba-40bd-985b-8bb01c63ac1c	t	Runzenze	c92ad023-972a-44e4-b045-11c2984ae341
8f641203-7554-4b7a-86c7-0f9cefe61fc4	t	Uwurugenge	c92ad023-972a-44e4-b045-11c2984ae341
6be4bcb1-ea55-46ab-8d0f-3de6e0042338	t	Amahoro	6cdafca0-8756-4d8b-a92f-db1eab51d990
fcb70293-10a5-41c3-9c1b-fd2cc8d3e7e1	t	Amizero	6cdafca0-8756-4d8b-a92f-db1eab51d990
3b3d1285-b821-43eb-bd34-917743aa6e50	t	Inyarurembo	6cdafca0-8756-4d8b-a92f-db1eab51d990
c0acb960-1655-4894-931a-6fe2ca7f147b	t	Kabirizi	6cdafca0-8756-4d8b-a92f-db1eab51d990
1a34d03c-c124-46ef-8094-ec1bcfe5d67a	t	Ubuzima	6cdafca0-8756-4d8b-a92f-db1eab51d990
713115f9-390c-4297-b615-a44f0d26ae7a	t	Uruhimbi	6cdafca0-8756-4d8b-a92f-db1eab51d990
7c6af57d-e07d-4ee2-9872-5212866abb59	t	Icyeza	a760cb3d-22cd-40fa-91a1-926621988b5b
f01ee9f7-320d-40a1-94f9-69a468601898	t	Ikana	a760cb3d-22cd-40fa-91a1-926621988b5b
052ce408-f19f-40d2-aef2-303cb1ac565a	t	Intwari	a760cb3d-22cd-40fa-91a1-926621988b5b
428964a0-c63a-45ca-bae6-4675d5739cfe	t	Kabasengerezi	a760cb3d-22cd-40fa-91a1-926621988b5b
c4d9ca0c-b454-48d4-8e8b-2d76002bf01e	t	Hirwa	a38f321d-84b0-4781-85f2-646b86ade175
049cedbc-85a1-44f2-8581-9ce0aaf43f6b	t	Ikaze	a38f321d-84b0-4781-85f2-646b86ade175
dd7e896a-6a07-497f-90e9-bc9280302801	t	Imanzi	a38f321d-84b0-4781-85f2-646b86ade175
65d6f102-a1d8-4792-a851-4cb644461d2e	t	Ingenzi	a38f321d-84b0-4781-85f2-646b86ade175
e8d81e89-c18e-4059-b546-b9500939dd54	t	Ituze	a38f321d-84b0-4781-85f2-646b86ade175
950fa93d-d968-463a-ac6a-714f25708a92	t	Sangwa	a38f321d-84b0-4781-85f2-646b86ade175
a7f3ca3b-79ba-4ec6-a101-864212752fea	t	Umwezi	a38f321d-84b0-4781-85f2-646b86ade175
7297dcd8-7675-4139-8193-c45dd24653ba	t	Abeza	0fb04d34-6e22-4630-b927-2da07b41753e
d7ef605b-c948-46db-b8cf-4d18fddbbc90	t	Icyerekezo	0fb04d34-6e22-4630-b927-2da07b41753e
ecea22dc-0e3c-4814-ad63-a4beed6193bf	t	Indatwa	0fb04d34-6e22-4630-b927-2da07b41753e
c2ce99e7-5531-4853-af0b-8cafb7b0ba9f	t	Rwezangoro	0fb04d34-6e22-4630-b927-2da07b41753e
ebc74882-cd52-4238-a224-5f9c4bf9ff1f	t	Ubucuruzi	0fb04d34-6e22-4630-b927-2da07b41753e
a398dc55-6176-4b5a-99a0-4b66ac1daadb	t	Umutekano	0fb04d34-6e22-4630-b927-2da07b41753e
7f0e122b-8b19-4514-9142-122f0f4e4cf2	t	Imihigo	f7a93c8e-745b-4a57-9b80-507e99dae65e
795d4332-a7d1-4eb8-a7ea-f1768b998292	t	Impala	f7a93c8e-745b-4a57-9b80-507e99dae65e
88873414-ce4f-4b3a-b6ac-ec26ccbf1ab0	t	Rugenge	f7a93c8e-745b-4a57-9b80-507e99dae65e
905315b7-2591-40e7-b5ab-b22b674e8bb5	t	Ubumanzi	f7a93c8e-745b-4a57-9b80-507e99dae65e
7d5d3ccf-2578-4bc7-8ed7-4006db85e15f	t	Indamutsa	32068352-ccc5-4f94-b6f9-a229ed9e3212
b4a24cc7-ed87-4fc8-95db-1d62b9687669	t	Ingoro	32068352-ccc5-4f94-b6f9-a229ed9e3212
7420021c-9b73-4f14-a80c-48efd480adc3	t	Inkingi	32068352-ccc5-4f94-b6f9-a229ed9e3212
f5a135f1-12ae-473e-b5a6-c01aaf4b8315	t	Intiganda	32068352-ccc5-4f94-b6f9-a229ed9e3212
389650b6-bd96-4ab2-bd1b-85cfc723da96	t	Iwacu	32068352-ccc5-4f94-b6f9-a229ed9e3212
be93328e-5b9c-43c5-b002-dbb32bc0a3d0	t	Tetero	32068352-ccc5-4f94-b6f9-a229ed9e3212
8f223b35-344f-40ea-935e-b62e546ae205	t	Isangano	cc502a30-1580-40b6-8a65-9f76532bb844
0676d6d3-6890-4691-9d64-18d110ace423	t	Kabusunzu	4dea5cba-d0d8-4d28-a51f-fc6575353a0e
b85b90f2-11c2-406a-8256-ce6110edc1a2	t	Munanira	4dea5cba-d0d8-4d28-a51f-fc6575353a0e
f851f7ec-3625-4fb1-a47b-4f3a6858ee8c	t	Ntaraga	4dea5cba-d0d8-4d28-a51f-fc6575353a0e
fa1bfbe0-f323-4b8b-beeb-9bb37765e77f	t	Nyagasozi	4dea5cba-d0d8-4d28-a51f-fc6575353a0e
5247488a-c7ae-4d8f-a7df-f7217087e92a	t	Rurembo	4dea5cba-d0d8-4d28-a51f-fc6575353a0e
a83e9676-df9c-43bb-be4b-3d0caf092592	t	Gasiza	551b444b-8996-4582-bbde-b0f7953a1489
0e809714-fae4-4106-859c-243cae70c527	t	Kamwiza	551b444b-8996-4582-bbde-b0f7953a1489
86016381-98c7-42e8-82c4-c7e6a72aa4dc	t	Kanyange	551b444b-8996-4582-bbde-b0f7953a1489
8a04f78c-561f-421d-8b91-a177d911dffd	t	Karudandi	551b444b-8996-4582-bbde-b0f7953a1489
30ab4b1a-d384-4295-a6bd-012140bc0b58	t	Kigabiro	551b444b-8996-4582-bbde-b0f7953a1489
489aca5c-d4b9-4db0-92fb-af081738de31	t	Kokobe	551b444b-8996-4582-bbde-b0f7953a1489
a6e31b68-1939-422e-88ea-437c1fa54185	t	Mucyuranyana	551b444b-8996-4582-bbde-b0f7953a1489
8495b796-23ce-4303-9bf0-171c5382d846	t	Nkundumurimo	551b444b-8996-4582-bbde-b0f7953a1489
a0c0d523-dfae-4c99-99a8-65501425c1bd	t	Akinkware	5b004d3e-5fd6-403a-9441-7efa168b2e79
fd7a3ad9-a5db-4557-9839-89caec4c0cb3	t	Gapfupfu	5b004d3e-5fd6-403a-9441-7efa168b2e79
c29f839a-4dfa-4358-bb00-1fa257beb378	t	Gasiza	5b004d3e-5fd6-403a-9441-7efa168b2e79
87c36f6f-29a8-4554-b806-47c5641fbc3d	t	Kariyeri	5b004d3e-5fd6-403a-9441-7efa168b2e79
89c5426b-72e9-4012-950c-9edf7cde3e4e	t	Kokobe	5b004d3e-5fd6-403a-9441-7efa168b2e79
165eb0ae-0c37-4688-ab7d-9f4ab425c739	t	Munini	5b004d3e-5fd6-403a-9441-7efa168b2e79
cebe0a25-8683-4863-9ce3-0b5d605d96e9	t	Nyakabanda	5b004d3e-5fd6-403a-9441-7efa168b2e79
37c9b737-1567-4696-ad7d-bd21b7fe845f	t	Rwagitanga	5b004d3e-5fd6-403a-9441-7efa168b2e79
538621ef-a39d-45b0-ac26-b66f88af8505	t	Ibuhoro	1441c0d9-6d1d-4050-af08-291100bcca1a
494c037e-8129-4dc8-acb1-44aa9a108770	t	Kabeza	1441c0d9-6d1d-4050-af08-291100bcca1a
7e9d55bc-a052-4a79-86f4-8d26e7fa1a88	t	Kanyiranganji	1441c0d9-6d1d-4050-af08-291100bcca1a
f6f83bad-0a6c-4594-a21e-38b57b605d5b	t	Karujongi	1441c0d9-6d1d-4050-af08-291100bcca1a
120f15f7-9485-4158-b250-d716d6d3111b	t	Kigarama	1441c0d9-6d1d-4050-af08-291100bcca1a
6165a369-6988-4487-b497-c802b687968c	t	Kirwa	1441c0d9-6d1d-4050-af08-291100bcca1a
3d37501e-6490-4820-99ea-e30a4d8be014	t	Amizero	05e59d37-6dce-4cea-acfc-e567455f5114
75b07d17-3073-4067-823d-9ad1b0842796	t	Gabiro	05e59d37-6dce-4cea-acfc-e567455f5114
b0f5b342-abbd-4aea-bebc-7e46547cf089	t	Imanzi	05e59d37-6dce-4cea-acfc-e567455f5114
ac66d13b-3219-4ad2-8080-b0421e03d6cf	t	Ingenzi	05e59d37-6dce-4cea-acfc-e567455f5114
ae42cef0-dee7-4f64-bcdd-7b74117c319f	t	Intwari	05e59d37-6dce-4cea-acfc-e567455f5114
7eae9047-0ded-4715-8705-6ff842a4a8bd	t	Karisimbi	05e59d37-6dce-4cea-acfc-e567455f5114
83a65200-ba26-4cfd-99d6-7a2ad99a1555	t	Mahoro	05e59d37-6dce-4cea-acfc-e567455f5114
8f97016b-90c1-4077-8860-7b837440bf30	t	Mpano	05e59d37-6dce-4cea-acfc-e567455f5114
4864c022-a228-42ff-bf49-6a36907f5ae0	t	Muhabura	05e59d37-6dce-4cea-acfc-e567455f5114
058cd92c-73c2-4542-8e63-060331487d15	t	Muhoza	05e59d37-6dce-4cea-acfc-e567455f5114
a935aad1-63f7-479c-be49-380eefc45c3c	t	Munini	05e59d37-6dce-4cea-acfc-e567455f5114
2702afaa-4638-4dde-bcda-c54bde698fa6	t	Rugero	05e59d37-6dce-4cea-acfc-e567455f5114
e60873c5-50af-4599-98ef-fbca14f22f81	t	Shema	05e59d37-6dce-4cea-acfc-e567455f5114
4ecf63b5-ad45-4445-83d0-00e60b68e407	t	Kagunga	2f027b2b-e9c9-4ad8-8fce-7f83a75ad3fb
72c832a7-8027-420a-8bc2-0c3d30fde8fa	t	Karukoro	2f027b2b-e9c9-4ad8-8fce-7f83a75ad3fb
39500e83-82ab-4bbc-85c6-0a9d4573531e	t	Rwintare	2f027b2b-e9c9-4ad8-8fce-7f83a75ad3fb
49e04ec8-6eed-4757-ab28-c1b5fe1a0fcf	t	Akanyana	b1904295-b3b2-481d-86d9-b56a9b455c13
b14822b8-41d9-4488-95e3-f5c16e8dfbde	t	Akanyirazaninka	b1904295-b3b2-481d-86d9-b56a9b455c13
3820ee8b-85e5-4c79-8e08-67a78b1ad5e9	t	Akarekare	b1904295-b3b2-481d-86d9-b56a9b455c13
ecd51de9-7539-4308-acdb-07aefbc81609	t	Akatabaro	b1904295-b3b2-481d-86d9-b56a9b455c13
b1f948f9-e74d-41c6-80b4-b3dfea666a9d	t	Irembo	b1904295-b3b2-481d-86d9-b56a9b455c13
7f944996-8e0f-4103-b73f-d1f5fcdc191a	t	Itaba	b1904295-b3b2-481d-86d9-b56a9b455c13
06c3c499-7c85-4c58-9f65-b562f1012a5b	t	Kiberinka	b1904295-b3b2-481d-86d9-b56a9b455c13
afaaaa53-1715-4949-8f3a-3a9d6431e869	t	Mumena	b1904295-b3b2-481d-86d9-b56a9b455c13
457c830a-ac91-4bb8-a657-4dc037b9a0c1	t	Rwampara	b1904295-b3b2-481d-86d9-b56a9b455c13
e0ab35a8-d3d6-4c77-8bf8-0b9377634653	t	Gatare	335d18f9-c3e0-4e6b-8e57-6ae37689f802
296b9b28-29db-40df-87e2-059b4e418290	t	Kiberinka	335d18f9-c3e0-4e6b-8e57-6ae37689f802
1a344d13-1783-4d4e-a742-f4d02b1d5f4d	t	Munanira	335d18f9-c3e0-4e6b-8e57-6ae37689f802
d608fdf1-b20f-4d4a-b8de-59070f3c836a	t	Riba	335d18f9-c3e0-4e6b-8e57-6ae37689f802
31765d6d-e679-46a0-bb65-102262497205	t	Rubona	335d18f9-c3e0-4e6b-8e57-6ae37689f802
f7105f5c-5627-4e41-8b52-0a998a62b45a	t	Rugarama	335d18f9-c3e0-4e6b-8e57-6ae37689f802
d5868dff-c275-495e-b7b5-896ad653c8c5	t	Runyinya	335d18f9-c3e0-4e6b-8e57-6ae37689f802
b0176808-1b41-48c6-ae57-ac14e874c926	t	Rusisiro	335d18f9-c3e0-4e6b-8e57-6ae37689f802
f34bfaa8-68bc-4c81-95e7-59a0091530a0	t	Tetero	335d18f9-c3e0-4e6b-8e57-6ae37689f802
e308ccbb-eacd-4a63-aa27-41bef422bf97	t	Agatare	2ee7d76a-b4f4-442a-9fa5-08c68402d6c1
d0aac745-87fa-41df-86ae-8055d0fc75ae	t	Amajyambere	2ee7d76a-b4f4-442a-9fa5-08c68402d6c1
2051269e-da6a-40c7-81a7-24a25d0f706e	t	Inyambo	2ee7d76a-b4f4-442a-9fa5-08c68402d6c1
76d191b4-db41-45c7-b36b-9ec7aa717f1f	t	Meraneza	2ee7d76a-b4f4-442a-9fa5-08c68402d6c1
3dff6ec8-9478-4099-9ea0-5b17d0269b7a	t	Uburezi	2ee7d76a-b4f4-442a-9fa5-08c68402d6c1
04583fad-8558-4757-ade6-7c7cb3ab6404	t	Umucyo	2ee7d76a-b4f4-442a-9fa5-08c68402d6c1
3ff34de9-406a-4f3f-a8bd-4e62d369549c	t	Umurava	2ee7d76a-b4f4-442a-9fa5-08c68402d6c1
bd13a049-440f-4971-a87c-dbe3aa781fd8	t	Biryogo	ef3c1bc4-785a-4d78-9c20-aca951b99dfc
a12e814f-e90a-43c2-8856-0b5c915081ea	t	Gabiro	ef3c1bc4-785a-4d78-9c20-aca951b99dfc
36ef1a62-0037-4374-a3db-401168e4f5ae	t	Isoko	ef3c1bc4-785a-4d78-9c20-aca951b99dfc
f3a36c9c-cd3c-4bab-b17e-e5e0d641cfa0	t	Nyiranuma	ef3c1bc4-785a-4d78-9c20-aca951b99dfc
b6f5a390-8bc9-4ccd-beba-b0efffcd3baa	t	Umurimo	ef3c1bc4-785a-4d78-9c20-aca951b99dfc
5e024f68-eaa8-402c-92cc-7484c5b3f3ec	t	Amizero	364702d6-a274-4729-a48f-63d6179952fc
7ac8ca50-4ef0-49ea-8e60-7887145a0d8c	t	Cercle Sportif	364702d6-a274-4729-a48f-63d6179952fc
a06321fd-a7c7-4b44-ae0a-ce8dae08d242	t	Ganza	364702d6-a274-4729-a48f-63d6179952fc
19801cea-b5a9-4d44-acb2-699667c425ce	t	Imena	364702d6-a274-4729-a48f-63d6179952fc
f821dcb7-2a99-4910-bc03-667bbba30bee	t	Indangamirwa	364702d6-a274-4729-a48f-63d6179952fc
70d2322c-f275-400a-8ca4-b2cb49695876	t	Ingenzi	364702d6-a274-4729-a48f-63d6179952fc
2370c902-6e63-47a5-b06e-363ce9207d22	t	Inyarurembo	364702d6-a274-4729-a48f-63d6179952fc
05cc0656-bf9d-48c1-a050-acd18c2e5035	t	Ishema	364702d6-a274-4729-a48f-63d6179952fc
337d6a13-c992-4830-bb0c-f43384a27728	t	Isibo	364702d6-a274-4729-a48f-63d6179952fc
8d594277-6ae8-4ee7-a570-52a76ce99033	t	Muhabura	364702d6-a274-4729-a48f-63d6179952fc
56c2f335-e417-4940-ad3c-f840181778a2	t	Rugunga	364702d6-a274-4729-a48f-63d6179952fc
4c09493e-57c2-4488-9c0e-661e7e6061a7	t	Sugira	364702d6-a274-4729-a48f-63d6179952fc
f004a0ac-019a-4e46-a784-83c129901965	t	Amahoro	8c7f972e-2d62-4f31-909d-8dfe4de785c2
4d747cf2-5792-41ed-99eb-16dd4ff40057	t	Gacaca	8c7f972e-2d62-4f31-909d-8dfe4de785c2
e94a931c-bda6-49e0-90ad-33d802c88cd0	t	Intwari	8c7f972e-2d62-4f31-909d-8dfe4de785c2
52912b10-d628-48c9-abcd-282a01f1a7b1	t	Rwampara	8c7f972e-2d62-4f31-909d-8dfe4de785c2
1b9917bd-938c-4327-8630-f6e85ba94d40	t	Umucyo	8c7f972e-2d62-4f31-909d-8dfe4de785c2
7e168885-82dc-4fd4-872f-83140d477944	t	Umuganda	8c7f972e-2d62-4f31-909d-8dfe4de785c2
13af61c1-1c3a-4142-9f1e-66a2bba2bc9a	t	Muhoza	0ddc1081-30dc-4893-9168-07e283f9bd91
b993d7fb-1d58-434d-ba92-dfbc063d3967	t	Muhuza	0ddc1081-30dc-4893-9168-07e283f9bd91
d3df6c89-538e-4437-9834-88b21a29dca2	t	Mumararungu	0ddc1081-30dc-4893-9168-07e283f9bd91
b8c5645f-e746-4f2d-a7c9-6c4c0903a19b	t	Murambi	0ddc1081-30dc-4893-9168-07e283f9bd91
f38567e0-c657-4143-872e-974f955c4502	t	Buhoro	2db3cb56-5681-4df6-8938-2d2a0b970b06
784d18c4-6ac1-43f1-b1b8-e03b4c8958e6	t	Gasabo	2db3cb56-5681-4df6-8938-2d2a0b970b06
a92eb181-7c4e-4336-8165-09b1cd145609	t	Mutara	2db3cb56-5681-4df6-8938-2d2a0b970b06
62f27582-ea5a-4a73-b7fa-1393bbf26e24	t	Ubusabane	2db3cb56-5681-4df6-8938-2d2a0b970b06
4040bf7b-9c40-4c9a-98f4-15dbe64e3f45	t	Abatarushwa	e650c442-8a90-4d33-853d-a2ada1c2d682
8d566029-4727-49a7-af50-18c2a0a1df9b	t	Indatwa	e650c442-8a90-4d33-853d-a2ada1c2d682
310e1804-3978-4024-b8c7-90835ea5a459	t	Inkerakubanza	e650c442-8a90-4d33-853d-a2ada1c2d682
becf5fc3-e7b3-400a-beb4-d10306a11cde	t	Intwari	e650c442-8a90-4d33-853d-a2ada1c2d682
342ba357-bda6-46ce-8c17-4acfda686aad	t	Amahoro	42d82f52-683f-4fae-8d8c-bdd18e5c0389
dbee2c51-8803-4115-8bb7-62a866003968	t	Umucyo	42d82f52-683f-4fae-8d8c-bdd18e5c0389
d2fa63a6-98f0-460f-8d83-7e1db4496ec3	t	Urumuri	42d82f52-683f-4fae-8d8c-bdd18e5c0389
88480f6e-275f-4714-a2b8-3e0d06d88c96	t	Katiro	2430cb83-ebad-44f6-ae2c-8e97ff9f00ea
ebeed4d7-53a8-4d84-ba90-d5e3c14d9e5b	t	Kinyana	2430cb83-ebad-44f6-ae2c-8e97ff9f00ea
adb5c460-5f59-49ee-93a9-b61560c657d8	t	Murambi	2430cb83-ebad-44f6-ae2c-8e97ff9f00ea
64e3653a-f3e6-497b-9ec6-5ec77ed65653	t	Sanzu	2430cb83-ebad-44f6-ae2c-8e97ff9f00ea
903ce1bd-91ee-4422-b2cb-338af065844f	t	Karehe	bb83c731-3a50-4792-bf8a-0050bd820aad
fbf478dd-0b2e-4642-ab42-677d2ab0a201	t	Mugusa	bb83c731-3a50-4792-bf8a-0050bd820aad
bdc251af-59ac-4dd6-94a7-1d0d89090b3d	t	Remera	bb83c731-3a50-4792-bf8a-0050bd820aad
fe8cb002-e8a6-4020-a619-6fb573415289	t	Rugarama	33679b9c-4172-487c-a256-72264e62eb1b
b08379ea-dc49-4c19-80aa-1ed860054b33	t	Runyinya	33679b9c-4172-487c-a256-72264e62eb1b
2bb0ed6d-9a62-48a0-8671-bff53630e1db	t	Bukorota	d14d3324-07c9-49ca-90b3-803f4b945ae3
78c2dbf5-a248-4269-93fd-7a198179ccdd	t	Kirivuga	d14d3324-07c9-49ca-90b3-803f4b945ae3
01efad85-1667-4ca3-bdfb-15ca561bddbd	t	Mbogo	d14d3324-07c9-49ca-90b3-803f4b945ae3
248e6b6f-e019-4827-a837-33b89beab358	t	Nyakabuye	d14d3324-07c9-49ca-90b3-803f4b945ae3
7f14c241-fa70-441c-a2ff-292fbc2d714d	t	Nyiramageni	d14d3324-07c9-49ca-90b3-803f4b945ae3
d83cc3da-d62d-4da8-8e11-3b8968352dda	t	Rwintare	d14d3324-07c9-49ca-90b3-803f4b945ae3
7331bf87-8539-4ef0-b3f4-d658087e63ea	t	Busave	4ff7ee6e-2184-481f-ad45-77ba83c1f351
b2c7d23c-f2f1-4ea8-8af3-6f65826743be	t	Kigozi	4ff7ee6e-2184-481f-ad45-77ba83c1f351
0fd4e028-ff30-4ccd-9b42-067d996e2ac5	t	Kivugiza	4ff7ee6e-2184-481f-ad45-77ba83c1f351
44aa8b2c-65e3-4401-8a86-e1733c77fb5b	t	Nyundo	4ff7ee6e-2184-481f-ad45-77ba83c1f351
e753e1f7-f167-4292-8b7c-b75a6469db30	t	Kurutare	4ff7ee6e-2184-481f-ad45-77ba83c1f351
c91deb7b-c2ec-4942-be3f-3820572b4d38	t	Hemba	7d99a7ff-9591-4f13-9567-1c41fc494785
9f699d66-1f5a-472d-8681-d6a8b305966d	t	Kanombe	7d99a7ff-9591-4f13-9567-1c41fc494785
6654c024-834f-41f9-84c1-a2481490d243	t	Mwiba	7d99a7ff-9591-4f13-9567-1c41fc494785
6cedee3a-d68d-4d22-b603-62f57940fda7	t	Rwinkwavu	7d99a7ff-9591-4f13-9567-1c41fc494785
5d388b33-ce7e-4539-9e40-dc08a8a89035	t	Gicaca	54d7f36f-8839-47aa-965b-9ab92e7454e6
66f209fa-c4af-4a8b-8152-a25c3cc305bd	t	Munyinya	54d7f36f-8839-47aa-965b-9ab92e7454e6
8275782f-5fd0-45ae-9f1a-43ed597598a1	t	Nkunamo	54d7f36f-8839-47aa-965b-9ab92e7454e6
5d62625c-4f98-4a43-a73c-081b258fbe9a	t	Nyakibungo	54d7f36f-8839-47aa-965b-9ab92e7454e6
e8716c3d-67ac-4229-bc65-bca36871a712	t	Rebero	54d7f36f-8839-47aa-965b-9ab92e7454e6
5d91c307-b301-43c7-9d00-f28854db4035	t	Rusasa	54d7f36f-8839-47aa-965b-9ab92e7454e6
97c9a008-f350-4270-94be-df222f8dc180	t	Gikuyo	c88af425-c76d-461e-906c-4e5616ea1e58
b1d23215-72aa-4d06-a515-945172386d7d	t	Gishya	c88af425-c76d-461e-906c-4e5616ea1e58
70a020cd-d71d-423c-99a9-2ac77fd15fdc	t	Kagoma	c88af425-c76d-461e-906c-4e5616ea1e58
c458f308-9163-423e-aaa7-42225846298b	t	Kavumu	c88af425-c76d-461e-906c-4e5616ea1e58
d3ac5f59-14c4-427b-aad7-251b90d50089	t	Muyinza	c88af425-c76d-461e-906c-4e5616ea1e58
455342a5-457f-42f6-8b7f-0d45676d1b99	t	Rebero	c88af425-c76d-461e-906c-4e5616ea1e58
5cd18a2a-1db8-4573-bc2a-a5a74b8af279	t	Rugogwe	c88af425-c76d-461e-906c-4e5616ea1e58
16ca6cc1-f558-4f8f-9057-0fcac3df7593	t	Agacyamu	e6f0e394-9d08-40a2-8a08-fa41863b854a
0c69bc7d-2673-41c1-a3e1-06de827da785	t	Akabuga	e6f0e394-9d08-40a2-8a08-fa41863b854a
69178ec3-fcd3-4de6-8a11-a800af40d8a3	t	Gatare	e6f0e394-9d08-40a2-8a08-fa41863b854a
3b33dc81-f535-4663-a91b-4fb3afb58524	t	Impinga	e6f0e394-9d08-40a2-8a08-fa41863b854a
34b8df97-9e11-43ac-a9da-849b0ae5e90a	t	Nyaruhengeri	219f07f2-c437-4265-a703-d2bfd980a7f8
5f965056-47ba-45cb-8270-c05281bbf903	t	Akayenzi	dab3a1b5-f8d4-41fc-b0ad-276c81cb1d8f
2f4eb839-76ac-4e40-8cc7-e6b8e723f093	t	Nyarunazi	dab3a1b5-f8d4-41fc-b0ad-276c81cb1d8f
1e501bd0-20d8-44b3-ba2b-697bf7c2ff04	t	Buhoro	e5e8b296-8af5-47e1-865f-f9259e821f1a
5ac372c9-4f5f-4fbc-98be-e419b1a96db7	t	Burashi	e5e8b296-8af5-47e1-865f-f9259e821f1a
3a69d0bf-5691-421f-b808-8ea384ffd1e2	t	Duwani	e5e8b296-8af5-47e1-865f-f9259e821f1a
dde32f07-9159-45f3-92d1-eaf87bb7b9a7	t	Karambo	e5e8b296-8af5-47e1-865f-f9259e821f1a
2f48aa5d-66a2-4f93-8186-433aaa3e1558	t	Kivumu	e5e8b296-8af5-47e1-865f-f9259e821f1a
a5982414-1cf3-4c21-8060-600f6ea58db7	t	Mbeho	54000954-8f1c-470f-bd8a-79dc75bdae15
9190faf0-9cc0-4180-bac3-be5e2c2eca26	t	Torero	54000954-8f1c-470f-bd8a-79dc75bdae15
12e5ff29-555f-49db-90d4-829158eeb2e6	t	Agasharu	39226421-cdd2-4db3-b92c-a3d90af9a2d0
4a1fcf44-39fe-48a4-a227-67471f4ca37f	t	Akagarama	39226421-cdd2-4db3-b92c-a3d90af9a2d0
d2414215-0fbc-467b-a808-0347eaca3a7a	t	Akirasaniro	39226421-cdd2-4db3-b92c-a3d90af9a2d0
ea584425-9162-47a2-b43b-ea9da45a46dd	t	Impinga	39226421-cdd2-4db3-b92c-a3d90af9a2d0
68d36d39-a71b-4daa-901b-487ae2e6cb5b	t	Nyagisasa	39226421-cdd2-4db3-b92c-a3d90af9a2d0
3df7cfdb-0d6b-4024-997d-bccc3308cec0	t	Itaba	39226421-cdd2-4db3-b92c-a3d90af9a2d0
c788eb12-7dc3-4a8a-8ffe-59cd4371b72e	t	Zihare	39226421-cdd2-4db3-b92c-a3d90af9a2d0
9353f17a-bcc2-4817-9741-b9459ad1af49	t	Agatongati	bea039ff-4d67-4723-bad4-30b83f1abcc6
e1518205-ad9e-411a-8925-4633ec3bd71e	t	Akabuhuzu	bea039ff-4d67-4723-bad4-30b83f1abcc6
5a33c94b-1d34-49a2-9b45-8344a0d507f8	t	Impinga	bea039ff-4d67-4723-bad4-30b83f1abcc6
c6d03370-ca50-4934-a668-f41d22360112	t	Karengera	bea039ff-4d67-4723-bad4-30b83f1abcc6
ba4ceae2-99ec-43ce-b798-d58d6358e6fa	t	Kigarama	bea039ff-4d67-4723-bad4-30b83f1abcc6
b28e0aad-b56f-4f15-9f43-647a41f12699	t	Ruhuha	0775ee9d-8e5c-4b56-a87b-74a5efb00ce4
2c3f57b6-3b49-45c6-b0ec-315eec73d451	t	Agatare	d416a3b0-824b-48ab-8e1b-515d7996fbd3
12bb6e7b-137e-4c24-b35d-64ffd47d7869	t	Taba	d416a3b0-824b-48ab-8e1b-515d7996fbd3
ea42e57f-f793-4791-a3c3-523efbed5c41	t	Akakijugujug	342a2b36-9f05-4b87-8b89-2b4a1e827422
9c38e532-e22e-4bf4-b016-1e7933140b20	t	Akabahizi	54c4e7c6-8cdf-4845-989b-27c457865d51
2cd6f752-0d99-4cc2-ae6a-15c07288f76e	t	Akimbaka	54c4e7c6-8cdf-4845-989b-27c457865d51
38665ce2-24fe-4610-b210-0d88c1c0956a	t	Rutaza	54c4e7c6-8cdf-4845-989b-27c457865d51
d23ed48f-4450-4c66-92a8-89ac9b60f64e	t	Ruyenzi	54c4e7c6-8cdf-4845-989b-27c457865d51
78cb9e94-8ce0-40b2-bd62-28bb5eae19b4	t	Akadogo	614a5c90-a00e-4040-9935-898cc0cc1a69
fdc9f54e-05a0-4d0f-bf66-bcbbf5a1190b	t	Nyakabuye	614a5c90-a00e-4040-9935-898cc0cc1a69
640601a1-38d3-4156-a77e-d9bded323208	t	Agasharu	c37c9dad-c446-4027-b6fc-a0e165f842aa
c4ec2855-c1d8-41b5-b45d-24d54b3b775e	t	Akatera	c37c9dad-c446-4027-b6fc-a0e165f842aa
5893295f-0e19-403c-b47f-11ba9440de2d	t	Gakomeye	16af960d-aab6-4757-9bef-488b790ae7b7
63d000d8-1345-41e9-ab4e-735484db0d2f	t	Rugwiza	16af960d-aab6-4757-9bef-488b790ae7b7
2878ba30-87f0-44ef-bd03-c15cd26b909a	t	Ruhuha	16af960d-aab6-4757-9bef-488b790ae7b7
dd382adb-0e04-415d-a03c-46bfc0b6c3c0	t	Sokofi	16af960d-aab6-4757-9bef-488b790ae7b7
f5360f89-5397-4470-a2f6-51799bf68e47	t	Buye	adb767b3-e5b7-42a6-ad8f-f97bbfb37934
8f46afff-f535-4c16-b650-6353ce8d8bcb	t	Kabuga	adb767b3-e5b7-42a6-ad8f-f97bbfb37934
c1ff7d99-f852-49c2-b90b-1e069424083b	t	Kirwa	adb767b3-e5b7-42a6-ad8f-f97bbfb37934
25c2df4f-8622-47b7-82fe-b8978b88eb87	t	Munopfu	adb767b3-e5b7-42a6-ad8f-f97bbfb37934
4ff2b56a-dce9-4bc7-abab-280e626eb5a6	t	Buhima	5988a320-4321-4c6f-967a-32e05d2718a8
0484d286-71a6-4b2a-9d92-cd0fe64d9398	t	Gakoma	5988a320-4321-4c6f-967a-32e05d2718a8
d168442a-c52c-40c2-afa0-f8bc81268ab5	t	Gatovu	5988a320-4321-4c6f-967a-32e05d2718a8
5a3ace0c-e281-4766-bf52-573b58341c53	t	Kirase	5988a320-4321-4c6f-967a-32e05d2718a8
0572e7d0-f748-4a66-9265-9ec6fc84facf	t	Nyarugenge	5988a320-4321-4c6f-967a-32e05d2718a8
fe25359e-3eb7-49af-b07a-113f1b986c7a	t	Rugunga	5988a320-4321-4c6f-967a-32e05d2718a8
754c8229-7010-4712-b993-1844ab2e685a	t	Kibumba	59a29314-53ba-4f12-bc2f-8ba4e02821da
f3ea1f4a-bcf3-4edc-a115-dbff3a9ec999	t	Mutori	59a29314-53ba-4f12-bc2f-8ba4e02821da
038f76c1-47a8-4eb7-a933-4f4f73b38275	t	Ruhamagariro	59a29314-53ba-4f12-bc2f-8ba4e02821da
6413de26-c646-42a4-a33a-97ecc082ba21	t	Murambi	b83e14d5-0c4a-439a-adba-3db8988dbd2e
8a41b130-3e41-48b6-8dc6-270511bff4c1	t	Nyiramageni	b83e14d5-0c4a-439a-adba-3db8988dbd2e
f65f09b5-0f2f-40a9-9692-9fe299f14929	t	Runazi	b83e14d5-0c4a-439a-adba-3db8988dbd2e
cbddd340-b981-4301-bd8a-0746d6cd4eb4	t	Musatsi	2f0b4293-20b5-4425-8382-66c24fcf3a18
fec5603b-a14a-4094-b28e-6a552b3ef51b	t	Nyiraburiba	2f0b4293-20b5-4425-8382-66c24fcf3a18
743a4d06-2287-48f8-8c6a-de252f9adcd6	t	Rugantete	2f0b4293-20b5-4425-8382-66c24fcf3a18
bb27d052-0509-4eb9-829f-0f7aa218257b	t	Rwimisambi	2f0b4293-20b5-4425-8382-66c24fcf3a18
61f316f8-1353-4c4a-8b2f-0713913d803c	t	Agasharu	60ea014a-c44b-4d20-a202-dca9d3b61dbe
46d0f573-a712-4794-aabf-c205c1458633	t	Agatongati	60ea014a-c44b-4d20-a202-dca9d3b61dbe
f30cbd0a-3c9c-4f89-bf07-af831b8081e3	t	Gitisi	60ea014a-c44b-4d20-a202-dca9d3b61dbe
c944d340-3db8-47b1-954c-77204e762d51	t	Ubusenyi	60ea014a-c44b-4d20-a202-dca9d3b61dbe
76ff0cb9-c53b-48ee-a77e-a99888d5065c	t	Urusaro	60ea014a-c44b-4d20-a202-dca9d3b61dbe
f7f9972e-9f95-4869-acad-06a50295b281	t	Butare	0d9c0168-060c-4c68-a83d-02a89b4daf1a
0ac46d48-09f6-4617-9120-c4d758e2480c	t	Akajyanama	0d9c0168-060c-4c68-a83d-02a89b4daf1a
dd741658-4348-4093-8e05-0bf70989f4a6	t	Taba	0d9c0168-060c-4c68-a83d-02a89b4daf1a
6cbd5024-ef76-47d9-8de1-efa3ec8937de	t	Agatovu	b10b0e33-5b80-48f6-b058-ee6ec10acc83
89fa45e3-53a1-4b51-89aa-72491d9f6406	t	Ubuseruka	b10b0e33-5b80-48f6-b058-ee6ec10acc83
594f40dd-943c-495e-b760-e7480c81ba3c	t	Impinga	b10b0e33-5b80-48f6-b058-ee6ec10acc83
d31304e9-e5ea-42f3-b766-f95e0919bdba	t	Kidaturwa	b10b0e33-5b80-48f6-b058-ee6ec10acc83
0f8f1000-bec9-49f6-908a-aa12cb96e1a2	t	Kiyogoro	b10b0e33-5b80-48f6-b058-ee6ec10acc83
75aadc1b-1aa6-4440-b1e2-cc9f1252cccb	t	Nyagatovu	b10b0e33-5b80-48f6-b058-ee6ec10acc83
120744e7-0805-4a5b-b9d0-254828d953e2	t	Ryarumenang	b10b0e33-5b80-48f6-b058-ee6ec10acc83
31dd6408-dbd5-4cfe-989d-29d8e9249f83	t	Akabacuzi	55117b1b-b6ac-485c-be03-3373a1d97f04
1fcc002d-7a43-4759-a1e9-cb16ff42e3b1	t	Bucaya	55117b1b-b6ac-485c-be03-3373a1d97f04
5034841e-5a04-41fd-b04a-82b530ad6145	t	Buhiza	55117b1b-b6ac-485c-be03-3373a1d97f04
f9de6796-fbf0-4cf8-8be2-1d79e44d3952	t	Duwane	55117b1b-b6ac-485c-be03-3373a1d97f04
780255e6-4114-42b9-a6f8-3d567a79dfe7	t	Impinga	55117b1b-b6ac-485c-be03-3373a1d97f04
285d98c3-ab2f-4f1f-86c7-65b5b487da90	t	Isangano	55117b1b-b6ac-485c-be03-3373a1d97f04
1aea8c6e-4bb3-4ed4-908a-e24663e62314	t	Kanto II	55117b1b-b6ac-485c-be03-3373a1d97f04
2c31c9c3-99b9-4dbc-8428-030b427021e2	t	Nyabigugu	55117b1b-b6ac-485c-be03-3373a1d97f04
dbda8348-01f8-4a19-ae51-ee668ce85954	t	Nyagafumber	55117b1b-b6ac-485c-be03-3373a1d97f04
9a12e55d-5f1d-480b-93e4-ed7b7e44e6e6	t	Nyamiheto  II	55117b1b-b6ac-485c-be03-3373a1d97f04
947cdbcc-eccf-452b-a386-82a384bb5ce0	t	Rwinkuba	55117b1b-b6ac-485c-be03-3373a1d97f04
4839495f-d23b-4ddb-a786-bb3ede9d0b3a	t	Nyabinyenga	0362ffce-7a6e-4578-980c-2425c30a1576
50ef2bb8-56ef-49d7-8dd6-25ca1055584f	t	Nyagatovu	0362ffce-7a6e-4578-980c-2425c30a1576
caddf2ba-5733-462a-9c6d-0745cf596c3b	t	Nyesumo	0362ffce-7a6e-4578-980c-2425c30a1576
93ffb555-2cba-444b-b717-cc39f5dd8d11	t	Akashyamba	6d661922-3d8f-489f-97b9-1c573eb14bbe
8314a979-2db9-4543-bfbe-10aac3795364	t	Rwahambi	6d661922-3d8f-489f-97b9-1c573eb14bbe
600300ae-b6af-4879-96b2-e1330fede42b	t	Akabugabo	bf63e9e9-1d5b-457e-a661-a9344a6154dd
7e781f17-4ad9-4a8f-b6d5-a5b50d7a5acf	t	Mushongi	bf63e9e9-1d5b-457e-a661-a9344a6154dd
53021d34-3635-4e1b-841f-97c438524f29	t	Rurenge	bf63e9e9-1d5b-457e-a661-a9344a6154dd
86eb1538-493c-413c-b1b6-13b8971e80a7	t	Impinga	9dbb0c47-5fec-4325-bc27-c160914f343b
4d48a008-b9d8-45f5-a9ac-285a0295acb4	t	Migina	9dbb0c47-5fec-4325-bc27-c160914f343b
37d3774f-6109-4ee7-ab66-aa42362d3980	t	Akanyamiram	938e7bd6-2b9d-4ec1-8bf4-d2183c0225b8
a861cc96-0d60-453f-aeae-8d0c1cc124a6	t	Akarangabo	938e7bd6-2b9d-4ec1-8bf4-d2183c0225b8
ad33f15a-28a8-4b85-9338-1f866337e8e3	t	Gitarama	938e7bd6-2b9d-4ec1-8bf4-d2183c0225b8
e5a1044b-e938-4381-9865-34c1b0eecf0d	t	Nyarusange	938e7bd6-2b9d-4ec1-8bf4-d2183c0225b8
afc28c8d-81fe-48ba-ac6b-564e6b98d62a	t	Umukungu	938e7bd6-2b9d-4ec1-8bf4-d2183c0225b8
f30c1edc-2ace-470b-b865-72630dba6aa3	t	Gatunda	dfedea52-4c26-4c06-b6cc-8e6e8605a79e
0e33d2a3-6376-49a7-a608-794cbbf165f0	t	Nyabikoni	dfedea52-4c26-4c06-b6cc-8e6e8605a79e
8e914ead-27e2-43a6-8918-605f97e839f9	t	Nyamabuye	dfedea52-4c26-4c06-b6cc-8e6e8605a79e
2501e369-32c5-4783-b432-606260274aef	t	Bukamba	e0e2695a-5380-4dab-8c79-5e0dd4bd35a3
a1430e56-b039-4c14-819b-8a5b0961673c	t	Gitwa	e0e2695a-5380-4dab-8c79-5e0dd4bd35a3
e3ee7cbe-5e8c-41e4-88b0-111375d977fd	t	Mukiza	e0e2695a-5380-4dab-8c79-5e0dd4bd35a3
86f4b02f-bc9a-40be-a720-745abf201032	t	Agatare	5b0d0286-4abc-4ea7-bff6-2719ee991c51
8e4f7021-12a9-410d-a6d2-a0248a00d07e	t	Kabuga	5b0d0286-4abc-4ea7-bff6-2719ee991c51
ce3df4b1-dbae-49e4-ae59-422c56372f3c	t	Akanage	5b0d0286-4abc-4ea7-bff6-2719ee991c51
c5f59296-a448-417d-becb-6fc07dc4dfcf	t	Kamasiga	5b0d0286-4abc-4ea7-bff6-2719ee991c51
982b11f3-e706-4dc2-95fc-ba59471328ae	t	Makwaza	5b0d0286-4abc-4ea7-bff6-2719ee991c51
6d585f68-9bd2-451b-b3b4-6ce403b36e78	t	Mihigo	5b0d0286-4abc-4ea7-bff6-2719ee991c51
b24859e8-3fbd-4677-abdf-0e75f7c8fc98	t	Mutondo	5b0d0286-4abc-4ea7-bff6-2719ee991c51
643c82fa-55c4-4abd-9993-e3f7464ac825	t	Nkurubuye	5b0d0286-4abc-4ea7-bff6-2719ee991c51
4a98c0e0-28d4-40a0-bd23-3a011692e791	t	Agakomeye	6010cbb4-eeac-4636-ab83-7fc0ceaa548b
3c18834d-6b0f-4b7e-81af-681d759cec98	t	Agasharu	6010cbb4-eeac-4636-ab83-7fc0ceaa548b
18fd18ff-a493-4946-89c9-447d06349de9	t	Akamaranga	6010cbb4-eeac-4636-ab83-7fc0ceaa548b
091a1993-9ad7-4db9-aee3-a5d08b42b5c0	t	Akarugina	6010cbb4-eeac-4636-ab83-7fc0ceaa548b
359333f4-a4b4-40e3-91de-0cbaeef8640b	t	Impinga	6010cbb4-eeac-4636-ab83-7fc0ceaa548b
9b1534e6-ce03-4067-a6fd-9f2121e1d645	t	Mpungwe	6010cbb4-eeac-4636-ab83-7fc0ceaa548b
7807ecc0-4319-429e-9c95-4fb9fa17132d	t	Nyiranguri	6010cbb4-eeac-4636-ab83-7fc0ceaa548b
824cd220-3d6b-4315-95b2-d22b6d85a2e9	t	Akagarama	4667107a-58ed-4fbe-98d2-e60d04a74b51
36695b12-e2fa-46b7-889b-d9efd16bde6a	t	Bukinanyana	4667107a-58ed-4fbe-98d2-e60d04a74b51
422b1d43-0dd1-4e43-bbc1-0c49e1a860f0	t	Kigoma	4667107a-58ed-4fbe-98d2-e60d04a74b51
cd7e26d1-327e-4dc9-a6c9-d91b6739c06f	t	Munyegera	4667107a-58ed-4fbe-98d2-e60d04a74b51
9681ce9a-154b-4166-b1d3-a864e3945652	t	Gasura	83c85f59-069d-43be-b6a1-2e386ac671d8
7d216e25-dc84-49d0-bc05-5093eb8bcaf1	t	Gitega	83c85f59-069d-43be-b6a1-2e386ac671d8
8da3e77b-5f40-4fa0-939d-0d2a49020298	t	Kagunda	83c85f59-069d-43be-b6a1-2e386ac671d8
2c6694df-ada4-492b-92ac-8233dc099bb2	t	Kigarama	997c7fe5-aa07-4fb0-99c8-78242731ddb2
a748467d-c04b-4829-9f63-f9332519db85	t	Murama	997c7fe5-aa07-4fb0-99c8-78242731ddb2
2c789219-e689-429a-a834-8c2e490624d4	t	Akabanga	9b5e551d-fc4b-49eb-bcac-6ac55858ea00
9c9fcbdd-930b-48c4-9542-31f365d0457b	t	Kamabuye	9b5e551d-fc4b-49eb-bcac-6ac55858ea00
271743da-e64f-434f-9c13-3b5031d93a29	t	Akiminazi	de6fd126-fe8d-4e79-8337-553eb1bb5df5
fe909b53-c58e-4ff0-bf3c-095948ef27a8	t	Gatobotobo	de6fd126-fe8d-4e79-8337-553eb1bb5df5
99d5c8b8-36db-4d80-a11f-227a0d5384b9	t	Giseke	7d67fc0c-756d-4687-bbce-c8770ff454c1
89f83364-2aa6-47ae-b8da-1f0269f35288	t	Ryabiyaga	7d67fc0c-756d-4687-bbce-c8770ff454c1
ab64aac3-6d10-46ee-b4f0-6959e95a879a	t	Urusenyi	7d67fc0c-756d-4687-bbce-c8770ff454c1
48441774-80f8-45d6-bba9-f2f0fed72c81	t	Gitwa	0ed33221-2f3b-4743-bc0f-07e57f2b156c
5b702631-e239-401f-8eb8-41af6391ff9f	t	Ndatemwa	0ed33221-2f3b-4743-bc0f-07e57f2b156c
5a175abb-4cd7-4fbc-b9e7-fb2ae53587c7	t	Gisagara	91c7f8a7-ea16-4303-b790-4522b331f516
e0821309-4d07-41c8-8213-cff3d16a1368	t	Kabuga	91c7f8a7-ea16-4303-b790-4522b331f516
c3bfb70e-4491-42ce-9041-9949c7a268bb	t	Kabuye	91c7f8a7-ea16-4303-b790-4522b331f516
7cdc2a3d-6262-4d17-b245-135865edac5f	t	Ndora	91c7f8a7-ea16-4303-b790-4522b331f516
a22062b8-71b6-4efb-9071-5ee4c841185f	t	Nyarunazi	91c7f8a7-ea16-4303-b790-4522b331f516
874f8fd0-5b60-49d3-978d-b127f397796b	t	Rutonde	91c7f8a7-ea16-4303-b790-4522b331f516
6f7145e7-db55-4f66-bbf3-9952c299d4ab	t	Nkinda II	d1b12fa3-f762-4639-a81e-4bf4aa3ea97d
ef437a1f-ee49-46dc-8ec4-8f752e583a6b	t	Nyarunyinya	d1b12fa3-f762-4639-a81e-4bf4aa3ea97d
266362c1-f2b1-49b5-898f-6d989a1eaf49	t	Amashya	f67af2d5-2f8d-48a2-9eb6-17625877562d
48cf1c94-d22d-4f97-b676-033c66433a41	t	Ruvugizo	f67af2d5-2f8d-48a2-9eb6-17625877562d
3388bcd2-a04f-42ea-89ee-dc702b3b1e75	t	Rwamiko	66ee91c3-9f8f-4ef8-8693-82c5969178d4
d311e658-b29b-4e75-a5af-23a48a9e2519	t	Urutoyi	66ee91c3-9f8f-4ef8-8693-82c5969178d4
85a92e4a-cb03-44fb-b3a6-c2fe16163a22	t	Marambya	a8ff98dd-ad24-4c4e-927e-54dfbb27bf86
e8590198-d977-4b36-8fc4-69a39b57692c	t	Gisunzu	a8ff98dd-ad24-4c4e-927e-54dfbb27bf86
081f6788-9599-4217-a5ea-b9e8bad9466a	t	Impinga I	a8ff98dd-ad24-4c4e-927e-54dfbb27bf86
dd16ac0b-a6ae-496c-94ae-0f5cd004ac7c	t	Intuntu	a8ff98dd-ad24-4c4e-927e-54dfbb27bf86
c214bae9-f072-4926-a953-d7e0628af002	t	Rugayantete	a8ff98dd-ad24-4c4e-927e-54dfbb27bf86
1e9c55fc-0fe9-4c25-8745-27368c7345b9	t	Akinyana	ed5b522b-502a-43e5-b32b-54923e0cb156
b9b55d30-fc99-41fc-b4ab-222348ca3803	t	Maheresho	ed5b522b-502a-43e5-b32b-54923e0cb156
aaddb06c-bf47-42f1-b6d6-ecd041f1e255	t	Remera	ed5b522b-502a-43e5-b32b-54923e0cb156
dee1bf8c-c0a9-429b-b5da-809c58ad97c8	t	Gasambu	12cc6a20-a0c8-4eae-aa44-1d4c36b56775
ad79e459-505e-486b-867f-bd34edcbd97a	t	Gashubi	12cc6a20-a0c8-4eae-aa44-1d4c36b56775
a8f76fb1-1076-410e-814b-1944ac74faae	t	Kampuro	12cc6a20-a0c8-4eae-aa44-1d4c36b56775
07402216-d8ee-4d3d-af7c-631dba3a0d10	t	Kaneke	12cc6a20-a0c8-4eae-aa44-1d4c36b56775
914ae977-6198-4d32-a241-672eb2caf482	t	Kavumu	12cc6a20-a0c8-4eae-aa44-1d4c36b56775
69defcec-0a94-4969-9e9d-471516cdaba7	t	Nyarigina	12cc6a20-a0c8-4eae-aa44-1d4c36b56775
b7ee29f3-18d3-4144-a4bd-675f775f47c8	t	Rugarama	12cc6a20-a0c8-4eae-aa44-1d4c36b56775
07d94c3e-c4de-435c-bae9-41561cca0ee2	t	Kadurumba	fb0da952-1dce-4ce7-9dcc-64b356c4a21f
492d98ad-9f63-47c4-8819-12abb03cba5d	t	Gitwa	fb0da952-1dce-4ce7-9dcc-64b356c4a21f
5f03c335-c62d-46e5-9f6d-f3202cde4b58	t	Kabitoki	fb0da952-1dce-4ce7-9dcc-64b356c4a21f
b86c996b-3c8d-4667-b244-1b28c0b471d5	t	Kigwa	fb0da952-1dce-4ce7-9dcc-64b356c4a21f
d6731f62-0c2c-4e15-92f4-693376a21739	t	Akarambo	95e99b83-53ac-44be-8597-e03a61f33c74
24f28730-39da-4d47-87ab-b704fadc913f	t	Bazenga	95e99b83-53ac-44be-8597-e03a61f33c74
8284a123-9d70-4ef3-913f-62b2cdb51c7e	t	Bitabire	95e99b83-53ac-44be-8597-e03a61f33c74
76c54f14-6c23-4daf-aee9-dd494ed89e82	t	Kamudahunga	95e99b83-53ac-44be-8597-e03a61f33c74
4e096647-dfad-4ef5-9c94-9ed365c150ac	t	Kivumu	95e99b83-53ac-44be-8597-e03a61f33c74
8df7afaf-47f9-4197-ad2b-6bd20e8696c4	t	Ryamaguri	95e99b83-53ac-44be-8597-e03a61f33c74
1011fabe-4dd2-4795-83e8-46067c1a3aa5	t	Gahora	6737e4d4-764d-4eb8-a8e1-c8ce3a83f7f3
ced9c427-cbb7-4c6a-9ef2-d610e03fb0ff	t	Kagende	6737e4d4-764d-4eb8-a8e1-c8ce3a83f7f3
cae430b8-df63-4551-b6cb-0c4ba6ca5bdb	t	Kirira	6737e4d4-764d-4eb8-a8e1-c8ce3a83f7f3
dfcb1fef-966d-4dc2-8317-e4832920cb7f	t	Mpinga	6737e4d4-764d-4eb8-a8e1-c8ce3a83f7f3
73a803e3-df1c-41c7-811a-dbc98659ca2a	t	Rugori	6737e4d4-764d-4eb8-a8e1-c8ce3a83f7f3
1aa25aaf-561e-4a62-b146-536f8022804a	t	Taba	6737e4d4-764d-4eb8-a8e1-c8ce3a83f7f3
05d5a149-5d43-4192-ae01-66727fa20b5d	t	Musekera	206fcb8e-4756-484d-b9f5-d63e1d01e3b8
3d7b8cec-0e81-4013-b01c-4443deb789e0	t	Nyagasozi	206fcb8e-4756-484d-b9f5-d63e1d01e3b8
ba9ae075-352a-428e-96a0-72e5baa7d2b6	t	Rugogwe	206fcb8e-4756-484d-b9f5-d63e1d01e3b8
96787d6f-3f43-4020-9d6e-846a1d5244fe	t	Rwanzana	206fcb8e-4756-484d-b9f5-d63e1d01e3b8
93f5d226-3025-43d0-9281-cc30d2f0ff2a	t	Byimana	8e5e8ab0-2c05-4405-b076-2e8cbafee808
4eda7ff3-a6f3-4335-915a-5914e575f33c	t	Kamabuye	8e5e8ab0-2c05-4405-b076-2e8cbafee808
41313313-9f33-4f92-b726-4f88ace02d48	t	Gasyankingi	5d68a628-908b-4698-87c7-59f0a4f2c2b5
75d9515f-2637-4161-ad46-32ee370cbb3c	t	Gitwa	e6e8ae56-cb90-452d-bf09-3a904b920067
bfff9522-cc4d-42fa-93c3-2be28e587471	t	Kiduha	e6e8ae56-cb90-452d-bf09-3a904b920067
2b983143-1fd5-495f-afcd-6d6c6a8f6f0e	t	Kabeza	1611f9c5-9ebd-4f2e-9a9f-f134954f0c9e
9b76f03d-0da1-411f-a026-c99e69813ab3	t	Rusasa	1611f9c5-9ebd-4f2e-9a9f-f134954f0c9e
000d31db-652d-42fd-a867-c049aba74a96	t	Agacyamu	687d684c-7033-4a22-81d0-898db4968d38
fcbe8605-5e79-47b5-b861-fbf4065fefc8	t	Akaruzi	687d684c-7033-4a22-81d0-898db4968d38
d7ece827-0ab8-4fed-bd87-393c98348f77	t	Kigarama	687d684c-7033-4a22-81d0-898db4968d38
fa76e5c2-0be8-4cb8-b206-57cb6a7bf836	t	Nkamatira	687d684c-7033-4a22-81d0-898db4968d38
6317acad-1646-4f94-b39b-1c98e16f930c	t	Rwaza	687d684c-7033-4a22-81d0-898db4968d38
7007325a-311f-4ae3-a29a-fe7ef833ca73	t	Shuni	687d684c-7033-4a22-81d0-898db4968d38
dbcf0cb1-4e47-4937-aa87-88ced805f0c8	t	Kamutima	207bd739-7c5d-45ee-9381-ad12ca5bacdc
7bc59cbc-dbfb-4de7-b451-78c4ee85b2dd	t	Agacyamu	910dc1fb-85d8-4696-b1d1-9a53ff4a1efe
524366e9-72fe-4615-8ff8-1661a3ae80eb	t	Agahenerezo	910dc1fb-85d8-4696-b1d1-9a53ff4a1efe
bc6281c1-7113-41c3-99d8-2fb7cd869e46	t	Agasharu	910dc1fb-85d8-4696-b1d1-9a53ff4a1efe
0e695f3a-cffe-4101-af3c-c6311831ace6	t	Gitwa	910dc1fb-85d8-4696-b1d1-9a53ff4a1efe
febd77ac-3943-41ef-93f0-0872e0d0e3ed	t	Kanazi	910dc1fb-85d8-4696-b1d1-9a53ff4a1efe
a8e72643-f69c-4874-8287-06b3046150b7	t	Kaseramba	910dc1fb-85d8-4696-b1d1-9a53ff4a1efe
c0656091-0b04-49a9-8bc4-1b1cb4a30306	t	Kubutare	910dc1fb-85d8-4696-b1d1-9a53ff4a1efe
2727f6e4-10b7-4c2c-8a4d-775b8ddd68fe	t	Magonde	910dc1fb-85d8-4696-b1d1-9a53ff4a1efe
eeedd58f-c36e-46dc-af49-776ab49a61ee	t	Nyagasambu	910dc1fb-85d8-4696-b1d1-9a53ff4a1efe
2f9cc956-51bb-49f3-9af6-cc0c84acc4da	t	Nyanza	910dc1fb-85d8-4696-b1d1-9a53ff4a1efe
ba933684-0c5a-47ea-a349-b5b868ecc63e	t	Sabaderi	910dc1fb-85d8-4696-b1d1-9a53ff4a1efe
9646ba82-3105-46f2-93f7-0bbb728de7ed	t	Gako	e09d7748-edcc-4f94-9893-80cbe6159874
d99fc205-c978-4957-8429-b78a8f271dbe	t	Gasongati	e09d7748-edcc-4f94-9893-80cbe6159874
6d3374df-852a-4f36-aa97-ad2974c14ad7	t	Gikombe	e09d7748-edcc-4f94-9893-80cbe6159874
0c10f615-e35c-48d3-94e6-1189dfd2df1b	t	Karambo	e09d7748-edcc-4f94-9893-80cbe6159874
5eb9d519-5e19-46f8-9c7a-b6320013161c	t	Karuhayi	e09d7748-edcc-4f94-9893-80cbe6159874
f2f9e79c-ea7f-4d64-b301-f7c6b673668a	t	Kigarama	e09d7748-edcc-4f94-9893-80cbe6159874
5facde1d-7ed6-4c2b-b591-d4b1cb6c3835	t	Ngobagoba	e09d7748-edcc-4f94-9893-80cbe6159874
0a24d20f-46e2-4b93-9720-51e3c9f16d98	t	Rwezamenyo	e09d7748-edcc-4f94-9893-80cbe6159874
4ea484f7-1198-4b15-a0c1-b2f95e9f7b5b	t	Kibingo	52c48996-b32e-469e-859d-22f6c76d51ef
af89961c-4415-4714-a03e-a80d4684cfe1	t	Mataba	52c48996-b32e-469e-859d-22f6c76d51ef
60619cd2-cc24-4646-894f-a1046999c531	t	Akarehe	ec92236a-6da5-448b-a179-cb5578cdd9b8
4468a2b4-5385-4b83-a0d1-83fac6f433fc	t	Akarambo	af6cdfdb-7964-4fea-98da-0698f2259919
db5a59b3-7be0-4b75-af5c-fd4c9fbef324	t	Nyarusange	af6cdfdb-7964-4fea-98da-0698f2259919
8640a4fc-f0c0-48ea-bfdb-b36c34a3a238	t	Sangano	af6cdfdb-7964-4fea-98da-0698f2259919
e98de359-8208-471f-9144-2f1f83004c41	t	Agasharu	997c515b-26bc-43b8-b116-03d68bf93c97
47f8a224-407b-4c7a-a285-3d065192169d	t	Nkoto	997c515b-26bc-43b8-b116-03d68bf93c97
9551004d-5c1d-47b8-8a5d-58b778e9ce1f	t	Zaga	997c515b-26bc-43b8-b116-03d68bf93c97
3250114e-c309-48f6-96f7-db9c7dd5f98c	t	Butare	55198202-8d7e-4919-a553-400d51cab894
e8d3c1b9-a062-48eb-8bbe-97034c896148	t	Cyetete	55198202-8d7e-4919-a553-400d51cab894
f4b15004-a6d3-4ef2-baf5-8beeeae9c6c7	t	Uwimpundu	55198202-8d7e-4919-a553-400d51cab894
b8eec76a-0738-4fa7-9e8a-ce7a66bb83c3	t	Karambi	5a1e86cb-39bb-43bc-b324-7048015ef6a2
99804018-0d0e-422a-a3b2-38ce6824c74f	t	Sanzu	945bb103-3143-4344-9830-617dd47237fc
15a2fe3b-93d8-45b9-bac6-1d3f26ea9981	t	Kagarama	4e0fbf8a-0f68-4dca-bb56-60f4a2daae24
be8c9973-9e8b-40db-b261-bc26766fec92	t	Gatovu	1f6c4bea-bb92-413c-9147-f29884eca132
ea50a154-cad2-4932-95e9-131b4473bb78	t	Kabacuzi	1f6c4bea-bb92-413c-9147-f29884eca132
2651c828-15bd-4773-83a4-e481164d621d	t	Kabakobwa	1f6c4bea-bb92-413c-9147-f29884eca132
37618d37-b242-4b2c-a05d-27a92f9f155c	t	Rebero	1561abdb-e2da-4e2a-9bdc-7888a8411cab
2adecd34-7f05-4f98-ba09-f281205493ba	t	Rusenyi	1f6c4bea-bb92-413c-9147-f29884eca132
2ff09e73-0a98-4a3d-b8cb-77f0bffe953d	t	Kabugabo	209df342-0185-4b14-9d04-59dab8516294
b690ff7c-d946-44e9-9a50-839cb6e9038d	t	Karambi	209df342-0185-4b14-9d04-59dab8516294
725e287a-730c-4439-9c79-54103c1492ca	t	Rugarama	209df342-0185-4b14-9d04-59dab8516294
db601ed4-3542-4e97-a6ab-936eef29fe5c	t	Birinjo	80d395e2-2184-4465-a4c5-64a6330a7ce0
7dec1242-2e90-401d-9390-3028955c0b85	t	Kabumba	80d395e2-2184-4465-a4c5-64a6330a7ce0
263c5aad-4d52-4744-aa1c-e49ab1895845	t	Kanyurapfund	80d395e2-2184-4465-a4c5-64a6330a7ce0
cedeb5b5-8052-4d80-a054-c587125c907a	t	Nyagahinga	80d395e2-2184-4465-a4c5-64a6330a7ce0
14e522db-ea52-4bef-a0e2-d1c954de49ee	t	Ruhinga	80d395e2-2184-4465-a4c5-64a6330a7ce0
611a0023-0afe-40ee-abb5-ff95b32fc1aa	t	Ryaruhimbya	80d395e2-2184-4465-a4c5-64a6330a7ce0
280b0946-85b2-4f5d-8213-775742f2197a	t	Kabicuki	a594fd7d-8bef-47b3-8962-b5b28c959686
a3d768f4-48cf-4a0c-a72c-24310c9775e0	t	Nyamirama	a594fd7d-8bef-47b3-8962-b5b28c959686
023fcd14-de64-490b-8aa0-7fb1595d1018	t	Gakoni	55beaa67-772e-421f-bb73-64d1c42e09c4
ae1c353c-77df-42e0-a245-1b8371470f33	t	Nyarurama	55beaa67-772e-421f-bb73-64d1c42e09c4
36dd96bb-366a-4f72-8dcf-f81ab8cc653b	t	Cyegera	39c33149-582d-4f4c-925a-8621dbdba71b
36f49638-5341-43c7-b476-3925d84c7810	t	Gasaka	39c33149-582d-4f4c-925a-8621dbdba71b
9a69f0d1-c7f9-4064-825a-12e9bc3ec8aa	t	Gihana	39c33149-582d-4f4c-925a-8621dbdba71b
2d0fab94-c2ab-4d26-bcfb-09773b5ce161	t	Rugarama	39c33149-582d-4f4c-925a-8621dbdba71b
48f498cf-b580-4290-ae9c-908d87fb32ad	t	Sogwe	39c33149-582d-4f4c-925a-8621dbdba71b
3ed2e51d-8cc8-4af1-901d-3b8f1bf81997	t	Hanika	46d92fd8-f418-4074-ac1a-cfb6b4de4c27
b719c424-5be6-4904-9b59-9f7a19c6730b	t	Karambo	46d92fd8-f418-4074-ac1a-cfb6b4de4c27
7fee7d6b-6c07-44a8-9721-76d9325410d3	t	Kinazi	46d92fd8-f418-4074-ac1a-cfb6b4de4c27
8466845f-5ff5-4379-9259-b5df87f99f23	t	Rubona	46d92fd8-f418-4074-ac1a-cfb6b4de4c27
c12ef251-11dd-412e-a71f-b9679b260012	t	Kibiraro	e911c381-49cd-432c-8eb8-524b815940e5
f157f8ba-676c-49bb-b7e0-dbf4dee7ae5a	t	Mujyejuru	e911c381-49cd-432c-8eb8-524b815940e5
806e7e39-5efc-45e4-8c5b-d3c9d80d1dc3	t	Munyu	e911c381-49cd-432c-8eb8-524b815940e5
b8f1b89b-9901-447b-9918-b7116c849708	t	Rwambariro	e911c381-49cd-432c-8eb8-524b815940e5
e69a279c-e3c1-4cc3-9519-7fd853896cbb	t	Gahondo	97c32539-dbe3-4584-9bcd-6f371e079d8c
e793b77e-4a79-48d4-8708-a6c1ccb02dec	t	Giseke	97c32539-dbe3-4584-9bcd-6f371e079d8c
482b1ed4-e648-4ef6-a0a5-51d64c9662fb	t	Kigarama	97c32539-dbe3-4584-9bcd-6f371e079d8c
398baadb-fa20-4c04-95ac-324ddf9bfc32	t	Mukuzanyana	97c32539-dbe3-4584-9bcd-6f371e079d8c
af161b83-a000-4af8-94e1-1952ddf6aca2	t	Nyabisindu	97c32539-dbe3-4584-9bcd-6f371e079d8c
11a1a86d-0476-484c-9383-cfce579f4cb9	t	Nyamiyaga	fb75df0f-1b96-4dd8-b2c5-eea26ccff061
65987fa9-4eaf-44d2-a4cf-d0d75830e817	t	Gisagara	2b7ace59-a955-44b6-bd14-f255224936ea
f8b982cc-b59e-42f3-b6bd-a96e967c16f4	t	Kagoma	2b7ace59-a955-44b6-bd14-f255224936ea
8ecb4f96-a567-4ff6-ad73-4df3f5057e25	t	Kizi	2b7ace59-a955-44b6-bd14-f255224936ea
193471a1-443a-45c6-8dc8-d96b8d9ab2eb	t	Agasharu	286ea5fb-342d-456c-b6b1-13e5d825bd76
659731ac-b07f-41c4-ab64-4112448282af	t	Akanyinya	286ea5fb-342d-456c-b6b1-13e5d825bd76
00eda8cf-66d0-4b5b-921f-57fe011b3c98	t	Bigangara	286ea5fb-342d-456c-b6b1-13e5d825bd76
6a6c7313-46dd-4cc8-8b1a-ae04a283ca35	t	Kanyaruhinda	286ea5fb-342d-456c-b6b1-13e5d825bd76
79f0586e-c649-43dd-bd47-8865f92053ec	t	Mpinga	286ea5fb-342d-456c-b6b1-13e5d825bd76
9e7e6244-8c8d-442e-aba1-418ab2ace21f	t	Rubona	286ea5fb-342d-456c-b6b1-13e5d825bd76
342932f2-319b-4c7d-9402-2c6b8a2ee2ea	t	Rwabuye	286ea5fb-342d-456c-b6b1-13e5d825bd76
17515819-3056-4266-9c32-3b2e19a46580	t	Gakombe	4383fd7b-edb7-4582-b01b-ce56818581e0
fe167dd2-c593-47a0-8e88-b129c74c0260	t	Gasharu	4383fd7b-edb7-4582-b01b-ce56818581e0
570500b4-adb5-4ee4-be47-ad473a2be4bd	t	Gicubuka	4383fd7b-edb7-4582-b01b-ce56818581e0
f8492409-1b4c-4c19-8fc7-484953992a89	t	Mpinga	4383fd7b-edb7-4582-b01b-ce56818581e0
6260e238-4826-405f-8efb-19d169686b81	t	Ndobogo	4383fd7b-edb7-4582-b01b-ce56818581e0
4590fbd3-74b2-4208-8bde-e950a54f6b27	t	Rwezamenyo	4383fd7b-edb7-4582-b01b-ce56818581e0
36887bd8-63e0-4a43-88df-d6a01cde586e	t	Kagera	998d2ac5-75de-43f9-93af-9a653323e7c7
f9bbea73-ea02-4e66-aaa3-5307c4fdb3b7	t	Kigusa	998d2ac5-75de-43f9-93af-9a653323e7c7
603e57c1-77d5-4462-b89a-454d40ccc47d	t	Kimuna	998d2ac5-75de-43f9-93af-9a653323e7c7
5d8cbd09-9261-4456-a620-940068f1b6ae	t	Kinyana	998d2ac5-75de-43f9-93af-9a653323e7c7
263ff23c-2729-4fcc-9c36-d3933fef5cf2	t	Rugarama	998d2ac5-75de-43f9-93af-9a653323e7c7
be2f5a51-33af-4886-8eb1-4da51925469b	t	Ruryango	998d2ac5-75de-43f9-93af-9a653323e7c7
db9030cb-9948-4fa1-94c3-3ed66e1a1496	t	Bumbogo	4c1b81e1-b7de-4665-b06c-c8bbc33d1478
8d122fac-e19e-491f-836a-b406a1eb44b7	t	Gitwa	4c1b81e1-b7de-4665-b06c-c8bbc33d1478
15859979-cb6b-4222-8fbc-ea85a8689c61	t	Kaburuba	4c1b81e1-b7de-4665-b06c-c8bbc33d1478
68fd5828-7e0f-4e4a-aca5-b68383940832	t	Murambi	4c1b81e1-b7de-4665-b06c-c8bbc33d1478
b0621b11-8137-4a1f-a580-935c753f401b	t	Taba	4c1b81e1-b7de-4665-b06c-c8bbc33d1478
f09e6e43-5c15-4ca4-96ba-8e4c5c7799a2	t	Gahanga	317bd051-332f-4432-9f13-2c579b0bca41
f6af2ba3-b7ae-4419-a250-a34d0cc0ec9c	t	Kamunyinya	317bd051-332f-4432-9f13-2c579b0bca41
9d4b23d5-b10e-443b-ac5a-480a21bd96c9	t	Kanzeyi	317bd051-332f-4432-9f13-2c579b0bca41
7966a5be-a74a-4971-be96-9a32886d6a34	t	Kibiraro	317bd051-332f-4432-9f13-2c579b0bca41
d8abbcd7-0bff-492c-bd71-aedb6cb3afc7	t	Kigarama	317bd051-332f-4432-9f13-2c579b0bca41
b44725e0-1ab1-4926-b6d0-d038e118455d	t	Mpinga	317bd051-332f-4432-9f13-2c579b0bca41
8f729e8e-9322-4c8f-8e10-ae94b9d41d37	t	Ngeri	317bd051-332f-4432-9f13-2c579b0bca41
37522188-9be0-49d9-afae-916f526406a9	t	Nyabisindu	317bd051-332f-4432-9f13-2c579b0bca41
3aed3a41-779e-4889-bd5c-a3058175bff6	t	Nyamirundi	317bd051-332f-4432-9f13-2c579b0bca41
a9e760a7-5d85-4a65-a912-150022fb1da7	t	Buhoro	d8cb6e6a-0676-4a98-9226-cd06895a78f2
d605cfb8-8362-4035-811a-1b2285a5f8ec	t	Gitwa	d8cb6e6a-0676-4a98-9226-cd06895a78f2
db65e178-b0c0-4737-bce7-23ba7a725fcf	t	Kibirizi	d8cb6e6a-0676-4a98-9226-cd06895a78f2
78ca5b6f-cfac-44db-8733-ac8dc6425f9e	t	Cyingoma	d8cb6e6a-0676-4a98-9226-cd06895a78f2
e4da4977-be95-4036-b17a-575d2a0ddf54	t	Ruhuha	d8cb6e6a-0676-4a98-9226-cd06895a78f2
444d6caa-bc76-451e-9880-81f83648db61	t	Cyahafi	372e6795-ab36-4670-8592-75eba2bab224
d7282435-80dd-4908-b360-4ac5dc788888	t	Gashikiri	372e6795-ab36-4670-8592-75eba2bab224
c1a2e9a4-1da3-4276-ad8b-618905948cab	t	Kavumu	372e6795-ab36-4670-8592-75eba2bab224
b9dd0f4a-1aa3-47cf-94e7-0648f990cf38	t	Rupango	372e6795-ab36-4670-8592-75eba2bab224
c38fe4db-28b2-4db8-9f8b-39787aaa9b18	t	Bweramana	118b1ecb-0a4f-4324-a602-0fd3b16bfd5a
5bf62e38-c320-404f-a9ac-1b367254a5d5	t	Kigarama	118b1ecb-0a4f-4324-a602-0fd3b16bfd5a
b6f8ed27-bbe5-4d22-a41c-3e22a81dfcaf	t	Taba	118b1ecb-0a4f-4324-a602-0fd3b16bfd5a
7924e9c8-9a78-4c42-87b8-e97d635f8ab6	t	Akagarama	a706170c-982f-473d-abfd-6f4992c75375
78e3b3c6-2a63-49d1-9952-d6b3f4acab65	t	Akogo	a706170c-982f-473d-abfd-6f4992c75375
048c655d-a357-4187-a1a5-27871c11a627	t	Amasanganzir	a706170c-982f-473d-abfd-6f4992c75375
96196489-71d3-4b1c-936a-7bd222e77f0e	t	Akabutora	a706170c-982f-473d-abfd-6f4992c75375
5a0880b0-7155-4652-8d09-a7a2fd469420	t	Mpinga	a706170c-982f-473d-abfd-6f4992c75375
a41f2207-34ac-4fee-9693-4e628ce8fbc8	t	Nyagasambu	a706170c-982f-473d-abfd-6f4992c75375
3faefebe-681d-400b-9f74-cee195dd397b	t	Akabuga	04f80804-e2fa-4a77-b22d-654cbb31c11a
2b6ab856-4523-406c-b017-a1b341012254	t	Akamahinda	04f80804-e2fa-4a77-b22d-654cbb31c11a
2b929309-f719-4c18-8c0a-02c060a863de	t	Gakombe	04f80804-e2fa-4a77-b22d-654cbb31c11a
fbeb27e7-a61a-4de6-afbf-ecdafef6b6c7	t	Nyarusambu	04f80804-e2fa-4a77-b22d-654cbb31c11a
536a4d4d-58d9-4e18-a79d-d03c61778b7b	t	Agakera	458557fe-b913-476c-b99e-c6c706ffa6f4
30cfdcae-4c5c-4c2c-9826-8a9393a75c8f	t	Agakombe	458557fe-b913-476c-b99e-c6c706ffa6f4
3edb0427-992a-45bd-830c-68bf00b81177	t	Gaseke	458557fe-b913-476c-b99e-c6c706ffa6f4
067b481b-96ea-41ec-b9df-edff087d2c8d	t	Kabahora	458557fe-b913-476c-b99e-c6c706ffa6f4
8a513f0b-3b60-4a5b-86e3-f11385b6f726	t	Mpaza	458557fe-b913-476c-b99e-c6c706ffa6f4
35ca9f03-9f55-4473-9f54-c5f7c89ec2cc	t	Nyamata	458557fe-b913-476c-b99e-c6c706ffa6f4
05b6505e-bd0f-4d95-b193-2eb9ca0cc3d0	t	Rwinuma	458557fe-b913-476c-b99e-c6c706ffa6f4
1dd43337-43c7-47d3-a304-2a9cf8049a9a	t	Akabuye	40cb4b8c-fd3e-435f-b2af-da659b5d815b
cb3abd90-e37d-4456-a79a-9791ac374679	t	Bukinanyana	40cb4b8c-fd3e-435f-b2af-da659b5d815b
2f622b2f-bca0-47f8-a88b-2ee9fbd281e8	t	Buye	40cb4b8c-fd3e-435f-b2af-da659b5d815b
6a5862b1-2b1d-42d2-bf75-f7ebe169f826	t	Gasoro	40cb4b8c-fd3e-435f-b2af-da659b5d815b
c7524f16-5791-43bf-9e10-34cec741b74d	t	Kabutare	40cb4b8c-fd3e-435f-b2af-da659b5d815b
fecb4c89-2a63-4a58-8ff9-b379b5947397	t	Karubanda	40cb4b8c-fd3e-435f-b2af-da659b5d815b
a2dc56a3-ed02-4984-9108-4a627554c687	t	Mamba	40cb4b8c-fd3e-435f-b2af-da659b5d815b
a13d3280-d2d4-4018-9a3e-a63eead0a84b	t	Busenyi	40cb4b8c-fd3e-435f-b2af-da659b5d815b
61c6c369-2938-43a1-bd2a-3931f5cb46e1	t	Taba	40cb4b8c-fd3e-435f-b2af-da659b5d815b
2ad17748-38b8-4e71-8985-87acfeb9657e	t	Gatoki	ba8be250-d971-4e7a-8b07-1fafe0724199
15671efa-5151-4148-a783-4e9787809029	t	Kaguhu	ba8be250-d971-4e7a-8b07-1fafe0724199
8cdf4e42-f23f-44b5-bd2d-9ba6d94c4584	t	Karambi	ba8be250-d971-4e7a-8b07-1fafe0724199
38848e63-75c4-456f-81b9-46e1b57a80f2	t	Nyabubare	ba8be250-d971-4e7a-8b07-1fafe0724199
fcd941b5-2ac0-43c7-b282-3118f71332b7	t	Nyagapfizi	ba8be250-d971-4e7a-8b07-1fafe0724199
bd25a7e8-8da3-4de3-b697-5d109c49e2d4	t	Rugarama	ba8be250-d971-4e7a-8b07-1fafe0724199
937d25d3-9ddb-479a-9cbf-208d14365a5c	t	Runga	ba8be250-d971-4e7a-8b07-1fafe0724199
ccb3cbf0-0f41-48b8-bca3-944b150d3c42	t	Gafurwe	84370341-c761-43ad-a3c1-ca8e7a481cfd
14ae3a3c-1016-41d2-87c7-1ca41f92a108	t	Kabeza	84370341-c761-43ad-a3c1-ca8e7a481cfd
d1a4f821-b752-485a-8e91-821b97ae2382	t	Kamucuzi	84370341-c761-43ad-a3c1-ca8e7a481cfd
c1104d14-78d0-4e1e-aff0-49896b1d1227	t	Nyabitare	84370341-c761-43ad-a3c1-ca8e7a481cfd
2d51db13-17cf-493b-8a6e-81eba9c16eff	t	Rurenda	84370341-c761-43ad-a3c1-ca8e7a481cfd
4c3a4db9-8e3d-4da3-8732-dd7508a48e7d	t	Rusisiro	84370341-c761-43ad-a3c1-ca8e7a481cfd
ff02c83f-5efe-4208-8209-02524007d8d9	t	Ruvuzo	84370341-c761-43ad-a3c1-ca8e7a481cfd
bd2f12ec-f275-48fe-9f9e-893c13d058dd	t	Ngoma V	a8fea5e2-e92c-4b5e-94e6-e81c4d254dca
ab5f5799-2114-4e9e-81c6-7c23970c97cd	t	Ngoma I	a8fea5e2-e92c-4b5e-94e6-e81c4d254dca
ca811628-d904-46a9-b0b5-f59b68417f5b	t	Ngoma III	a8fea5e2-e92c-4b5e-94e6-e81c4d254dca
b9d88ad8-114c-4a05-aa83-8641b32b8fa8	t	Ngoma IV	a8fea5e2-e92c-4b5e-94e6-e81c4d254dca
c8d9b783-4a5c-4a69-a309-8c0d8eebe357	t	Ngoma VI	a8fea5e2-e92c-4b5e-94e6-e81c4d254dca
72935279-4c2d-4176-b6eb-3c79f763c35c	t	Ngoma II	a8fea5e2-e92c-4b5e-94e6-e81c4d254dca
95e97e00-1894-4590-aae8-b4a8ccf15f1a	t	Dutare	905197c4-9fd6-4c2e-bcae-9e5e8b297abe
ce713d04-615b-4e77-b89c-51be57b018dc	t	Karambo	905197c4-9fd6-4c2e-bcae-9e5e8b297abe
6368e5b1-e8ac-4c67-9234-a79dc229a628	t	Kigoma	905197c4-9fd6-4c2e-bcae-9e5e8b297abe
637a1499-1df7-4a77-abe7-f156e4b11986	t	Kiyanza	905197c4-9fd6-4c2e-bcae-9e5e8b297abe
bcaa9cef-da89-4923-83a2-363ea1f08d9a	t	Murama	905197c4-9fd6-4c2e-bcae-9e5e8b297abe
9c633e04-8ca2-4832-9e72-5e1cbe08215a	t	Kampogo	f274108a-5e61-4cc7-a689-d475a5cee7ad
e78eaa95-1ff0-46c9-8893-716de13ee02e	t	Karambi	f274108a-5e61-4cc7-a689-d475a5cee7ad
8c89839c-89f9-4817-8476-af61cefadc61	t	Rukubiro	f274108a-5e61-4cc7-a689-d475a5cee7ad
669206f3-b058-4457-91b6-dee6ff2b8975	t	Umuyinza	f274108a-5e61-4cc7-a689-d475a5cee7ad
0a990546-c967-4121-9fd2-23d2abf11d32	t	Bwankusi	51df8f17-ccf0-43b5-b15f-ad7d76a973d1
1d41b657-7eef-4116-a8af-f2487da4d123	t	Gashikiri	51df8f17-ccf0-43b5-b15f-ad7d76a973d1
b18bd5d4-90f4-4f61-bced-fcab4dd389d6	t	Gitwa	51df8f17-ccf0-43b5-b15f-ad7d76a973d1
858de036-2687-47d3-a4a3-7066fe1fc0e6	t	Karambo	51df8f17-ccf0-43b5-b15f-ad7d76a973d1
2ee80925-6983-4639-88e0-37540f0f4360	t	Rwamara	51df8f17-ccf0-43b5-b15f-ad7d76a973d1
d6bcf7b4-cc1b-4674-afb1-953bad2d9b80	t	Agasharu	18746d64-4f20-4694-bb39-107ea55e94bc
0ed7d262-0f8b-4177-84f8-104d0c192da3	t	Kinziramuhin	18746d64-4f20-4694-bb39-107ea55e94bc
b28e8d89-cff0-45a3-b9d5-6459c972d4df	t	Nyakabingo	18746d64-4f20-4694-bb39-107ea55e94bc
8b78da7d-d268-4242-9ca3-dceaef9e6382	t	Shyara	18746d64-4f20-4694-bb39-107ea55e94bc
d9bbb26a-560f-43d7-92a0-25bf33b86fb2	t	Taba	18746d64-4f20-4694-bb39-107ea55e94bc
e18a31c8-8855-42f7-8c3a-75de1b12c017	t	Akanyana	13ad08f6-e814-4981-b908-643d6f14002f
6f938b1e-f267-435f-908d-123b96a93f32	t	Mbagabaga	19ee5c18-5d03-4a6c-816c-73244a72b81c
43a4aebd-ced4-40fb-8b90-7ac188189869	t	Impinga	6bb94ac8-ca25-4997-8c41-76fbf7a5d5af
8fcb113b-a03d-4db4-8f57-f0669683e447	t	Kanyirankuba	6bb94ac8-ca25-4997-8c41-76fbf7a5d5af
34d12fb5-562f-4189-8d29-dd95d9f50a50	t	Mucunda	6bb94ac8-ca25-4997-8c41-76fbf7a5d5af
16f4a195-1556-41a2-9ce6-86bb43756d32	t	Kabuga	58575571-08d2-40eb-8b32-e50b4df4828a
63f5423c-6b60-4b11-a74b-9e5ce05a4dc4	t	Kigarama	58575571-08d2-40eb-8b32-e50b4df4828a
c1cf2fee-9151-411c-8305-9baeee855343	t	Kigari	58575571-08d2-40eb-8b32-e50b4df4828a
b99a6985-3791-4ccb-85f6-3e4ecdbdcacd	t	Mubuga	58575571-08d2-40eb-8b32-e50b4df4828a
741a2b49-8004-4acb-86d1-b374779c6c6f	t	Ruvugizo	58575571-08d2-40eb-8b32-e50b4df4828a
64e7c91a-ae69-4e74-af12-be11f85f01ff	t	Kagasa	db1bee31-63db-405a-9c97-94a3f0babe9e
1f5694c9-884c-4c15-b3a2-a5a0e6543a3c	t	Kavumu	db1bee31-63db-405a-9c97-94a3f0babe9e
ae76b37c-0303-4d3f-9dac-11da201b87f4	t	Kigarama	db1bee31-63db-405a-9c97-94a3f0babe9e
d7b53fc2-f6e6-4f47-8e20-35f3c0e3bcbb	t	Ndyome	db1bee31-63db-405a-9c97-94a3f0babe9e
561b6e38-1b5d-46b2-b0c8-0c9f460be232	t	Nyakabuye	db1bee31-63db-405a-9c97-94a3f0babe9e
cd0c73eb-40d4-4363-b745-cd0ce669e984	t	Rubanga	db1bee31-63db-405a-9c97-94a3f0babe9e
020b4afa-18a5-44e7-b236-e3a70d1fd4f7	t	Kamabuye	6dd14e41-dbf9-4c00-9527-69895dae9ab9
942f3438-1c22-47d9-a689-9b4507fa797a	t	Kimigo	6dd14e41-dbf9-4c00-9527-69895dae9ab9
ea7bb2e4-db32-4ebd-9d77-4c1bf465da4d	t	Murambi	6dd14e41-dbf9-4c00-9527-69895dae9ab9
9498e778-3e1b-40da-94b2-e82dab7b0786	t	Nyabusunzu	6dd14e41-dbf9-4c00-9527-69895dae9ab9
864b731e-b46e-4b0a-9b17-b21e87c7450f	t	Rwamuganda	6dd14e41-dbf9-4c00-9527-69895dae9ab9
13c3bafb-7f6c-462d-ab08-1e5b3c093200	t	Agasharu	f5a4fab4-7cc0-44a6-989c-f0d0ca712128
3cc5b6b4-ee09-47a9-b7aa-b97cc5163df4	t	Impinga	f5a4fab4-7cc0-44a6-989c-f0d0ca712128
29364838-047b-4495-b7d1-e79019bbe793	t	Nyagasozi	f5a4fab4-7cc0-44a6-989c-f0d0ca712128
096ae14e-6321-4b11-8edc-06baf2ff9dac	t	Nyarucyamu	f5a4fab4-7cc0-44a6-989c-f0d0ca712128
2134a5fa-fbae-4a91-a6d5-7a3a911ba3be	t	Nyarugenge	f5a4fab4-7cc0-44a6-989c-f0d0ca712128
8b9538d9-1ca9-4caf-a778-acd92e3b54ee	t	Rubona	f5a4fab4-7cc0-44a6-989c-f0d0ca712128
da6d1780-78da-4346-b376-b4f1d852ec72	t	Tumba	f5a4fab4-7cc0-44a6-989c-f0d0ca712128
c287a477-8c78-4da3-b931-8548f3f09238	t	Gicubuka	d867a954-a944-4a05-9d72-ef36d107eece
f48de8f6-4059-4ffd-af3a-eafe9f78f7d7	t	Amarongi	74d38a17-0537-4bb6-a4de-62b24e0d8f26
14dc1a1e-0c27-46b3-8c94-918141f19848	t	Gatwaro	74d38a17-0537-4bb6-a4de-62b24e0d8f26
f6cecddc-c0cb-45c0-8118-1ba07a7ea498	t	Nyakabuye	74d38a17-0537-4bb6-a4de-62b24e0d8f26
eae67ebc-be25-4a5a-8ee4-06d2dce5a6de	t	Rumana	74d38a17-0537-4bb6-a4de-62b24e0d8f26
30a51357-5260-4be6-be8a-c9d51cb41e71	t	Gakomeye	19a2fd84-6b3f-4b27-84b9-081e54fee885
e40e4bf4-9067-420f-bfe5-1bc20c2c8222	t	Kamwambi	19a2fd84-6b3f-4b27-84b9-081e54fee885
88aa7d27-bb65-41d8-b862-fa4e24aeb0e7	t	Karambo	19a2fd84-6b3f-4b27-84b9-081e54fee885
a322081b-158d-44ac-8e2f-938c3e3a9bc1	t	Remera	19a2fd84-6b3f-4b27-84b9-081e54fee885
3085c3c5-4118-4778-9bb1-934f29becc19	t	Rurembo	19a2fd84-6b3f-4b27-84b9-081e54fee885
d9219adc-398d-45ca-9edf-da8cc650df17	t	Murehe	73cde831-69ad-45e3-b382-653957aee0b7
26e6c120-7b93-4d05-b26e-eaa89391fd05	t	Nyabisindu	73cde831-69ad-45e3-b382-653957aee0b7
625548ef-a158-46ef-964c-9d2db36d88b4	t	Gafurwe	73cde831-69ad-45e3-b382-653957aee0b7
0c79846f-b486-4666-92cb-c9cd9f1f31c8	t	Nyarunyinya	73cde831-69ad-45e3-b382-653957aee0b7
dda2d469-0ce4-4d70-b77e-3811af5a8360	t	Murango	eeae03d9-dd11-4e90-b1d9-4e1992802074
ef293196-eac7-4ee4-97ad-08708431d8aa	t	Bweramana	9808b312-dbe6-4532-b807-a0e6f62836ca
0f56d2f7-aba4-43e9-87f5-1244e47ad6fe	t	Kigarama	9808b312-dbe6-4532-b807-a0e6f62836ca
e67c6e65-4c6b-44e8-a010-416ea82206f4	t	Munanira	9808b312-dbe6-4532-b807-a0e6f62836ca
ba74e6dd-914a-489c-8353-e826e5de57fd	t	Nyagacyamu	9808b312-dbe6-4532-b807-a0e6f62836ca
6a5cb0ff-5017-40fe-b31c-558b6804b1af	t	Nyamabuye	9808b312-dbe6-4532-b807-a0e6f62836ca
cc6c493f-d531-4b18-a048-db2d60604a71	t	Gasharu	1eb98234-dc14-4def-8677-50b3a3203a26
9d793840-06bd-4238-90ed-de5fa59d049e	t	Kibara	1eb98234-dc14-4def-8677-50b3a3203a26
16a74d78-b914-4cce-a4f3-74487f01c9c3	t	Kigarama	1eb98234-dc14-4def-8677-50b3a3203a26
0cc7d4d1-2afb-4992-9583-152a54de8325	t	Murambi	1eb98234-dc14-4def-8677-50b3a3203a26
c5060ddb-e89c-4fa5-8ee6-0c8234965c48	t	Mwezi	1eb98234-dc14-4def-8677-50b3a3203a26
2943929d-8be7-4a5a-b701-828e1c751173	t	Nyabujengwe	1eb98234-dc14-4def-8677-50b3a3203a26
8022ef62-79ca-46fb-95bd-b8d08927a9ce	t	Rugarama	1eb98234-dc14-4def-8677-50b3a3203a26
452f43f2-76ec-4be7-b36d-602fe863981d	t	Karama	88b8b8b0-b278-4379-ba45-6b611f08bac8
b9184b18-b023-44e5-b197-685c4d6736e2	t	Karugumya	88b8b8b0-b278-4379-ba45-6b611f08bac8
43b2916b-a96e-4677-9c34-c87c205a0ce1	t	Kiboga	88b8b8b0-b278-4379-ba45-6b611f08bac8
52736a66-50fd-49e2-867a-393c5117f03b	t	Kigarama	88b8b8b0-b278-4379-ba45-6b611f08bac8
af00bb9e-c078-4a7e-b3a2-81550fb9248e	t	Rugarama	88b8b8b0-b278-4379-ba45-6b611f08bac8
cb55db67-72b5-40a2-b28e-8aa87534fb9c	t	Bisambu	8d9b6373-535a-4c52-a44b-d2804b9f1875
cdcaeba8-c094-498d-a2c1-1fa910c026ba	t	Cyendajuru	8d9b6373-535a-4c52-a44b-d2804b9f1875
c991eba1-2340-445e-9c62-fb862c95e41f	t	Rugarama	8d9b6373-535a-4c52-a44b-d2804b9f1875
eb3a3d2b-508c-40db-bc77-eea7fac2023e	t	Rwatsi	8d9b6373-535a-4c52-a44b-d2804b9f1875
6c9fdf04-9676-4289-b1d5-0d1f7d42212d	t	Bwiza	2ed69990-6f83-4280-b141-6eb7a508c894
85291716-591d-4fbd-a85f-7b4fee73fed7	t	Maliza	2ed69990-6f83-4280-b141-6eb7a508c894
8eab4323-9183-4fbe-b767-c53f830621a0	t	Muranda	2ed69990-6f83-4280-b141-6eb7a508c894
07731f5a-be11-4bee-858f-443eadee5b56	t	Ndago	2ed69990-6f83-4280-b141-6eb7a508c894
f32c4c20-1e5c-4360-8a55-494b8c8953b7	t	Ntobwe	2ed69990-6f83-4280-b141-6eb7a508c894
4c58afd6-4565-478d-aadf-da52b9c51a7a	t	Rusuma	2ed69990-6f83-4280-b141-6eb7a508c894
57193161-3f68-420a-9eb9-9a91deec2fa5	t	Nyamirama	561cb518-1a77-428d-8cb1-cca72bde53aa
f87cabc8-1e12-4e75-9986-5149617e8d26	t	Rugarama	561cb518-1a77-428d-8cb1-cca72bde53aa
bcc6ef0c-9ee5-4c68-80ae-551a046ee7d7	t	Agahora	4aa51065-6ccb-4117-b00f-6b9973eb12e6
0df86935-8add-4340-8e00-19cf8eb2957b	t	Agasengaseng	4aa51065-6ccb-4117-b00f-6b9973eb12e6
4beb590e-e772-412b-ae29-257e7f4d06e6	t	Agasharu	4aa51065-6ccb-4117-b00f-6b9973eb12e6
f786a44d-b270-4b82-b924-f1c921b13121	t	Agateme	4aa51065-6ccb-4117-b00f-6b9973eb12e6
5b764876-9e79-4a87-929e-f049cd1f8b34	t	Icyiri	4aa51065-6ccb-4117-b00f-6b9973eb12e6
f76ebea0-d083-46ef-a040-5b353c586830	t	Kabeza	4aa51065-6ccb-4117-b00f-6b9973eb12e6
b578eb9a-fa4a-45d6-bce5-6659ff629428	t	Kigarama	4aa51065-6ccb-4117-b00f-6b9973eb12e6
d9f53618-c095-4ff6-888a-34313d7527a3	t	Taba	4aa51065-6ccb-4117-b00f-6b9973eb12e6
7956a029-f20b-4430-8455-3d58a6f64711	t	Abizerwa	2b957380-9ca9-4df4-a622-5af04215a43f
d4973645-81a1-4761-99ff-e695840300b1	t	Akamuhoza	2b957380-9ca9-4df4-a622-5af04215a43f
12278723-6d0b-4150-8424-fefc290e3fd8	t	Amahoro	2b957380-9ca9-4df4-a622-5af04215a43f
bd14d5ae-efb4-4bb8-af60-981a2ff70e2f	t	Ubumwe	2b957380-9ca9-4df4-a622-5af04215a43f
bd6ab804-4ecd-45f7-9ccd-8f056f79eb06	t	Ubwiyunge	2b957380-9ca9-4df4-a622-5af04215a43f
627ca8fc-32a8-4934-9486-3a0a6daf9a15	t	Gasenyi	ce8f4f18-3a6c-4542-8bdd-85d0c351dd70
2c89bb01-47c1-4fbb-8b6d-9857b6e6279c	t	Berwa	ce8f4f18-3a6c-4542-8bdd-85d0c351dd70
467cb8ec-eb24-4c43-a448-2623c1b2feb3	t	Nyarurembo	ce8f4f18-3a6c-4542-8bdd-85d0c351dd70
21181b6c-5630-4221-a933-9926e39fc6ad	t	Rebero	ce8f4f18-3a6c-4542-8bdd-85d0c351dd70
66e6ebf1-8df4-4ea9-afe8-a7a0c8484c79	t	Rimba	ce8f4f18-3a6c-4542-8bdd-85d0c351dd70
02639c6f-b58b-4d53-aa12-94dc32dcc8b7	t	Agasharu	07516222-36f4-4033-ac2c-0af933387bd6
500c3846-6e9c-4c92-8609-943c836f847c	t	Akabuga	07516222-36f4-4033-ac2c-0af933387bd6
8168b643-db7b-443a-aa64-2dc83f36648a	t	Akarugiranka	07516222-36f4-4033-ac2c-0af933387bd6
c639cf8e-b8c3-4257-8033-9661c740e627	t	Kigarama	07516222-36f4-4033-ac2c-0af933387bd6
3f433d59-10b4-48f6-bbba-44b8f199146d	t	Musange	07516222-36f4-4033-ac2c-0af933387bd6
2dd358a0-bb66-435d-a47d-dc3d4561f7e9	t	Runyinya	07516222-36f4-4033-ac2c-0af933387bd6
ab65de71-ab4a-44e4-a61d-5b1c95410d0c	t	Rwanyanza	07516222-36f4-4033-ac2c-0af933387bd6
087dc86c-227d-4b79-adeb-d782ec8d1e65	t	Akabeza	2eef0f48-3b86-4aa0-914d-0f242d19a1ad
1ea5ad60-7ddf-4227-8f55-e06a9fcfe391	t	Akakanyaman	2eef0f48-3b86-4aa0-914d-0f242d19a1ad
47185467-a035-4383-bddc-728b1c8890e1	t	Byimana	2eef0f48-3b86-4aa0-914d-0f242d19a1ad
6e763b84-4b56-4bfb-a543-b7ab478ff784	t	Kigarama	2eef0f48-3b86-4aa0-914d-0f242d19a1ad
ef4ba10f-d73b-4aad-bfda-0caa6525a450	t	Ntangarugero	2eef0f48-3b86-4aa0-914d-0f242d19a1ad
592a155c-ef65-4591-a5f3-2a80a1b56164	t	Urugwiro	2eef0f48-3b86-4aa0-914d-0f242d19a1ad
90a95b94-b4ce-4d9f-b786-bf30e0622897	t	Kagarama	3f2e6c04-57fe-4ace-9dee-56b19c311fb9
2517264b-dde8-4bdc-8210-794df8dafa1a	t	Nyagasozi	3f2e6c04-57fe-4ace-9dee-56b19c311fb9
7586d5a6-59c0-4b8e-8f99-d2ae0c6b82f5	t	Nyarunyinya	3f2e6c04-57fe-4ace-9dee-56b19c311fb9
63462c1d-6498-46cd-8e29-12f439763cb7	t	Kibanza	d7d7d651-418c-4517-a616-8cfd74ae0c87
f0210b56-703b-431c-9a80-cf0c92885b0e	t	Kidaturwa	d7d7d651-418c-4517-a616-8cfd74ae0c87
dfd81ce0-8604-4abf-8285-f4ab792316a4	t	Buhoro	e4fce17b-e805-4daf-ba9a-81c02e5693e5
b43bfa53-7793-4bb1-8bed-23d5933ff15d	t	Mushimba	e4fce17b-e805-4daf-ba9a-81c02e5693e5
a483e0f9-5b8e-4a9f-bff8-963398198f0c	t	Rugobagoba	e4fce17b-e805-4daf-ba9a-81c02e5693e5
d329e4d6-3553-43b1-9046-d4307c25f0cd	t	Kamonyi	aa4e853b-878a-4a65-acdf-0cd7d8efcdb1
e79aa87d-117e-48da-88f0-29bb4966712f	t	Mataba	aa4e853b-878a-4a65-acdf-0cd7d8efcdb1
a71263ec-6ec4-4a22-afc5-085c79bae51a	t	Nyamugari	aa4e853b-878a-4a65-acdf-0cd7d8efcdb1
855dc8b2-276a-4802-b7a6-e0ca7aa71271	t	Rubona	aa4e853b-878a-4a65-acdf-0cd7d8efcdb1
ed33463f-f69d-403f-8997-b1bf3689f0a4	t	Kajevuba	2dc23136-17dd-4941-9ec1-40784381158d
281c10c6-7897-458d-958f-291fc1575c9d	t	Kinkeri	2dc23136-17dd-4941-9ec1-40784381158d
09b0a7fa-6680-477c-9f5a-0480bd1b580b	t	Kokobe	2dc23136-17dd-4941-9ec1-40784381158d
20c77635-de3d-4ba3-b876-4d02d4b2c2d9	t	Ryagashaza	65a37abf-b4f4-413d-94df-b998e7adaddd
bc464492-a229-40b9-8810-08f6327cd436	t	Nyamitanga	e713e313-df8a-472b-a7cb-904d97dda34c
34db0cea-7591-49e0-8358-eab6ea65fb91	t	Kavumu	2bf3dacf-e537-4582-9b8d-6d799eaf0077
3898ac9e-4352-45c7-a65d-7028263bfb5e	t	Remera	8bfd0a30-3377-4e7f-b58d-d3141d684016
342cf95a-5b16-431a-9782-a6b263149abe	t	Gitwa	687ce23f-276a-4496-b13c-54af5170800e
5be0e8a4-60b1-46cc-8999-f3b6eeae457b	t	Ntwari	687ce23f-276a-4496-b13c-54af5170800e
c3bb7921-8ab2-4d00-a113-406860e86577	t	Rwishywa	687ce23f-276a-4496-b13c-54af5170800e
cfa5dbbb-f9b8-4702-85d5-f0f82d214970	t	Gitwa	7d23eb68-bf1c-4b59-a065-69a053fa688c
2f7952aa-43c2-4b2b-bca2-e6550cbc2baa	t	Gasasa	19a19289-b38f-40af-9d87-9e69b61d6538
69fd0a9c-2ffa-4c01-9115-3ff9f5913b54	t	Nyarubaya	19a19289-b38f-40af-9d87-9e69b61d6538
150723b5-304f-4b2d-820a-c9172fedba4f	t	Nyarunyinya	83001b51-ad71-4302-a2a6-f1f4994f9383
c77e4922-051b-47c2-8910-c9631e9a7c47	t	Mirehe	3a53e06c-f319-4069-bfd5-ca6acea537c6
16353726-91c8-4860-ac7a-44dd61fa5053	t	Ryamanywa	3a53e06c-f319-4069-bfd5-ca6acea537c6
64b283d4-45de-40ec-b5b5-dbd89af08315	t	Kaje	5c8751c5-b33c-450d-8f37-8f9e7b1cedb8
870b8fb0-cea6-4db1-9ef3-294c4da224b4	t	Munini	97483b97-9f6b-45b3-baab-fdab58035dcc
33850a3a-5129-459e-b2ad-a16f1707c056	t	Bihenga	7882126e-9359-4f8b-8804-4930fd0b62e3
8ed5eff9-4c8b-48b9-be2f-10efc366beaf	t	Cyeru	7882126e-9359-4f8b-8804-4930fd0b62e3
4375271f-a96e-44c9-8329-79610705007a	t	Mataba Sud	7882126e-9359-4f8b-8804-4930fd0b62e3
086b80ba-ae49-4053-ae1c-326f4ae92a1a	t	Runzenzi	7882126e-9359-4f8b-8804-4930fd0b62e3
7aeca0a0-a595-4e79-ad8e-18a489cd1465	t	Kigorora	d95f5e88-e85d-4bea-b832-41a43bbb2321
c913af05-ffbe-4628-bb37-1d83ff007b72	t	Mbati	d95f5e88-e85d-4bea-b832-41a43bbb2321
cff8a460-9a51-4e99-b354-5e4a20ea2ec6	t	Kagasa	184f4780-eead-485b-8ec4-f7a421062f52
e75fb4eb-4f45-4e5f-a0b3-e1a180e2c27f	t	Kireka	184f4780-eead-485b-8ec4-f7a421062f52
0f99c9a5-955f-4e8d-aaaf-f071f0397955	t	Mparo	184f4780-eead-485b-8ec4-f7a421062f52
fa93b8d3-e241-4cef-9294-be1f76499db3	t	Mugina	184f4780-eead-485b-8ec4-f7a421062f52
ec82a540-4ddd-4808-b627-057bd2fe6b43	t	Gishari	c54c7b84-ec1d-4205-ac11-16f50e220b86
f81ec3f0-717a-467c-97b5-a5971cc01bab	t	Kona	c54c7b84-ec1d-4205-ac11-16f50e220b86
62279abf-1375-43fd-b118-69e5b3343e21	t	Ntasi	c54c7b84-ec1d-4205-ac11-16f50e220b86
48204055-4f61-4eaf-932a-f77aecca0fbd	t	Nyagisozi	c54c7b84-ec1d-4205-ac11-16f50e220b86
009998b2-1773-4b58-89e5-350de822360e	t	Rusoro	c54c7b84-ec1d-4205-ac11-16f50e220b86
b0251d46-15ec-4681-85b2-d2f6152aaf80	t	Busasamana	09572e7f-8686-4705-a1fc-f756076c5582
c66e36c2-10df-4958-bf8e-22b6ac57e671	t	Gihembe	09572e7f-8686-4705-a1fc-f756076c5582
b5cbe7ae-6856-4f5c-b41c-0c88c9afb4b9	t	Reramacu	09572e7f-8686-4705-a1fc-f756076c5582
a5d4ab46-1271-4d97-b5d0-c144d3224930	t	Bimomwe	26621101-4538-43e6-af87-b98ffa272999
e139340a-59af-4a33-b597-131b9c2e28d8	t	Shaka	26621101-4538-43e6-af87-b98ffa272999
fd9f4a0c-b29f-4184-8b6b-341d6c240d36	t	Kamayanja	5fb15cf8-4094-4ad4-bc81-e49ebdd40e0e
51a3484b-2e59-49c6-b37d-ba28ee094314	t	Nyarusange	5fb15cf8-4094-4ad4-bc81-e49ebdd40e0e
17d14637-2bf3-443b-b752-5a52a0814236	t	Nyarutovu	5fb15cf8-4094-4ad4-bc81-e49ebdd40e0e
eeae843b-7fad-4d89-8f7a-e3d30db0648b	t	Rubanga	5fb15cf8-4094-4ad4-bc81-e49ebdd40e0e
bb4161fc-e62b-4bd4-807d-9528cfc5ecf5	t	Gitega	3ff9d1ef-7381-4331-be6c-3e89e0fce7cb
9c04d280-9b54-4213-83ed-8b31b2859ed0	t	Munazi	3ff9d1ef-7381-4331-be6c-3e89e0fce7cb
375cc42f-51e4-48ad-ba2f-80bd5c643ad8	t	Nyagisozi	3ff9d1ef-7381-4331-be6c-3e89e0fce7cb
bc80f93c-2deb-42bc-9d2b-d7fb2f10a47e	t	Nyerenga	3ff9d1ef-7381-4331-be6c-3e89e0fce7cb
cc056215-5e7e-4bf8-b7c3-aa1f2b9335a9	t	Wimana	3ff9d1ef-7381-4331-be6c-3e89e0fce7cb
5ee44e30-2900-45ca-8a93-42998e1c5fde	t	Kabere	88d48a13-e8dd-4717-86f5-6763f6071fd6
0fa92c9c-5745-4cbf-b0b8-14515150f5f2	t	Kingoma	88d48a13-e8dd-4717-86f5-6763f6071fd6
f73b794b-df50-4b2b-8b12-38ed2ca5b557	t	Nyarubuye	88d48a13-e8dd-4717-86f5-6763f6071fd6
f6a4fb76-d9ec-485d-8e83-85dbd361a2ff	t	Ngoma	844fe150-3fbb-4994-8a08-2e1b57be0fea
a2d823b2-8b85-4f96-8d8b-f328c82fa889	t	Nkomane	844fe150-3fbb-4994-8a08-2e1b57be0fea
758ac0fc-df51-4b63-8023-5857fe1c63a4	t	Nyamirembe	844fe150-3fbb-4994-8a08-2e1b57be0fea
05b42bae-0c61-4cbc-924e-0c129281d7d8	t	Cyimigenge	1fde8906-84d0-4382-9719-550461936c25
8bd9ef5b-2543-4e65-a48e-be8651fd5a1b	t	Fukwe	1fde8906-84d0-4382-9719-550461936c25
454fad7e-ddbc-454e-9a38-0cc27d628d10	t	Musenyi	1fde8906-84d0-4382-9719-550461936c25
5bb935ae-fa9f-4913-9b80-57c85476b159	t	Raro	1fde8906-84d0-4382-9719-550461936c25
da7228f8-8137-44b2-919c-d6d2cbe99fb6	t	Bigobe	03ba493f-c611-4946-a53a-b73ccb55c9f8
bbebcf77-327a-466b-b213-1607dc7e6aca	t	Gatare	03ba493f-c611-4946-a53a-b73ccb55c9f8
b630a012-00be-4d24-bdce-e72ac0f01cbf	t	Gatwa	03ba493f-c611-4946-a53a-b73ccb55c9f8
ead03ea8-0e11-44f3-bf54-9539c561fcc6	t	Kabande	03ba493f-c611-4946-a53a-b73ccb55c9f8
e87a576e-60b1-499d-8c4c-d1ade508236b	t	Kajevuba	03ba493f-c611-4946-a53a-b73ccb55c9f8
7d23124d-ad0b-4dcd-98f3-172d6ba8610f	t	Munoga	03ba493f-c611-4946-a53a-b73ccb55c9f8
ee2aa0f0-1bfd-4c85-a03c-b3d1ed1d7bbf	t	Gahinga	fb8ab0b8-c0f9-454f-af95-5f876f1e9050
4afa4b27-c894-43e2-96c8-b4e4ca71fe30	t	Kabagogo	fb8ab0b8-c0f9-454f-af95-5f876f1e9050
1f413dd7-a4b0-406f-bfd2-9dff6777c4b0	t	Byenene	11c7cdc3-2443-4348-8f7c-3954067a1f85
e89e5dbf-3441-4cd4-a882-be7311dd9ae0	t	Karubanda	11c7cdc3-2443-4348-8f7c-3954067a1f85
8a43ead8-7a14-4910-b53b-ac48ff8a69cf	t	Murambi	11c7cdc3-2443-4348-8f7c-3954067a1f85
e3f6ef51-0b44-4c52-93e6-486d4e70f9c2	t	Nkimbiri	11c7cdc3-2443-4348-8f7c-3954067a1f85
79ab9134-e162-48f2-9bf8-4e5ccea49507	t	Bumbogo	e534c91f-0584-4bb8-b0d6-f42b64411bb7
181133a2-8342-42e9-a222-b131a5d0c47a	t	Buye	e534c91f-0584-4bb8-b0d6-f42b64411bb7
d46d08ac-2d94-4af7-8c74-44e4c3b5a050	t	Gacumu	e534c91f-0584-4bb8-b0d6-f42b64411bb7
00c83700-e78f-4d10-b621-a8ef9b40e93c	t	Kigabiro	e534c91f-0584-4bb8-b0d6-f42b64411bb7
95a75942-9796-4893-8d69-bde5353d21b8	t	Mukuyo	e534c91f-0584-4bb8-b0d6-f42b64411bb7
02a12f9e-2d73-408e-a8cb-380613a22b0f	t	Murehe	e534c91f-0584-4bb8-b0d6-f42b64411bb7
84a53caa-348e-4688-9899-5be736aa8402	t	Nkoto	e534c91f-0584-4bb8-b0d6-f42b64411bb7
fe1d3d21-55c7-44ed-8097-cdcf61959b18	t	Ruvugizo	e534c91f-0584-4bb8-b0d6-f42b64411bb7
8b5121ac-8412-46a0-a94b-feb79f33d577	t	Ruyumba	e534c91f-0584-4bb8-b0d6-f42b64411bb7
595122fe-325d-4d9b-88ba-19f5e25951d8	t	Umugarama	e534c91f-0584-4bb8-b0d6-f42b64411bb7
05d86e9d-0cf3-4c78-8e1e-e55d70a8554f	t	Kirehe	a1b90152-a6c2-4060-bad0-f23c486c18d0
0524fdf2-ecd1-421f-96fe-e52d5e531eec	t	Magu	a1b90152-a6c2-4060-bad0-f23c486c18d0
f3e0fda6-6302-43de-9e43-3943e0024826	t	Nyarubuye	a1b90152-a6c2-4060-bad0-f23c486c18d0
87bec5dc-6914-429f-94c3-77ded732fd9a	t	Rugarama	a1b90152-a6c2-4060-bad0-f23c486c18d0
8ec4233b-13e7-4237-9201-df86b8527e4f	t	Rugwiro	a1b90152-a6c2-4060-bad0-f23c486c18d0
b36da2e4-9a64-49e1-98a4-5d94b7cad938	t	Rwezamenyo	a1b90152-a6c2-4060-bad0-f23c486c18d0
e9b10900-3cfb-4032-8a2e-28ebae0dedcc	t	Sabununga	a1b90152-a6c2-4060-bad0-f23c486c18d0
5898ffd5-7252-4e69-849e-bb3843283ec2	t	Birembo	ce983105-e20d-47ae-af23-642c36ea0439
429fbef1-da11-4264-a22e-9cba6ab8a448	t	Kabeza	ce983105-e20d-47ae-af23-642c36ea0439
f1488076-839c-4d6a-914c-143b71c080de	t	Kayenzi	ce983105-e20d-47ae-af23-642c36ea0439
b93e686f-8639-45bd-acff-e7131be0d5c1	t	Mbayaya	ce983105-e20d-47ae-af23-642c36ea0439
ce548b1b-f054-4493-a17f-189bd5f6976f	t	Nyabubare	ce983105-e20d-47ae-af23-642c36ea0439
29b9bdf9-3b22-43e3-9f88-c74ff4063569	t	Nyamahuru	ce983105-e20d-47ae-af23-642c36ea0439
800f8ac3-ff00-44d1-a507-5faea379b788	t	Nyarugenge	ce983105-e20d-47ae-af23-642c36ea0439
fe8fdefe-ff89-4955-a23e-884818e7872c	t	Nyaruhengeri	ce983105-e20d-47ae-af23-642c36ea0439
48343112-427f-44c3-83d5-3620b5497884	t	Wimana	ce983105-e20d-47ae-af23-642c36ea0439
0150d4fc-e080-4107-bfe2-dba0b139d064	t	Buhoro	f2f87bd6-1c3a-43de-b7d7-48d0bf47dd2f
8ed382d5-9db6-492f-be8f-d2ad772b64b3	t	Gitega	f2f87bd6-1c3a-43de-b7d7-48d0bf47dd2f
ca1ad274-2ed3-40c3-bf25-f3c91b6d0e5c	t	Kabahazi	f2f87bd6-1c3a-43de-b7d7-48d0bf47dd2f
50d6d09f-2761-4611-9dab-d7b0e818846f	t	Kamabuye	f2f87bd6-1c3a-43de-b7d7-48d0bf47dd2f
ca2c9a27-2506-4082-84a1-69b408b80bc3	t	Kinanira	f2f87bd6-1c3a-43de-b7d7-48d0bf47dd2f
515ac517-91d7-4f2c-a118-baac82c37517	t	Kivugiza	f2f87bd6-1c3a-43de-b7d7-48d0bf47dd2f
4cf30593-aff3-4bb6-8d20-4f25ded465aa	t	Munyinya	f2f87bd6-1c3a-43de-b7d7-48d0bf47dd2f
f6ce595d-86ca-466d-ada4-2f4b9d5bb75c	t	Rwankeke	f2f87bd6-1c3a-43de-b7d7-48d0bf47dd2f
0ae1dbb6-889d-444b-9e1a-201ffab3d80d	t	Mugereke	3d1e96dd-b4f1-42a2-ac21-fad6f7a74b4c
abb47044-39bd-4a8b-895e-e4bbc9224a75	t	Nyabitare	3d1e96dd-b4f1-42a2-ac21-fad6f7a74b4c
539905f2-547c-4b09-83fd-7b29969a9706	t	Kirwa	95aa2f0e-10e0-4d6d-a203-b6f4a94ba672
67e063d1-30ba-438f-af7b-d0a45a816935	t	Nyagihamba	95aa2f0e-10e0-4d6d-a203-b6f4a94ba672
a2790e42-c15e-4c0e-aac3-ae172a0ded96	t	Ruseke	95aa2f0e-10e0-4d6d-a203-b6f4a94ba672
095e69a3-47ae-4fc7-955c-97ae2deae38d	t	Kigarama	d5449ce2-6811-4ecf-b459-c010f58995c2
16ff18c8-305d-4793-89ac-749c08a57ae7	t	Kintama	d5449ce2-6811-4ecf-b459-c010f58995c2
83598d94-9ba3-450e-b94d-a1ddb83a8b8b	t	Rugarama	d5449ce2-6811-4ecf-b459-c010f58995c2
4b43b322-7ab9-4406-a73d-04a1d55b581b	t	Ngendo	e408f673-b9d7-4ff6-9ac8-7cd97faa0afa
2593af99-7a9a-4932-b781-f45fc2ae82b9	t	Tare	e408f673-b9d7-4ff6-9ac8-7cd97faa0afa
fdca5df2-e28c-43c3-bdd7-c43c22a8bcae	t	Buhunga	0b9072a0-837c-41ec-8703-9d593698ba8e
2de5288f-c192-4f07-96e0-c49519393e60	t	Gatagara	0b9072a0-837c-41ec-8703-9d593698ba8e
359e9e5f-de09-4fce-bdef-b74129153fa8	t	Gitega	0b9072a0-837c-41ec-8703-9d593698ba8e
aee25cdb-2fe6-4606-8e1d-5e7dd96f2ab6	t	Bikamba	8a7230a9-2df4-4770-a1df-5cb610b2a1be
d72dd576-bfbd-4e33-8a90-5985fa250ee1	t	Kigese	8a7230a9-2df4-4770-a1df-5cb610b2a1be
3c60ea59-b012-4310-a905-4121ffe0dfd0	t	Kirega	8a7230a9-2df4-4770-a1df-5cb610b2a1be
261a88d6-c383-432d-8c69-23a6abb10532	t	Mibirizi	8a7230a9-2df4-4770-a1df-5cb610b2a1be
769d5e22-7651-4ecd-b487-aefd7f14848e	t	Rugarama	8a7230a9-2df4-4770-a1df-5cb610b2a1be
5fc26d47-d6ed-4695-80db-473e64caf984	t	Masaka	dc43b606-76f3-4d0f-84a5-0522f257c7bf
4de2b184-7527-49b9-a648-21b12d5e8ae4	t	Mpungwe	dc43b606-76f3-4d0f-84a5-0522f257c7bf
d0730b79-1b62-459c-b162-97ad8fa84fc6	t	Ruramba	dc43b606-76f3-4d0f-84a5-0522f257c7bf
6c5adc61-5f78-4c74-a7ca-04cad3cc7ef7	t	Taba	dc43b606-76f3-4d0f-84a5-0522f257c7bf
65dea860-a588-4ad8-84d2-a38b0ab7c9ee	t	Kabarama	31fc1286-ef4d-4ca6-87da-fcae8abc6979
269fd54d-ab92-4b1d-81bd-df45c08b05e8	t	Nzagwa	31fc1286-ef4d-4ca6-87da-fcae8abc6979
7cf26712-c258-4e16-99aa-8fae1d027c27	t	Remera	31fc1286-ef4d-4ca6-87da-fcae8abc6979
d8b028fc-129f-4da1-b5e5-c9054a5aefe3	t	Ruhogo	31fc1286-ef4d-4ca6-87da-fcae8abc6979
633b5551-d5ad-4df0-8a35-9b1b7b6eb14c	t	Samuduha	31fc1286-ef4d-4ca6-87da-fcae8abc6979
a4c5d485-579b-4214-b979-295838400c57	t	Kagangayire	da777c48-65e8-44a9-846e-1d0177b6309f
1909e6aa-3065-4113-be9f-bf01dddeb798	t	Karehe	da777c48-65e8-44a9-846e-1d0177b6309f
816e44cc-32f7-4286-9ed3-d9275728b4e6	t	Kigarama	da777c48-65e8-44a9-846e-1d0177b6309f
3bd8ebfc-5856-46ca-9590-30672c85633f	t	Ntebe	da777c48-65e8-44a9-846e-1d0177b6309f
3db910d8-0017-4ad7-a9de-1fb543c981d8	t	Bugoba	445d3be4-30f8-47fe-a102-9748c00a5c41
7b29a351-c4c2-43a0-a88f-6d64add421ff	t	Gatare	445d3be4-30f8-47fe-a102-9748c00a5c41
324b40ac-a1e5-4036-9f38-d24b87011f5c	t	Kabuga	445d3be4-30f8-47fe-a102-9748c00a5c41
5fb87db0-f508-4913-b3f9-c3bedef5aab5	t	Nyarurama	445d3be4-30f8-47fe-a102-9748c00a5c41
5fa598bb-4d01-4d3b-8f3e-5aea7d5f5f78	t	Nyenge	445d3be4-30f8-47fe-a102-9748c00a5c41
4846534b-7edf-44d8-b24e-79bf4a1d781d	t	Buguri	f6963b1b-7c8a-424c-8257-175ce7b28b26
55ca7aee-bcef-417b-8677-e198b38e1896	t	Nyabuvomo	f6963b1b-7c8a-424c-8257-175ce7b28b26
b9cf399f-dd87-4ad6-b166-804f97a7bb28	t	Nyagasozi	f6963b1b-7c8a-424c-8257-175ce7b28b26
a147f793-433f-4c44-babe-da84c165ce4b	t	Nyakabande	f6963b1b-7c8a-424c-8257-175ce7b28b26
c8f275d1-4b7d-49a0-bde9-7cacca883b40	t	Ruzege	f6963b1b-7c8a-424c-8257-175ce7b28b26
1c11239a-78b1-4ea2-af2b-88a5224313ab	t	Tunza	f6963b1b-7c8a-424c-8257-175ce7b28b26
361454ef-4f89-4424-84be-747fb70e7ab4	t	Gahungeri	4e2a2ffe-2463-48f8-837d-b753fd75eb6d
a685f8fd-b962-4f10-a73d-7b343d7d3ac5	t	Gishyeshye	4e2a2ffe-2463-48f8-837d-b753fd75eb6d
66784204-437e-483a-b001-3d2201e1d3b0	t	Murambi	4e2a2ffe-2463-48f8-837d-b753fd75eb6d
456a6fd4-826b-4d39-90a5-f4e0d1a6d2f8	t	Nyamabuye	4e2a2ffe-2463-48f8-837d-b753fd75eb6d
6b3c4cb1-5781-49cc-a942-a6fa9e1f8681	t	Rubare	4e2a2ffe-2463-48f8-837d-b753fd75eb6d
9d33b5a3-ea14-46b4-9d1c-5454c95e2e34	t	Kabagabo	cab991bd-4a40-44a2-9761-697df5901caa
3bfba4f2-ea52-4a7e-bf21-741f6c1ae8fd	t	Mubuga	cab991bd-4a40-44a2-9761-697df5901caa
c1cba573-b992-42df-b94b-4103c733920b	t	Rushikiri	cab991bd-4a40-44a2-9761-697df5901caa
6b6c6666-eecc-4723-a1b4-0a5ef16f677a	t	Uwingando	cab991bd-4a40-44a2-9761-697df5901caa
ab76be90-b032-400a-933c-9c0114d5ddf5	t	Gafonogo	281f4739-0030-49c4-b87b-01199473a908
d4bdc74d-ea8d-4d99-962e-1491e487fb2e	t	Mwirute	281f4739-0030-49c4-b87b-01199473a908
4e451578-52d1-476b-a3a0-156a58daaa21	t	Nyarusave	281f4739-0030-49c4-b87b-01199473a908
69ef9ded-ed87-4097-9d3b-35bf95d6a813	t	Rubuye	281f4739-0030-49c4-b87b-01199473a908
0a1ff096-805f-49af-80a7-d3e005ce64b8	t	Rugarama	281f4739-0030-49c4-b87b-01199473a908
d1053189-da99-467d-a3b2-04619b848596	t	Kabande	28d0f27c-60b3-43cf-8c1c-321ad023bd59
081ddae3-729a-4ca9-9c51-66dbebde75f5	t	Kanyinya	28d0f27c-60b3-43cf-8c1c-321ad023bd59
fd36e1e6-67fb-4133-805d-f9af43f4e4f2	t	Mbizi	28d0f27c-60b3-43cf-8c1c-321ad023bd59
09bdb74e-156c-42df-8e52-99e79d0226b7	t	Bukokora	00658efd-ffa9-410c-b126-4e401840c74e
599c0c6a-092e-412f-b1b3-50c01f9e403a	t	Karuri	00658efd-ffa9-410c-b126-4e401840c74e
cb52e0e0-4622-4df0-834d-07866480a376	t	Nyarusange	00658efd-ffa9-410c-b126-4e401840c74e
7a71c458-f9c0-4cad-92be-7d1c485a5ff8	t	Nyirabihanya	00658efd-ffa9-410c-b126-4e401840c74e
718cfe3d-de7e-4f45-9d71-f46ba5b99e97	t	Taba	00658efd-ffa9-410c-b126-4e401840c74e
5ba4ec17-662b-4dea-8c06-025648026cf5	t	Bikimba	a8e4abc9-3b2d-4c5b-908b-94adac0e6d86
b63627f6-5340-4c0a-8a7c-a818eda2c215	t	Bimba	a8e4abc9-3b2d-4c5b-908b-94adac0e6d86
f998422a-a702-4e13-af3b-e4156743137c	t	Nyagatare	a8e4abc9-3b2d-4c5b-908b-94adac0e6d86
baeff6c2-0465-420c-bccf-7a54bedc77ea	t	Ruyigi	a8e4abc9-3b2d-4c5b-908b-94adac0e6d86
43b4cb8c-7440-4d79-9f67-9c920a131482	t	Kabagesera	5e664266-d072-4730-85ac-d622ef110370
7f7d84ff-9089-4fc2-8fe8-25e1141172e7	t	Muhambara	5e664266-d072-4730-85ac-d622ef110370
2faade9c-079f-465c-8c2e-fedf8968829d	t	Rubuye	5e664266-d072-4730-85ac-d622ef110370
2fe87bab-25df-4cd1-9d94-a810de100db2	t	Gasharara	20dd6724-7d0b-4c06-8c2a-31529272e2cf
09134b9e-4fe9-4284-b4aa-feac227ad1bd	t	Kagina	20dd6724-7d0b-4c06-8c2a-31529272e2cf
cd88fd75-86e8-4670-89de-28e785a9193b	t	Kigusa	20dd6724-7d0b-4c06-8c2a-31529272e2cf
ab845396-738c-4427-a356-fb93758d37ad	t	Musebeya	e8c6d8e4-d972-4087-a4d2-4acfaf9955a5
40d17d17-2d8f-429c-9214-6bc4a7eec81b	t	Nyagacyamu	e8c6d8e4-d972-4087-a4d2-4acfaf9955a5
56f8ac62-be8d-4723-b66c-19e75ae6ce46	t	Rubona	e8c6d8e4-d972-4087-a4d2-4acfaf9955a5
99483c9c-5e9b-49fd-a89f-b2380995af99	t	Kibaya	a34c9fc5-797c-46eb-a618-47c5a3282d97
7d16c5bd-b8eb-4fa5-bf06-450db1161e13	t	Nyagacaca	a34c9fc5-797c-46eb-a618-47c5a3282d97
3d60c33a-e90e-4253-b27b-6f7e84bb456e	t	Rubumba	a34c9fc5-797c-46eb-a618-47c5a3282d97
a54cf1c2-c37f-4ce9-bfaa-bd244db0ccc4	t	Rugazi	a34c9fc5-797c-46eb-a618-47c5a3282d97
8662bfd3-5b65-423f-9c4e-c20615e643c4	t	Mbirizi	95b77d2e-0171-4203-9997-55bf284a60d4
f38e8ac7-69d0-47c2-9114-104dc5689787	t	Rwinkuba	95b77d2e-0171-4203-9997-55bf284a60d4
e85ec6c4-98d5-4a81-83b5-f898138770e3	t	Buruba	8c38ff83-875c-4326-8e2a-fa7b9694989e
4773e93d-52fb-421a-b281-014c4aacfc34	t	Busozi	8c38ff83-875c-4326-8e2a-fa7b9694989e
ee7d87fb-2cf6-47cf-a3eb-abca0db6c60c	t	Bwirika	8c38ff83-875c-4326-8e2a-fa7b9694989e
2491f445-87e4-4a0f-b3b8-dd842ebb2b6d	t	Takwe	8c38ff83-875c-4326-8e2a-fa7b9694989e
20ebe53d-f5aa-49c1-be96-c2921ab251f4	t	Kigaga	03cca771-ccc7-482a-8379-70cadbb850fd
ec4f41a9-a8f4-4e0a-8d86-9123d4fa8012	t	Rwamugoroba	03cca771-ccc7-482a-8379-70cadbb850fd
c14a67f7-9de5-4024-9b7b-d172f18e9b39	t	Buhoro	59bec503-ea3e-4087-80c8-099195c4f21a
f43689c4-5a93-46e2-9350-48969efa97ce	t	Gahembe	a4fa5f0e-656c-476f-a8d6-c5ee63fc97c2
95725642-87fe-4354-bbc2-ad0922af371e	t	Gahinga	a4fa5f0e-656c-476f-a8d6-c5ee63fc97c2
557953b6-7f81-4fde-a921-938836993140	t	Kabayaza	a4fa5f0e-656c-476f-a8d6-c5ee63fc97c2
cc7a2f96-48e9-44c9-8f6a-2fb26b3fdbe8	t	Kirambo	a4fa5f0e-656c-476f-a8d6-c5ee63fc97c2
abf12357-fdfd-4dc5-8775-de0420173ca7	t	Musasa	a4fa5f0e-656c-476f-a8d6-c5ee63fc97c2
abe7a720-4961-4d45-bd4a-6d49ddd1a489	t	Gihinga	61ced810-662e-4539-a3bc-3300be76c950
02dd00b5-968a-40ae-a9a7-8a152d5a3f54	t	Karambo	61ced810-662e-4539-a3bc-3300be76c950
e7e09d67-9faa-41f5-be84-451ff1e50585	t	Nyirabwayi	61ced810-662e-4539-a3bc-3300be76c950
1859161a-235b-4ba1-b431-7557120787df	t	Kabuga	63b432ad-a3c3-4a3e-b42c-e357a7c68506
5ea95571-b970-4376-a132-d7152860a298	t	Peru	63b432ad-a3c3-4a3e-b42c-e357a7c68506
addc0d8e-eec1-4fc9-86f1-78b621429e0d	t	Gasave	2c70fd7b-43a8-45b1-91a6-fcd5d7273230
f2657ffd-d438-47db-bccd-feba56510348	t	Gasiza	2c70fd7b-43a8-45b1-91a6-fcd5d7273230
3b44f568-e105-48d0-b42c-2261ae76193d	t	Kabuga	2c70fd7b-43a8-45b1-91a6-fcd5d7273230
2fc5a1dd-21fa-4c73-ba12-107d241e417a	t	Rebero	2c70fd7b-43a8-45b1-91a6-fcd5d7273230
0d31f30b-0805-4c14-98c6-631809b77ef0	t	Rukoma	2c70fd7b-43a8-45b1-91a6-fcd5d7273230
bf3ec638-8e3d-49aa-b763-3e4cc39793ad	t	Kamiranzoger	ba9d20e8-d065-408d-be91-71c79cb29c77
6e52566c-c65e-4fcb-adb0-bf8ddefba41d	t	Karambo	dec6aa0c-abfe-4fa8-9996-aa564e81f9f9
6b91fcec-aa9a-47a9-b9d2-943a358195be	t	Cyambari	2c73c255-c2b0-4311-9519-e8e42ce6f024
32d04370-a0ee-4026-97a0-9bf38fdaef97	t	Gitwa	2c73c255-c2b0-4311-9519-e8e42ce6f024
83180088-fbdb-41dc-b7c3-6d966fb83470	t	Nkegete	2c73c255-c2b0-4311-9519-e8e42ce6f024
0b60ff90-cb90-41d3-918a-19f2064971c6	t	Nyarunyinya	2c73c255-c2b0-4311-9519-e8e42ce6f024
810a8e13-828d-4179-844a-004ac43052b3	t	Peru	2c73c255-c2b0-4311-9519-e8e42ce6f024
d8e68197-dc0d-403c-946d-e33fbb17261c	t	Karambi	5e6aa3a6-b7a3-4cde-905f-21398877d251
72db1071-8726-4f1f-9bee-1a41ab9bbaf0	t	Muduha	5e6aa3a6-b7a3-4cde-905f-21398877d251
112eca0f-a7fa-44a7-ae21-4ec12e29c05a	t	Musenyi	5e6aa3a6-b7a3-4cde-905f-21398877d251
0a6c506e-c73f-4933-93b0-9ca92decb448	t	Ruramba	5e6aa3a6-b7a3-4cde-905f-21398877d251
98a85b19-aa37-40be-88df-267c44b8ff85	t	Cyakabiri	a4193cb1-dee8-4b6e-9dec-352ab698312c
80aa8a05-2bd7-4a2d-a0fa-f05c59fc1a8e	t	Kagahina	a4193cb1-dee8-4b6e-9dec-352ab698312c
553fe81d-76ff-4439-bde8-28ba2212be9c	t	Kagitaba	a4193cb1-dee8-4b6e-9dec-352ab698312c
ca425181-cb0d-48fd-b2a7-54f07117a518	t	Nyanza	a4193cb1-dee8-4b6e-9dec-352ab698312c
b2e5019e-b895-458e-9e22-1c6f5ca4e7bd	t	Sabusaro	a4193cb1-dee8-4b6e-9dec-352ab698312c
c1b6a3ee-12cf-4e99-a872-aa3d288a2d33	t	Busumba	7ad849ff-67c2-4316-9962-21480f337285
c0f668c7-1c15-4c68-81b2-c67031d422f8	t	Gatwa	7ad849ff-67c2-4316-9962-21480f337285
e23a7c57-a5b2-471f-9e62-3f8ccdb2f060	t	Mubuga	7ad849ff-67c2-4316-9962-21480f337285
ee5285c3-949b-4af8-9704-360949899d12	t	Nundwe	7ad849ff-67c2-4316-9962-21480f337285
2acb59b8-c821-4c2f-bc0e-411cba5677e0	t	Busindi	809b1dbb-cde3-464d-987c-6475aa11e714
a1424253-9567-4857-bc82-f6329e402221	t	Kabuga	809b1dbb-cde3-464d-987c-6475aa11e714
90128c3b-0ea6-4fec-893f-9351d7cb6d2c	t	Matovu	809b1dbb-cde3-464d-987c-6475aa11e714
8499b65f-968d-491d-bd48-283b8c6888d5	t	Munini	809b1dbb-cde3-464d-987c-6475aa11e714
e806631e-fb42-4f63-aea6-c2eb57d6fd07	t	Musagara	809b1dbb-cde3-464d-987c-6475aa11e714
98146190-0529-45ea-9cbb-a90ffe368539	t	Nyamirambo	809b1dbb-cde3-464d-987c-6475aa11e714
b0364bc3-b434-46d5-a939-5c4c3b629a1b	t	Mataba	2bcc094e-be15-485d-bb60-a79b631dffb1
5413eb30-944f-42f1-bd09-c95bc176f32b	t	Gasenyi	183afc7a-7fb8-436b-a3d9-f5eaa56ccb78
b2942135-ca4e-4972-acf2-9719f19c1722	t	Kamazu	183afc7a-7fb8-436b-a3d9-f5eaa56ccb78
3115a17a-f917-4dbd-980a-2e278803e65c	t	Gasaka	c201d97b-217f-4718-a0c1-73741004f881
8520537d-c4d5-4dd7-9bfb-000a7a670f24	t	Gitima	c201d97b-217f-4718-a0c1-73741004f881
0f618956-515b-4784-bdc9-e71e55c58190	t	Kivomo	c201d97b-217f-4718-a0c1-73741004f881
886e9ca7-f3fe-415b-8725-e1487c7234b6	t	Nyahinda	c201d97b-217f-4718-a0c1-73741004f881
39f1e3a9-389c-4de0-9497-63b6b1b40142	t	Cyarubambire	e1797c34-9374-49ee-8c36-d7d92ce87c81
12450f9e-c2fb-46db-a9a9-70ad9636a1fd	t	Gataba	e1797c34-9374-49ee-8c36-d7d92ce87c81
e2baed37-ef7c-4a78-bcd1-37f4ce5d518a	t	Gitwa	e1797c34-9374-49ee-8c36-d7d92ce87c81
c6aac070-2aa7-4c38-a3c2-e2eab92765a2	t	Kabeza	e1797c34-9374-49ee-8c36-d7d92ce87c81
1a3897c1-0d57-4cec-8a6a-82f9fd25245a	t	Kabare	936716f5-8708-4f3f-bf8e-6c6e95b95dc9
5857c604-425b-460a-862e-c09b52205c75	t	Kiyoro	936716f5-8708-4f3f-bf8e-6c6e95b95dc9
951f1913-91a7-456e-98f7-7f5648ec78d3	t	Rwinkindi	936716f5-8708-4f3f-bf8e-6c6e95b95dc9
31781fe5-1690-4806-b237-4500dbcfd761	t	Gisovu	a43b5d09-1a58-46d8-89c2-38ecd9ef42e4
1312d401-a2fc-4193-a205-3a0bd1d77aa3	t	Hanika	d5887628-3ff8-4cd3-9b3d-41de198bd73b
be881e1c-9734-4e79-98fb-5354439fed20	t	Kivumu	d5887628-3ff8-4cd3-9b3d-41de198bd73b
6ebee4d8-1db1-4809-980c-c4591fd46c6f	t	Rubona	e1b2e68f-a330-4022-b28b-745782257908
3bc16c1a-3c3a-492e-9310-23f93a7e46f9	t	Nyamasheke	3b8124f0-5a95-49db-91ff-a937e1ebfb0d
3bde0978-2e64-4c71-8f17-305680f3018e	t	Nyanza	3b8124f0-5a95-49db-91ff-a937e1ebfb0d
8d8b7560-0e8e-4c6d-addc-28708e2693f6	t	Gitwa	c71e7de2-dd62-4a8d-801a-35b8811b940e
197d3ff9-d98e-4231-9f83-4c3616b12aac	t	Mugeni	c71e7de2-dd62-4a8d-801a-35b8811b940e
e899d65b-9419-491d-a541-fe0ffa0c3906	t	Gihuma	6a1e3211-9aef-42a8-86fe-3ac29cea24ac
b0a2429c-8e75-4534-b150-d196d9934112	t	Kamazuru	6a1e3211-9aef-42a8-86fe-3ac29cea24ac
c5dd6704-b813-4f02-ab23-e8114fc9ed1b	t	Kavumu	6a1e3211-9aef-42a8-86fe-3ac29cea24ac
c363e957-870f-4b09-8b24-199fd6071da4	t	Nyarucyamu I	6a1e3211-9aef-42a8-86fe-3ac29cea24ac
531f3dc7-b354-4efa-991c-d2b2d73eaa5f	t	Rutenga	6a1e3211-9aef-42a8-86fe-3ac29cea24ac
58594f9b-e237-40eb-a385-2f9f656ad830	t	Ruvumera	6a1e3211-9aef-42a8-86fe-3ac29cea24ac
e2e2e70c-aca8-42ab-95c4-51c50cbc3731	t	Gifumba	ebb6a7c4-66d0-4486-971f-01362692c4d4
ef3aa9a0-a989-4e6c-bb8a-86695a4e0776	t	Gisiza	ebb6a7c4-66d0-4486-971f-01362692c4d4
2d1a2a01-a6f0-44bb-9ee2-7be920d7c4bf	t	Kirebe	ebb6a7c4-66d0-4486-971f-01362692c4d4
69222e98-63d9-4bef-8322-0e7411072d7b	t	Rugarama	ebb6a7c4-66d0-4486-971f-01362692c4d4
198f5d83-3597-4251-a156-995c7ae6cfaf	t	Rutarabana	ebb6a7c4-66d0-4486-971f-01362692c4d4
e1da197d-703c-448d-b0d0-1effa976756b	t	Samuduha	ebb6a7c4-66d0-4486-971f-01362692c4d4
489f0f5b-7f36-42f7-93ee-e8f8c33a47a4	t	Kagitarama	d91d5dc5-2b37-4013-a1ba-607521ced68f
922c10e1-f901-4388-8e10-6c0dc6bf9ee6	t	Kavumu	d91d5dc5-2b37-4013-a1ba-607521ced68f
97df56fb-b891-4947-af10-33d11a163d15	t	Nyabisindu	d91d5dc5-2b37-4013-a1ba-607521ced68f
5081a504-34b1-4b82-8d2e-1fc9eb5038e5	t	Biti	fd46b2aa-65aa-452a-a713-67c190e5d7da
21fbef2b-abab-4486-801e-5206ec8ef16c	t	Gasenyi	fd46b2aa-65aa-452a-a713-67c190e5d7da
0e88ae5d-5fe9-465c-989d-4943e125684b	t	Gasharu	fd46b2aa-65aa-452a-a713-67c190e5d7da
824ba488-8cba-4825-bc46-05be7088296b	t	Kirenge	fd46b2aa-65aa-452a-a713-67c190e5d7da
884976c1-0baa-4f44-b19c-44cd23c65e44	t	Munini	fd46b2aa-65aa-452a-a713-67c190e5d7da
dbb5a121-e754-4f5c-89e5-54072e4ba2a2	t	Nete	fd46b2aa-65aa-452a-a713-67c190e5d7da
5ce9df13-0cff-4db7-b096-6e7250e98b6b	t	Nyakabingo	fd46b2aa-65aa-452a-a713-67c190e5d7da
d1bdb1b7-faa9-47c5-8db6-58c2c9f98df9	t	Gasave	83d665b8-74da-4411-9d51-60f615073c5c
98fc383b-f2db-4359-b405-e9db94dcc006	t	Gasharu	83d665b8-74da-4411-9d51-60f615073c5c
f59b98da-e43a-42e3-8959-be67634fa4bf	t	Karehe	83d665b8-74da-4411-9d51-60f615073c5c
a85fba23-1f61-4231-afb0-b7ce10a35d4d	t	Ntenderi	83d665b8-74da-4411-9d51-60f615073c5c
f31928e4-6eba-4abf-b7d2-74e83b78f935	t	Nyarushora	83d665b8-74da-4411-9d51-60f615073c5c
e34f79bb-e102-4b68-a7b9-c4b6d0686781	t	Cyiciro	b1bcad2a-7da6-436b-8c88-2b1d63522563
b5d557c3-cc20-4a85-ae08-1cc48adf7b80	t	Kagarama	b1bcad2a-7da6-436b-8c88-2b1d63522563
24f60375-a5ff-4f2d-8e30-8572610b6246	t	Murambi	b1bcad2a-7da6-436b-8c88-2b1d63522563
59f35b8d-52f8-44cb-9e4d-ea7cc15235cc	t	Gitega	d75d499a-a88e-4771-81a7-c19289396e49
3587f669-7566-4ded-bca2-289eb26fe972	t	Remera	d75d499a-a88e-4771-81a7-c19289396e49
aab2d96b-99c6-4b5c-bce4-dec50861c899	t	Rukamiro	d75d499a-a88e-4771-81a7-c19289396e49
8ab2574c-0ac9-45e2-b701-4dc7f729bb59	t	Mututu	a8615151-09b0-4d46-9d92-cc144b2eb0d2
c81ea611-dce3-46c5-b962-a7511209ba8c	t	Rukurazo	a8615151-09b0-4d46-9d92-cc144b2eb0d2
d173471e-ca3c-4db4-a58f-8761afdede19	t	Rwambariro	a8615151-09b0-4d46-9d92-cc144b2eb0d2
68b2a62e-5183-4005-bfb9-5fb18608d8ce	t	Fumbwe	4660c564-2633-42af-a1d7-2228eb2abfe4
9dddb25b-c1ed-497f-9adb-00c12bc13a28	t	Gasharu	4660c564-2633-42af-a1d7-2228eb2abfe4
96ec9676-dd6f-4487-88b3-07e87f8050ee	t	Kidahwe	4660c564-2633-42af-a1d7-2228eb2abfe4
bc5c49e2-fa7e-454e-9667-bb2d7b7dfb8a	t	Murehe	4660c564-2633-42af-a1d7-2228eb2abfe4
07f097e8-556e-4aef-9d95-2d85606f1838	t	Musenyi	4660c564-2633-42af-a1d7-2228eb2abfe4
d4b8735a-7d63-4367-974f-b2a8e3183435	t	Nyabugombe	4660c564-2633-42af-a1d7-2228eb2abfe4
c26de84f-cd15-4055-a1ae-0a161094fab0	t	Gituza	9f2db773-821d-4f79-97c4-1b54563267c9
2cd969a5-2ba4-4172-abf3-8bbfc802cfd3	t	Karama	9f2db773-821d-4f79-97c4-1b54563267c9
5390b0fd-a24c-4b95-b59d-d2c14ba749f3	t	Nyamiyaga	9f2db773-821d-4f79-97c4-1b54563267c9
7c77e41d-fd02-4aac-94bd-854324079ec1	t	Gifurwe	906a133a-1daa-4c7a-9440-cbd97b64e1d9
ea5a63ca-3cf4-480a-b14e-fc3348ccc2b3	t	Gitwa	906a133a-1daa-4c7a-9440-cbd97b64e1d9
e9c3eb50-0efe-48c5-afef-612fe6118632	t	Nyabikenke	906a133a-1daa-4c7a-9440-cbd97b64e1d9
6e15dab0-5b46-4d50-b914-743c2b99a638	t	Nyagasozi	906a133a-1daa-4c7a-9440-cbd97b64e1d9
f225885e-2774-46d8-93b1-d7b5317095bf	t	Gisoro	ed8b57ee-27d6-449a-a375-610d81f59437
b8cd4abc-946e-4df2-80cf-7fbd3da5e937	t	Kabakungu	ed8b57ee-27d6-449a-a375-610d81f59437
d1c55e44-b3e4-4227-b5f9-d7e982608276	t	Karambi	ed8b57ee-27d6-449a-a375-610d81f59437
6c22c558-b2c0-4b83-be33-fffe11f70c19	t	Mugwato	ed8b57ee-27d6-449a-a375-610d81f59437
1c7223c8-1eb6-47e9-8e7e-bf48dd713dd1	t	Ntarabana	ed8b57ee-27d6-449a-a375-610d81f59437
ec67ccd1-fba0-4f57-b0e8-cbd771939a1e	t	Rugogwe	ed8b57ee-27d6-449a-a375-610d81f59437
6925679d-9dfd-44fd-be4c-e28676a15d53	t	Rwamure	ed8b57ee-27d6-449a-a375-610d81f59437
a493594f-b4b8-46e6-a83b-d5e6c1208180	t	Kondo	9f9037a8-16a2-4104-9428-ce4ab7489519
15b8b103-34e4-4b47-9550-9074ea732893	t	Muyebe	9f9037a8-16a2-4104-9428-ce4ab7489519
54b041b5-1e4e-4917-99f1-69e8329d70ba	t	Rukoma	9f9037a8-16a2-4104-9428-ce4ab7489519
2950d259-4b97-4bc7-9af4-cd601dcb65fd	t	Gasharu	e153a879-cce2-44e6-aef5-9b9b42d879e5
ca9f189f-c065-4194-b240-e69eb0636cad	t	Nyagasozi	e153a879-cce2-44e6-aef5-9b9b42d879e5
6b4fb01f-ba19-4d4f-8947-0416ad265d37	t	Ngando	0f5b7db9-95ce-4dc1-ac0b-75857460061c
bbf47432-5dc2-4635-a7b8-be3c7d9424d0	t	Nyundo	0f5b7db9-95ce-4dc1-ac0b-75857460061c
76290709-fbd2-4fe2-99e7-60da1285c3fb	t	Twabumbogo	0f5b7db9-95ce-4dc1-ac0b-75857460061c
f558159d-05e8-44bd-ac5e-e78ca1352a36	t	Gatare	1b39ca5d-d6a0-4b52-8837-33aaf6bc998c
60347a4c-61b5-4396-a8e3-71eed466776f	t	Kabungo	1b39ca5d-d6a0-4b52-8837-33aaf6bc998c
69508e8d-f554-4796-b5bb-5ce91cbfdd53	t	Kinyami	1b39ca5d-d6a0-4b52-8837-33aaf6bc998c
e8e5798b-5e4b-43e9-b99e-d4caba35a6e7	t	Musezero	1b39ca5d-d6a0-4b52-8837-33aaf6bc998c
43e96bd7-60d6-460d-bcbf-bedf3e076a7a	t	Nyakabingo	1b39ca5d-d6a0-4b52-8837-33aaf6bc998c
9350cb41-042c-4374-ae45-e8a4793eecfb	t	Nyakaguhu	1b39ca5d-d6a0-4b52-8837-33aaf6bc998c
66096451-0f3e-4e0f-a386-083e84dada1c	t	Buriza	cd13198a-7b86-4f41-8447-d7899fa4f03d
b029f4c8-d6f2-4d5a-8e52-e9e39995f9d3	t	Muremberi	cd13198a-7b86-4f41-8447-d7899fa4f03d
a9af0ced-a2ee-4c4e-83f2-7396045d3e7d	t	Rubugurizo	cd13198a-7b86-4f41-8447-d7899fa4f03d
3fc0789f-8877-406e-8713-3786216a193e	t	Songa	cd13198a-7b86-4f41-8447-d7899fa4f03d
38ebe7b5-07b6-4680-b104-921c4530d6b6	t	Vunga	cd13198a-7b86-4f41-8447-d7899fa4f03d
743c92da-90f9-401c-a299-3f17f008e606	t	Gakomeye	c16cd61b-cea6-4382-a519-dbd40a0b2498
0b279cff-7251-420c-8f52-a54b5b8dbcd9	t	Gasharu	c16cd61b-cea6-4382-a519-dbd40a0b2498
02b38b7f-6766-47b6-a542-e72024e0e8b3	t	Kigarama	c16cd61b-cea6-4382-a519-dbd40a0b2498
9bec5af7-7ba6-485a-b89c-19b399cae8d2	t	Mapfundo	c16cd61b-cea6-4382-a519-dbd40a0b2498
58f75dee-a44d-4e88-aa5f-559ce74b176e	t	Nyarucyamu	c16cd61b-cea6-4382-a519-dbd40a0b2498
a1c9ff0e-2eeb-4b7b-bc85-10170aca4291	t	Rwamaraba	c16cd61b-cea6-4382-a519-dbd40a0b2498
083f2556-537d-4216-8423-cb3f18bf9d9e	t	Kabeza	1d3f9ad5-b3c3-46f4-bcc2-a26fa5ba490e
a9b748c3-e55e-46ab-92a4-fd4458ab407d	t	Karama	1d3f9ad5-b3c3-46f4-bcc2-a26fa5ba490e
cbd5db89-5de3-4064-ba9f-387cb0dc8529	t	Kavumu	1d3f9ad5-b3c3-46f4-bcc2-a26fa5ba490e
2b2dca0d-c8a5-4ac4-99f8-f5e7755185a7	t	Munyinya	1d3f9ad5-b3c3-46f4-bcc2-a26fa5ba490e
c97eaf5b-7cdc-4eb7-aa61-4467546cf82a	t	Murambi	1d3f9ad5-b3c3-46f4-bcc2-a26fa5ba490e
f4ff16e7-e69c-4fc6-99af-d1a4165cded8	t	Nyagacyamu	1d3f9ad5-b3c3-46f4-bcc2-a26fa5ba490e
a0060ee7-a0dd-493b-8c3c-6ec76de53363	t	Ruhina	1d3f9ad5-b3c3-46f4-bcc2-a26fa5ba490e
2a5f470b-ef8e-4168-8731-01e6a07e44a5	t	Mugote	4ce39303-7aa7-4095-9f08-07456e4c77e2
a374a29a-52fd-42b0-b031-55f57911e126	t	Gakangaga	441c1db8-8167-4708-8cf4-14e68ce20b10
55798d87-06e3-4a76-b35a-e8f600ea0829	t	Rukeri	441c1db8-8167-4708-8cf4-14e68ce20b10
2c5df23e-69d1-4f1c-946b-caaeb8499260	t	Gifurwe	cca95e95-36c1-40ae-b995-e7c262503aed
d583e3cb-07da-4dc4-aaac-8236a2c5f738	t	Nganzo	cca95e95-36c1-40ae-b995-e7c262503aed
a0d08142-be82-4180-a3e0-0c144a84d0c6	t	Nyamaberi	cca95e95-36c1-40ae-b995-e7c262503aed
68b1794c-5894-4bcc-bf36-b82af00ac195	t	Ruronzi	cca95e95-36c1-40ae-b995-e7c262503aed
193527ad-b21f-4ab7-ab96-b29d4969d875	t	Uwankiriye	cca95e95-36c1-40ae-b995-e7c262503aed
87de00a8-d462-40c0-9443-2bcd9caa8fb8	t	Cyinyonza	93cd66b0-f85d-49a0-bb4d-af3497caa61c
d46dcb75-c562-4f75-8a3f-2cab7c7c91dd	t	Gitovu	93cd66b0-f85d-49a0-bb4d-af3497caa61c
3e402828-7182-485d-9852-f210255e3c9d	t	Magumira	93cd66b0-f85d-49a0-bb4d-af3497caa61c
f84b52df-f5bd-446c-94cd-008e130feecb	t	Matsinda	93cd66b0-f85d-49a0-bb4d-af3497caa61c
1114e8b6-e56f-40fe-907b-de1050244811	t	Munini	93cd66b0-f85d-49a0-bb4d-af3497caa61c
45c2dd99-0a2b-4036-bf5f-20248f8d05e3	t	Uwinzovu	93cd66b0-f85d-49a0-bb4d-af3497caa61c
08853c75-696c-4c73-b576-c680d252eadd	t	Nkamba	4a0f2bab-6155-4ed2-a498-86c761b8b790
1c0a94e2-3d3b-4ea2-90c9-7e137f76f41f	t	Gitega	b9621118-4b55-428b-9b19-009fb6ae7d06
ab6f609b-e7af-48b3-8737-c5bae9f77d45	t	Kigarama	b9621118-4b55-428b-9b19-009fb6ae7d06
655b4279-078f-4d86-80fd-35ee493c6b1a	t	Munyereri	b9621118-4b55-428b-9b19-009fb6ae7d06
294f7ac2-9c02-4884-b056-2af4de69f1bc	t	Musasa	b9621118-4b55-428b-9b19-009fb6ae7d06
acfd7c28-2b5c-4c5c-8c39-595e157e8aa6	t	Rwingoma	b9621118-4b55-428b-9b19-009fb6ae7d06
b1579de5-57c4-4b51-993f-30b96833152d	t	Karama	eeee8779-0959-45d3-8ca4-246bf2641ed1
917fa573-ff63-42a9-9fb6-c7460bc3d116	t	Munyinya	eeee8779-0959-45d3-8ca4-246bf2641ed1
9c639d0f-0057-4afb-9011-8d7b33c55b6f	t	Nyanza	eeee8779-0959-45d3-8ca4-246bf2641ed1
524b031c-20aa-48c3-89ac-3f93a2c66ca1	t	Kaviri	f99eaadf-75a6-4915-9055-2f1b1b75f7e0
f0aa52a7-842b-46ac-aa1e-3b40d516d044	t	Nyarucyamu	f99eaadf-75a6-4915-9055-2f1b1b75f7e0
939422a6-9f9b-4b6f-98f8-d671c66e26b1	t	Kinga	cbea40ea-4ac0-4aca-bc9e-1289ef959310
c348475d-f3fb-4ad6-88d7-808bf4150dfd	t	Nyamirambo	cbea40ea-4ac0-4aca-bc9e-1289ef959310
ffb76810-46d8-4f01-af95-f443b1c2f464	t	Kibingo	8be8ea52-b3d6-49be-91ec-dfd5e0d49041
9596a409-c25a-4b9a-a854-000fc90ed7ad	t	Nyabisindu	8be8ea52-b3d6-49be-91ec-dfd5e0d49041
42b2ccc8-b84b-4700-8637-5962a3c298d9	t	Rugaragara	8be8ea52-b3d6-49be-91ec-dfd5e0d49041
36d599d1-9445-458d-a853-815d443be39d	t	Karuvenya	10f06b38-c6f1-4349-b5e0-712813967e14
cae0a7cd-1e03-40e2-8c9f-e8bf11a57f0e	t	Mbeho	10f06b38-c6f1-4349-b5e0-712813967e14
60335de5-93f1-4c1a-ba0e-9ab2dae99d3b	t	Mugari	10f06b38-c6f1-4349-b5e0-712813967e14
725e6616-ccb7-4bbd-ae33-68630348addc	t	Gakoma	2951600e-17be-41b9-adeb-e46fa346cf79
acea0fa2-841b-47f2-881c-96ec21ea732a	t	Munombe	2951600e-17be-41b9-adeb-e46fa346cf79
ba43b19b-c10b-45d1-b426-680e4e2eb894	t	Nyentanga	2951600e-17be-41b9-adeb-e46fa346cf79
c3345d91-7f16-4cf3-89e2-191463bbab73	t	Kitazigurwa	67bbbd31-155d-420b-898c-29279257b349
0cb72a4f-b9ca-4e4d-9354-262caacdb3dc	t	Sumba	67bbbd31-155d-420b-898c-29279257b349
347f56e0-e252-4387-b95e-e4cc6a6db2ea	t	Dusego	6b4dd0a0-baff-4f94-8f63-5f02f4bed71a
29486e23-d05b-471e-8ddd-b62b95117129	t	Gasharu	6b4dd0a0-baff-4f94-8f63-5f02f4bed71a
3af87f41-3181-4bb5-bf4d-ccdf16f5924e	t	Kabacuzi	a21848e9-b9d3-4f15-b889-0fbd7cb41cd1
9f850afb-d6f2-4c70-9c5e-d280e49d6ce2	t	Kabajogo	a21848e9-b9d3-4f15-b889-0fbd7cb41cd1
3a36aad0-d9a1-4bd2-81ed-ba48f629c81f	t	Karama	a21848e9-b9d3-4f15-b889-0fbd7cb41cd1
79cd912c-fa19-4f41-9231-67554e5661c5	t	Kigarama	a21848e9-b9d3-4f15-b889-0fbd7cb41cd1
2c305746-e0da-49f2-b796-1a64797a6c33	t	Nyamugari	a21848e9-b9d3-4f15-b889-0fbd7cb41cd1
a6fa0c64-21f6-42d4-9fd0-d0edea83f280	t	Nyarusange	a21848e9-b9d3-4f15-b889-0fbd7cb41cd1
a1e59ef7-5480-4390-bb98-c99a5a44f899	t	Gasaka	d80cec4f-3e00-4674-9acc-f8b1aaec10b9
114f8d9a-f045-4612-8dc9-40218ea66451	t	Nzega	d80cec4f-3e00-4674-9acc-f8b1aaec10b9
35f7e81b-a414-4aec-8ff8-c858108a4c1e	t	Murambi	4676f5a5-2672-4ba2-a309-e421d162fddb
d1310f31-17a9-4c24-924a-3c1bb4b5bdeb	t	Muriro	4676f5a5-2672-4ba2-a309-e421d162fddb
742b5f2d-62da-40f4-9215-05fe64fbb6c5	t	Nyamifumba	4676f5a5-2672-4ba2-a309-e421d162fddb
b061f3c4-eb31-42ac-ba54-9f0709592fca	t	Gashasha	862f9b70-d252-440d-a1ad-b8ec7b651b2b
61b586ad-c163-4bdd-9b2b-69d73276abdf	t	Murembo	862f9b70-d252-440d-a1ad-b8ec7b651b2b
0519644b-c485-4522-9117-513fb45cc3b6	t	Rwamakara	862f9b70-d252-440d-a1ad-b8ec7b651b2b
d48619e3-6406-4d83-9c05-00299dba0d16	t	Uwisuri	862f9b70-d252-440d-a1ad-b8ec7b651b2b
680e9d1b-8331-4d84-9129-71bda20af337	t	Bamba	deae4157-c13d-4f3f-8186-f8746eaf9d6f
9d50108b-5416-4ab2-89a9-8aa1bbdb135f	t	Biziguro	deae4157-c13d-4f3f-8186-f8746eaf9d6f
375d3952-76b7-4bc0-a550-4cfe93778469	t	Gahama	deae4157-c13d-4f3f-8186-f8746eaf9d6f
f471068b-b8b6-42a1-86ee-8ff042c7138c	t	Gataba	deae4157-c13d-4f3f-8186-f8746eaf9d6f
34b5f31f-c11a-41d3-ae39-e57897a46d9f	t	Gitega	deae4157-c13d-4f3f-8186-f8746eaf9d6f
47a54eab-d8dd-4f39-b6d4-dd501763d6ff	t	Kabuga	deae4157-c13d-4f3f-8186-f8746eaf9d6f
efac6fc6-eaa4-41e7-8c24-d7fa6ffc88e4	t	Karehe	deae4157-c13d-4f3f-8186-f8746eaf9d6f
18f22478-0da7-4a19-aed5-a58a619f6fce	t	Kavumu	deae4157-c13d-4f3f-8186-f8746eaf9d6f
5557c2c3-1616-449c-a08a-c81ebab95e54	t	Kasemanyana	1561abdb-e2da-4e2a-9bdc-7888a8411cab
9b0cac2a-99cc-447a-99a2-371de33752cc	t	Kibiraro	1561abdb-e2da-4e2a-9bdc-7888a8411cab
0de543ab-199f-40f4-998a-f42825f7b109	t	Munini	b4de1127-f055-4f30-a883-e6c873b824b3
5158976d-dcfa-46c3-8bc5-cab2e54d0689	t	Nyakirambi	b4de1127-f055-4f30-a883-e6c873b824b3
ee723690-5cfa-41c5-81d4-f157e38dcd8d	t	Kabaziro	20e11c99-6dbc-492e-bc52-5e9176f80daa
97b7557c-465c-47c9-9dd5-bfa1bd09380d	t	Kirehe	20e11c99-6dbc-492e-bc52-5e9176f80daa
e2708b45-b7b7-4a1f-ba84-b57b83ffb687	t	Kivumu	20e11c99-6dbc-492e-bc52-5e9176f80daa
c1941dec-3dcf-49a2-b189-a063babca606	t	Cyugaro	c57caec7-b7af-488b-9347-7ce041ce13b8
97387419-ba9b-4440-8cc6-e878556d9ce9	t	Gashiru	c57caec7-b7af-488b-9347-7ce041ce13b8
de92665a-c4c7-4d13-9861-3b50f2ce860e	t	Nkomero	c57caec7-b7af-488b-9347-7ce041ce13b8
91b9ead5-801d-4839-8e16-f6f33654c106	t	Nyakabingo	c57caec7-b7af-488b-9347-7ce041ce13b8
0f750e60-3bb2-4df2-b328-d7823a93cd53	t	Ruhuha	c57caec7-b7af-488b-9347-7ce041ce13b8
93e8cd66-4cd3-4ae5-8b30-44e5ff48cb15	t	Gitwa	c7e4bca0-1e1d-4257-b4a3-fb2221bfb2d9
a7c5e8f9-861b-4451-a4a3-0c71cc924dfb	t	Ryanyirataba	6ec107a4-9b5b-4a87-85cc-4ac64af95b83
b250a393-2592-44bd-aab9-6ed0676163eb	t	Nyarusiza	8637b380-1d39-43a7-b178-63bba5a819ff
7abbee78-1e82-423d-887c-377bfd8019bc	t	Kamina	0f7ccbfb-4a2b-42ff-8532-a5cdd8fd162a
f12015e0-8506-44d1-aaee-ab5b3782db54	t	Kivumu	0f7ccbfb-4a2b-42ff-8532-a5cdd8fd162a
e9e0cf94-fec6-4e10-85ad-b184e9403db4	t	Nyabusozi	0f7ccbfb-4a2b-42ff-8532-a5cdd8fd162a
98e1346b-872f-45c9-9867-ae1a19a2444e	t	Kasebuturany	392b38b2-d523-443b-9ac9-928a756dfc23
98245374-b2df-4da3-94fe-50c656d871b5	t	Muyange	392b38b2-d523-443b-9ac9-928a756dfc23
052b2f0c-97d6-4b53-873b-7776c5d0d4e6	t	Uwinyana	392b38b2-d523-443b-9ac9-928a756dfc23
54c40084-02db-443d-af51-97a4e5c2dd09	t	Muganza	3ea00ba9-4231-40ba-bdd2-bc92a2a46670
af1ccc2a-5eed-481f-9d94-3f2027d7fec4	t	Nyabubare	3ea00ba9-4231-40ba-bdd2-bc92a2a46670
4575c3a8-518c-4e06-99ec-86688ba0984a	t	Gisoro	bcb04680-450f-4fdb-9cea-5d0084dba6f0
7b4f02ee-71af-41c1-9167-e98bec5e3690	t	Gitwa	bcb04680-450f-4fdb-9cea-5d0084dba6f0
fbd9370b-90c3-49f0-9506-cc047fdbfd7b	t	Kavumu	bcb04680-450f-4fdb-9cea-5d0084dba6f0
0aa5cce5-9c5e-4db4-9197-731253612bef	t	Nyamirama	bcb04680-450f-4fdb-9cea-5d0084dba6f0
823000ed-ca2f-4bdd-a6e0-60c93dd2892c	t	Nyirakiraro	bcb04680-450f-4fdb-9cea-5d0084dba6f0
db1f4353-4689-482b-b678-a3ce830890da	t	Gakoma	a8bd6183-8e42-483e-b079-e0703107ecb5
881ebb18-2f9e-4410-a0d3-45348f03d09e	t	Nyagishubi	a8bd6183-8e42-483e-b079-e0703107ecb5
52b19d1b-b610-4c59-bb83-f24cd3e5712e	t	Birembo	c389b481-cdc4-444b-8964-605336684bf1
c94233b7-b92c-4bd6-a982-b65137c6ed8f	t	Karumbi	c389b481-cdc4-444b-8964-605336684bf1
25136bb4-4d95-4cbf-8ea3-92eed9addfba	t	Mugote	c389b481-cdc4-444b-8964-605336684bf1
332503ac-d2d4-4c86-b9c9-e823c5bb4ac6	t	Murwa	2d3df74a-f124-4f29-a8ba-d26bc3acf96f
f8016c13-6668-4ea9-9fca-9858b357e690	t	Nyagatovu	2d3df74a-f124-4f29-a8ba-d26bc3acf96f
6aee9665-12d1-4b66-a613-66a415229ce1	t	Gikomero	c6d6c965-3c1c-455e-998b-07296a95f569
9fbcc697-d722-4a02-8b00-f44c34abd6c0	t	Nkurubuye	c6d6c965-3c1c-455e-998b-07296a95f569
589c7ed6-68c3-4373-8b04-e9d6e1bc0b60	t	Gatandaganya	3ad8a839-cac1-4ed8-b2f6-031805f349d3
fde0d5c3-2248-455f-8f01-98524aa7b3fe	t	Kabere	3ad8a839-cac1-4ed8-b2f6-031805f349d3
b7f262f9-e943-4c74-9894-ef96053ae679	t	Kanyege	3ad8a839-cac1-4ed8-b2f6-031805f349d3
668edda1-d994-4b95-b23a-0efc77744e04	t	Rwezamenyo	3ad8a839-cac1-4ed8-b2f6-031805f349d3
c740402e-d0df-43ee-828a-8677fc1b615e	t	Nyakizu	66da9cd8-69b6-4e9f-bf0b-fefca8fad62b
4b5697d5-7940-4752-9621-2942c8326d72	t	Bususuruke	e939d47d-ae3c-4bb8-adf4-d9b66e58aaa3
299a942a-4236-45d0-9711-92ec778cb329	t	Kintobo	e939d47d-ae3c-4bb8-adf4-d9b66e58aaa3
3140b85f-43e9-4204-b0db-c1ad2c84ebf5	t	Turonzi	e939d47d-ae3c-4bb8-adf4-d9b66e58aaa3
4565cb31-b6ad-482d-9801-5f8c7aee3b11	t	Uwabumenyi	e939d47d-ae3c-4bb8-adf4-d9b66e58aaa3
0e694052-1cb0-464e-86f8-94cc1850cb11	t	Uwarwubatsi	e939d47d-ae3c-4bb8-adf4-d9b66e58aaa3
fa8269e8-6b7c-412f-aaad-824d84a5b9e9	t	Uwintyabire	e939d47d-ae3c-4bb8-adf4-d9b66e58aaa3
93c7fc7c-e3bf-4321-bc9f-6347c422157c	t	Gahande	aef6362c-8bbe-4233-a691-cec2bb51d646
3282fa0a-55d7-480c-8a8a-5a0acd147400	t	Gasasa	aef6362c-8bbe-4233-a691-cec2bb51d646
516282cf-a31f-47aa-9176-48e6e479a529	t	Mujuga	aef6362c-8bbe-4233-a691-cec2bb51d646
4a29157f-b254-4800-ba44-dcd36ad4c44f	t	Mukaka	aef6362c-8bbe-4233-a691-cec2bb51d646
0a76be75-ac44-492e-abbf-f43f371ddaf1	t	Rwufe	aef6362c-8bbe-4233-a691-cec2bb51d646
1ece2b22-8dd0-408a-a829-3a04faa58cff	t	Uwanyakanye	aef6362c-8bbe-4233-a691-cec2bb51d646
f2009bba-73aa-4c26-9d86-9ab35a4198ef	t	Uwinka	aef6362c-8bbe-4233-a691-cec2bb51d646
1d8f7818-f771-437f-bb01-314df4c2f269	t	Gahira	22667417-a584-43ef-af0b-a33b5909d486
218c3908-6d89-4e59-80a3-7d5cf14f63dd	t	Gatare	22667417-a584-43ef-af0b-a33b5909d486
fbfe37e4-36cf-4e71-9581-84677a7ee567	t	Karambi	22667417-a584-43ef-af0b-a33b5909d486
87fe4afb-cbca-4926-99e0-63684150e19f	t	Uwicurangiro	22667417-a584-43ef-af0b-a33b5909d486
d15d4c76-153d-41bd-8658-37aa0a88a221	t	Uwurunazi	22667417-a584-43ef-af0b-a33b5909d486
d5c9dc6b-fc90-44c3-a475-0a84422b0b98	t	Gatwa	4dc092f8-9b5f-46c8-a6c6-26161fe4adef
984d5a7e-2e43-4b3c-9483-43bc97714563	t	Nyamirama	4dc092f8-9b5f-46c8-a6c6-26161fe4adef
7d0d6637-a545-4486-b752-7e16a9c6c3ec	t	Maheresho	d846c3c1-5671-4a88-813b-0840e111f6d1
08747c17-26e7-4e87-8b05-a261e4dcaa53	t	Gasharu	857d214d-86d0-4097-b9dd-7f16dcf5ab9c
983bd980-87ef-4d3e-b1ab-207d68b0c05e	t	Gisiza	857d214d-86d0-4097-b9dd-7f16dcf5ab9c
a790fed9-c830-411a-a27b-758dc0b7b3dd	t	Kabuhoro	6bf05a68-cedb-4d13-8ac3-c1e52587129b
71f93d5c-4088-452c-99c1-88ef65e5d895	t	Kirenzi I	6bf05a68-cedb-4d13-8ac3-c1e52587129b
56a883ce-d611-41c3-8c86-3a014f5e0723	t	Rutabo	6bf05a68-cedb-4d13-8ac3-c1e52587129b
52e5cee6-7fb2-42cf-bd8a-fa0c81cfcc4e	t	Karambi	1d323fc7-228c-4295-acd5-75730d71a7fb
9d4fdd3e-6640-4498-9727-2fcec1fa24c2	t	Kigarama	449f990f-5856-4f66-b60a-e7afde111a47
fa4cb909-a5e2-4228-a714-0c65f5d0b5be	t	Nziranziza	449f990f-5856-4f66-b60a-e7afde111a47
fc8b388a-7e97-461e-8b39-7600cd0c5b51	t	Rugarama I	449f990f-5856-4f66-b60a-e7afde111a47
beac7968-6038-436a-a190-8e05979ca1e0	t	Gasiza	cba0cb0a-57e6-4f48-b7fe-6be8b3fe3308
25db7098-acb0-4c9b-b8a7-234f5ff5b625	t	Turyango	cba0cb0a-57e6-4f48-b7fe-6be8b3fe3308
f6e8919e-ce58-4880-a672-1e5487cf0a3e	t	Gasura	c3515585-bb97-4ed8-b76d-a57e07b9f902
f4856839-c1ad-4d37-9fb5-f233374464d0	t	Murambi	c3515585-bb97-4ed8-b76d-a57e07b9f902
4216e433-362f-4ba8-aa12-cfe1cf80369a	t	Nyakabuye	c3515585-bb97-4ed8-b76d-a57e07b9f902
6758d248-8be8-487a-870d-699fa4a709d9	t	Kabakannyi	e506df0d-57e1-43ac-a7c9-10d865b9df87
e0fb7105-eb39-4e5d-92d0-d9160f501db7	t	Kavumu	e506df0d-57e1-43ac-a7c9-10d865b9df87
324d9ed9-4e74-4903-b222-41e3c9777d30	t	Kayogoro	e506df0d-57e1-43ac-a7c9-10d865b9df87
592bdcb2-d46c-45ff-9611-0de94cc6683b	t	Nyakibungo	e506df0d-57e1-43ac-a7c9-10d865b9df87
18eae789-5af5-4dd3-98be-bb47619a6553	t	Nyakirambi	e506df0d-57e1-43ac-a7c9-10d865b9df87
c54b6983-abcf-45f8-89a0-ea80c7d8d7d5	t	Cyabasana	96b07be8-a767-4243-9e76-1ac9a4ba25db
7f166b41-ce2a-4593-973c-22c90d9d7e20	t	Mutakara	96b07be8-a767-4243-9e76-1ac9a4ba25db
7aa01f8a-02e7-465c-b8b0-17d7bfcbbd2f	t	Gasagara	3b9e32af-022e-4535-85a2-fc4215710daf
2d5c330b-b31e-4f9e-a8aa-21d67ad69225	t	Mubuga	3b9e32af-022e-4535-85a2-fc4215710daf
b3e99932-0777-4a31-a95c-9377dcab8754	t	Nyakabuye	3b9e32af-022e-4535-85a2-fc4215710daf
3ec5e097-1329-43e5-8aeb-8b9c8f593824	t	Rutuntu	3b9e32af-022e-4535-85a2-fc4215710daf
1b9b7491-4310-4f22-b407-ae4d455d4f66	t	Kibaga	d5f9f0eb-a436-4142-9d33-a1d9789a55a9
9175f3ae-0f24-4da7-ba15-c8bcd4ab0ba6	t	Ruhuga	d5f9f0eb-a436-4142-9d33-a1d9789a55a9
99302c91-5a67-4122-82eb-5bc706119893	t	Uwabarashi	d5f9f0eb-a436-4142-9d33-a1d9789a55a9
97a6938a-e563-47ec-bc17-8e4c71e89165	t	Kanyiranzoga	ac430462-886b-4c53-ad46-b116edeb1f6b
cdae5712-dce9-41a7-9e9e-a42cc3c8f8c4	t	Ryanyakayaga	ac430462-886b-4c53-ad46-b116edeb1f6b
47959312-ef69-4fbd-a0c3-4758dc71e850	t	Busanza	e10fdabd-895c-4246-9d0e-d2104baf7d5a
3fedff0b-3c41-4adc-b620-09160eafa3f7	t	Bitaba	21ecc4da-54e1-40ea-8b7f-aaaf09888c73
6696d5f8-a7fc-4712-a81d-a3a00506c844	t	Gakereko	21ecc4da-54e1-40ea-8b7f-aaaf09888c73
2267b108-3f0c-429f-bf71-0b3e5dda5626	t	Rebero	d606ed87-fc3f-4f8a-ac1e-89e6b78f0abc
4bb31095-c61b-4ba4-9171-345ca565ed71	t	Nyaruhura	98685999-8dc3-497d-925a-e2e0932c1e68
92c8a695-7286-43ef-b953-d8a45057fa4d	t	Rugazi	98685999-8dc3-497d-925a-e2e0932c1e68
4cb6735f-f9dc-4c61-a8ac-1cfc9fa4a79f	t	Kizanganya	32c8554c-dc81-4c24-b890-29915207a234
78eadefc-89ee-4ba5-955e-597fde6528de	t	Remera	32c8554c-dc81-4c24-b890-29915207a234
9f29ec91-b4ca-431f-a034-a88f3704820c	t	Rutoyi	822517b3-9480-4903-a108-44b04e3031dd
cade43da-205b-45dd-8222-4030f322908a	t	Bweramana	62bad14c-23c0-4914-a010-ba4c03a45ecc
4b6b338b-c6b5-4868-888b-7c576ad623e0	t	Gashwati	62bad14c-23c0-4914-a010-ba4c03a45ecc
fde8fcb4-d18c-4fe0-b7dc-a3d1ac8fd6eb	t	Mushubi	62bad14c-23c0-4914-a010-ba4c03a45ecc
681392d4-ce53-4172-b6d5-dc6cd5bedd7c	t	Buhanzi	6d793e67-ec24-467d-ac8d-e9c26c7fe803
b3444a96-201a-49e6-b351-193bd9021840	t	Rugeyo	6d793e67-ec24-467d-ac8d-e9c26c7fe803
9375396c-81be-4394-9dd1-ec5a9c82672e	t	Gatorove	3604ac56-0019-4b72-95b1-40e9ffd8da66
f566a217-5204-4866-a6ff-9c6a5ecc44e2	t	Gihunga	3604ac56-0019-4b72-95b1-40e9ffd8da66
a220f2f3-4a2b-4c06-b126-97ea98a3e682	t	Kimbogo	3604ac56-0019-4b72-95b1-40e9ffd8da66
ea725162-3181-472c-875b-ef3916cbe0ad	t	Musaraba	3604ac56-0019-4b72-95b1-40e9ffd8da66
4e31ddde-52b0-4bb5-8550-a240afa2dfea	t	Rusoyo	3604ac56-0019-4b72-95b1-40e9ffd8da66
0538afc6-26f0-45fe-bfe2-84bafb4023f3	t	Rwimpiri	3604ac56-0019-4b72-95b1-40e9ffd8da66
15c0d7f0-a329-41d0-b225-9167474f839f	t	Gihwahwa	f564c90e-197a-4b0b-893d-6a382ec22416
9277902c-beba-4b28-a3ea-0a803298cc39	t	Mutengeri	f564c90e-197a-4b0b-893d-6a382ec22416
1ba677e5-b25d-4038-ba77-64841a120a70	t	Mugari	07137ddf-7652-4d14-bf2e-103bd70a21eb
24c212d6-5dd5-49f1-8f1c-8256367f870a	t	Bisharara	00c65a3b-be47-4944-b69b-1703a4d44e7c
c363129a-28d1-4507-8ef9-ac7eb8c05089	t	Rutoyi	00c65a3b-be47-4944-b69b-1703a4d44e7c
d66faacc-b8d9-4bc3-9deb-9ee4cf1d9bbd	t	Twiya	84e68c0d-db2a-486f-b35a-146934851aca
0e7a5ea4-0ac0-4011-b8cc-41ac5c20a2c7	t	Kagarama	55efb95c-4eec-4604-93f7-c9c20ae9a6f3
4c7b9253-c1cf-439b-a868-38abdd0d24f8	t	Murangara	55efb95c-4eec-4604-93f7-c9c20ae9a6f3
28361e33-12ce-4241-b806-cb8d4efbc362	t	Muse	55efb95c-4eec-4604-93f7-c9c20ae9a6f3
0f70b428-95df-4d30-af96-6877ddf66987	t	Gasenge	66a0e5f8-3c33-44f5-89db-7e16e410299b
ffa13f06-f081-44a0-9452-d78e2c680923	t	Kigusa	66a0e5f8-3c33-44f5-89db-7e16e410299b
68eadf55-0d97-4fdc-9944-308a4aaf9083	t	Muhati	66a0e5f8-3c33-44f5-89db-7e16e410299b
d470c9ed-3fd3-49a8-9208-38f088649234	t	Buremera	d5646c11-027b-413d-a368-1711d57cc52e
d5177734-f553-4e8b-9a40-81f4feee1898	t	Cyimicanga	d5646c11-027b-413d-a368-1711d57cc52e
64b85105-4437-4bfe-92a6-9fa694ecbf81	t	Bireka	55310ce3-a46e-4597-8cac-c817350728c5
5fbca0ec-7f34-4ddc-b241-b4919b7fe39e	t	Kibwije	55310ce3-a46e-4597-8cac-c817350728c5
4511fa73-a341-4539-af55-8282e27e3416	t	Muhumo	55310ce3-a46e-4597-8cac-c817350728c5
f10f816c-89ae-4212-8b39-08509ff45852	t	Rugeti	55310ce3-a46e-4597-8cac-c817350728c5
41e832e2-2f13-4d44-9962-babca706e001	t	Rukereko	55310ce3-a46e-4597-8cac-c817350728c5
e50f2769-1658-47d9-bc8d-6e9a5051d4b4	t	Vumwe	55310ce3-a46e-4597-8cac-c817350728c5
49b0207c-f805-485e-b99e-12a67b53d25a	t	Gakoma	a4dbd83b-55df-4529-a0f9-f8d63dcbea08
b2f74b0f-5500-4417-8847-d2c032fc824c	t	Nyarugeti	a4dbd83b-55df-4529-a0f9-f8d63dcbea08
120c3e30-5815-4d88-afab-2a433c05efe9	t	Bigumira	7511af33-2404-4191-878d-8d388b76d801
c1422891-d0c8-4906-b558-0f57d1db8065	t	Cyumuganza	7511af33-2404-4191-878d-8d388b76d801
6237ad12-ddc1-4808-89ae-43ecd8bd351d	t	Gakoko	7511af33-2404-4191-878d-8d388b76d801
be35969a-b605-4b9e-8e25-4f96c0e957bf	t	Bunyunyu	3e00d6aa-b711-4e5f-aff4-c2000c300f85
8e1eba2f-763d-4820-b8c8-969861cafedc	t	Kibugazi	3e00d6aa-b711-4e5f-aff4-c2000c300f85
eb331db4-1b2b-4f12-bbc2-2fd5b4403fb4	t	Kunyu	3e00d6aa-b711-4e5f-aff4-c2000c300f85
1a883268-267d-48b4-9b46-f76d9e310e96	t	Uwinkingi	3e00d6aa-b711-4e5f-aff4-c2000c300f85
bd059475-4cb0-4121-8e1b-5296554de9c9	t	Bishya	87edf933-c1b5-41fc-8a89-0e5190f6ab83
6a845643-fa73-41ab-85e5-8c40c57dda34	t	Cyumuganza	87edf933-c1b5-41fc-8a89-0e5190f6ab83
72bb7d4e-72c1-4202-8f36-fd3b8fa2a11e	t	Kabuga	87edf933-c1b5-41fc-8a89-0e5190f6ab83
143c58d9-fc87-493e-a869-96c3a62579bf	t	Sabake	87edf933-c1b5-41fc-8a89-0e5190f6ab83
d34f8ab7-4974-4917-a12f-df0df99e8379	t	Sekera	87edf933-c1b5-41fc-8a89-0e5190f6ab83
dc36eca1-cc5e-4e70-81dc-ddd6e76df4c6	t	Rushubi	8dceb21a-5d0d-4ff8-b4f8-1ceeff6cd4d1
d524502e-de08-4075-825e-0f50979b7b66	t	Gahango	1be1180d-e296-4330-84e3-6b82159124e0
0818d362-46a1-4f44-8d5b-de4287dfc35d	t	Kanyampongo	1be1180d-e296-4330-84e3-6b82159124e0
9ad66c0e-6dab-4557-b897-b0e644782947	t	Kimina	1be1180d-e296-4330-84e3-6b82159124e0
f2742d19-2748-4108-8ac2-9700c70080c9	t	Munyege	1be1180d-e296-4330-84e3-6b82159124e0
fa29eec9-6592-427d-bf70-6afd6f71ed74	t	Nyarurambi	1be1180d-e296-4330-84e3-6b82159124e0
9edd7d3a-466b-4d61-bc30-1f772e5d2106	t	Munini	8915d965-916f-42f1-a3c8-66863bdfc313
33bace6d-bd1d-4c88-8ca8-307fe5595961	t	Nyamugari	8915d965-916f-42f1-a3c8-66863bdfc313
4da3919b-0dda-49b8-83f2-7ad54454c280	t	Rugeti	8915d965-916f-42f1-a3c8-66863bdfc313
2796ebb5-b073-4059-9e84-66d066c91675	t	Bigega	ab7695b6-866a-47ca-849a-4490422cbd3f
891cec13-8b60-4fbb-843a-6e7bb3aa706c	t	Karama	ab7695b6-866a-47ca-849a-4490422cbd3f
365c3028-bf1d-42ca-888c-d44150667dbe	t	Kavumu	ab7695b6-866a-47ca-849a-4490422cbd3f
044c58eb-57e4-4a93-82cf-58c10a5eec28	t	Nyakwibereka	ab7695b6-866a-47ca-849a-4490422cbd3f
7bdd400a-494a-47b5-b50e-5d21a7a3457a	t	Gihisi B	9b9cd723-d537-4c1f-9e93-0dca4320ea4d
835c491f-8028-4247-80d5-72592365d298	t	Majyambere	9b9cd723-d537-4c1f-9e93-0dca4320ea4d
c731c29b-ca46-45f0-a345-33ac15c54e9c	t	Mugandamure	9b9cd723-d537-4c1f-9e93-0dca4320ea4d
abd24c13-4aa7-46a6-81bf-e2a25e327312	t	Nyagatovu	9b9cd723-d537-4c1f-9e93-0dca4320ea4d
f733c261-bb21-4b52-aeed-d6095d60a488	t	Rukandiro	9b9cd723-d537-4c1f-9e93-0dca4320ea4d
b8b1cae6-ebb7-4dff-8ad1-7dd25df202ff	t	Nyamagana A	9b9cd723-d537-4c1f-9e93-0dca4320ea4d
b33dcab1-dab2-416e-b574-76af1b7a5ef2	t	Kabuzuru	42b5b74d-1db4-4bbb-9ade-054e8a79da21
1bc94e00-ce2c-4de4-aef1-6ffe2e2f3a30	t	Ngorongari	42b5b74d-1db4-4bbb-9ade-054e8a79da21
87e29c46-3587-4000-88ec-f8a2a9ffac40	t	Rugari A	42b5b74d-1db4-4bbb-9ade-054e8a79da21
7ef9705c-ea42-48c5-a0e3-2f8f7214106a	t	Rugari B	42b5b74d-1db4-4bbb-9ade-054e8a79da21
46987d7c-9327-430c-bde3-89e40a2586f0	t	Gatsinsino	0b4ed8e6-a3af-48d7-a361-5de1f6151e91
a6433073-7862-4c71-aa69-d80a97edff4c	t	Kavumu	0b4ed8e6-a3af-48d7-a361-5de1f6151e91
0a9a8e88-d3e2-48df-a2a4-6ed473dc7d8e	t	Kigarama	0b4ed8e6-a3af-48d7-a361-5de1f6151e91
6110c78d-bd96-480f-afb9-549849382964	t	Kivumu	0b4ed8e6-a3af-48d7-a361-5de1f6151e91
567a4dd8-b482-4807-bcaa-ac677499d689	t	Mugonzi	0b4ed8e6-a3af-48d7-a361-5de1f6151e91
3a74814e-dd03-426a-85e7-2f5de95cb931	t	Nyanza	0b4ed8e6-a3af-48d7-a361-5de1f6151e91
ec2e7873-698b-4103-a0f6-0a1330aa37cf	t	Nyarunyinya	0b4ed8e6-a3af-48d7-a361-5de1f6151e91
b4597e5e-cdda-42b7-bf0d-05b16a337e74	t	Bukinankwav	c2896955-f3ba-4306-8de4-71732caa7a29
11d3eb2a-55c0-437b-b492-b409029a15ef	t	Gisando	c2896955-f3ba-4306-8de4-71732caa7a29
1ba017de-c3eb-4bcb-99e6-f7ea3a19863c	t	Kabona	c2896955-f3ba-4306-8de4-71732caa7a29
f13435cd-f814-4f49-84d8-9ade5a7fb255	t	Kidaturwa	c2896955-f3ba-4306-8de4-71732caa7a29
417258ea-ab83-482f-9511-c89908de5845	t	Murambi	c2896955-f3ba-4306-8de4-71732caa7a29
2c386f61-767a-4950-9c15-257f405f5615	t	Mwima	c2896955-f3ba-4306-8de4-71732caa7a29
c895d132-176d-49fe-8846-9a241521a3f3	t	Nyabisindu	c2896955-f3ba-4306-8de4-71732caa7a29
9184231c-8b54-48a0-9d7d-b60d0746fdc8	t	Rukari	c2896955-f3ba-4306-8de4-71732caa7a29
92b19ce3-1301-4768-a633-e0d2e53795d3	t	Gitega	047cc418-878e-45d4-bf83-46fb711b1035
005d5d0e-7bdc-432c-94e8-801dc0f1b0eb	t	Kayenzi	047cc418-878e-45d4-bf83-46fb711b1035
cb97e114-3f02-45b0-a90a-09241b8581b1	t	Musumba	047cc418-878e-45d4-bf83-46fb711b1035
c003f7c5-7a15-40cf-bb2f-b097723d4b77	t	Nyacyonga	047cc418-878e-45d4-bf83-46fb711b1035
f302f910-9f12-401d-9500-d76a29bd608f	t	Nyagasambu	047cc418-878e-45d4-bf83-46fb711b1035
e417ebf8-9436-4706-b55f-54633365397c	t	Rushoka	047cc418-878e-45d4-bf83-46fb711b1035
76982bec-1976-4517-9dbc-65a1a02ef249	t	Kimirama	3a6ac51a-0cab-4adc-941d-428d4615c235
85034280-d69f-4085-80a5-36b256488eda	t	Ndamira	3a6ac51a-0cab-4adc-941d-428d4615c235
c46ad589-3ac6-4396-9eb0-4434d4e09db8	t	Rugarama	3a6ac51a-0cab-4adc-941d-428d4615c235
7fcbb232-4c27-4da4-9cbd-78b1fa16cdc8	t	Bweramana	fa84081f-2513-4419-9fa4-01b508977b7b
1a70e951-4d35-4061-b855-375479ab1458	t	Masangano	fa84081f-2513-4419-9fa4-01b508977b7b
09a0c5b3-c2d2-41c6-98a7-1bd3fe0d5294	t	Murambi	fa84081f-2513-4419-9fa4-01b508977b7b
086f7758-86e9-4e96-ba74-fa8d5bdef2fd	t	Nyarugunga	fa84081f-2513-4419-9fa4-01b508977b7b
3b8afc20-e1e6-4e39-97d9-96c4be1a2cda	t	Runyonza	fa84081f-2513-4419-9fa4-01b508977b7b
33de25ca-979a-4e26-8bb7-c5f40b1505f6	t	Kagarama	b9891e12-eced-4b24-9bdd-0704cab3557b
17cf1338-1f51-4d2e-9189-d38c9847618c	t	Kigali	b9891e12-eced-4b24-9bdd-0704cab3557b
3ede2b86-c6ba-408b-8fbd-f2642b7127c7	t	Kivugiza	b9891e12-eced-4b24-9bdd-0704cab3557b
e97a67f6-3bcf-46b4-9859-32d62c2f81f9	t	Rwara	b9891e12-eced-4b24-9bdd-0704cab3557b
44c2e2d1-a064-4603-a95b-a46b1f988bd5	t	Cyamugani	f280cda4-e5e7-493f-b951-48c51d965a9e
1d142c99-54e9-478a-b3bd-7e1a17cfd484	t	Gasambu	f280cda4-e5e7-493f-b951-48c51d965a9e
442aa404-bd66-446b-b4ce-84ed237e75cb	t	Rwangoga	f280cda4-e5e7-493f-b951-48c51d965a9e
6ac4f1e1-3193-4516-aecf-4e8acbb92cb2	t	Nyamoyaga	1a8b3028-9d36-4ee3-93fb-032397c6e4e4
69049a7a-0f76-4d69-a939-d7f6a8767404	t	Rucyamo	1a8b3028-9d36-4ee3-93fb-032397c6e4e4
8f5208f7-19d0-43d0-a756-320edfd1514d	t	Saruduha	1a8b3028-9d36-4ee3-93fb-032397c6e4e4
f565108b-1345-42e2-b592-7bc944b96740	t	Kabeza	1efc0ffc-9a6e-4673-a932-640f42e00b0b
8fb02cbf-0136-42d9-a8d0-88bd55313d59	t	Gahondo	6140ef18-4c83-491b-8679-f3b466d167ad
95f12a71-b713-4e22-b937-8239a056c439	t	Gatongati	6140ef18-4c83-491b-8679-f3b466d167ad
1bd9123f-5d38-4e81-bae4-b391ae0c6707	t	Karama	6140ef18-4c83-491b-8679-f3b466d167ad
cd3e030f-630b-43ef-9d9d-2bd8f2c60607	t	Nyabinombe	6140ef18-4c83-491b-8679-f3b466d167ad
e7013908-750e-4708-959e-f77393095250	t	Nyabinyenga	ca983f0a-7bc5-4e51-95c9-41e61a52b3f5
97f78753-0f76-4339-87d0-b152127cc46b	t	Rugote	f4bfff48-f832-4192-8be8-99c6f11035e8
0ffa8fd4-199a-4c73-adf0-caddaf5e6a25	t	Ruvuzo	f4bfff48-f832-4192-8be8-99c6f11035e8
dbc2aa92-30e8-456b-a651-fa3d65d0beef	t	Gahunga	ed904580-1cc4-4415-a949-322f74a1ccd9
80fad5c9-e031-46d2-b7d7-09314e4be6b7	t	Murambi	ed904580-1cc4-4415-a949-322f74a1ccd9
8f23df2e-15d5-4cb5-9b64-a571a2e82ffe	t	Kamatamu	7408d6bd-2c8e-48a0-a1f9-02e1be8cd855
8d0f6e15-1f85-4108-9718-aa6b6ce63a9e	t	Matara	7408d6bd-2c8e-48a0-a1f9-02e1be8cd855
181762d5-ceb9-4d2f-99b0-77f29b5cf106	t	Muyebe	7408d6bd-2c8e-48a0-a1f9-02e1be8cd855
03f47796-ad7a-4319-ba52-16c769661986	t	Nyamunini	7408d6bd-2c8e-48a0-a1f9-02e1be8cd855
cab2c71d-3150-451e-877e-932737a3a641	t	Rutete	7408d6bd-2c8e-48a0-a1f9-02e1be8cd855
5f0ddea9-d05b-443e-910e-1ec83bff69a6	t	Binyana	457f7389-ebab-478f-98c7-b8831e3ad55b
370b228c-99ca-4611-96d4-da9162237ee1	t	Gihama	457f7389-ebab-478f-98c7-b8831e3ad55b
0dafac7a-de96-422f-a0a7-f0f364725c67	t	Karambi	457f7389-ebab-478f-98c7-b8831e3ad55b
49cb6d6a-ad62-47b0-b86a-d626f5f3f581	t	Karehe	457f7389-ebab-478f-98c7-b8831e3ad55b
0f0e9f1e-569f-4a68-9255-fa7996b9bc9d	t	Mukoni	457f7389-ebab-478f-98c7-b8831e3ad55b
1ba54d31-6088-4229-97b6-e5a1360f6d80	t	Rukore	457f7389-ebab-478f-98c7-b8831e3ad55b
afc7fd6a-8182-4d27-808a-1f82b85c0e64	t	Gatongati	8fc6f862-5585-4392-879a-4339d2cb2ac7
46a037e3-703d-4398-ab04-920ed7bb1e8f	t	Gicumbi	8fc6f862-5585-4392-879a-4339d2cb2ac7
e94ba5f4-f882-4a2a-bfc0-43c98567a36e	t	Kabeza	8fc6f862-5585-4392-879a-4339d2cb2ac7
7e061bba-e1a4-4de0-9067-9edb54caa8ad	t	Kanyinya	8fc6f862-5585-4392-879a-4339d2cb2ac7
357114f0-395d-492e-a7bd-ace85cdd0766	t	Kivugiza	8fc6f862-5585-4392-879a-4339d2cb2ac7
248d7aa2-3547-44fa-8138-35e1d64e720b	t	Kibilizi	9ced01ef-5970-422d-98ca-51f3759244a6
5dacb0c6-560b-4e83-965c-1c34453e092d	t	Mubano	9ced01ef-5970-422d-98ca-51f3759244a6
4179bf6d-fd4c-4afe-88fe-4c0ae03e4d88	t	Mubuga	9ced01ef-5970-422d-98ca-51f3759244a6
24cf55ce-0b33-4793-a994-57bfd7b03e64	t	Mutima	9ced01ef-5970-422d-98ca-51f3759244a6
c676d99f-639b-45f2-a972-d14ac0e231ba	t	Nyarurama	9ced01ef-5970-422d-98ca-51f3759244a6
90818503-b44d-4ac9-9ddd-df340f64eda5	t	Saruhembe	9ced01ef-5970-422d-98ca-51f3759244a6
46923de3-d8af-44a6-b0ab-23fac72c18db	t	Shusho	7c042565-eb08-4626-9d0f-57e2c48336b1
cd30e776-e3da-442b-aec9-62b519e96327	t	Karama	7c042565-eb08-4626-9d0f-57e2c48336b1
6c0b8a50-b967-4266-ba0d-adb27109c641	t	Nyesonga	7c042565-eb08-4626-9d0f-57e2c48336b1
864f40a0-c3f9-46b4-9457-ecbf9ca854be	t	Kavumu	33d922b2-4d81-4ad5-b8ba-3123a78a5365
1123f149-e7c6-4d97-b821-54b5f792bdfe	t	Nyabusheshe	33d922b2-4d81-4ad5-b8ba-3123a78a5365
5c42e618-5fdb-4a78-9729-8a046db4e018	t	Runyinya	33d922b2-4d81-4ad5-b8ba-3123a78a5365
18c8faf0-7240-442f-993c-b6497a7c11ef	t	Gashikiri	68017a48-4545-4263-9e6b-adf02133676e
91c56124-3690-4093-8364-e9cdacd787f1	t	Gicunshu	68017a48-4545-4263-9e6b-adf02133676e
02027029-ba5c-46ce-85bd-0f10d4f43da6	t	Kirerabana	68017a48-4545-4263-9e6b-adf02133676e
b6b3257a-f542-4407-8f90-b0fa333caed8	t	Nyagacyamo	68017a48-4545-4263-9e6b-adf02133676e
956a6242-eb7b-4601-9d4c-c7b0d22f7c56	t	Rugarama	68017a48-4545-4263-9e6b-adf02133676e
8fdaea07-9c50-4afc-b4fa-c5e3dea8a749	t	Serivise	68017a48-4545-4263-9e6b-adf02133676e
23b9ca58-195f-4cd0-9344-3efa30cb2120	t	Bwambika	ef33306a-0a25-4ab0-8aa9-e124ad054955
b53f5b53-613f-4d16-a824-305e8033afb8	t	Gisoro	ef33306a-0a25-4ab0-8aa9-e124ad054955
14ffa125-f8be-4731-887d-4d0515220dbe	t	Giturwa	ef33306a-0a25-4ab0-8aa9-e124ad054955
2f5a3ff5-d41f-4d95-ad57-10fc4f20fc13	t	Kabacuzi	ef33306a-0a25-4ab0-8aa9-e124ad054955
efaf4591-f07f-4bad-b345-07fa53269b27	t	Akintare	1b46fcd3-c8f8-48e7-b079-4b8de4dbccd8
c15fb6c6-a814-4b1a-b543-b0392ca7304c	t	Buharankakar	1b46fcd3-c8f8-48e7-b079-4b8de4dbccd8
b9c14cae-5a11-4f55-92ec-9af77d499aa0	t	Buhoro	1b46fcd3-c8f8-48e7-b079-4b8de4dbccd8
b9143141-db21-40e5-8d02-9d96917d633d	t	Karama	1b46fcd3-c8f8-48e7-b079-4b8de4dbccd8
d0581653-f7e1-4068-9ae2-c969a5e486c6	t	Kigarama	1b46fcd3-c8f8-48e7-b079-4b8de4dbccd8
d7b82d2f-ecfb-456e-9b34-d4211e9bfcaf	t	Muramba	1b46fcd3-c8f8-48e7-b079-4b8de4dbccd8
acf268d8-aa1c-4421-bf52-9140405c1cbb	t	Birambo	964b6c94-adb6-449e-a604-e35ae4f846d7
55ba4a1b-e56e-4798-9978-36cde1be82ac	t	Bweramana	964b6c94-adb6-449e-a604-e35ae4f846d7
4690f2d3-2502-4334-b93a-05508db25769	t	Cyerezo	964b6c94-adb6-449e-a604-e35ae4f846d7
b24186de-b41a-4036-bcc7-e8c0c92ea4ff	t	Cyikirehe	964b6c94-adb6-449e-a604-e35ae4f846d7
ba7820a5-6335-4e42-8f72-b082ea1ba5c1	t	Cyumba	964b6c94-adb6-449e-a604-e35ae4f846d7
8748c69d-1811-4d0f-b982-dddc12c3ddd4	t	Gasharu	964b6c94-adb6-449e-a604-e35ae4f846d7
c2feada7-9a87-4444-8689-3da7f0945c9f	t	Kamabuye	964b6c94-adb6-449e-a604-e35ae4f846d7
861d1014-a248-4fc3-92ea-a7e3b5c33781	t	Karambi	964b6c94-adb6-449e-a604-e35ae4f846d7
43f46e9b-ff3e-40aa-9290-55a95dc2cba0	t	Nyarutovu	964b6c94-adb6-449e-a604-e35ae4f846d7
e798afdd-80a1-4f5d-84f4-9f6e8d5aeb6e	t	Cyahafi	bb41e89e-f585-49f3-928e-a05711ca9ea2
51607653-79c4-49b4-9d28-1a3c4fb6426d	t	Gatagara	bb41e89e-f585-49f3-928e-a05711ca9ea2
3d33df82-8caf-4a7b-a3e7-f3acdac96495	t	Karama	bb41e89e-f585-49f3-928e-a05711ca9ea2
1acade0c-00be-4846-bf54-bc6e8896ed9c	t	Karuhwanya	bb41e89e-f585-49f3-928e-a05711ca9ea2
ae602b7e-b476-4344-a5cf-1f63c4cc0248	t	Kinyogoto	bb41e89e-f585-49f3-928e-a05711ca9ea2
a537df85-e28a-4367-93a2-c82bd7b68b33	t	Nyamuko	bb41e89e-f585-49f3-928e-a05711ca9ea2
eb79dae8-58ff-4b8c-b09d-6315df8af9ac	t	Gahoko	1225b010-9650-4dee-a6a2-bef313a44888
93cb4206-af08-48e5-aaf6-0daf41bb8ebf	t	Kaganza	1225b010-9650-4dee-a6a2-bef313a44888
55b4a009-5ea9-4ce0-959a-094e2bd8b762	t	Muturirwa	1225b010-9650-4dee-a6a2-bef313a44888
172303d9-f15d-4fa3-891d-18710d221394	t	Nyabishinge	1225b010-9650-4dee-a6a2-bef313a44888
16f4bbdd-13ea-49e7-82a8-7e4f76baf1a7	t	Nyankunamir	1225b010-9650-4dee-a6a2-bef313a44888
1292f5b6-a45d-470c-a32e-332eda6b3ce9	t	Birembo	5d340e15-f226-4e8f-b1af-54630eee572d
cbd8f74c-1827-4267-adcf-0c27d3957f02	t	Nyakabuye	5d340e15-f226-4e8f-b1af-54630eee572d
99e1602a-3ca5-4f6b-8c9e-cc785a8215fc	t	Nyamazi	5d340e15-f226-4e8f-b1af-54630eee572d
59d06ef9-3cd6-4d9b-a2f0-adb22d90070e	t	Remera	5d340e15-f226-4e8f-b1af-54630eee572d
7e40d2e8-6ba3-4673-8923-4240c63d30bd	t	Mwanabiri	57d53b8c-182e-4fee-b3f7-ee7d1c3ce881
b7615073-e5ee-46b8-b382-ee38e9f870a8	t	Nyarunyinya A	57d53b8c-182e-4fee-b3f7-ee7d1c3ce881
826e8b69-7ede-4292-af1e-21abd8bba681	t	Rutete	57d53b8c-182e-4fee-b3f7-ee7d1c3ce881
0967a9dc-2fa7-4cc4-9d89-c541d9f27896	t	Kabarima	5cb91c8b-55a0-46ec-af57-fefa610d06b2
74938952-945e-4329-a33a-bf86c95cf053	t	Kibonde	5cb91c8b-55a0-46ec-af57-fefa610d06b2
a749380e-405e-4498-8ac1-c4a2fd2c6dd8	t	Kigarama	5cb91c8b-55a0-46ec-af57-fefa610d06b2
6b58a187-e23f-445c-a081-a7498ebb6490	t	Ruhosha	5cb91c8b-55a0-46ec-af57-fefa610d06b2
4fec0efb-4fd0-4814-a15e-d27e9cc9955e	t	Buhaza	05a91f2d-cdae-4a03-8a98-885faf26f0e7
c081dc1e-3f9b-420b-9f5a-5700a1d3b019	t	Kimfizi	05a91f2d-cdae-4a03-8a98-885faf26f0e7
592ce785-a038-4edd-974e-d861a2efe837	t	Ruyenzi	05a91f2d-cdae-4a03-8a98-885faf26f0e7
962e2417-7367-4685-be02-10d5c0a0c2f2	t	Rwabihanga	05a91f2d-cdae-4a03-8a98-885faf26f0e7
4660167b-2fdc-434b-bbfc-a823ca141e0b	t	Bugina	82efdb5c-73cc-44ac-a2a8-4cd5c74a7c6a
793f76eb-dcd7-484c-bf14-50ad77615a6a	t	Kalilisi	82efdb5c-73cc-44ac-a2a8-4cd5c74a7c6a
8a84493f-b6c0-44bd-b29f-1d4a789dc462	t	Kinyana	82efdb5c-73cc-44ac-a2a8-4cd5c74a7c6a
3300305f-784b-4d4f-a3c4-bfd92e239ac5	t	Musenyi	82efdb5c-73cc-44ac-a2a8-4cd5c74a7c6a
2609bdf9-4578-42a3-9c56-b36b2993228b	t	Nzovi	81d9cd02-2e44-4ed7-b1ff-131237b13f6d
070a2e2f-5e27-4262-85db-08c3f6658b9c	t	Cyegera	50e8f0aa-f953-41a3-bd6b-dda252622bc9
0f22d2f3-6fab-498e-8c20-52f6191477c7	t	Gituza	50e8f0aa-f953-41a3-bd6b-dda252622bc9
d1ea4a79-678a-4b4c-bd48-b51a473bcaa1	t	Kanyundo	50e8f0aa-f953-41a3-bd6b-dda252622bc9
cd518fb4-50de-4607-9c62-ec76d8664a05	t	Nyarugunga	50e8f0aa-f953-41a3-bd6b-dda252622bc9
70cf140e-decd-4f54-bbd1-fa47979c99bb	t	Mugari	d561ac81-1435-4ac1-86b8-5db76a3688b1
059dd39d-58d1-4d97-ace2-73bfad515dd3	t	Nzoga	d561ac81-1435-4ac1-86b8-5db76a3688b1
3deaab5f-da8b-48eb-85cd-d317aecea1c8	t	Gisayura	a9e501a9-c6af-4cb7-a919-d04e32b2c2d5
5ff9a08d-4e8d-42af-9f26-d42e0ed8650b	t	Kiruhura	a9e501a9-c6af-4cb7-a919-d04e32b2c2d5
0e05e2c4-d9fc-4a35-8b83-2fe9fc1fa80b	t	Marabage	a9e501a9-c6af-4cb7-a919-d04e32b2c2d5
146d8275-1b80-47bd-a073-f441468d9bfc	t	Ndago	a9e501a9-c6af-4cb7-a919-d04e32b2c2d5
45fec461-d18d-4302-8f5e-efa2ee92a4ba	t	Rugarama	a9e501a9-c6af-4cb7-a919-d04e32b2c2d5
d635dd31-31d6-4b46-ad78-5e2cd5f16d8a	t	Kankima	1543ea98-27b5-4651-8afb-2767395bb130
ee47388a-c3df-4c19-90d0-f3ec5af791c3	t	Karuyumbo	1543ea98-27b5-4651-8afb-2767395bb130
bdb6c9bb-812d-4ab7-bd70-aa0508e21b76	t	Mpande	1543ea98-27b5-4651-8afb-2767395bb130
4161ff9a-924d-47bc-9a74-8f38392c377d	t	Nyabigugu	1543ea98-27b5-4651-8afb-2767395bb130
81c87931-786d-4677-b4af-4ee05ba477b4	t	Nyarutovu	1543ea98-27b5-4651-8afb-2767395bb130
7cb31dac-4092-44a3-88b0-27d7407457c8	t	Ruyenzi	1543ea98-27b5-4651-8afb-2767395bb130
680b7fc6-83d6-4aa6-a151-3d78a5da646e	t	Rwimpundu	1543ea98-27b5-4651-8afb-2767395bb130
badc54b7-0024-41ee-b95d-75c0ad971cca	t	Kamabuye	3ddd9df5-0290-4044-a3f2-5813ffefdadb
144ba7b1-f229-4017-81cf-e357d6f319a6	t	Ntebe	3ddd9df5-0290-4044-a3f2-5813ffefdadb
a68b95f4-bb87-45e6-a73f-4b5a9bda22c1	t	Nyamirambo	3ddd9df5-0290-4044-a3f2-5813ffefdadb
db9d7b3c-dc9d-411c-aabe-d644c922684d	t	Nyamizi	3ddd9df5-0290-4044-a3f2-5813ffefdadb
e29544bf-f440-4eec-ac77-ada3f2ed0afd	t	Rusasa	3ddd9df5-0290-4044-a3f2-5813ffefdadb
ba0b72a3-1ffb-4b15-bfaa-dfc2d0c85729	t	Kagarama	d0847425-c9df-46a9-9e2a-c83ffa79d738
9996f5be-a170-4d9e-8b14-64a9ccf5b460	t	Kamabuye	d0847425-c9df-46a9-9e2a-c83ffa79d738
90201312-c826-4295-8e7e-990a0e138019	t	Muhero	d0847425-c9df-46a9-9e2a-c83ffa79d738
52a88b7b-063a-4195-8b3a-c38c6bea2664	t	Munyiginya	d0847425-c9df-46a9-9e2a-c83ffa79d738
081b92a6-b112-4932-b9d8-b56d875b9fb9	t	Muyenzi	d0847425-c9df-46a9-9e2a-c83ffa79d738
7f4fbb0d-7057-4bc8-bee9-fad2bab6094b	t	Nkombe	d0847425-c9df-46a9-9e2a-c83ffa79d738
42bda622-7c01-41af-b663-616da82000bc	t	Rukoma	d0847425-c9df-46a9-9e2a-c83ffa79d738
fb722dbc-19d3-47b7-b00c-95132de22e14	t	Kigohe	8c48bbc0-d1e6-46d7-847f-ff63d703602e
4f4be884-7766-45f8-bb3f-96e2f7fe95e5	t	Mweya	8c48bbc0-d1e6-46d7-847f-ff63d703602e
80200939-a34f-4eb0-8484-2858e7ad9ef5	t	Cyahafi	6b85270e-f464-485f-bd23-6974bab66b80
7af17fec-2779-42f6-a0cb-2027c906d727	t	Gihimbi	6b85270e-f464-485f-bd23-6974bab66b80
3494b59c-95d6-43b0-be0d-4fb7bf50d6c5	t	Kabuye	6b85270e-f464-485f-bd23-6974bab66b80
301396e6-3088-41b5-ae9f-bff5d194b228	t	Mirehe	7d7769b0-0e2f-4cf4-b67b-bd197356d725
e014ede0-3406-4f90-a783-478dcfd3a98b	t	Busenyeye	ebfd73a0-f25d-4b45-9826-98fba2839f5a
2c898df8-9596-4981-abf9-3d9f8e6f07ee	t	Bweru	ebfd73a0-f25d-4b45-9826-98fba2839f5a
626a107d-3fe0-4694-a8b8-d8c200aadb24	t	Jarama	ebfd73a0-f25d-4b45-9826-98fba2839f5a
ed47f307-3563-4e7c-823b-05f194cfc904	t	Mpaza	ebfd73a0-f25d-4b45-9826-98fba2839f5a
2f2375ee-6e7e-4d17-bcea-211d249d1baf	t	Murende	ebfd73a0-f25d-4b45-9826-98fba2839f5a
09fe3f7f-ec7b-47dd-b2d2-5e8b104ba336	t	Kami	bb96b472-bc47-4f6d-bab2-82fa41104a21
c536c2fa-9c12-4b9c-ac59-8ebb6c4f519c	t	Kigarama	bb96b472-bc47-4f6d-bab2-82fa41104a21
c63def60-cb39-4e1b-8fbe-7d10c0408025	t	Musongati	bb96b472-bc47-4f6d-bab2-82fa41104a21
d85e2f31-d2c7-447f-9938-af861611b0ef	t	Nyamagana	bb96b472-bc47-4f6d-bab2-82fa41104a21
2c9b99e8-6ff8-4655-853f-bafa4371b170	t	Nyaruvumu	bb96b472-bc47-4f6d-bab2-82fa41104a21
4fda6023-44b8-4555-a2e1-ce389a1bc2c9	t	Bisambu	eb8c3f7e-44fb-4c37-aa19-182c3b3648cd
f927810f-3479-4bb1-a660-02359ecf86d2	t	Gisake	eb8c3f7e-44fb-4c37-aa19-182c3b3648cd
761597b1-48f9-4f2e-9da6-7ba828e35a72	t	Nyamiyaga	eb8c3f7e-44fb-4c37-aa19-182c3b3648cd
43359083-ebcf-479a-8d01-6b1422f6af50	t	Rwamushumb	14bd6a26-126a-4df5-83a6-85d31e9e8e71
e6ab93e7-f7c6-4574-9809-19b8e7bb21c3	t	Karwiru	a4b5debb-c8af-40d2-903b-a5b9e5ee6f5f
35c81af0-39ee-4ddb-9686-d9cc93fdbae8	t	Nyamiseke	a4b5debb-c8af-40d2-903b-a5b9e5ee6f5f
7dcdd28e-8022-418e-b9cc-163fd03f6e02	t	Kirwa	0cbec2d5-4085-4403-9228-b14a75bbd968
f4b53bb2-5909-4f05-b5a1-34ca2b59f5d2	t	Nyamuvumu B	0cbec2d5-4085-4403-9228-b14a75bbd968
26c41079-38ab-47bd-a271-6e7d88161b1f	t	Cyarwa	1d256e32-81fd-424f-9454-722aa716975d
949fd1ee-2b2b-4f6d-8dd5-64e87327831f	t	Kamushi	1d256e32-81fd-424f-9454-722aa716975d
a4bf56fe-c14b-48ef-b706-4372d1c04b49	t	Kamuvunyi A	1d256e32-81fd-424f-9454-722aa716975d
07df6aa3-658b-4c6e-9889-c74f3d4c4b8f	t	Kavumu A	1d256e32-81fd-424f-9454-722aa716975d
8911367e-715b-4810-be37-759995aafd8d	t	Bukinanyana	c2ad5bdd-5c47-4e5a-a530-980158226622
75767a74-6aad-4c83-b48e-77c619e14eb9	t	Gisenyi	c2ad5bdd-5c47-4e5a-a530-980158226622
518a618a-9116-4bf3-85c4-a98e758ced1f	t	Gitwe	c2ad5bdd-5c47-4e5a-a530-980158226622
f6f12cbe-9a7b-4673-bfd8-1adc9d4573a0	t	Kinyinya	c2ad5bdd-5c47-4e5a-a530-980158226622
4de0c928-09a8-42e1-8ef0-4e2f9ecbda86	t	Masiga	c2ad5bdd-5c47-4e5a-a530-980158226622
0532b7cf-13ea-4a2f-8412-80fbc2dcb338	t	Bitare	731819c9-cdc6-4f77-a06f-cb4cc151e88f
884bff7a-9c67-4328-9420-5442b28a9e4d	t	Mutarama	731819c9-cdc6-4f77-a06f-cb4cc151e88f
ba2a1f73-d062-42b6-ae51-42699b97ce5e	t	Mutobo	731819c9-cdc6-4f77-a06f-cb4cc151e88f
e2cfee88-df05-4386-a57b-5ba717db164c	t	Nkanda	731819c9-cdc6-4f77-a06f-cb4cc151e88f
d467c62b-53d8-4570-8028-a26ed2b89fc8	t	Uwamakumba	731819c9-cdc6-4f77-a06f-cb4cc151e88f
31e27c14-8dea-45ca-a31f-b2012f1e64f3	t	Kabavomo	fd771b01-58f0-4962-8fef-699a1b16163a
60d21da3-eda7-406b-96d6-8963159b7b40	t	Ndatemwa	fd771b01-58f0-4962-8fef-699a1b16163a
49ca5af8-17b2-4a6b-907c-3a9cfcd96090	t	Nteko	fd771b01-58f0-4962-8fef-699a1b16163a
7f01d4a0-ec04-40a2-be72-f4d7d4ab1689	t	Musebeya	0203909d-c7c2-4875-b7a9-80a4497c791a
1729ab14-eb99-4517-87de-9b2b90a1a09c	t	Rango	0203909d-c7c2-4875-b7a9-80a4497c791a
032de315-43d8-4a73-96be-96502434c05d	t	Ryabusagara	0203909d-c7c2-4875-b7a9-80a4497c791a
6e61f53a-6cfa-4b02-8be8-47bdb193344c	t	Shwima	0203909d-c7c2-4875-b7a9-80a4497c791a
d409d464-b5ca-4d48-b63c-ad4c0a5d402e	t	Bukinga	91cb3161-4655-4389-accb-ac480fde938e
60bad5bb-49c1-45dd-924c-cbabd5484781	t	Rutabo	91cb3161-4655-4389-accb-ac480fde938e
bccfd131-2e1a-4201-86c1-2a8f42a16bfb	t	Coko	c32f9205-2976-491d-87eb-366292971a5f
156e156b-e491-4766-9a78-6612c7684163	t	Gitara	c32f9205-2976-491d-87eb-366292971a5f
c604aeed-0287-4d18-b4e7-96c0dd010a98	t	Ruko	c32f9205-2976-491d-87eb-366292971a5f
b28dec95-60d5-4a21-b9cb-01f26461f7c0	t	Cyahinda	855d3c55-ba35-4878-a70c-3ea28a28b91e
28f25b01-f730-48ad-ad0e-6ed204603a5f	t	Cyanwa	855d3c55-ba35-4878-a70c-3ea28a28b91e
dfb8046f-1537-4c68-99bb-1367c3a8f20a	t	Kinyaga	855d3c55-ba35-4878-a70c-3ea28a28b91e
71add35f-2f1f-43f4-af03-c43b2c81ffe9	t	Saburunduru	855d3c55-ba35-4878-a70c-3ea28a28b91e
0b7b9661-37ab-45da-8971-ae87fcbeb8d6	t	Rutega	855d3c55-ba35-4878-a70c-3ea28a28b91e
68ea4106-402b-43c4-a8fd-515936da6af1	t	Gasasa	e958a7a2-8413-44f8-93bb-376911b8d57d
6bea6ed2-3767-4817-a54a-7c0e35a2cbdb	t	Kavumu	e958a7a2-8413-44f8-93bb-376911b8d57d
e1803017-6435-4dc9-ad84-67273403dce6	t	Ryamarembo	e958a7a2-8413-44f8-93bb-376911b8d57d
8452350a-47a1-484a-ba58-4644dab03c33	t	Busanza	f90e335d-ad32-4d33-a2c3-1635469af1ed
70866ab0-bb86-4806-9180-4fe441581465	t	Byanone	f90e335d-ad32-4d33-a2c3-1635469af1ed
4efbe220-8339-4a51-b84f-43d42b3648f7	t	Gasharu	f90e335d-ad32-4d33-a2c3-1635469af1ed
d378651b-67e9-4797-a343-6f449703e0aa	t	Kubitiro	f90e335d-ad32-4d33-a2c3-1635469af1ed
b1f82068-dfda-4240-8f85-a9f9e141dc6f	t	Nyagatovu	f90e335d-ad32-4d33-a2c3-1635469af1ed
942ecbcb-c249-46c5-9666-aa77c2fe308e	t	Rebero	f90e335d-ad32-4d33-a2c3-1635469af1ed
8d98cf9e-678d-4249-b337-b95322add53a	t	Kanyinya	c89bd8bc-ed21-46fd-a116-ccfb324fa9ef
d8ba3c5e-44e7-42dc-bfa3-ad3e07e454ff	t	Kibumba	c89bd8bc-ed21-46fd-a116-ccfb324fa9ef
4e9a05f9-c9e3-48d2-86a3-cb7a82283f8a	t	Rubona	c89bd8bc-ed21-46fd-a116-ccfb324fa9ef
e1fd7a12-f41d-4632-bc97-0340a1408f3e	t	Rugarama	c89bd8bc-ed21-46fd-a116-ccfb324fa9ef
e2f3b031-b1b7-4916-9773-1a00fdf1f65c	t	Rutobwe	c89bd8bc-ed21-46fd-a116-ccfb324fa9ef
93049cbd-768c-4e0b-966a-7c1ddd50fcfc	t	Viro	52abc701-d625-4155-95f4-676f07fba4fd
870e5c99-23d3-44ac-943a-13487be4774c	t	Agateko	1eba0e01-47e2-405f-b826-1112cd2b6c4e
a0c53d81-347e-466b-a8dc-56e19fcf84c8	t	Akajonge	1eba0e01-47e2-405f-b826-1112cd2b6c4e
1db775d1-c4b2-4d3f-a02e-e6ae15749c68	t	Sinayi	1eba0e01-47e2-405f-b826-1112cd2b6c4e
6e7314db-cfec-4a6f-8de1-7130c20d9656	t	Rwimbogo	2c10107a-e1bb-4318-b8c7-583a941e29a6
74d0b5aa-f5e1-40f1-a512-0925c9f27ae5	t	Banga	b685946f-6fd4-4da2-8c6e-b826384f6372
2c901278-71e7-4b12-9a66-362a4a62f9c6	t	Kibayi	b685946f-6fd4-4da2-8c6e-b826384f6372
ed8c6bba-74c3-466a-9e5f-defcfda92bcd	t	Mpanda	b685946f-6fd4-4da2-8c6e-b826384f6372
b11feafe-6349-4892-9808-28b4f9edc531	t	Munege	b685946f-6fd4-4da2-8c6e-b826384f6372
25970f8e-36fb-4cbf-949d-53a1d2020cd5	t	Mubuga	ec58c769-a252-439a-92da-4830ea7dcd2c
fb7e7899-ab67-4668-b5fd-6012f3ce6b82	t	Nyarusovu	ec58c769-a252-439a-92da-4830ea7dcd2c
34e9013f-a534-408b-b149-6a4126f625c3	t	Nyarwumba	ec58c769-a252-439a-92da-4830ea7dcd2c
2d0c09fe-e8b8-44e1-9762-45d033cd2c4f	t	Uwintobo	ec58c769-a252-439a-92da-4830ea7dcd2c
85960702-ebae-4f69-b90c-5df3b3e9c06a	t	Agateko	5e66db1a-ee12-4009-a1a9-e6e84277b332
177c66e7-2922-4c20-99e5-80528ee62925	t	Businde	043e6255-45d8-4dfe-8d05-45740ac67fc2
61b23301-e008-44f7-af78-9cd88122c901	t	Cyanyirankor	043e6255-45d8-4dfe-8d05-45740ac67fc2
f5a5546d-b8f4-47ea-ae39-be4c3ca795d6	t	Ruganza	043e6255-45d8-4dfe-8d05-45740ac67fc2
d1e34bee-63b4-49d4-a4da-cf13d21bfdad	t	Gasezo	633844ac-7e59-4eb6-be17-41435a599625
d319a2b5-a924-46b2-b172-f0da501c9bee	t	Uwamizirikan	633844ac-7e59-4eb6-be17-41435a599625
d631bdf2-2c76-49ce-b1b9-d4e2efc815f5	t	Kabeza	f21b81c1-17d3-45bd-8f5e-c1aa6dc6c6b1
ca2d931f-7cd3-4950-9211-3a6b0e12c2db	t	Kabingo	f21b81c1-17d3-45bd-8f5e-c1aa6dc6c6b1
85f23e75-b6fe-4fab-b693-817b3ecd657f	t	Uwisaga	f21b81c1-17d3-45bd-8f5e-c1aa6dc6c6b1
02643557-1841-4103-ab4a-ebec2919f395	t	Kivu	ac87e618-d296-4892-8a4a-6a11ced13831
1bc12031-3171-49d4-8fb7-4a8bf459e12f	t	Murambi	ac87e618-d296-4892-8a4a-6a11ced13831
83711e45-0aa0-4da8-9246-ad3049a83b9a	t	Rubumburi	ac87e618-d296-4892-8a4a-6a11ced13831
93e328b1-9b3a-4a70-9768-80e665b81d15	t	Rusuzumiro	ac87e618-d296-4892-8a4a-6a11ced13831
f3086f82-3ac1-475b-a636-58cf3f4b1665	t	Kivumu	4998e6b7-d0f1-4761-980e-b2399efd2281
ee927b34-ab56-4d4f-88cf-13a8f2edcca1	t	Nyarwotsi	4998e6b7-d0f1-4761-980e-b2399efd2281
d7b21473-6dbf-4dda-9e88-df0eaff0ff18	t	Rugerero	4998e6b7-d0f1-4761-980e-b2399efd2281
666aa2e8-ce7f-4b12-83f2-c6b1d6962e49	t	Mataba	c57b1143-c8df-49bc-8355-54872857a493
9019bb88-8d64-4a49-813e-48456c867a04	t	Ruhunga	c57b1143-c8df-49bc-8355-54872857a493
96ed20a1-ddd8-4977-8abf-ac41ba8bea31	t	Mata	63a87db5-c9ae-4231-8fc8-36c62bfbe5ab
c929d85f-5998-4d98-8d71-5bd84bd8f917	t	Murambi	63a87db5-c9ae-4231-8fc8-36c62bfbe5ab
f98694e8-800a-4a21-b39c-dcc9e449b5e9	t	Nyamyumba	63a87db5-c9ae-4231-8fc8-36c62bfbe5ab
e8468ddd-7902-4b2d-939e-e30b97b38432	t	Runono	63a87db5-c9ae-4231-8fc8-36c62bfbe5ab
8ba2e7c4-3572-4bf6-a543-20c5a2639380	t	Nyacyondo	3301ca98-b533-4cff-a53a-cbc877b42f56
af99b79f-f554-4d7f-bbe3-fb9079fded73	t	Rwinanka	3301ca98-b533-4cff-a53a-cbc877b42f56
7a14bf39-f2b3-4d7b-97b6-328177fcd128	t	Cyafurwe	4258d9bc-81ff-45b4-98d2-46c0acd5db1d
05bd2acc-f552-41e7-baef-3e54fa036b3f	t	Gasasa	4258d9bc-81ff-45b4-98d2-46c0acd5db1d
fb39cea5-f57a-4bd2-a901-54e59886183e	t	Ramba	4258d9bc-81ff-45b4-98d2-46c0acd5db1d
8a09a3ab-ec94-4755-b584-1b7c428c8489	t	Taba	e2a3c837-e2a0-4eed-8864-22367eb54ccd
31fddf53-9f78-4290-bdc3-18baa1d09740	t	Mubazi	73c57327-89f4-4d5d-88f2-51b956a73d64
ca868d47-1c5c-4ca8-85cb-5cd990d63e6a	t	Muganza	73c57327-89f4-4d5d-88f2-51b956a73d64
23dae57a-74ad-4b38-a5b6-4e5654152f45	t	Ngara	73c57327-89f4-4d5d-88f2-51b956a73d64
e3db621a-2a36-42e7-9796-306481a0eaee	t	Nyabirondo	73c57327-89f4-4d5d-88f2-51b956a73d64
d721ccb4-570c-42bd-b8c4-ff43e1a1aa84	t	Rambyanyana	73c57327-89f4-4d5d-88f2-51b956a73d64
cee405c5-ba9b-4a37-b4ad-8f43b446986d	t	Nyagisenyi	ddaad8fb-33ce-4239-ad83-0367dbc0d970
54e556ff-b248-4c60-b288-f875c5e6d02d	t	Remera	ddaad8fb-33ce-4239-ad83-0367dbc0d970
4ea448f0-c3f8-414b-8567-477ad13cfc7a	t	Rwishywa	ddaad8fb-33ce-4239-ad83-0367dbc0d970
85374ba8-8303-452f-bfcc-db8a9fcb9eba	t	Bigugu	121700d1-4ff7-44c7-be22-cc6b84556a0a
85a84714-bb8c-4f54-b831-61e1c3e1b7cd	t	Cyurukore	121700d1-4ff7-44c7-be22-cc6b84556a0a
9f7a7867-3b0b-42fa-a843-0706521460bb	t	Gituntu	121700d1-4ff7-44c7-be22-cc6b84556a0a
24ad426f-71f2-4b1b-ad56-d73e8b3c7dc8	t	Kigwene	121700d1-4ff7-44c7-be22-cc6b84556a0a
96b421b7-2659-4ed1-8a19-17ffaab11702	t	Tangabo	121700d1-4ff7-44c7-be22-cc6b84556a0a
6feccf5e-f9fa-4637-b734-5429dcc2f28e	t	Migendo	2863ad1f-fdb7-4318-9e3d-68c4e8202da0
5fcebf1a-880a-49a4-8653-7ff5c1e64149	t	Mukongoro	2863ad1f-fdb7-4318-9e3d-68c4e8202da0
a30ee040-2a8a-4fb8-9201-61b6226bee69	t	Sekera	2863ad1f-fdb7-4318-9e3d-68c4e8202da0
18a64038-86a5-4476-9a73-d60eb7568003	t	Agatare	c2e855e1-4fda-4da2-a15c-86b1f6965318
fce3f921-9fd4-43ff-9e1e-c28d93e87730	t	Gisizi	c2e855e1-4fda-4da2-a15c-86b1f6965318
8a0cd2af-1d4a-403d-bbee-05794793df63	t	Gitega	c2e855e1-4fda-4da2-a15c-86b1f6965318
1ad5dc8b-54ee-4a4f-a5a6-187458d7346b	t	Uwumuko	c2e855e1-4fda-4da2-a15c-86b1f6965318
d14211ef-d9d9-4ba3-bb2c-c2302b25f3ba	t	Akagera	fb40d41d-a43a-4d88-8494-f6e790e680e0
d0ca133d-9cde-44e7-bae0-2996ae702e5d	t	Mushwati	fb40d41d-a43a-4d88-8494-f6e790e680e0
3e963df1-0cfb-4487-8e18-e701d78bd6e3	t	Rubona	fb40d41d-a43a-4d88-8494-f6e790e680e0
454a545a-3a3d-4d45-bae1-b60f65adb3d3	t	Ruseke	fb40d41d-a43a-4d88-8494-f6e790e680e0
623c07d9-4271-48da-b5c0-019e83112960	t	Kabirizi	b9bd6c6d-53f9-42fd-b81c-63d760b15dc6
36cd1286-c645-4bfe-a994-28e8f436ba98	t	Umurambi	b9bd6c6d-53f9-42fd-b81c-63d760b15dc6
ecf4e348-14a9-488b-b849-e3ecd6050c07	t	Kamana	c039ad7d-9596-46f7-8c9b-05278f575d69
a7e185f2-f1d0-43c0-ab6a-94ec7203c292	t	Kimena	c039ad7d-9596-46f7-8c9b-05278f575d69
f56aa0b8-80e9-41d5-b317-5c87bba7bed6	t	Muhororo	c039ad7d-9596-46f7-8c9b-05278f575d69
039d6bfa-c238-4a14-980e-b48cbe4665b9	t	Nyarure	c039ad7d-9596-46f7-8c9b-05278f575d69
2fd9554a-e56a-4f43-b1e2-e85d06edded7	t	Sheke	c039ad7d-9596-46f7-8c9b-05278f575d69
f23449ef-e2b2-49ce-9aec-8c64c1b62dbd	t	Sheke	e2715554-222a-4040-aafe-bccf518c1de4
fff2d815-8fa3-458f-8266-010489c2a552	t	Cyamutumba	5ad7f1fd-5ce3-46ce-a8fa-981ea684da52
a982dd29-3683-491a-b77b-ab5e64e939e4	t	Mukuge	5ad7f1fd-5ce3-46ce-a8fa-981ea684da52
df511dd9-9d2c-48be-b036-4f67e96606bf	t	Nyarugano	72703c5d-6706-416f-848e-d82bbfeeeace
9c5d61e4-3317-4944-85b3-dca78515e848	t	Runyami	72703c5d-6706-416f-848e-d82bbfeeeace
2ca16a17-c3de-4c00-96ea-15028365dc90	t	Mubuga	1a31b9b4-1fa8-40d4-8560-397e1aa4dbb5
c64532b9-69d0-49d3-b477-409206b9c9c6	t	Gisozi	7b3fdece-85c0-4d3b-bf96-580e7f44d57c
393c2baf-c3d6-4053-9bb3-7bb73d26a2d0	t	Kibingo	7b3fdece-85c0-4d3b-bf96-580e7f44d57c
1fdcbe6e-4d30-4027-9c31-75a690b4c66e	t	Nyanza	7b3fdece-85c0-4d3b-bf96-580e7f44d57c
a760cda8-958b-4acc-864d-90c927ddfc0d	t	Buhunga	23968414-166b-49a4-a074-c026c7470ff4
60043a58-5efe-4eee-be6f-43e72eb12f76	t	Yaramba	23968414-166b-49a4-a074-c026c7470ff4
8d740dd8-9f69-4ffa-83e1-d0496b716464	t	Gasha	4e4b2412-9f30-4cc3-926e-67d9ad344978
3102bfc0-33ce-4b30-b119-13534f74a51d	t	Nteko	4e4b2412-9f30-4cc3-926e-67d9ad344978
255cfc81-0c56-4ef8-8f31-84de23266203	t	Ruli	4e4b2412-9f30-4cc3-926e-67d9ad344978
a322c8f5-cbfb-4099-8b14-ebfbf9901b46	t	Akagano	82c23631-4a27-4f7f-b6fe-7cf438b607e5
d53502f7-c4a2-4569-a15a-3f2ac85515ca	t	Maraba	82c23631-4a27-4f7f-b6fe-7cf438b607e5
90f82780-be2b-4d77-a8f0-7e00b667ea00	t	Munini	82c23631-4a27-4f7f-b6fe-7cf438b607e5
18f7e2b6-3f71-4b0b-a185-301804a0c016	t	Mwumba	82c23631-4a27-4f7f-b6fe-7cf438b607e5
8a5b3dab-f903-47cc-8d47-b21ac6f56c79	t	Ururambo	cc0d1643-3b72-44bd-a046-c5ea04b5bcab
4497d61a-d730-45fb-b8f8-0c1df6be54f1	t	Akabuye	db9ba809-5494-49d8-90e5-cf5dc2432b07
2731acb6-1d9a-48d3-ac5b-d5a7791c18e7	t	Bihembe	db9ba809-5494-49d8-90e5-cf5dc2432b07
663788cd-21b7-4c04-b025-cdb077d32410	t	Nyagasozi	db9ba809-5494-49d8-90e5-cf5dc2432b07
084d3173-6c27-44db-a463-7c4cf4a2cf3d	t	Rushubi	db9ba809-5494-49d8-90e5-cf5dc2432b07
31a9fe25-31d8-40f4-bc31-a8d22d708372	t	Bihembe	86eef330-ca27-4054-bfc4-09abc4de944c
0b6b9c16-98fa-4f21-9f97-e80497a87915	t	Rugarama	86eef330-ca27-4054-bfc4-09abc4de944c
8d705796-0cc5-48a3-a686-6f93d2fecb04	t	Uwurusugi	9a77e63c-6b03-4503-8271-0caae654b92a
3c728ab9-e25d-4875-bcf3-6f3459a731e5	t	Mishungero	1e7f42db-7d61-4769-8fac-35d0d07e38da
676279ac-28ae-4fbe-91c8-343007725258	t	Ngarama	1e7f42db-7d61-4769-8fac-35d0d07e38da
d67fc00c-db4d-497a-b099-db265eb9f7bf	t	Rubindi	1e7f42db-7d61-4769-8fac-35d0d07e38da
3a87cf28-746c-4c8b-96fa-dcdc14e87a99	t	Murambi	debc248e-9eb6-4a15-adc9-ec6ed26a0932
1b1ffcf7-21aa-4d1b-8956-a25ea0c7c094	t	Mutobwe	debc248e-9eb6-4a15-adc9-ec6ed26a0932
5af6a768-6624-49db-8c87-f7ed15905b9c	t	Nyabimata	debc248e-9eb6-4a15-adc9-ec6ed26a0932
58f34686-482b-4e3d-82f3-44ab68c60379	t	Agasugi	b97fb7a0-60bd-4937-a299-5c140afebbc3
8c198331-00a7-4ff8-8678-54a0c358309e	t	Ndaro	b97fb7a0-60bd-4937-a299-5c140afebbc3
9508bdc0-7384-4204-8e48-48e6e5c6f734	t	Ruhinga	b97fb7a0-60bd-4937-a299-5c140afebbc3
65d67675-b50b-45c2-9f15-f614022c19cf	t	Maraba	7fb028ea-62ca-4f74-9571-b69861fcfb03
1cc36e15-0094-4f40-99ae-ac715f78a2f2	t	Nkima	7fb028ea-62ca-4f74-9571-b69861fcfb03
4fe21fff-d4f9-4843-a2fa-3ece093ec1b9	t	Rushunguriro	7fb028ea-62ca-4f74-9571-b69861fcfb03
22325d35-9895-4728-8f74-914d662fdbf6	t	Bwerankori	9dd6ab32-9d1d-46fa-b65f-cdb079da64b8
187aca35-6e87-4a17-9c84-88e8c958feed	t	Bihembe	b7ddf90d-951e-4787-beb9-7f82bf11e47c
eb59af81-f309-4a6c-aa51-c4a01213b9c3	t	Nkakwa	b7ddf90d-951e-4787-beb9-7f82bf11e47c
eb5a5530-66a9-44a0-a4a2-7a817e80587c	t	Rarire	b7ddf90d-951e-4787-beb9-7f82bf11e47c
0ac93a76-83ca-487a-8c0d-7d6fdbd71a5d	t	Rubuga	b7ddf90d-951e-4787-beb9-7f82bf11e47c
a1f1386e-9cad-4f33-988b-2be7faa158b4	t	Muriza	22eb4f2d-2308-4709-8580-63b99c15a2a9
92f8a90b-2634-4491-a4fe-5ce77b48ba03	t	Nyagishayo	22eb4f2d-2308-4709-8580-63b99c15a2a9
ec1a69f9-66ea-4f15-8a4b-ae203f4ba183	t	Nyamiyaga	22eb4f2d-2308-4709-8580-63b99c15a2a9
56cf64c3-c087-4ca7-b034-edb589a25cc6	t	Ryabidandi	22eb4f2d-2308-4709-8580-63b99c15a2a9
0870f79f-73a4-47b6-8e90-f0edeb2f9cf3	t	Uwimfizi	22eb4f2d-2308-4709-8580-63b99c15a2a9
a9669101-ab0e-4ffd-897e-8cddcc4cef79	t	Nyacyonga	619f7cf8-cdaa-417b-8918-361982f0b704
067b0dc9-3929-48ab-ba10-83bc8a5259a2	t	Busenyi	e149ba4f-02e2-4405-911a-b24090173a8a
62def351-d966-4dfd-a5b9-d635cc0eead5	t	Gambiriro	e149ba4f-02e2-4405-911a-b24090173a8a
d3031673-7d2d-456e-b6e5-721e4634c0ba	t	Cyivugiza	95412e2f-f613-4512-aaec-c2c875551668
c52f8b2c-332a-4a99-8681-210ab6a85364	t	Gitwa	95412e2f-f613-4512-aaec-c2c875551668
a86ed627-8aa6-473b-acac-ad13544ef957	t	Mutumba	95412e2f-f613-4512-aaec-c2c875551668
1c4bb95c-f4e7-416b-b4ba-6ebb55c8df54	t	Uwinyana	95412e2f-f613-4512-aaec-c2c875551668
f1a6fe57-2694-4bfa-a999-7927cf205b5c	t	Ruyenzi	7041f288-8950-4fc8-ab1c-77295d2d7221
d35fae2a-9c06-4ecd-aeaa-cf3777665199	t	Zirambi	7041f288-8950-4fc8-ab1c-77295d2d7221
25a985c6-5fde-42ca-b733-4e38c1c48fae	t	Gakaranka	060460e0-f9f6-4c4b-8518-efc30fe524b0
f77be1e8-9e85-4c72-bbc9-8270f625b353	t	Mubuga	060460e0-f9f6-4c4b-8518-efc30fe524b0
018de8b5-c4ed-4c95-a67a-0639df18fe2c	t	Rugote	060460e0-f9f6-4c4b-8518-efc30fe524b0
8a8473e1-a72e-4826-8faf-a1ef7128c959	t	Uwimbogo	060460e0-f9f6-4c4b-8518-efc30fe524b0
b78f450b-7005-4ccd-94f6-d63bea843ece	t	Yanza	060460e0-f9f6-4c4b-8518-efc30fe524b0
e53bcb91-860d-49cf-8706-9946a3aea96c	t	Bukoro	f61dbeb9-2acc-4d8b-b6a4-09e8a4d14526
5df5aefe-785e-4ec6-b1dc-294e43b6241d	t	Kageyo	f61dbeb9-2acc-4d8b-b6a4-09e8a4d14526
2cb24ee9-25cf-478e-ad41-5863da7db51c	t	Giseke	1a4e192d-4bfb-49f6-8871-1b46e1f9dd6f
d3ed616e-2824-4277-b61b-59ec6e5d2e82	t	Kabari	1a4e192d-4bfb-49f6-8871-1b46e1f9dd6f
3ebfad87-89f9-421a-b428-f445d0666450	t	Matyazo	1a4e192d-4bfb-49f6-8871-1b46e1f9dd6f
cc241678-da8c-4989-a0de-998614cb4843	t	Gisorora	e921c6d3-cb9e-4bc4-a6de-3251ef8b059d
5d76e28c-eca0-42b8-982b-1fd7c149cb2a	t	Kinyonyo	e921c6d3-cb9e-4bc4-a6de-3251ef8b059d
eb3f044e-891e-4420-8b78-81ebe030879d	t	Uruyange	e921c6d3-cb9e-4bc4-a6de-3251ef8b059d
41666ab2-714a-449f-a26d-6a2557dea71b	t	Bugizi	d963a52a-f641-49ee-b9ce-4798e1a6a214
8a59d0db-2ac8-4b8c-b908-8141967588d0	t	Busasamana	d963a52a-f641-49ee-b9ce-4798e1a6a214
38a00732-32f5-4624-a116-4b8f4cc9781f	t	Karambi	d963a52a-f641-49ee-b9ce-4798e1a6a214
a165b3cd-af1b-4f44-af80-399b0afc55c4	t	Ruramba	d963a52a-f641-49ee-b9ce-4798e1a6a214
e5ff7502-7e34-4d20-a533-a3bcba504ff3	t	Jali	4b968b06-fe64-48c8-a231-d2619ad39268
315f745a-39cf-40e6-901a-7f2bad93f53c	t	Toraniro	4b968b06-fe64-48c8-a231-d2619ad39268
15c5e0d5-bcec-4814-b3fe-843964b07d64	t	Cyuna	25e8ba59-4625-4611-ac28-075f94fb0178
dfd731e5-8c9c-4b4f-bec7-5df49d84eb08	t	Kiramutse	25e8ba59-4625-4611-ac28-075f94fb0178
3801c82d-12b6-4c84-b664-a63abcfa776d	t	Remera	25e8ba59-4625-4611-ac28-075f94fb0178
936348d6-4859-42d5-9368-3dce6598898a	t	Uwamuhizi	25e8ba59-4625-4611-ac28-075f94fb0178
14a98356-aad7-4e3a-b9d7-be111b680bd5	t	Kibu	b9f5f74c-13e8-4184-ac1f-1c60dd3f92dd
dfa70f19-d309-4f25-b782-0cd065bf6c90	t	Rwabujagi	b9f5f74c-13e8-4184-ac1f-1c60dd3f92dd
7ac631d0-32b0-4146-9485-932658ae90db	t	Gihango	2c9e1a09-3dc0-4428-8f05-4d4aca43b46b
c84bede3-34df-45d5-9388-605a8173862f	t	Kabuye	2c9e1a09-3dc0-4428-8f05-4d4aca43b46b
7945cf79-06ee-4a98-9e34-d264fb84686b	t	Miko	2c9e1a09-3dc0-4428-8f05-4d4aca43b46b
912fd8e7-557c-4292-8170-03e835445e75	t	Rasaniro	2c9e1a09-3dc0-4428-8f05-4d4aca43b46b
fc2032da-b9bc-414c-91c4-6642ea89c37d	t	Gasave	ed5db0ad-0b37-4b6a-8710-dc1dc169e3a5
3f65cbd2-5144-49b3-99af-02fc23e4530b	t	Karimba	ed5db0ad-0b37-4b6a-8710-dc1dc169e3a5
0db323aa-cd03-40e5-a2f7-80f3d174f8c4	t	Ntanda	ed5db0ad-0b37-4b6a-8710-dc1dc169e3a5
59c27fca-ae82-40c3-a39d-359197a9b439	t	Kabacuzi	e7a802d6-2836-4f75-8286-df380b73ae7f
1619a207-50e6-44f4-838c-f6154f463636	t	Kamusindi	e7a802d6-2836-4f75-8286-df380b73ae7f
b94b90f3-a2e4-4518-bd08-d0dbc3248352	t	Kavumu	e7a802d6-2836-4f75-8286-df380b73ae7f
14f4d4c3-dccd-4086-8a48-f2186876be6e	t	Runyinya	e7a802d6-2836-4f75-8286-df380b73ae7f
166aa81a-8a1e-4544-8b19-709849cb19b3	t	Gakongoro	2008b1cb-f548-42ca-a6eb-dc1cf0c0c15a
19897ae6-df63-4ab1-93fb-9a9f978e8488	t	Kabugusu	6fff7527-a832-4ea9-877c-e325ad357ef8
65238030-4b05-47d9-b3b2-ec0c6cab658a	t	Nyamaraba	6fff7527-a832-4ea9-877c-e325ad357ef8
942eea9f-541d-4ae6-ae0e-6bc840900924	t	Gasharu	9cea8b60-e709-40c2-bcec-7b7b178a57aa
65b29891-cff7-4c0d-b1e4-7120b39e1197	t	Karambo	9cea8b60-e709-40c2-bcec-7b7b178a57aa
f3478a8b-575d-4ff2-b491-915b6352f942	t	Karutsindo	9cea8b60-e709-40c2-bcec-7b7b178a57aa
a41f4c90-25d6-426e-b3fa-f08f7e2f8be3	t	Rusororo	9cea8b60-e709-40c2-bcec-7b7b178a57aa
3dfde4e0-0f82-4714-92f9-de301efc19cc	t	Birambo	9d820010-adc5-4d33-99ce-6ec7283496b0
41a597c5-4a4d-439f-858d-63e6b8b14447	t	Masambu	9d820010-adc5-4d33-99ce-6ec7283496b0
5e837fc3-f2f6-43e1-b6ca-ae0b62d681b4	t	Nyagasozi	9d820010-adc5-4d33-99ce-6ec7283496b0
9f749dff-ce3b-497a-ab83-a31c2c69e94c	t	Nyarubuye	3a2c8864-3d16-4f96-8ba7-12d7c81771ef
cd58a11d-bbf9-4b2e-99d6-07b8b5315f39	t	Rugogwe	3a2c8864-3d16-4f96-8ba7-12d7c81771ef
23d0e17c-bd7f-4631-85ef-9a36b770bc1c	t	Gakomeye	2c3a862f-2169-451b-8bcd-44cc656ad65d
4096d115-3911-4b72-90f9-67e5e5f2e3a5	t	Gakurazo	2c3a862f-2169-451b-8bcd-44cc656ad65d
a5853418-4a9d-4521-9434-394c39bd93c4	t	Gitanga	2c3a862f-2169-451b-8bcd-44cc656ad65d
5593f98b-e36c-4e76-ae05-3d48d45f9fb7	t	Gatoki	8e29389f-ef23-4ba2-b59c-d2ff5d14497b
f8061b2a-a9da-4b75-a502-39458cba32a8	t	Kirengeri	8e29389f-ef23-4ba2-b59c-d2ff5d14497b
0457cdbc-3203-4cac-afd0-14ba4fbfc5d8	t	Nyabizenga	8e29389f-ef23-4ba2-b59c-d2ff5d14497b
c8b4829c-b0b1-46da-8350-592676db5402	t	Kavumu	690192db-9cfe-4621-9f19-3726eaae97ac
b3ce49ed-68cf-4b97-a38e-b0ee917764c8	t	Muhororo	690192db-9cfe-4621-9f19-3726eaae97ac
f525da93-aa69-4140-846c-91618723585f	t	Mutobo	690192db-9cfe-4621-9f19-3726eaae97ac
4644c14d-231c-44d2-afba-6a0511aa4856	t	Gitega	1f667d1a-7449-4f03-8ad7-ededb027aa35
e5a86f5e-644a-42e9-87a8-53ed62a5df45	t	Kanyarira	1f667d1a-7449-4f03-8ad7-ededb027aa35
c48acefc-87ff-429b-a4d2-4e995ac3bbdc	t	Bukomero	a1bd43f5-b02a-42a2-a51a-ede2bbb8909e
adfaec5c-e005-4c73-855d-5d58e6aed0b8	t	Karenge	a1bd43f5-b02a-42a2-a51a-ede2bbb8909e
c298de6f-b2e3-4130-9cc8-d3aa21c02891	t	Remera	a1bd43f5-b02a-42a2-a51a-ede2bbb8909e
8a9d3bd6-0fe6-4344-81c7-b209a30dc1cd	t	Bugarura	8a87bf5a-ddeb-4b69-b18c-f55d74f74f81
5c0f6716-11de-4ad2-90a9-c126609ee17c	t	Kageyo	8a87bf5a-ddeb-4b69-b18c-f55d74f74f81
4dd5ad7b-1632-471e-94ae-ffc87a4a071c	t	Ntenyo	8a87bf5a-ddeb-4b69-b18c-f55d74f74f81
123e3f0e-0757-4604-b9b8-5a5012d7b17f	t	Gasasa	42de3933-d6fe-47ac-9c2c-e31a836cc36c
9b39cc08-9bad-42a4-86f8-5a01ca547fb0	t	Kizibaziba	42de3933-d6fe-47ac-9c2c-e31a836cc36c
438e0358-8202-4e9a-8e8f-d370f41ca97b	t	Ndago	42de3933-d6fe-47ac-9c2c-e31a836cc36c
d16cfdc5-9440-49c4-a204-c57f75334d0b	t	Nyarubumbiro	42de3933-d6fe-47ac-9c2c-e31a836cc36c
c90311c8-f851-446b-858d-65f42a751c56	t	Bihembe	8215cd94-9a73-4dab-a3f4-b4b4ae970f6f
ee96a8c3-fb6a-475f-b9bd-e7fde503cfba	t	Kirwa	8215cd94-9a73-4dab-a3f4-b4b4ae970f6f
ad409f6d-f1b4-4df2-ac5a-cc048154cc2e	t	Kashyamba	cd43ad8c-5fd6-4bbf-a080-b8acc3b9bc03
d817ab71-4a25-4ca9-beab-05ba0d4a4020	t	Kagitare	58c11058-84f4-4324-8c6d-fb58e4c77cde
42da34bc-4b38-40b6-87b5-2e843c6cfe30	t	Munanira	58c11058-84f4-4324-8c6d-fb58e4c77cde
11cfafd0-82a6-49b0-b499-3fb322493447	t	Muremera	58c11058-84f4-4324-8c6d-fb58e4c77cde
bcd2d3bd-7562-41ca-9597-0e5437cef29d	t	Musekera	58c11058-84f4-4324-8c6d-fb58e4c77cde
114542e8-ddd0-4bf4-a1db-c58356e9b184	t	Muhororo	27652664-344f-49be-93da-4698548d8ddf
e8082569-3157-425e-a861-d4bdea820244	t	Rwankuba	27652664-344f-49be-93da-4698548d8ddf
7114fc97-47b6-42c0-9743-045eebe42ead	t	Rwesero	81fd434d-f8e8-448e-8732-42d0170e8cbb
92e46a02-44a3-401c-8ca2-8b09ba7ffeb2	t	Serugeme	81fd434d-f8e8-448e-8732-42d0170e8cbb
e0ccf5ca-d6c3-407e-8639-dfcb0fce9b68	t	Kanyinya	e7f155ac-a00e-42f8-9ac3-4d74e5cdc450
c71de844-eb06-4b11-8a1f-38aa427f9de0	t	Kavumu	e7f155ac-a00e-42f8-9ac3-4d74e5cdc450
811a1c8f-b442-40aa-b350-5b123bd78268	t	Nyarushishi	e7f155ac-a00e-42f8-9ac3-4d74e5cdc450
fe174d74-1f60-479d-93a6-e0f4980cae5d	t	Burima	1fc5daa2-bd37-4f61-be68-68c43c91f95c
4d743281-2353-48f0-af61-633072271a4a	t	Mirambi	1fc5daa2-bd37-4f61-be68-68c43c91f95c
4a265d7d-7c48-4b65-8094-0ff8fa89304e	t	Nyamiyaga	1fc5daa2-bd37-4f61-be68-68c43c91f95c
2bec0b77-2d37-4bac-a0ec-1420c85fa6b6	t	Nyaruteja	1fc5daa2-bd37-4f61-be68-68c43c91f95c
acca6d27-0596-4139-9ef0-7d330b4a7510	t	Gisari	05489fe3-94da-440e-9265-d4cffdeb8513
6d39d009-c306-4be3-b790-064009ac6e78	t	Kabeza	05489fe3-94da-440e-9265-d4cffdeb8513
4e77e2b4-7154-4758-86d7-8aca86aa4ebe	t	Kaduha	05489fe3-94da-440e-9265-d4cffdeb8513
40982ddd-6803-48ce-9af8-d65d933f4d52	t	Kakirenzi	05489fe3-94da-440e-9265-d4cffdeb8513
cb545d0a-087b-4a9c-a734-57c68be5fd9a	t	Kamuraza	05489fe3-94da-440e-9265-d4cffdeb8513
df615f41-dde5-49fd-a092-571f43208668	t	Kanaba	05489fe3-94da-440e-9265-d4cffdeb8513
a618bef9-2a34-4826-b20e-359cd322aba7	t	Matara	05489fe3-94da-440e-9265-d4cffdeb8513
7edd8e21-c375-4b3a-ada4-9d80abe91cf2	t	Nyabusunzu	05489fe3-94da-440e-9265-d4cffdeb8513
011d5343-3031-4cc4-b5ce-d4935b886042	t	Nyiranduga	05489fe3-94da-440e-9265-d4cffdeb8513
825360e4-76bf-4082-ab07-5baedb5f3bd2	t	Remera	05489fe3-94da-440e-9265-d4cffdeb8513
f3520099-b868-46f1-b40e-ec654e4de0fd	t	Impara	f59a8ab4-ae82-4338-9f30-4f565c1deb77
e0ae7065-91d1-41d7-bbbd-32b615d7c496	t	Kacyiru	f59a8ab4-ae82-4338-9f30-4f565c1deb77
dba8675a-92d5-434c-a589-c37dec5d3cf8	t	Karuhuga	f59a8ab4-ae82-4338-9f30-4f565c1deb77
5c1d306a-e222-4433-8917-c92222f15fb1	t	Nyabisindu	f59a8ab4-ae82-4338-9f30-4f565c1deb77
a8710273-7550-446f-abbb-b36eea7c9121	t	Buhanika	0a17d3c1-83e7-458f-8473-c2674843b8a8
6f369440-93ec-428c-a998-57619f45aec4	t	Gako	0a17d3c1-83e7-458f-8473-c2674843b8a8
d8d23867-475f-4cae-941b-59696e95f7a9	t	Kigarama	0a17d3c1-83e7-458f-8473-c2674843b8a8
6a3a264e-cb8b-4111-b4f4-c0aa3c2d8e35	t	Rubona	0a17d3c1-83e7-458f-8473-c2674843b8a8
deec9b51-396b-41b4-a903-1db0fbffba49	t	Susa	0a17d3c1-83e7-458f-8473-c2674843b8a8
8c467ccf-2dbd-4057-b117-a0c99b68e167	t	Gitwa	bbeff635-9f83-48ac-8d90-1e37a47602a0
832559b3-2066-4f59-8808-b6334fef10d5	t	Mukoma	bbeff635-9f83-48ac-8d90-1e37a47602a0
4bef16f8-56f7-4445-a82a-39fa40c184e5	t	Nyarugunga	bbeff635-9f83-48ac-8d90-1e37a47602a0
5159073b-3517-4af8-8875-ceba15c2d26b	t	Nyarunazi	bbeff635-9f83-48ac-8d90-1e37a47602a0
43174dea-d210-423a-9156-2beacbe7a432	t	Rutabo	bbeff635-9f83-48ac-8d90-1e37a47602a0
34cd27e9-7888-43a5-8783-84c26e1f1dd0	t	Gahororo	bf3cf9a3-4ff7-4bd9-bbbd-642e79d6dfd7
cd4c68f6-2684-425c-8e9c-d3fbdba12653	t	Gihororo	bf3cf9a3-4ff7-4bd9-bbbd-642e79d6dfd7
5db14b94-72e3-4d2f-bc32-66039923a684	t	Muremure	4a6bc4d3-7884-4b9a-b0f5-01c1d1b63b93
bdc5763b-414a-4dd6-81e7-555395cfdf7d	t	Nyagatovu	4a6bc4d3-7884-4b9a-b0f5-01c1d1b63b93
8dd62d2e-b017-4e05-8df4-de9799c1fb80	t	Nyamagana	4a6bc4d3-7884-4b9a-b0f5-01c1d1b63b93
9c0276a8-141e-4daf-8036-e589fffeba1f	t	Muyange	870d657e-4083-44ce-a06d-991cbfaac552
e8376dda-797c-418d-8f8c-ae3216060116	t	Wimana	870d657e-4083-44ce-a06d-991cbfaac552
85e37fa5-1e86-4c87-a1b2-a5dbefb2e49b	t	Nyarubumbiro	5f8d5d7d-0616-4a45-85ec-6f8912f5260d
4eedfc66-5549-4cbc-a988-4d2aaeb18d58	t	Nyarutovu	5f8d5d7d-0616-4a45-85ec-6f8912f5260d
7e7e2aee-a40f-4129-8e5a-0170f5926dc0	t	Kibirizi	0bd4ebe7-077b-4b87-8c8d-1354c00ed0ce
8d5edca3-8e8e-47a0-962e-03ed534bb95e	t	Rusizi	0bd4ebe7-077b-4b87-8c8d-1354c00ed0ce
6ce5b129-5fd9-4bd9-9384-bc4dbb9b05f0	t	Kabacuzi	39b2d6ac-ce66-4244-bba7-2e48137481cc
8e206893-61fc-4ce5-8f41-1486b3c1f715	t	Kabirizi	39b2d6ac-ce66-4244-bba7-2e48137481cc
f58458e7-4350-48ee-9ec9-366bae3c4f35	t	Munini	39b2d6ac-ce66-4244-bba7-2e48137481cc
cff2c200-cee3-41e7-bb4f-96267c909ef5	t	Kabungo	b7c7356c-08ee-45b0-b75f-211b9860336c
a0746f15-5143-4afe-93f1-15621f41942b	t	Nyamikoni	b7c7356c-08ee-45b0-b75f-211b9860336c
80f22464-bbf5-4ba9-b70c-899dba9277b3	t	Gishari	d1b28895-c90f-4bf5-860d-9b4c8ceaac09
4b3e2730-7087-4a89-b243-77f1de93c869	t	Karama	d1b28895-c90f-4bf5-860d-9b4c8ceaac09
826c316d-a61a-4cf6-a6d6-8a39cadab29c	t	Kavumu	d1b28895-c90f-4bf5-860d-9b4c8ceaac09
ff4c6e1f-c482-4dae-8c2f-2af9bfd0045f	t	Kabuga	be050979-b617-4cb0-a9c2-cddddc5f947b
e14f38a0-447a-4e1b-8f2d-b48c7f953904	t	Kinyinya	be050979-b617-4cb0-a9c2-cddddc5f947b
38fa421d-d542-49a2-ba44-1936fd6b9c10	t	Musenyi	be050979-b617-4cb0-a9c2-cddddc5f947b
7302d0f1-e4cd-43a2-8696-37969dc38da8	t	Nyakabanda	be050979-b617-4cb0-a9c2-cddddc5f947b
5107c9f3-37fa-4be5-bf14-01f97f274aa0	t	Bereshi	ba5570fd-72c8-4904-b79d-68d030473577
f2d2d7cd-6404-4bb7-b061-6717b1584aa6	t	Biraro	ba5570fd-72c8-4904-b79d-68d030473577
7c6968fd-092e-4e33-bbf3-45f7980b8a45	t	Kizibere	ba5570fd-72c8-4904-b79d-68d030473577
6305fdea-fdaa-4dfe-a0e6-930da1c0da6f	t	Mayunzwe	ba5570fd-72c8-4904-b79d-68d030473577
9e4bb586-f227-4dd8-8023-553725f72eb2	t	Rebero	ba5570fd-72c8-4904-b79d-68d030473577
0efd0cce-550d-4a4e-80eb-8f729baad861	t	Buremera	b34a5c1a-5737-4925-bda8-9185baebd439
80973556-4b41-4c1b-a63b-2872c881853f	t	Cyobe	b34a5c1a-5737-4925-bda8-9185baebd439
1aad3015-cf92-4c24-b565-11b6beacc4cb	t	Kamurema	b34a5c1a-5737-4925-bda8-9185baebd439
c8759b30-9f21-4f5b-86e9-620a2905c88a	t	Rwimposha	b34a5c1a-5737-4925-bda8-9185baebd439
ab67ba11-599d-488d-bd1c-e9b9a886f810	t	Cyanika	c9cacc22-12d0-4acd-aa2f-e7b53ecb3c97
568d32ca-29b1-4683-961d-65b4a6a710b9	t	Giticyuma	c9cacc22-12d0-4acd-aa2f-e7b53ecb3c97
f549fbf5-d1e9-45a3-80a2-3a581b86a859	t	Ipate	c9cacc22-12d0-4acd-aa2f-e7b53ecb3c97
12b02ca4-aebc-4946-8380-139c8e4a5698	t	Kabuga	c9cacc22-12d0-4acd-aa2f-e7b53ecb3c97
5806124e-da47-4387-b53e-db114813dcdc	t	Karama	c9cacc22-12d0-4acd-aa2f-e7b53ecb3c97
dfa3e9a8-a5f6-49cc-bf30-9a84a74e7730	t	Vunga	c9cacc22-12d0-4acd-aa2f-e7b53ecb3c97
b1ec8524-c891-4cea-90d7-be6de33ddf51	t	Kigabiro	7dc65a49-b555-43f0-848b-142ce14ee10d
d07fbb8b-b71f-4aa5-951d-72bfde997183	t	Nyakarekare	7dc65a49-b555-43f0-848b-142ce14ee10d
e5a2dc0f-90f0-4aa2-b100-9a36cc4c3ec7	t	Kimburu	190c5af3-3790-4d6d-a1f8-7ec47627d767
4f560b36-4359-4296-bdb8-24ba66281250	t	Ruhamagariro	190c5af3-3790-4d6d-a1f8-7ec47627d767
b46b0076-24a4-4897-af9c-ec055282f229	t	Kanzu	be796056-9f4b-4fd1-9f0f-6aaecb3d915b
9dd470ca-582f-4ef4-b43e-72d4dd89c5aa	t	Nyakizu	be796056-9f4b-4fd1-9f0f-6aaecb3d915b
bc74a07f-d84c-4dc4-a33b-29c868c10a82	t	Rubona	be796056-9f4b-4fd1-9f0f-6aaecb3d915b
a35549f2-6269-45c2-8114-35548977546b	t	Nyarusange	e3ddce41-1a83-46b6-a196-9c31e39ba3fd
0cf16361-abc9-4875-82e4-ada705c05b8d	t	Gitaraga	9e2548cc-6e81-4404-a7ff-46ef65b4ac3a
5ae535bf-719e-4ade-91e4-a7404f6f51a9	t	Kamuzimanga	9e2548cc-6e81-4404-a7ff-46ef65b4ac3a
ae0759b6-fc2a-4d70-8120-c1154b2437ce	t	Bunyankungu	b8154035-a9c6-458a-bec4-646012d90985
bf150d93-7604-4786-aff2-cbf64ad4b36f	t	Ntongwe	89503110-c967-452b-92c1-9979001f1dd3
b382ae60-f505-4de8-8d21-1fcd075a629f	t	Rugasari	eca181e4-820c-4f59-aa36-93347fd1cf3f
05ae9386-b6b2-46c5-975a-205a295f3995	t	Gikoma	ea27a6db-e3cc-4f63-bc74-a4c14ae1c9b0
731812b1-13e1-4494-9f80-0e5f2a353f19	t	Kantwari	ea27a6db-e3cc-4f63-bc74-a4c14ae1c9b0
05ccb628-af04-473f-9804-156cf3c47081	t	Nyabuhuzu	ea27a6db-e3cc-4f63-bc74-a4c14ae1c9b0
cb677525-2b72-43d8-ad3a-ed28c7711383	t	Nyabyugi	ea27a6db-e3cc-4f63-bc74-a4c14ae1c9b0
70f007d1-5044-416a-8c78-d40dc6c9d414	t	Kavumu	b3c43786-2b71-4190-87cd-6181f358d1c9
da0d599b-19df-40ab-b5ca-f740fac9d152	t	Kibatsi	b3c43786-2b71-4190-87cd-6181f358d1c9
10356f96-32dd-445e-a9a1-c3648949d501	t	Marimba	b3c43786-2b71-4190-87cd-6181f358d1c9
068eef71-a5a7-4c01-9a1e-576ded19afc1	t	Ruko	b3c43786-2b71-4190-87cd-6181f358d1c9
9790dc8b-1904-49df-ad78-13a63f20b843	t	Ntungamo	3072fe55-b919-42dd-aa4b-b8dae9d7c69a
96d4f06a-3673-4f9c-ad8e-004cf560ad9a	t	Nyamigende	3072fe55-b919-42dd-aa4b-b8dae9d7c69a
e744573f-3d1d-464d-a874-0bab21105f9c	t	Cyeru	62ab9544-a719-44bd-9dee-3538bb0f7dec
507079a6-aa74-4c5b-9a17-dce6aa632c49	t	Karama	037f4336-432c-46d1-931e-a5749cd71fcd
98922544-203b-4ece-8236-8a4f29a3c8d6	t	Nyarusange	037f4336-432c-46d1-931e-a5749cd71fcd
c63b606f-55cd-4497-a6e4-8409256f0792	t	Byimana	b1f3ede6-85e3-4fa7-84d6-98fdb746f97f
0fd7042b-4dd1-40b2-ab87-c060b2a1875d	t	Gacuriro	b1f3ede6-85e3-4fa7-84d6-98fdb746f97f
2c8727b7-38d2-4c31-af73-c452ee8179ea	t	Karama	b1f3ede6-85e3-4fa7-84d6-98fdb746f97f
77ea9a9e-d1a5-4f77-991c-ba7e36c0ca63	t	Kigabiro	b1f3ede6-85e3-4fa7-84d6-98fdb746f97f
7f5335f5-fc42-4efb-b444-858a25491144	t	Kintore	b1f3ede6-85e3-4fa7-84d6-98fdb746f97f
f067aeaf-4bee-432e-8a8f-986c1b4f8296	t	Mutima	b1f3ede6-85e3-4fa7-84d6-98fdb746f97f
0af36434-0823-4b72-9083-88edebe57a73	t	Ruhuha	374d8ced-f809-46a8-b70f-c5543e840959
16a74769-d92b-4c6e-b441-37b1e6470dc1	t	Buhoro	7d238fcd-29ac-4cb5-9234-37c5c2b6ffd4
6f8f691a-574a-4ff7-add1-249ae22ce1c0	t	Karambo	7d238fcd-29ac-4cb5-9234-37c5c2b6ffd4
ed5766bd-77e6-4a0c-81f6-bb14ea2e49dd	t	Muhororo I	7d238fcd-29ac-4cb5-9234-37c5c2b6ffd4
e737a322-7dcb-4f2b-bfa7-ea796b63bfd5	t	Muhororo Ii	7d238fcd-29ac-4cb5-9234-37c5c2b6ffd4
ed940ee4-cb79-495a-bca0-1df358772bf3	t	Rwinkuba	7d238fcd-29ac-4cb5-9234-37c5c2b6ffd4
33939fbb-90ef-4d3c-bef1-165201eb4e1d	t	Busego	0bc3f8d5-870f-4d72-8447-9888779674bd
b18c3a12-ac3f-492b-9427-e6b616e099c5	t	Kabega	0bc3f8d5-870f-4d72-8447-9888779674bd
ca4e7d48-6863-4e4c-bda4-8a93b9cc9c1a	t	Karehe	0bc3f8d5-870f-4d72-8447-9888779674bd
c792b27f-cb0c-447a-8287-2fd38755d042	t	Kasemahundo	0bc3f8d5-870f-4d72-8447-9888779674bd
af110f36-1c1d-4751-95ed-946284746e56	t	Nyabisindu	0bc3f8d5-870f-4d72-8447-9888779674bd
96625df1-d2fb-43a4-91b7-8af86fb843e5	t	Rusebeya	0bc3f8d5-870f-4d72-8447-9888779674bd
d70b1b34-d310-4b0e-bd25-c33ac6c96e6e	t	Rebero	63ac65a1-469a-476a-a6a1-58a7998bece8
ec86976d-ccd7-4453-a072-26670f0791d0	t	Rurembo	63ac65a1-469a-476a-a6a1-58a7998bece8
38c66686-c3f1-47f9-a4a2-27591f128f95	t	Bisambu	1d287df2-81d7-4d95-948c-47af9547622e
1d80cb43-81db-4139-9b28-239a670f1a36	t	Kibingo	1d287df2-81d7-4d95-948c-47af9547622e
00eb2f06-22f9-4ba7-a2b1-72c7e2dbf3aa	t	Muremera	1d287df2-81d7-4d95-948c-47af9547622e
64857634-0a79-44de-b4bc-1ee39d05f7bc	t	Ruhuha	1d287df2-81d7-4d95-948c-47af9547622e
cfecfc6d-8a2c-4864-91ce-9d08abb75e16	t	Cana	a505dbf3-ed45-4c4b-bf91-fd559c588998
79f86f2a-573d-4d11-9e12-1a75696bb090	t	Kabere	a505dbf3-ed45-4c4b-bf91-fd559c588998
00779c77-1390-4ce3-b68e-2a7d5b888dce	t	Kamabare	a505dbf3-ed45-4c4b-bf91-fd559c588998
1ed15ee8-fd1f-4bf6-b4e9-e217d9bd3362	t	Kinama	a505dbf3-ed45-4c4b-bf91-fd559c588998
65eff84f-772f-4629-a267-04dd6e4109d6	t	Mwali	a505dbf3-ed45-4c4b-bf91-fd559c588998
c395e424-8bd0-41d6-8e72-2579ac06d53c	t	Wimana	a505dbf3-ed45-4c4b-bf91-fd559c588998
c15a67e7-4add-45cb-8ad5-62af7bcfb9e1	t	Bumbogo	e9dab837-94f2-4b2c-ab54-a1f8e7723499
97bd7290-550d-4357-a136-9c30f19d6de1	t	Gataka	e9dab837-94f2-4b2c-ab54-a1f8e7723499
65612866-f323-45ad-9573-fcf1ad6cca50	t	Kinama	e9dab837-94f2-4b2c-ab54-a1f8e7723499
2878f1a0-10ca-4472-a956-a1e28f4bd27e	t	Mabera	e9dab837-94f2-4b2c-ab54-a1f8e7723499
b07d1801-72f7-4c46-ade2-c1932034c200	t	Ruhango	e9dab837-94f2-4b2c-ab54-a1f8e7723499
7ec38cf9-e8cc-40b2-bc77-2a4ca149175b	t	Bihome	8b26437b-bfd4-497c-8d61-02ec399943b6
5a6a7f95-f616-4e29-8894-2260a71ce539	t	Gatebe	8b26437b-bfd4-497c-8d61-02ec399943b6
a62148ee-b325-4b26-b97d-379541ffc4a2	t	Kabambati	8b26437b-bfd4-497c-8d61-02ec399943b6
2d9a188c-50f0-4ad7-ac12-499abbdadfd1	t	Kibiraro	8b26437b-bfd4-497c-8d61-02ec399943b6
fe0dadcf-8fd3-4f69-bfdf-4d279f81f37e	t	Muyange	8b26437b-bfd4-497c-8d61-02ec399943b6
3cdc0f1e-d9dd-4f54-8133-4079112d87c9	t	Nyabisindu	8b26437b-bfd4-497c-8d61-02ec399943b6
ec89cca1-7db9-4f52-902d-faca3283e0ca	t	Nyamugari Ii	1c8a1a89-0f86-44a5-95fe-d7856ae7210f
ce6050ce-3474-4e87-8f71-0811615fa5e4	t	Nyundo	1c8a1a89-0f86-44a5-95fe-d7856ae7210f
c33987bd-63cc-45ea-884f-5736056353fe	t	Ruduha Ii	1c8a1a89-0f86-44a5-95fe-d7856ae7210f
4a81f1b9-987f-4c59-9cf6-0790b0f43d59	t	Rugarama	1c8a1a89-0f86-44a5-95fe-d7856ae7210f
810a6ea1-9f8e-44ee-99e3-81215e29cfa0	t	Majuri	a1a2610e-0bfd-4351-8718-325b31188d90
9eaf5930-a0c4-4f62-bcad-fb5091293a27	t	Nyabikenke	a1a2610e-0bfd-4351-8718-325b31188d90
9d5e71a0-aca8-4a35-a5e8-b0bb1c29f989	t	Twimbogo	a1a2610e-0bfd-4351-8718-325b31188d90
34d28e00-2530-472d-8367-61d0dc8c8bda	t	Gafuruguto	7e1b44dd-4448-4e36-8a30-51d7dbe0ffde
ac89239f-25de-43a6-b621-f16ea2e8db42	t	Nyabihanga	7e1b44dd-4448-4e36-8a30-51d7dbe0ffde
7c0ff696-711c-43a0-8444-678e41439354	t	Nyagahinga	7e1b44dd-4448-4e36-8a30-51d7dbe0ffde
1756f135-e77a-4759-a273-28520dd96b07	t	Nyarusange	7e1b44dd-4448-4e36-8a30-51d7dbe0ffde
cfbec236-568a-4b33-9772-7813df9fb585	t	Ruganda	7e1b44dd-4448-4e36-8a30-51d7dbe0ffde
2c00be29-93df-47e8-ada4-75c0295051a2	t	Gitarama	2fbecc76-7f8e-4893-bdb6-c82efeeac967
9cc58268-9389-4cd1-bec0-f931d111b1c2	t	Gomba	2fbecc76-7f8e-4893-bdb6-c82efeeac967
3f07a45a-68db-4983-86f9-40968a4b66b3	t	Josi	2fbecc76-7f8e-4893-bdb6-c82efeeac967
988afb6b-f14d-4101-96e7-98f1f05c0b47	t	Gitega	bbb77c40-d170-47d5-99d6-2abc67239432
3aaf8112-f598-4b1c-be95-587b393f35eb	t	Mugomba	bbb77c40-d170-47d5-99d6-2abc67239432
b3ee1261-8ebf-4d9e-9cc6-e1d1922bd184	t	Nyabikenke	bbb77c40-d170-47d5-99d6-2abc67239432
a8b631df-eb41-4bb9-9b57-79a193509a58	t	Ruhande	bbb77c40-d170-47d5-99d6-2abc67239432
1c30d540-cc91-4c02-bf38-ca02de974573	t	Gacumba	8e516801-3d41-438c-988c-415a78b15a33
31fd1c8f-7545-493d-80f4-0863642ef098	t	Gatwaro	8e516801-3d41-438c-988c-415a78b15a33
f08965e9-6aa6-4bde-aa2e-9ab405e7190d	t	Rurembo	8e516801-3d41-438c-988c-415a78b15a33
2598a811-ba26-4110-989a-c6b04ad90c10	t	Karutete	0ada106c-43fe-4d3b-b07b-18df1e80c29e
b471bd64-82a9-4871-997a-5e8496eaddaa	t	Kiyovu	0ada106c-43fe-4d3b-b07b-18df1e80c29e
b6456cdb-0bf4-4213-bd0a-e9add497ef06	t	Maryohe	0ada106c-43fe-4d3b-b07b-18df1e80c29e
8b5e169d-0d39-416f-9328-66cc9a58af2d	t	Nyabaguma	0ada106c-43fe-4d3b-b07b-18df1e80c29e
5e7336be-ffe7-45c0-808d-b2826c3fb1a2	t	Nyakigezi	0ada106c-43fe-4d3b-b07b-18df1e80c29e
60c2b1ec-2d75-478a-ab2b-d18bd52bd5e1	t	Nyarurembo	0ada106c-43fe-4d3b-b07b-18df1e80c29e
f41b37ed-4213-44fb-858b-38b318439b39	t	Ruganda	0ada106c-43fe-4d3b-b07b-18df1e80c29e
a2410f66-329c-4038-98a9-88adfcc4e4ad	t	Bupfune	4f5c1f6f-fd6d-41c1-a736-e033ab055d35
3061fb7e-bc10-471b-9020-d023a258d8c3	t	Bwishyura	4f5c1f6f-fd6d-41c1-a736-e033ab055d35
4624d8f6-e02a-4585-bf6d-65082fdc755f	t	Kanyabusage	4f5c1f6f-fd6d-41c1-a736-e033ab055d35
6897d941-4af6-4cb3-a124-a0c9330cf847	t	Karongi	4f5c1f6f-fd6d-41c1-a736-e033ab055d35
956c4057-fed1-416b-b3d6-aaa13925b66f	t	Nyarusozi	4f5c1f6f-fd6d-41c1-a736-e033ab055d35
7c28cd23-9bdc-47d2-87ae-085392e0f31e	t	Birambo	e5697647-3b41-43d1-9b0f-9f2c31bd8756
a30fb4f1-b1c1-4e82-a0cd-e1063de3cb91	t	Nyagisozi	21f7c73a-faf7-4b35-bd3c-1e5ee0ac9ed2
fc353eec-00f2-46d8-a819-6cbca1480f3e	t	Mboneko	aee20241-9cb5-429d-b6d3-0989ecae8973
0cee4df8-be1b-4726-b96f-9b7dbdb4652c	t	Mweya	aee20241-9cb5-429d-b6d3-0989ecae8973
3ba6e0c5-85d4-43e4-931f-d7b8cd56112d	t	Ruhunde	aee20241-9cb5-429d-b6d3-0989ecae8973
c3ca74af-3be7-437a-b26f-216bf159bd78	t	Tura	aee20241-9cb5-429d-b6d3-0989ecae8973
a7b17d29-0181-46e6-8cb4-2ed5a03d8d14	t	Gataba	6950f2e9-b0a2-4044-9f93-4a36d96c4df8
35517bde-3820-4379-9bb1-d68a2d09122f	t	Gisiza	6950f2e9-b0a2-4044-9f93-4a36d96c4df8
b9cf7da8-f1d4-48d2-9442-75c2ee4ad9b1	t	Gitovu	6950f2e9-b0a2-4044-9f93-4a36d96c4df8
4cb12893-306c-4a2f-bb5e-6b1c24ca82c3	t	Kabuga	6950f2e9-b0a2-4044-9f93-4a36d96c4df8
6fabe353-ad36-460a-be5d-5434b087549e	t	Kagano	6950f2e9-b0a2-4044-9f93-4a36d96c4df8
88b48137-ba99-4c06-a1cc-52e25ce64cd4	t	Mpatsi	6950f2e9-b0a2-4044-9f93-4a36d96c4df8
54310f09-132b-4880-9fe7-1622d2b5e910	t	Gitwa	4a3856b7-50b9-4f66-b9ba-2dc3ec60255b
ece7fa04-2d82-4ec1-9bf0-a691cd271185	t	Kabwenge	4a3856b7-50b9-4f66-b9ba-2dc3ec60255b
7eedc289-b70c-44d8-9835-00e911dc3e76	t	Karenge	4a3856b7-50b9-4f66-b9ba-2dc3ec60255b
9c3489eb-ee64-48c5-9c94-f70f90917518	t	Butare	a587e91a-3479-4a3f-bd56-889d9dab98fb
911144a1-ab9d-49f1-9809-e6fb2cd8be8e	t	Bweramvura	a587e91a-3479-4a3f-bd56-889d9dab98fb
fe2b899b-e57c-4bc5-a663-2b531a5c8f6c	t	Gisoro	a587e91a-3479-4a3f-bd56-889d9dab98fb
da4c02a2-0b40-4910-a3df-256ecece8a2b	t	Gasharu	eb1f9b71-efbf-40be-b2f1-547ae3f3e026
a96c144f-6655-42e2-8b42-2e5e8eceaa24	t	Kabuga	eb1f9b71-efbf-40be-b2f1-547ae3f3e026
6380ce1b-6393-4bc5-b9c4-8bc39594885b	t	Kamunungu	eb1f9b71-efbf-40be-b2f1-547ae3f3e026
a30ec96c-dc95-480c-afb5-7159b540cbe4	t	Kibaya	eb1f9b71-efbf-40be-b2f1-547ae3f3e026
78b926b9-2377-45bf-b6be-20e9aae3700f	t	Kirunga	eb1f9b71-efbf-40be-b2f1-547ae3f3e026
8528f8ea-b355-4274-ba5b-4a9a1fe76e2c	t	Musebeya	eb1f9b71-efbf-40be-b2f1-547ae3f3e026
b9aec7f1-34da-41a7-ad00-e6476e68b150	t	Rwagisasa	eb1f9b71-efbf-40be-b2f1-547ae3f3e026
6994b0f6-2a86-4044-9d4a-752c82b5a416	t	Murambi	4f609228-37a8-4042-a4ae-2fc55b4f46ba
03940a5c-da74-4e89-9950-4bf4a7356889	t	Uwingabo	4f609228-37a8-4042-a4ae-2fc55b4f46ba
480c03d3-34b3-48d0-9b6b-06d503d59613	t	Giticyuma	edb2cf30-357d-4484-9218-90cc103a26a5
2c283d9a-447f-418e-b625-0c644979c27a	t	Karongi	edb2cf30-357d-4484-9218-90cc103a26a5
45612125-4c37-49d0-b2b7-8965acf23907	t	Nyagisozi	edb2cf30-357d-4484-9218-90cc103a26a5
ec4ac382-4db4-469a-b048-df20b40f7b30	t	Kirambo	7b80887f-f074-4e71-95d4-add4c7bbde42
bd491ccd-7872-4c9e-ba24-fb9e993b0bab	t	Nzabuhara	7b80887f-f074-4e71-95d4-add4c7bbde42
1a5ad276-4bc2-4f34-9fbd-23f028853dbc	t	Kinama	961859cb-c394-4c46-8c71-9f4db27c0566
7eceebc3-2587-4493-b7ed-bdddac9cb13d	t	Munanira	961859cb-c394-4c46-8c71-9f4db27c0566
4f5476b6-4ade-474c-a182-e6217393019e	t	Nyabigugu	961859cb-c394-4c46-8c71-9f4db27c0566
e6ab5cbc-0ccf-4ddb-a21a-30b2b2c251e3	t	Nyarucyamo	961859cb-c394-4c46-8c71-9f4db27c0566
b75e2b25-8ed5-4e05-afaa-322dc9b856d7	t	Gasayo	cdf76c16-33dc-4da4-8f65-7aaad698c2bb
5d73621e-bbff-4995-8369-7cc36d9a1312	t	Muramba	cdf76c16-33dc-4da4-8f65-7aaad698c2bb
5c793746-7695-4db8-85d5-f61a8c87b058	t	Nyabikati	cdf76c16-33dc-4da4-8f65-7aaad698c2bb
4c1788cb-b267-4cb7-aeb6-1b42210dd169	t	Nyagahinga	cdf76c16-33dc-4da4-8f65-7aaad698c2bb
c5f821ce-5121-42d8-ac1c-0f67647fab11	t	Nyarubuye	cdf76c16-33dc-4da4-8f65-7aaad698c2bb
1718829a-19ce-4e6d-9616-4dd6e4748cb8	t	Kigarama	716b504b-c9ea-4537-a94e-5b3da851f077
cb9d4e57-1a23-446c-bd89-2567d75b5be3	t	Kirwa	716b504b-c9ea-4537-a94e-5b3da851f077
e586819f-745d-42ec-9784-169ed2edc6f2	t	Bitaba	369522c6-3b95-454b-b654-57c13855d428
0c33a6af-f835-42ca-8635-657941d63293	t	Buhari	369522c6-3b95-454b-b654-57c13855d428
917ab309-d76d-46a0-b539-e374b799d003	t	Kagabiro	369522c6-3b95-454b-b654-57c13855d428
541daf19-5fc8-4a31-a06a-62b6c271b429	t	Mweya	369522c6-3b95-454b-b654-57c13855d428
6c803c1b-3bf6-44a0-ad1e-63d1828886c2	t	Nyabinyenga	369522c6-3b95-454b-b654-57c13855d428
1faa3968-0a62-4df5-8758-db9f3c17f526	t	Nyakabande	369522c6-3b95-454b-b654-57c13855d428
0a955129-f237-434f-818c-cc476c0995e5	t	Kabuga	57d7453c-dca1-42d6-8c80-5098740da788
b975ae05-0356-432b-bb7b-d89d7cbc5706	t	Kaduha	57d7453c-dca1-42d6-8c80-5098740da788
50bfb331-4cca-46d4-b819-26dca6b35207	t	Karora	57d7453c-dca1-42d6-8c80-5098740da788
c79df83d-778e-43ac-9d7c-08b9a39c1e34	t	Murangara	57d7453c-dca1-42d6-8c80-5098740da788
36ec1553-650c-47e1-a1cc-99dc5e6cf0c9	t	Nyabitare	57d7453c-dca1-42d6-8c80-5098740da788
2de95a4c-8538-4b6a-b7b0-7412e8625220	t	Rubyiro	57d7453c-dca1-42d6-8c80-5098740da788
70380ca2-3c78-4dd4-b0f4-9b71726f6828	t	Rwakamuri	57d7453c-dca1-42d6-8c80-5098740da788
cf4c92c1-4846-4245-b7ad-7e222b5f94b7	t	Gisizi	fef68f0f-81bb-4192-b4d8-a68ea3afbca2
093fd547-799d-42fd-b635-a3e0b086edfc	t	Mara	fef68f0f-81bb-4192-b4d8-a68ea3afbca2
c9ae58c1-2d2d-46b7-a2a9-ff8b66b66302	t	Nyagatovu	fef68f0f-81bb-4192-b4d8-a68ea3afbca2
82466b4d-bc37-4a25-9517-72aecab384fc	t	Nyankira	fef68f0f-81bb-4192-b4d8-a68ea3afbca2
515d1d1f-3c60-4d0f-a3df-b22f9d4eac26	t	Ryarugenzi	fef68f0f-81bb-4192-b4d8-a68ea3afbca2
0f84c2af-8abe-4d7c-9618-961147f53e7c	t	Bikenke	e04625d0-6a9f-4350-bad0-1f478528d4a1
679d5d28-fe26-49a2-8491-1bfe032e46a2	t	Jurwe	e04625d0-6a9f-4350-bad0-1f478528d4a1
ff26413e-a04d-46a2-955f-acc9cb26b297	t	Kizibaziba	e04625d0-6a9f-4350-bad0-1f478528d4a1
eca77e63-89d6-48bc-88ff-70b704919e21	t	Mubuga	e04625d0-6a9f-4350-bad0-1f478528d4a1
db5d7010-716e-4b90-80be-de4b2cd84349	t	Ryaruhanga	e04625d0-6a9f-4350-bad0-1f478528d4a1
2ecdfb8b-6369-4d92-ad05-2a86d22de0d4	t	Gasebeya	d7cfc690-7f95-41e1-83c2-6064b80d7f4c
08150c19-421b-4539-8e4d-a75e562c0c0e	t	Kazibaziba	d7cfc690-7f95-41e1-83c2-6064b80d7f4c
8226b31b-85ff-4c27-a378-002ada30ee5d	t	Ndago	04bcc49f-6c91-48ab-8215-09ff84cbef43
cb76d77c-80f1-4a15-9fc3-89a7e092602b	t	Gituntu	6c55528f-0268-4f3c-b0ff-3acc43726a14
f50f1006-06ee-4c06-9572-76e5b55e93d0	t	Nyaruhanga	dced12d4-7410-41c9-aa9b-886f63a6239d
80b4d203-8f53-4c7a-bc55-4fc267c9a75f	t	Nyakarambi	0b17fe2a-adde-4dee-8c50-53cb95f25d1e
453bf9d7-b6e1-4911-be0e-3447eb3ce66b	t	Bwenda	9976c491-d469-4595-848e-4afabb5cc3fb
253adb44-2e4f-4297-b93b-a00ba71cc8a2	t	Kuruganda	9976c491-d469-4595-848e-4afabb5cc3fb
fb9f32cc-daf1-442a-b6a3-77201923cc5a	t	Gititi	3ce13115-661b-47a1-a1d8-897f074bfb71
cc532841-a00f-4fe9-8fcd-19e677be8864	t	Kivumu	3ce13115-661b-47a1-a1d8-897f074bfb71
bda7fe6a-3daf-4d73-ba6c-c637c167a501	t	Muhondo	3ce13115-661b-47a1-a1d8-897f074bfb71
1b86df54-f8e7-4a02-9536-5ce5780678ec	t	Rugogo	3ce13115-661b-47a1-a1d8-897f074bfb71
0b95dbbe-f52c-4f37-833a-2f86ed76945b	t	Gakomeye	5c7fe6cd-5ad5-4457-b59a-7e4565fbd289
60a620e5-0fb7-4ede-9ab3-6e3de844760c	t	Kavumu	5c7fe6cd-5ad5-4457-b59a-7e4565fbd289
5c569ef6-62eb-464d-9242-e2865690c61d	t	Makurungwe	5c7fe6cd-5ad5-4457-b59a-7e4565fbd289
ca590c35-80c1-41be-be55-a64ac9308585	t	Gasharu	f0236418-cbba-4872-9583-800d184b3e49
f37c974b-70fd-49c0-a5ef-364020bf3a89	t	Kamuvunyi	f0236418-cbba-4872-9583-800d184b3e49
49c6a816-675c-41d0-9c9a-b07eb63b8f24	t	Kamwijagi	f0236418-cbba-4872-9583-800d184b3e49
b9b34771-af79-4e31-aed9-5297cc72874f	t	Karehe	f0236418-cbba-4872-9583-800d184b3e49
dd459abc-9314-49c8-ad8e-30a2965c4bfd	t	Nyarubuye	f0236418-cbba-4872-9583-800d184b3e49
82f9ee2e-e5ca-4c98-bc33-6a934a354b97	t	Remera	f0236418-cbba-4872-9583-800d184b3e49
94c4d5f5-1c5e-46d4-9d8f-8eddbbbc192e	t	Nyabitare	5aee636a-a373-4967-93cf-d0b92dbdceb1
e56cb2c6-b2ad-4b2a-9ba7-63e2335a5d1d	t	Nyamagana	5aee636a-a373-4967-93cf-d0b92dbdceb1
e54b7322-a027-4f3e-967c-b3eda9cd7107	t	Rubona	3d43dfc4-6dba-4350-b7fd-5f080eeb7d88
a8a3a590-b32c-42c3-a722-6fdcf5eb9ce4	t	Buhoro	53a54859-2a6c-4c02-ad05-d85e8207ebe3
b6c9b886-8381-426f-9ed4-425fc5cf83c7	t	Cyimana	53a54859-2a6c-4c02-ad05-d85e8207ebe3
0b3735f9-c794-43e0-8cf1-029129c89606	t	Kabeza	53a54859-2a6c-4c02-ad05-d85e8207ebe3
3b514504-6b38-4de2-a7fa-583925ada7ab	t	Kagarama	53a54859-2a6c-4c02-ad05-d85e8207ebe3
1d7adc8a-584c-406d-ac1d-4f628105947c	t	Kamusangany	53a54859-2a6c-4c02-ad05-d85e8207ebe3
8743d978-7b9d-4299-a664-afa61f765998	t	Kimigenge	53a54859-2a6c-4c02-ad05-d85e8207ebe3
611c0ded-e0d9-46e0-88b7-ba624d108f76	t	Ndengwa	53a54859-2a6c-4c02-ad05-d85e8207ebe3
75ae0e05-637c-456a-bfd0-30285a600530	t	Rubona	53a54859-2a6c-4c02-ad05-d85e8207ebe3
a1ebbda3-ac28-4e9e-9580-d124ba4a091e	t	Gatare	194062d1-c07a-4393-821b-bd1745b6fe91
5950302a-559a-46a1-985b-38a83be24547	t	Nkomagurwa	194062d1-c07a-4393-821b-bd1745b6fe91
361e5579-00e5-4736-b47e-5490a5556686	t	Bunyankungu	0ece2f0d-9820-4324-bd78-ca049f89a888
31486f9f-0aa1-45a1-a006-6be43b10b30f	t	Kabeza	0ece2f0d-9820-4324-bd78-ca049f89a888
91530a8b-02c0-4a81-9274-d16626a0e1b6	t	Nyagahinga	0ece2f0d-9820-4324-bd78-ca049f89a888
f716a43b-4e06-4e69-8b7b-8f693db4e226	t	Nyagasozi	0ece2f0d-9820-4324-bd78-ca049f89a888
1911f5da-17c8-4149-b37e-78bc83f011b3	t	Nyagatovu	0ece2f0d-9820-4324-bd78-ca049f89a888
383cab48-a6af-4a1f-82b0-8ca6ddec2915	t	Nyakabungo	0ece2f0d-9820-4324-bd78-ca049f89a888
e346aca3-f8ff-4f9a-a5d3-5da4ca74bd2a	t	Rugabano	3c60820f-28c5-4c4e-87a7-32a6b2e42699
a2d28834-946d-4c05-a1ce-917a66dff615	t	Gihara	39e39bdb-75f0-4a0a-80a3-bf7d73a66967
44d2c27e-c73f-4a21-8d47-85a4b11e9222	t	Kagombyi	39e39bdb-75f0-4a0a-80a3-bf7d73a66967
82e49b3f-65c9-4158-bbde-047037b72552	t	Kivumu	39e39bdb-75f0-4a0a-80a3-bf7d73a66967
47431f72-42d3-40e6-91f0-6cb56167c7c2	t	Ryangondo	39e39bdb-75f0-4a0a-80a3-bf7d73a66967
f5c80070-e091-43c9-a859-be9910eb6405	t	Bwihe	30d91813-3fe4-4d1d-9dd0-10af37dd48f0
ed25ee76-3f23-461d-b67a-30b7f3aac8c9	t	Gitabi	30d91813-3fe4-4d1d-9dd0-10af37dd48f0
79310ef4-61e0-47f4-b80d-fabfa6aa2e54	t	Kanyegenyege	b254af28-51fa-4228-855b-76fa1b462759
e694441a-fd48-483d-bea9-70545fac8520	t	Gahunduguru	98d12a73-6f8d-46e6-ab77-7f3bef67f22f
a344da2d-b1c3-46b3-a213-770321416ab6	t	Ruhuha	da16bbad-62af-449a-911d-56d4b47fe7a4
bbb01451-f085-4bff-859a-a6f7d995f943	t	Jurwe	1fa7472c-81fa-47ed-aaf5-fe983c1ed409
a18d219e-9019-4a61-bb73-d4dcc1a4ee88	t	Uwingabo	1fa7472c-81fa-47ed-aaf5-fe983c1ed409
79a53e9d-b618-45c7-915c-a291a6ccf864	t	Muhingo	adc492f6-22fa-41c0-b195-f37ba403394a
059108e5-80e2-4a46-a826-6c4f69a2a46e	t	Rwasheke	adc492f6-22fa-41c0-b195-f37ba403394a
3c861925-fc83-467c-a6fe-fafc8435fa7f	t	Kinaba	fcd3d68d-6a88-4dda-bca6-36c25e6f0861
baa94ea4-a8c1-4893-b98f-4771d85cc61b	t	Winzira	fcd3d68d-6a88-4dda-bca6-36c25e6f0861
24c20320-6a9b-4e72-b1e2-a87d2c7d5869	t	Mahembe	7ea9bb8d-efdb-47d2-a91b-95403096ef36
b956bfe5-6c27-4365-9964-a8e069cf9f16	t	Musango	7ea9bb8d-efdb-47d2-a91b-95403096ef36
314757f5-c4f4-49bf-a83b-cafa19853688	t	Nyarushekera	7ea9bb8d-efdb-47d2-a91b-95403096ef36
8195b3c7-2453-4c29-8aef-12081d5066de	t	Gasharu	1e981cbf-12fa-40fa-b50a-511f39975320
9303aa12-079b-40d6-9159-bfabfee7dde3	t	Karambo	1e981cbf-12fa-40fa-b50a-511f39975320
d4680a5f-52eb-40a1-a4ab-c55221604184	t	Kigogwe	1e981cbf-12fa-40fa-b50a-511f39975320
4712efe1-4a5a-4a2e-90fc-cf92e105913b	t	Kanyege	1e981cbf-12fa-40fa-b50a-511f39975320
d04ad020-30d0-46d3-9d80-05a87565531f	t	Wingwa	1e981cbf-12fa-40fa-b50a-511f39975320
0db73ab5-b267-454a-96e1-9695c8321b91	t	Ruhinga	fd67a8f6-1bd6-4a31-9dd8-1db77741b524
fadf6ca3-0e15-442b-906f-4d901fde7ecf	t	Rushishi	f30b1f77-936f-4e15-bd10-25496606e275
4133ae5b-f9f9-43eb-a244-a8c771a45e94	t	Gakoko	63942efb-44b9-44dc-8446-0e5ca55c3060
9f8f5325-0218-427f-8d33-95ff87ead94b	t	Karumbi	63942efb-44b9-44dc-8446-0e5ca55c3060
01f0081a-f96b-4977-9a30-c9c8cd31e45c	t	Nyamiryango	63942efb-44b9-44dc-8446-0e5ca55c3060
66afc144-ee6a-404b-804c-b4d30336907b	t	Twumba	63942efb-44b9-44dc-8446-0e5ca55c3060
02d8dd1d-8528-4a4c-b8ef-574f724fb566	t	Gashihe	b1c57b2a-81df-4c95-ba9b-40d3793b07f6
cc9200f1-a61e-4b1b-b4ba-96fcd883e2ec	t	Gatare	3c47d9b3-bead-4e8b-b17e-42e9a6d95371
62b5697e-ff6e-4e34-8735-6100735e754f	t	Mataba	3c47d9b3-bead-4e8b-b17e-42e9a6d95371
ecefe5b1-4f4f-4a6c-adab-a780e83b24bf	t	Nyakiyabo	3c47d9b3-bead-4e8b-b17e-42e9a6d95371
20b04d4f-c1eb-45e9-8352-44cb2cecec5a	t	Tuvunasogi	3c47d9b3-bead-4e8b-b17e-42e9a6d95371
afa3ff0e-4759-432d-b528-6a311ec622b2	t	Duhati	9c67f3a8-a41b-4360-8770-cf72436e09f7
d6556826-3c00-47c8-81e1-3d85d27e2faa	t	Kirwa	813f3a3c-0c5d-4dc7-b9a0-abc009fa6274
de00c780-7a4f-4c60-a0f2-cda329cef621	t	Nkuri	813f3a3c-0c5d-4dc7-b9a0-abc009fa6274
0c7a7042-c645-4f1f-8165-08a05d3ebfba	t	Rutoyi	813f3a3c-0c5d-4dc7-b9a0-abc009fa6274
01dcfb42-2d5d-42f8-ba7b-61d0e26894bc	t	Gasasa	b98c0fac-7e67-4980-8e3c-9e8658860cf0
70ddfb39-9443-49d0-b6a9-f8c84aee1ecd	t	Gitonde	b98c0fac-7e67-4980-8e3c-9e8658860cf0
eb06846d-206c-4a2c-b9a7-39d61b5a3cb8	t	Rukeri	b98c0fac-7e67-4980-8e3c-9e8658860cf0
859f9b49-de0b-4aa3-87b4-2b58fcc9c363	t	Rwamakara	b98c0fac-7e67-4980-8e3c-9e8658860cf0
f8001fbf-d85e-4bb5-ab7e-dfc3c054e521	t	Bereshi	7f956bc2-b371-47a2-8b23-bddb0db77c26
f7287229-fd12-4764-badb-52864ee4aab5	t	Gitarama	7f956bc2-b371-47a2-8b23-bddb0db77c26
bb6eb0bd-5944-4593-a864-aedcd32cf6e8	t	Kurushishi	7f956bc2-b371-47a2-8b23-bddb0db77c26
f6c39225-267d-4522-bc75-cfcf33d85e37	t	Mukingi	7f956bc2-b371-47a2-8b23-bddb0db77c26
223b2a92-e048-4dc2-ae3c-24e29691e065	t	Nyakarambi	7f956bc2-b371-47a2-8b23-bddb0db77c26
46cc81a2-655b-47f4-b55d-595ece8a0f61	t	Birambo	6920d7e3-cfb3-483d-b7ea-ca20d0014548
ba8b3b22-e857-4577-8f03-085e495be63c	t	Mpara	6920d7e3-cfb3-483d-b7ea-ca20d0014548
097c002d-b5a1-43d7-9085-af3a516c8d99	t	Ruvumu	6920d7e3-cfb3-483d-b7ea-ca20d0014548
9fed70f8-7e04-413e-8bd7-ea50aed890d7	t	Gasave	2381c1be-80b8-4d16-90e7-8cb3ef2456fd
755cb231-3b30-4183-a88d-af81450c5847	t	Shyogi	2381c1be-80b8-4d16-90e7-8cb3ef2456fd
7114be1d-00ae-467d-98c7-7a4ab1f5eeb5	t	Byimana	6bd41cd8-5a7f-423d-83e1-84a0c6bb8203
24ad6858-948b-4b1d-ac7e-7e6269f1b338	t	Gasave	6bd41cd8-5a7f-423d-83e1-84a0c6bb8203
5208e38e-d80d-4116-a13f-bf89160ab703	t	Karehe	6bd41cd8-5a7f-423d-83e1-84a0c6bb8203
ac1083a2-2fa1-412a-bf18-bf2247c39e96	t	Kavumu	6bd41cd8-5a7f-423d-83e1-84a0c6bb8203
2fa6e093-d98b-4f84-9f4b-3c32ca7748ee	t	Kimisagara	cba5469b-2047-4848-97d2-e3dabb9ce457
e55e1327-01a9-4dc9-9647-bdc725b3c28b	t	Nteko	cba5469b-2047-4848-97d2-e3dabb9ce457
be94993a-9de0-4da0-8b01-d90c67500f0b	t	Rugara	cba5469b-2047-4848-97d2-e3dabb9ce457
f97c6e2b-1053-4796-9025-9dec951bd2c7	t	Butare	f88b8cfe-9532-44b8-a7cd-64761ee74093
c44d9caa-c1bd-4b4b-b37b-85ceb989445c	t	Jimbu	f88b8cfe-9532-44b8-a7cd-64761ee74093
7a77969e-e283-45d5-b596-8fcb2f9a3db6	t	Kabeza	f88b8cfe-9532-44b8-a7cd-64761ee74093
c7900ec6-3cf0-4464-9b66-0e2cbe4f5b99	t	Kagarama	74675155-d944-48c3-9b35-c3db69d234df
c7e8fd1b-8b44-40f4-9fc1-6fc723922acf	t	Mukaragata	74675155-d944-48c3-9b35-c3db69d234df
97ee56e0-1a7b-43aa-8e6d-b274a5c300cf	t	Buyungu	4363a6ca-6c9a-4f39-8492-d3a86892bbab
173ef0aa-54a1-48bf-9cc2-da542534518c	t	Gapfura	271158e3-e7c1-4100-9d91-432a458ed60c
07613d58-d1cb-4709-aa82-918195e1844a	t	Gasovu	271158e3-e7c1-4100-9d91-432a458ed60c
d74e1fe7-3462-4bde-9f58-fcf29df5b234	t	Kabenge	271158e3-e7c1-4100-9d91-432a458ed60c
f51e0fcf-9dbe-40c0-a6d1-d8de40c1c24a	t	Bwoga	642c4cda-6803-4290-bee6-dd11c467260f
2e923b30-675a-4350-9872-29b2c444950a	t	Kamana	642c4cda-6803-4290-bee6-dd11c467260f
2154c1e1-ff21-4e99-960d-f6ed36071e98	t	Rugari	642c4cda-6803-4290-bee6-dd11c467260f
59503d88-6f86-4c53-b698-228c939a16f3	t	Kagugu	64a01bb8-e198-4852-bf18-cc5f71bb04bd
6a55486c-9b75-4b56-9eff-4918d5b7f1fb	t	Kiribata	64a01bb8-e198-4852-bf18-cc5f71bb04bd
7896c87f-06f3-4c71-982c-e8a850d588d4	t	Muvugangom	64a01bb8-e198-4852-bf18-cc5f71bb04bd
b93be4ee-b861-4223-84b6-e8787fe69ba8	t	Kabuga	7ca81046-73ba-466e-83ac-d970eafb904c
c2c95054-9918-4c7b-aa2b-67cad8ad1306	t	Kamonyi	7ca81046-73ba-466e-83ac-d970eafb904c
44a8f632-a965-44de-a56c-e3f1e4c5ac98	t	Gitaba	e659cc48-ee11-48ef-8a3a-7d628307e798
709695c1-929b-4f3a-81ae-3a989eef6f69	t	Kabere	e659cc48-ee11-48ef-8a3a-7d628307e798
be360dbe-ddba-4ba1-9573-0909fc9eb2ff	t	Kabusizi	e659cc48-ee11-48ef-8a3a-7d628307e798
e5d9aca1-46b0-49dd-a35b-72616bd182e4	t	Kinyamiyaga	e659cc48-ee11-48ef-8a3a-7d628307e798
ef4a48c1-91ba-4404-bd1d-644657c27c23	t	Mbandari	67713534-fcd0-4cb4-98b2-52b862a581f4
f75631ef-1ee8-4a88-8e91-50d44e88bb1c	t	Mitabo	67713534-fcd0-4cb4-98b2-52b862a581f4
62330889-bf0a-457c-8a93-55e339f0299e	t	Muturagara	67713534-fcd0-4cb4-98b2-52b862a581f4
a256b606-fe9a-4fd2-a11a-21b4aa6da034	t	Nyamweru	67713534-fcd0-4cb4-98b2-52b862a581f4
4446a775-70c1-4faf-b43c-c82988d1e23a	t	Rugari	67713534-fcd0-4cb4-98b2-52b862a581f4
85084863-5047-4306-893c-1767fe308dc2	t	Kiyovu	73bb030b-7183-4879-b4dd-3b1e79a4b828
2a3f9bd1-9225-41d7-a842-e5a9fb0ea321	t	Migongo	73bb030b-7183-4879-b4dd-3b1e79a4b828
d7ba855c-99ba-4d99-ad0a-97b9915fc4a8	t	Rebero	73bb030b-7183-4879-b4dd-3b1e79a4b828
557d6dd2-e1a1-4768-94e8-a2819a3500ed	t	Rurembo	73bb030b-7183-4879-b4dd-3b1e79a4b828
89878996-7945-4062-846b-d9f88e895e2b	t	Rwantozi	73bb030b-7183-4879-b4dd-3b1e79a4b828
5ba0b4d3-9c2b-47a6-a712-4e4ed832c0a3	t	Bukonde	5c77f2b7-bb57-422c-8a93-917e72a6595f
22d57005-d4b2-479a-885a-304018c691df	t	Merabuye	5c77f2b7-bb57-422c-8a93-917e72a6595f
f8d0cda7-56cc-4b2d-ab83-01e978a5a80e	t	Nyabarinda	5c77f2b7-bb57-422c-8a93-917e72a6595f
82a3fb6e-b88e-4202-aa8d-6997b999a424	t	Rubambiro	5c77f2b7-bb57-422c-8a93-917e72a6595f
1d94772f-654f-41a2-ac7a-44cc3eb31c4a	t	Gisebeya	a3445f1f-2c66-4363-b7c8-14156dd12a0b
e3fad70f-a22f-414c-a300-e9a8794955c5	t	Gitumba	a3445f1f-2c66-4363-b7c8-14156dd12a0b
2cb7bbf8-aa06-45a5-b463-88310b7f5df6	t	Hanika	a3445f1f-2c66-4363-b7c8-14156dd12a0b
365d1b2e-df4f-4c87-8ca8-42bfff21e53f	t	Ngoma	a3445f1f-2c66-4363-b7c8-14156dd12a0b
643e7e08-4074-4502-87cc-119214334cbf	t	Nyamugeyo	a3445f1f-2c66-4363-b7c8-14156dd12a0b
f5af2464-5dec-44f1-a6d2-289124956403	t	Rukorati	a3445f1f-2c66-4363-b7c8-14156dd12a0b
96506e27-e1b8-41ee-8232-bc718c1ca369	t	Bukonde	abb86429-4372-44d6-bbbf-0e46b4aa7375
27886abe-fc71-4ee3-9bc7-1011fd923678	t	Kimiramba	abb86429-4372-44d6-bbbf-0e46b4aa7375
31faf5d7-764c-47f3-848d-bae2e22f6a6a	t	Kirwa	abb86429-4372-44d6-bbbf-0e46b4aa7375
270a3d10-e4b1-4ebe-b47c-dae05f81b065	t	Kariha	a9693b4d-acb0-47a6-b602-18ab910906b9
f96ce97f-c77a-48c0-81b4-67cf0ce78657	t	Ruganda	a9693b4d-acb0-47a6-b602-18ab910906b9
9a5eb3d7-c2b3-4449-b859-9b2f5f6450c0	t	Rusenyi	1d4060e4-1826-481b-a3e8-26ff00c9331f
1b6d3aa6-5483-4244-8a30-3d7d67c4d8fd	t	Rurambo	112bc3b4-87ca-4539-9eef-508b8a09ff62
e8e5040a-bdb3-44b3-bf09-755fc6c94aca	t	Kabuga	9aeb455a-8d90-4e2f-8281-56d350f81eb0
4fa5bddd-be7f-43a5-8aa5-a4197e732169	t	Gasiza	02ef05d2-eda2-4e02-b456-1e7817ebf401
25fa1de1-c990-40a9-998d-7febde4ecf2b	t	Giseke	02ef05d2-eda2-4e02-b456-1e7817ebf401
38bb1c7e-e20b-4604-96ae-02db2beff340	t	Mubuga	02ef05d2-eda2-4e02-b456-1e7817ebf401
d1c1f871-83bc-40fc-b089-f7b4d9dea373	t	Buhuma	e636fd0a-eaab-45c9-ab2f-4fb541286409
fde3df26-7e6f-4c8c-af2b-d2d7eb38bf53	t	Gashaki	e636fd0a-eaab-45c9-ab2f-4fb541286409
ae81ee9e-44c0-4955-a44b-1bc7bb661939	t	Nyabitsina	e636fd0a-eaab-45c9-ab2f-4fb541286409
5b1ec8ec-ec04-4dc2-b802-0807f94dfbbf	t	Karambi	ca9ca699-960b-4885-a953-a9810e984ee8
982b993d-705b-48b2-b82b-67af298a0de0	t	Kaziba	ca9ca699-960b-4885-a953-a9810e984ee8
9e25525e-21a8-49ae-b961-328bb1a183e2	t	Nyarukara	ca9ca699-960b-4885-a953-a9810e984ee8
253bfb9e-7527-4145-a6d1-68a5c48e6aec	t	Cyasenge	6500bd67-ecef-4bb2-8f86-3c0add773842
f4e19584-ae7d-4920-8046-c216c6b94dcd	t	Gasibya	6500bd67-ecef-4bb2-8f86-3c0add773842
88e79363-8473-4106-a969-dc5578b98174	t	Nyaramba	6500bd67-ecef-4bb2-8f86-3c0add773842
ff22dc54-91c5-4ee2-bbae-d10d9f0cd555	t	Ruhurura	6500bd67-ecef-4bb2-8f86-3c0add773842
e0ba4909-e2eb-4126-9a68-85cab6ac0658	t	Gatovu	0b22a1a4-0283-4ab9-860d-2544a957c4e7
fa1ebfe5-dc01-47d4-aed7-a85bf3e77e0c	t	Kabere	0b22a1a4-0283-4ab9-860d-2544a957c4e7
60a75e95-0d35-4b2c-a34d-7fabe978dc9a	t	Murimba	0b22a1a4-0283-4ab9-860d-2544a957c4e7
110709e5-ac7e-41a0-aad0-3bced7551652	t	Mwiyanike	18be4ae8-5597-4a1e-8868-98282d0f81ea
fc0ddab5-593c-4ebf-8b63-9e4268b9687a	t	Bereshi	e5e90259-8993-45d9-99e1-82a190025fb3
ee6d7b08-b2b2-4fed-8321-9c834f4e9bf0	t	Kasumo	e5e90259-8993-45d9-99e1-82a190025fb3
a41d27ae-653b-4352-b953-fbf49832e25b	t	Busoro	4d6f6348-cee0-467b-99b2-e12d36464642
f9ecb106-d855-4fdd-afa2-a76d46f004f2	t	Nyagisozi	4d6f6348-cee0-467b-99b2-e12d36464642
c323405b-906f-471b-8fb8-f9eba01429df	t	Barama	a510f891-bcd1-469e-93e6-46ea3e893f35
014fcad6-c364-4703-8fc3-c5ab95a250f7	t	Gitega	f8505d8b-646e-4f96-9acd-2afef346d2a4
c13ff9d2-ea7f-40cc-b86d-8a8ca774e340	t	Ruhurura	85c0102c-e1a5-4f34-9194-c70dc1fd8551
6548fd15-711a-462f-add8-047368357335	t	Nyakibande	7ee4ce06-fab5-4b58-9e01-ed84141009ca
5707cf4b-80ab-4fa1-a2d4-e2f1789bb27b	t	Rwamiko	7ee4ce06-fab5-4b58-9e01-ed84141009ca
2f99efad-29b9-45fd-947f-6f3b5a0326ef	t	Bugarura	e90389b3-7d62-4d2c-bb97-9b6bd6ebc0fc
0bc102cc-6d56-408a-998d-a96931ca7dfc	t	Burorero	e90389b3-7d62-4d2c-bb97-9b6bd6ebc0fc
5b21785b-87f6-4121-b680-a3862572c0c3	t	Ngando	e90389b3-7d62-4d2c-bb97-9b6bd6ebc0fc
6cad9dca-8666-4c51-99f3-3c5560c679c2	t	Nkongora	e90389b3-7d62-4d2c-bb97-9b6bd6ebc0fc
0b6fd26d-a9b1-440e-bb8e-562d3adbcd6d	t	Gasiza	3fb18cbd-9962-491a-8ed3-bea12a8642e9
fda6e5d2-51eb-4f99-9260-80d1bb7e4796	t	Kabeza	3fb18cbd-9962-491a-8ed3-bea12a8642e9
9a124c23-1e0e-4785-b879-4406171bd1ff	t	Kigina	3fb18cbd-9962-491a-8ed3-bea12a8642e9
83b6f3b4-d786-4aa2-a968-bc6ed4f765b7	t	Rwantobotobo	3fb18cbd-9962-491a-8ed3-bea12a8642e9
f6c9c88e-2663-4b83-a1a9-1523cb4be659	t	Byerezo	9a209c5f-04aa-46ef-83cf-cce1e790776b
d73c29c3-b336-45fe-a68e-e603e92cd483	t	Kagano	9a209c5f-04aa-46ef-83cf-cce1e790776b
f0fabce4-c546-4b62-be09-715696a45594	t	Kazuba	9a209c5f-04aa-46ef-83cf-cce1e790776b
3547c4a9-26dd-4613-9b61-4d9f15e37e5e	t	Rubaya	9a209c5f-04aa-46ef-83cf-cce1e790776b
c6e5bd5a-45ed-4e87-a94e-33cdbaa1fe53	t	Gisebeya	4387a6e1-8c54-4921-b077-4ea46892cf86
922cabae-7ad1-403c-bf9f-8fab2ed34d13	t	Gisiza	4387a6e1-8c54-4921-b077-4ea46892cf86
76a9b36e-2e01-46d5-996c-a431de5a755d	t	Gisunzu	4387a6e1-8c54-4921-b077-4ea46892cf86
73760367-3cc8-48da-99ca-df178077e7ee	t	Misemburo	4387a6e1-8c54-4921-b077-4ea46892cf86
a990abb9-32e0-4b5c-8c4f-2de4cd39512a	t	Gacaca	02bdd6ec-8800-4d0e-b2be-2af14b7d8529
e32c1870-ee27-4dff-9011-1783339a32f5	t	Ntendure	02bdd6ec-8800-4d0e-b2be-2af14b7d8529
7d28b192-5078-4506-b960-8c89744eb78d	t	Ruganda	02bdd6ec-8800-4d0e-b2be-2af14b7d8529
874d9b23-f244-4447-832f-764c07bf7e65	t	Bambiro	b6f88ab6-1e4c-44b1-9d5b-7c12beb7c0f0
a8d6c71d-d084-4e7b-8d47-d6ee07ca164f	t	Nyamutoni	b6f88ab6-1e4c-44b1-9d5b-7c12beb7c0f0
50cfa1e6-3731-4d99-82fa-057c771b5d00	t	Nyanshundura	b6f88ab6-1e4c-44b1-9d5b-7c12beb7c0f0
22558b45-1ca5-4d54-8e60-ebe0caf11b9b	t	Rukondo	b6f88ab6-1e4c-44b1-9d5b-7c12beb7c0f0
ea8252ee-7cee-40f5-b599-fe5c12f2223c	t	Burengo	3a05f6a5-3337-4457-8618-781bdaffd530
54188339-5ef3-4b41-81f5-15f7aedcd583	t	Gashonyi	3a05f6a5-3337-4457-8618-781bdaffd530
684af666-5454-4b50-80ec-7bdd2b992e3b	t	Mitsimbi	3a05f6a5-3337-4457-8618-781bdaffd530
839e56bb-0e0b-46d0-8c4f-c2934426e79b	t	Nyabigogoro	3a05f6a5-3337-4457-8618-781bdaffd530
aa0b720d-d116-4f50-a858-6c3cdfbf8178	t	Nyamirama	3a05f6a5-3337-4457-8618-781bdaffd530
1f04c9ce-8c9e-447e-a3ed-481be647094b	t	Kibingo	81ee50aa-0b6e-420b-9422-f14fda982054
98d76ee7-8e60-43fe-82c5-47783adf8d44	t	Buhiro	10f3fa04-8e18-4032-a9de-0d4d7a236d7a
d23cec25-5941-4b43-954d-36724d54b069	t	Gapfura	10f3fa04-8e18-4032-a9de-0d4d7a236d7a
f8503b1e-1980-49a6-8e70-130be5e563f0	t	Kagunga	10f3fa04-8e18-4032-a9de-0d4d7a236d7a
68ed2ea8-3663-4c19-b14a-6008e63a89a6	t	Ryabadanga	10f3fa04-8e18-4032-a9de-0d4d7a236d7a
63730632-1d8c-4c5a-847b-6ba248684721	t	Kansi	94262c17-86cf-415f-a088-fb3e6e179770
2903e006-86f8-494e-80a0-8ce0299f7aa9	t	Kavumu	6ca9a516-b29c-4416-b3eb-d6ea1cc6e9b8
3f12de15-3ce3-4544-acd0-31e4cf2549f1	t	Kibuga	6ca9a516-b29c-4416-b3eb-d6ea1cc6e9b8
b7913fbb-d7a2-4088-ab64-041e94aeed1a	t	Kamuyobora	f0c4b0bb-a02e-4d16-bca7-6ff623a9c8ce
408eca7f-7b58-4575-bc40-ea39af6d0ba2	t	Ngugu	f0c4b0bb-a02e-4d16-bca7-6ff623a9c8ce
28122da2-d2f6-445d-b5d7-c47c7dffacf6	t	Rwamikeri	f0c4b0bb-a02e-4d16-bca7-6ff623a9c8ce
51bcc10f-f1ee-44ee-8878-8c02fffbf065	t	Ruhanga	038a6745-fd96-4ebb-bc33-d2893e9cc3a8
c695fc5a-7adc-480a-bd5c-618d66979076	t	Kideberi	b11a0d8e-5fe1-458b-a99e-8a9d15d87f7f
8653900f-5b9f-4cb9-9798-31c65529411b	t	Kimirehe	b11a0d8e-5fe1-458b-a99e-8a9d15d87f7f
f5b07809-49c1-4e32-b5b5-bb08e4e250cb	t	Rutambiro	b11a0d8e-5fe1-458b-a99e-8a9d15d87f7f
8d6faced-3b61-4996-a569-26aaae2ec690	t	Rusebeya	254de8de-08b5-498f-a9fb-9ac350ea3e6b
6e84f974-56ec-490d-af02-8063635fff60	t	Cyandago	5b43e7a4-618b-44ca-8efb-3dc6dc312938
2abee016-03b7-4513-8c0c-adcbbdaf9efa	t	Gatare	5b43e7a4-618b-44ca-8efb-3dc6dc312938
b796cec1-bfc9-4d9f-872c-8dcc5201a8c2	t	Kabeza	5b43e7a4-618b-44ca-8efb-3dc6dc312938
d1138588-10c2-4aa6-9841-8b655fdca8a4	t	Kabusunzu	5b43e7a4-618b-44ca-8efb-3dc6dc312938
d3fdde76-665d-41bb-8382-fc88cda336ae	t	Kanyinya	5b43e7a4-618b-44ca-8efb-3dc6dc312938
39c33b69-7eda-40c5-8150-88f7d24b174b	t	Nyamabuye	5b43e7a4-618b-44ca-8efb-3dc6dc312938
acab93f8-af49-4673-a173-fcc6dee0dade	t	Butezi	efbe40bd-0ac9-43a7-a827-38ddec500537
2444467a-8993-4b79-ae5f-9c25e89880cf	t	Cyansi	efbe40bd-0ac9-43a7-a827-38ddec500537
5f8dab62-c104-4225-bec5-21512841a12a	t	Ngororero	efbe40bd-0ac9-43a7-a827-38ddec500537
f47c893a-69c6-45c7-90ae-f2a8db18030e	t	Kabuga	6f7e5ac3-865d-40f3-b892-a65ddeb6a5f4
7f090252-76e1-44ee-bfe6-86e3bc95884d	t	Mpara	6f7e5ac3-865d-40f3-b892-a65ddeb6a5f4
1148367b-5794-4720-8938-9d646effa559	t	Cyumba	a984ec7d-92fe-4003-abfb-708130dd08a7
245abb69-d425-4619-bb65-d6f18a1aee8e	t	Kabagari	a984ec7d-92fe-4003-abfb-708130dd08a7
c11093f0-6d02-4244-9b05-25d91469f8a6	t	Rukaragata	a984ec7d-92fe-4003-abfb-708130dd08a7
8a8f3f9c-3c87-451b-94c6-c4bb90e8c8a4	t	Rususa	a984ec7d-92fe-4003-abfb-708130dd08a7
149f9663-a952-4f70-acbf-bb33e72f479b	t	Nyakariba	27b7b308-640f-4e68-b890-b30ee32e0b2b
5fad487d-8ee2-4c2f-a2dd-93f90e4361da	t	Gakoma	3c5eb52b-2092-4bd9-8d9f-c9967d416556
2afa4652-8dd1-487f-8c83-7be892ac4a03	t	Birambo	39fcafd2-511f-4137-bffb-97b8a7d37127
2b7ccbc7-56ca-483c-91bb-ce0dc0f4ac9b	t	Dutwe	39fcafd2-511f-4137-bffb-97b8a7d37127
9dd9fe79-0414-451a-84be-fe3a0d228a89	t	Gaseke	39fcafd2-511f-4137-bffb-97b8a7d37127
fec674fd-e752-4495-89cd-9fcb49066df7	t	Giko	39fcafd2-511f-4137-bffb-97b8a7d37127
e166f86c-5746-42b8-a5e0-f1f4b3deda65	t	Ngobagoba	39fcafd2-511f-4137-bffb-97b8a7d37127
a6fc3ebe-3803-481b-8760-489b24ed2af2	t	Cyambogo	e5a8966f-eeeb-45a9-a21d-7f6e8834a0a3
bec08eec-b078-4b02-833a-776774767127	t	Muganza	e5a8966f-eeeb-45a9-a21d-7f6e8834a0a3
493a6022-2b6a-42fb-9990-e85acf306a1a	t	Murambi	e5a8966f-eeeb-45a9-a21d-7f6e8834a0a3
b716c245-db68-4eec-b184-5a4d565c24f5	t	Nyange	e5a8966f-eeeb-45a9-a21d-7f6e8834a0a3
61019510-7984-4c4d-8045-536cfe3ccbc1	t	Nyarusange	e5a8966f-eeeb-45a9-a21d-7f6e8834a0a3
a3649ee7-0d98-41c2-be5e-26ba335c007c	t	Vungu	e5a8966f-eeeb-45a9-a21d-7f6e8834a0a3
5c18d395-94e4-47b4-9fed-44154bb2e7a8	t	Zegenya	e5a8966f-eeeb-45a9-a21d-7f6e8834a0a3
1dfca34c-de75-44d1-bc3e-fd29f510f2b9	t	Karambo	c60cb082-c02e-476d-9ae4-ef4cf8804a10
e9711767-00c7-4490-a62a-ee6b7b6e5f58	t	Nyagatama	c60cb082-c02e-476d-9ae4-ef4cf8804a10
6f22cd00-a75f-4d38-bde2-2a984896ba42	t	Nyamyungo	c60cb082-c02e-476d-9ae4-ef4cf8804a10
a540f387-e4d6-4946-ace0-9dc21c519aff	t	Kabayengo	26c9ef73-1468-4cbc-9f67-46e5952994de
5ace5d2f-2ea0-4e5f-855d-2a2bed43c940	t	Nshano	26c9ef73-1468-4cbc-9f67-46e5952994de
6c788650-a1f4-4b0c-a825-1e13e359af1c	t	Ndagarago	2d0fbb8a-6358-4f18-a1b6-ec2730462158
8828ff07-8793-456e-a65b-1ffed4c5fbcb	t	Nyamuza	2d0fbb8a-6358-4f18-a1b6-ec2730462158
2bdccafc-c1e0-4e0e-8d8c-56ea693c3a89	t	Butenga	2c3d0d5c-2f9d-43bb-b409-84b36eeba849
b04a3e76-962b-4aa4-844f-631e6fe5956c	t	Gatare	2c3d0d5c-2f9d-43bb-b409-84b36eeba849
b9bc37a4-3ee3-430e-883b-20caea19f800	t	Migendezo	2c3d0d5c-2f9d-43bb-b409-84b36eeba849
bb6e3ee3-8b33-46a4-98e9-00ebcd3f69d0	t	Nyirabwina	2c3d0d5c-2f9d-43bb-b409-84b36eeba849
c114ea9a-7eb1-4162-9b61-0f4e73746cd8	t	Arusha	c57b6210-d8f4-4cc7-982c-f1c3de92a4f4
c8e5f985-f495-4b5f-b703-f504e225a864	t	Bukinanyana	c57b6210-d8f4-4cc7-982c-f1c3de92a4f4
b03afd52-c62f-438c-8839-1887180b7ed5	t	Busasamana	c57b6210-d8f4-4cc7-982c-f1c3de92a4f4
893abbaa-191a-437b-a1e7-0914db5d7d53	t	Ngamba	c57b6210-d8f4-4cc7-982c-f1c3de92a4f4
3ae5f2e3-8d6f-4e7c-9df8-20850b8281ae	t	Ngandu	c57b6210-d8f4-4cc7-982c-f1c3de92a4f4
fbca538c-6868-4dfc-bdc7-c04aa4e5f84f	t	Nyabishungur	c57b6210-d8f4-4cc7-982c-f1c3de92a4f4
8300f643-6820-4e05-ac1d-7528617c3923	t	Nyagihinga	c57b6210-d8f4-4cc7-982c-f1c3de92a4f4
d8c10c2e-0ae4-4d07-91c7-c5b1c233aa7a	t	Gasizi	23603f8e-5080-45b6-a60f-fc0fe9c18ffd
6d961eec-0ee2-4b1c-964e-b863aae11059	t	Giticyinyoni	23603f8e-5080-45b6-a60f-fc0fe9c18ffd
27479b6e-8b93-41e1-be71-c4d263e15af0	t	Ngando	23603f8e-5080-45b6-a60f-fc0fe9c18ffd
cf87edf6-fe40-4abb-a9e3-d5662b57db2e	t	Vuga	23603f8e-5080-45b6-a60f-fc0fe9c18ffd
36418487-eca0-48ab-89d7-16cc7cf2307b	t	Kazuba	fb1c8ac6-a7e3-48f7-afa3-827d0b155bfb
dc298cfc-d4c3-483d-ad69-e738ff0ed8c0	t	Kijote	fb1c8ac6-a7e3-48f7-afa3-827d0b155bfb
d23799c9-a641-48aa-9e7b-658a31e27e6c	t	Kabatezi	9ff34bdd-ec6f-49f3-8e06-98f8f2068557
7b03b26f-2cb8-4fa3-a892-b22e261fc336	t	Kabuga	9ff34bdd-ec6f-49f3-8e06-98f8f2068557
acf78cd8-bcd1-4159-a685-78bd7b507473	t	Kageli	9ff34bdd-ec6f-49f3-8e06-98f8f2068557
ed57541c-75b3-4443-9c92-dbb8559e2e8d	t	Ruhinga	9ff34bdd-ec6f-49f3-8e06-98f8f2068557
6752c2aa-bc75-418e-a872-7044fb1d9733	t	Rukore	9ff34bdd-ec6f-49f3-8e06-98f8f2068557
1ac725a3-1f93-4017-b0b0-51233e7941fe	t	Rwankuba	9ff34bdd-ec6f-49f3-8e06-98f8f2068557
ba114917-c6b2-4c3e-a004-4d697d81b2c1	t	Bihangara	c44b3e8d-8e42-46aa-b3f8-4f13cff30361
f16f3efb-d080-4a4c-8b78-4dc910695722	t	Kagano	99194158-59a8-453d-a7ee-0af09c7636f8
e151ea47-f8ff-49ef-85d7-e793fc097b9d	t	Kariyeri	99194158-59a8-453d-a7ee-0af09c7636f8
90bc6f3d-69e7-411b-9ac4-e719b926c0a4	t	Kinamba	99194158-59a8-453d-a7ee-0af09c7636f8
d3228e6e-29b6-4d86-9e4e-99a70fd013f4	t	Mizingo	99194158-59a8-453d-a7ee-0af09c7636f8
b191df57-f843-410a-b6a0-331cde164be5	t	Ngangare	99194158-59a8-453d-a7ee-0af09c7636f8
7f8111ed-33a5-466e-aeb7-c69ac3521f28	t	Nyagafumber	99194158-59a8-453d-a7ee-0af09c7636f8
68304eb4-9594-443f-8ce2-63e176f961e9	t	Bibanza	a11f4f70-1875-4861-bf54-e0056f93fe23
68239b5a-8f71-4185-8caa-2df7ab4b4faa	t	Bukinanyana	a11f4f70-1875-4861-bf54-e0056f93fe23
528de0c4-3835-4e8c-8d5b-ec7bac8e2932	t	Kageri	a11f4f70-1875-4861-bf54-e0056f93fe23
7d31c442-7217-4dd8-a187-c4ab9bea6af6	t	Karuhirwa	a11f4f70-1875-4861-bf54-e0056f93fe23
1e854b86-2a1b-4671-b203-feb3859b2f73	t	Kibaya	a11f4f70-1875-4861-bf54-e0056f93fe23
3b1a2d0c-e766-49b4-8b41-62e80c374a9c	t	Nsakira	a11f4f70-1875-4861-bf54-e0056f93fe23
ab2ad47b-9640-4251-a4fa-9be58466f6cc	t	Kagano	dc0a1308-fb25-4a9f-8b0c-3c425517c2cc
cf0fc6e0-e1e5-453c-8b68-87386fb6367b	t	Kanyaru	dc0a1308-fb25-4a9f-8b0c-3c425517c2cc
739685c7-7707-4975-a046-b2a5a10c5929	t	Kinyengagi	dc0a1308-fb25-4a9f-8b0c-3c425517c2cc
6ba8aa63-3d10-448b-b74a-d77517f2c84c	t	Mikingo	dc0a1308-fb25-4a9f-8b0c-3c425517c2cc
f2be6443-ec93-4683-b744-4cf3fe1753c1	t	Rwanamiza	dc0a1308-fb25-4a9f-8b0c-3c425517c2cc
633926cb-3f13-4e3f-98fb-08ae738b89a3	t	Gitambuko	ec5d5472-7151-4c49-a767-5ad3e31e8dd2
0d57d573-bc0d-421f-a3d5-a478f2135a98	t	Kagaga	ec5d5472-7151-4c49-a767-5ad3e31e8dd2
61d7a83a-442b-4abf-921d-bf217482906b	t	Matara	ec5d5472-7151-4c49-a767-5ad3e31e8dd2
8f23c9cf-91ce-44a2-b6b0-ecce23abb1b8	t	Musumba	ec5d5472-7151-4c49-a767-5ad3e31e8dd2
3dd971f2-4241-4030-ae24-24432b7ecd95	t	Ndorwa	ec5d5472-7151-4c49-a767-5ad3e31e8dd2
67107a8b-4e5d-4a58-b744-5cc625f5b468	t	Runyanja	ec5d5472-7151-4c49-a767-5ad3e31e8dd2
a3991ef2-fdb3-458c-9e65-49aad67ccf50	t	Kareba	6cb64c1d-8b54-4470-a9da-8d2db888cd29
0a786951-2340-41c0-b901-9dbc8da2a0a5	t	Jenda	9f626d6e-2fe9-416a-8d2b-4577e0a6eec8
b63ba0e6-b860-432a-b1d1-077b2f345f10	t	Nteranya	9f626d6e-2fe9-416a-8d2b-4577e0a6eec8
959499a4-fe09-4348-882a-c0e0f09af038	t	Rushunguru	9f626d6e-2fe9-416a-8d2b-4577e0a6eec8
ba4ccec0-9705-4847-a778-47d07e5e7726	t	Bihinga	7e64fec9-e35b-4c6e-b73f-5b1cadf1dc31
7811702b-fc80-4df6-874c-6d10a18d8c1d	t	Gakarara	7e64fec9-e35b-4c6e-b73f-5b1cadf1dc31
88dddcbb-ad8b-4924-89b3-27ec4e20a1e5	t	Kajebeshi	7e64fec9-e35b-4c6e-b73f-5b1cadf1dc31
0b9d0b4a-171c-4ac3-bd3e-bf894200e4bb	t	Rega	7e64fec9-e35b-4c6e-b73f-5b1cadf1dc31
6c1826e6-0c12-4a7d-8271-dd52d0065b36	t	Terimbere	7e64fec9-e35b-4c6e-b73f-5b1cadf1dc31
0e22a617-e5d2-44ca-b345-c4be694c3268	t	Kanama	39afb0ec-5d0b-4f61-a493-8685c2573ec4
84f46aae-27c7-4f33-82d5-9c09526080f0	t	Nyundo	39afb0ec-5d0b-4f61-a493-8685c2573ec4
ab0314c7-25af-4fd6-b683-428ea422a52a	t	Gasura	09f43ea5-34c9-467b-ba28-7d8f0548dd7e
cacdd9df-cafd-4d68-be85-63f26d0cf22a	t	Gisoro	09f43ea5-34c9-467b-ba28-7d8f0548dd7e
8f89bff3-a4c8-4995-9da4-407b87826705	t	Kagano	09f43ea5-34c9-467b-ba28-7d8f0548dd7e
9fc8a8a4-9caf-47f4-9649-e641c5c5afbc	t	Ryabirumba	09f43ea5-34c9-467b-ba28-7d8f0548dd7e
1a38de14-a40d-4f38-b8b1-c98d7883da47	t	Futi	be4b7a03-9e2e-4f59-b99a-ba8e66032942
0f5a2593-8ec0-46ce-b920-89778c70fd8b	t	Gikaranka	be4b7a03-9e2e-4f59-b99a-ba8e66032942
a67c3210-412a-495a-9708-345792eec693	t	Gisizi	be4b7a03-9e2e-4f59-b99a-ba8e66032942
d2b1aaa6-cf89-4d04-897b-22646bbaf38e	t	Guriro	55e16192-ffe7-4a4b-b53f-09225713ada8
f6758cb0-cc5e-4b6b-8bea-c9238beee65b	t	Misegwibiri	55e16192-ffe7-4a4b-b53f-09225713ada8
e44423d5-0990-4efc-9447-1ed442c8f119	t	Ngabo	55e16192-ffe7-4a4b-b53f-09225713ada8
8c36d710-0779-4452-aba7-d97682849a39	t	Nyarusongati	55e16192-ffe7-4a4b-b53f-09225713ada8
6f2f3588-283e-4a89-ae96-537ff89abba8	t	Kavumu	e417739d-0e57-40e0-879a-c99f9694750c
967e4fbf-892b-4d2c-a51f-9e7c65c6b445	t	Munyege	e417739d-0e57-40e0-879a-c99f9694750c
5ec40e13-8708-4b0a-86fe-13b4f3382eaa	t	Rugerero	e417739d-0e57-40e0-879a-c99f9694750c
e0b3acc7-b012-4bbb-aaa7-5f0f2ed91c63	t	Bihinga	ce71c23d-f419-4a65-a2ff-4f9dcaebf785
10da2339-bac1-43d7-bede-eaaee0afd121	t	Ntwaro	ce71c23d-f419-4a65-a2ff-4f9dcaebf785
ef58dd03-d299-47b3-9022-78ff23cee66c	t	Nyamitanzi	ce71c23d-f419-4a65-a2ff-4f9dcaebf785
bd6f0fa7-33a6-4fe4-b1cb-e36e32aa541f	t	Rubavu	ce71c23d-f419-4a65-a2ff-4f9dcaebf785
f8242edd-22d8-44d8-9d82-5f38981bfca9	t	Rugera	ce71c23d-f419-4a65-a2ff-4f9dcaebf785
9600c61e-651c-4990-90db-859769a8007e	t	Rutabu	ce71c23d-f419-4a65-a2ff-4f9dcaebf785
b05ff86a-b5a0-4844-9e76-6abcc3e0fc70	t	Batikoti	e8bcbcf0-8c3c-4d56-a6d3-b8d6b5a0fd89
9229c426-0dd7-46d9-8597-83ffd81bee2b	t	Kamuhe	e8bcbcf0-8c3c-4d56-a6d3-b8d6b5a0fd89
f78eb228-61be-4323-869e-23a4a1ea2bc1	t	Rubare	e8bcbcf0-8c3c-4d56-a6d3-b8d6b5a0fd89
238fda72-bb42-4ac7-8729-332bf4b4f512	t	Sake	e8bcbcf0-8c3c-4d56-a6d3-b8d6b5a0fd89
2e38bfab-69aa-4df8-ab5a-78358bd65bf4	t	Kabagabo	4811cf04-48ee-4a66-8546-38f1bfcaf799
5273bdea-126f-4729-b0fd-0ed2d7e3b541	t	Murambi	4811cf04-48ee-4a66-8546-38f1bfcaf799
2b84755f-6a1f-46a9-9267-1129bf2fe265	t	Bisukiro	35fb5aeb-3f7a-403b-b9c1-08847de2b9bf
2973e8d5-902e-4ef5-849e-0c2073994b99	t	Kaminuza	35fb5aeb-3f7a-403b-b9c1-08847de2b9bf
5fc8a4e8-32de-4911-a950-1ea8dfc34364	t	Kinyababa	35fb5aeb-3f7a-403b-b9c1-08847de2b9bf
1e360c3f-040f-4e3f-9a9a-1177fdc6b33e	t	Rushubi	35fb5aeb-3f7a-403b-b9c1-08847de2b9bf
15ba5515-0bf3-4cbc-b7e5-c5e34bbb46dd	t	Akabeza	4eda8bc3-b564-48fb-bcb1-6295890a46f7
52c2abce-1906-4c52-b4af-bc61eac52198	t	Akimitoni	4eda8bc3-b564-48fb-bcb1-6295890a46f7
4458b24c-4c52-483d-9141-7f304075b534	t	Butaka	4eda8bc3-b564-48fb-bcb1-6295890a46f7
a3dfa718-85e0-4be0-9020-771c0e0f25b7	t	Myuga	4eda8bc3-b564-48fb-bcb1-6295890a46f7
9d314355-07de-4f34-9bc5-6c512352bb96	t	Gaharawe	6177382b-0c30-4842-a732-46da8126a510
867806fc-220f-4b67-99b5-277983c2f776	t	Kiramira	6177382b-0c30-4842-a732-46da8126a510
61d2a8f2-9e4b-45c6-8fb5-a330a8034a33	t	Ruhango	6177382b-0c30-4842-a732-46da8126a510
dcc6f1a9-ee6c-492e-b0aa-1e6694765ca5	t	Karambi	7c6e62f0-9236-48dd-b2ad-0fee17f46c63
33555725-7766-4f82-a043-3d1377abf870	t	Kinkware	7c6e62f0-9236-48dd-b2ad-0fee17f46c63
7f191bf3-e4a9-4fa0-90b2-23cde126a498	t	Masasa	7c6e62f0-9236-48dd-b2ad-0fee17f46c63
0db991ec-143f-48e1-901a-e469ec76b7db	t	Remera	7c6e62f0-9236-48dd-b2ad-0fee17f46c63
715b7e2d-5b19-4866-b8ac-ff410c1d3a80	t	Nanga	b2cce3ab-4771-4652-87a0-c0fa82bf560a
11375e58-e1e6-4ad3-bfe5-8bd5ffecce5b	t	Nyagasozi	a3ca0281-3230-470c-8e2c-08df206cd144
1b59f822-ae51-4e5e-906c-e1e97a5dacce	t	Mwiyanike	593b6208-501b-414e-b5f5-1c314965d476
2bb1cb1a-bfda-4c74-ba06-d07e26e865a3	t	Gatovu Centre	e011897f-bc01-497e-a4e7-d929ed341dce
4bc3a4f9-1ba2-4e1e-8bff-1ade12338a40	t	Kankima	20da6224-5075-4786-a815-1623692ad4da
b962bd59-a8c0-4822-854b-0b8509b20d79	t	Sasangabo	2f4b1110-6349-4ea8-ab0e-b813c69a80d5
44ae5018-f14d-4d63-a701-043f5dab3015	t	Butondwe	795a57f2-3705-4561-87ad-72604518eb6a
8883822b-6f79-42f7-bbcf-314b5d4df82b	t	Gisenyi	795a57f2-3705-4561-87ad-72604518eb6a
2fcc040e-64da-4736-a627-03eb114778c4	t	Hesha	795a57f2-3705-4561-87ad-72604518eb6a
7b69cddb-9c4a-42bf-b813-4b72f0a9b94c	t	Nyirabasheny	795a57f2-3705-4561-87ad-72604518eb6a
b3697bf3-f0c0-460d-a60c-7cc84b0946e7	t	Rwanyirangen	795a57f2-3705-4561-87ad-72604518eb6a
e767a79c-8f9e-491e-9baa-2388b2753399	t	Kabere	bc6d3888-1544-453d-a91c-f05c170a88bb
c05c896d-312d-4e1a-8687-84eca6751247	t	Kanyove	bc6d3888-1544-453d-a91c-f05c170a88bb
c347e8fa-4f3b-4b9f-a31d-7e092125bd54	t	Cyivugiza	7596791a-b05a-4537-8e48-f9999d4cf995
fa6fe0e5-ac86-471b-94ee-f9f7a24396a3	t	Kaburende	7596791a-b05a-4537-8e48-f9999d4cf995
8ee22bbd-456e-4f15-ab94-90228ef633e8	t	Karandaryi	7596791a-b05a-4537-8e48-f9999d4cf995
7f77da94-1111-4376-9fd0-fe3b3109e736	t	Cyinkenke	16b363ee-0f87-4fda-a18c-7cd1d794296b
29cb5d30-cec3-4593-8ae8-5d535b81a86b	t	Kamenyo	16b363ee-0f87-4fda-a18c-7cd1d794296b
770093b4-c7db-4497-a5ea-6ea59f672550	t	Karama	16b363ee-0f87-4fda-a18c-7cd1d794296b
feb56aeb-0368-46e0-bfe2-ec3dfc63cbf8	t	Kazibake	16b363ee-0f87-4fda-a18c-7cd1d794296b
3702dad8-562b-47ef-8595-c6da552b7b07	t	Kazuba	16b363ee-0f87-4fda-a18c-7cd1d794296b
c4f4436a-f956-41df-92b6-f666a8dc93d7	t	Rutovu	5881aa54-e10d-4bf7-831c-18b2a43e644f
2dbfef7a-965b-4ce8-871d-94b21c2ee576	t	Rwankeri	5881aa54-e10d-4bf7-831c-18b2a43e644f
77f5b1b4-b12e-4efe-9fb0-87c37757547b	t	Kinihira	8bbea048-1bb6-4a50-a42c-214d7e6d45e3
1ed46bd3-25f4-4d52-9661-d6977a74cee9	t	Munini	8bbea048-1bb6-4a50-a42c-214d7e6d45e3
63004a70-d5e5-4a9d-8ed6-c68632c56ded	t	Bunywero	785a9524-bd2a-48ef-b7d0-b0414bd5cbb9
d5d8d3c2-13ad-41a8-a313-f73da8ddc783	t	Gakamba	785a9524-bd2a-48ef-b7d0-b0414bd5cbb9
0d98c6da-0a7b-4028-b035-19fe5812804d	t	Gora	785a9524-bd2a-48ef-b7d0-b0414bd5cbb9
e8afa3a4-97b4-492e-bbba-43c937ae0f97	t	Kivugiza	785a9524-bd2a-48ef-b7d0-b0414bd5cbb9
9052817c-32c7-4da6-babb-20408cfc5b9e	t	Migongo	785a9524-bd2a-48ef-b7d0-b0414bd5cbb9
82b43241-c1a8-4132-b315-5612ceffde6f	t	Rurambo	785a9524-bd2a-48ef-b7d0-b0414bd5cbb9
cc5f24fc-76fb-4447-ba5c-cfa06411406e	t	Mucundebo	93d72785-8679-4690-a4e4-be5afaecb085
cee0bb1c-a16a-4108-8592-aeca94ae1d01	t	Musaraba	93d72785-8679-4690-a4e4-be5afaecb085
f46301fe-57d0-45d1-836e-d4c3aa8fa790	t	Ryanyirandab	93d72785-8679-4690-a4e4-be5afaecb085
6ff78c45-d5e2-4fd6-9fcf-dea6d8765e6d	t	Kamajanga	94324c6f-b52c-40e1-820a-81cf71f723d9
14b8c5df-0098-4de9-b92e-de2a29c0ebbb	t	Kinaba	94324c6f-b52c-40e1-820a-81cf71f723d9
3bea794a-63b1-41c1-9363-6db2e29bc843	t	Mabare	94324c6f-b52c-40e1-820a-81cf71f723d9
a0379d52-a77f-4fea-bc71-548be9df2239	t	Muremure	94324c6f-b52c-40e1-820a-81cf71f723d9
02dba33b-a827-4dcc-949a-656ebd474272	t	Bambiro	78f34c32-65ad-4354-a6d4-cecdec7e8e3e
c204da2d-7d13-4edd-bae4-c1a0fea25c8e	t	Kanwiri	78f34c32-65ad-4354-a6d4-cecdec7e8e3e
c2ffbd4d-07aa-4c93-b8a8-c450dd4c12ed	t	Muyange	78f34c32-65ad-4354-a6d4-cecdec7e8e3e
cc63f987-6574-4dc6-8c8a-572bdbf50fe4	t	Nyamasheke	78f34c32-65ad-4354-a6d4-cecdec7e8e3e
987dc6ae-8300-4e89-bc69-52e83c618c0a	t	Rubare	78f34c32-65ad-4354-a6d4-cecdec7e8e3e
41c5268d-f28f-4b9d-8a2d-a5b97fe31dc1	t	Gasura	34a99935-8e62-46dd-8902-a52155c4ee32
2436a54a-0776-4f50-b5b0-9d92a61e02c6	t	Karambi	34a99935-8e62-46dd-8902-a52155c4ee32
a098e315-3f6a-4177-918f-eaefa6715afb	t	Musenyi	34a99935-8e62-46dd-8902-a52155c4ee32
4c168d33-222e-4a0f-ad6c-d6f1fa017fc3	t	Rwandarugari	34a99935-8e62-46dd-8902-a52155c4ee32
26bdb7ff-eed7-46ca-83ec-6f417e07e885	t	Birembo	2e06f4b8-9642-44a6-ae6a-a83e514e2a3d
b966b42d-9ad5-4707-be98-9ee211bd5e0f	t	Rugarambiro	2e06f4b8-9642-44a6-ae6a-a83e514e2a3d
5b7a0284-7312-47d0-9403-f25ed13e9176	t	Kabeza	7fdd2752-1b04-4a0f-8854-cad3951a3948
7b74ae8c-485a-4494-bc66-27afb980a22b	t	Rwenzo	7fdd2752-1b04-4a0f-8854-cad3951a3948
0cc36a35-9795-4224-936e-07fbc5ffc2ef	t	Bukinanyana	1e88f35d-607f-4c3f-bffe-f272363d86b9
c2b7a34b-5728-49f8-a1e4-922cf60b72c0	t	Rusekera	1e88f35d-607f-4c3f-bffe-f272363d86b9
89724d60-4187-4f3b-95a9-207907699609	t	Gasiza	89fb280f-7deb-4a52-8e1f-154476d64d14
9bf6f71e-c02d-4822-8db5-27df020e5dfe	t	Kamifuho	89fb280f-7deb-4a52-8e1f-154476d64d14
901325e8-0b5b-44ff-a0f6-2b51ddbb08cf	t	Myumba	89fb280f-7deb-4a52-8e1f-154476d64d14
d613e5d7-06d8-4172-bf3c-4d2d1db795d7	t	Nama	89fb280f-7deb-4a52-8e1f-154476d64d14
3e1efc2c-ad5c-429f-918f-ad8d4d12bfed	t	Nyempanika	89fb280f-7deb-4a52-8e1f-154476d64d14
d5603823-0ada-4628-bdb9-8f0d01234764	t	Rwinkingi	89fb280f-7deb-4a52-8e1f-154476d64d14
1caf423d-6830-487f-95e9-d29085ea495b	t	Giharo	0f8eda98-f64c-4af6-949d-105b03d22a40
7ff51022-8b41-44e0-8bf6-3d943628ddd4	t	Kamiro	0f8eda98-f64c-4af6-949d-105b03d22a40
031174e0-04fe-4af0-a758-63145cd106fa	t	Kibumbiro	0f8eda98-f64c-4af6-949d-105b03d22a40
9afa5245-0a9a-451c-b916-99f581a0eb43	t	Muturagara	0f8eda98-f64c-4af6-949d-105b03d22a40
e236d2db-f53f-428f-a2f3-39d2f92ed917	t	Muturirwa	0f8eda98-f64c-4af6-949d-105b03d22a40
630ad1b5-3574-476e-a00e-7ed4c399249e	t	Nkomane	0f8eda98-f64c-4af6-949d-105b03d22a40
f22adca2-8675-4463-8472-91fc91dbefe9	t	Mubuga	89b06d1b-b065-492d-8ad3-0038ec60e08e
d1df85aa-0efe-461d-b598-ab2f18c15993	t	Nyakigezi	89b06d1b-b065-492d-8ad3-0038ec60e08e
610f57fc-bfce-4c9a-acbd-d9e6768e1e66	t	Gitotsi	41800604-c84f-48ec-a481-d471e5918fd4
ae5d9892-5d50-476e-8fde-cf75c32c4868	t	Muhare	41800604-c84f-48ec-a481-d471e5918fd4
0c7373ea-0b49-41c6-b0d3-ef6e38f499db	t	Musenyi	41800604-c84f-48ec-a481-d471e5918fd4
97ab1034-b93f-4344-be70-1b0315eafe15	t	Mwambi	6763039a-65cb-4f5d-b672-ccb4091d003a
4181b2a7-a5b6-4a61-a32c-5ed5cac5c34f	t	Cyasenge	da61cc04-5278-4537-b25b-a75321d1c434
6c96f02d-001b-4fb9-92dc-a62537dca3cd	t	Gahama	da61cc04-5278-4537-b25b-a75321d1c434
9d77455b-0da1-4441-9660-25a0e8f4a2b2	t	Gihuri	da61cc04-5278-4537-b25b-a75321d1c434
81bbd4f4-e646-43f5-9d58-8e9e79ca3248	t	Karambi	da61cc04-5278-4537-b25b-a75321d1c434
3325df2e-4f8b-4151-a044-b69427b5bd78	t	Nyakiriba	88ad1d02-dba6-4db4-ac0a-04d7ac29e9b6
18b2533c-f872-404e-9793-ef618303b1b7	t	Cyanika	9ce690c1-e718-4da8-a3cd-d754819ab663
573608a5-8bc7-4d20-ae36-57d20b6e0dd1	t	Gitega	9ce690c1-e718-4da8-a3cd-d754819ab663
35213625-2b87-45d2-a475-5140820d838e	t	Bugeshi	806520cd-4b6d-4605-bdf1-16c5dbe151df
1f3dc214-e8dc-4630-9c67-af0560668b15	t	Muremure	806520cd-4b6d-4605-bdf1-16c5dbe151df
18168d36-e146-4e48-92d4-b277529d2e82	t	Nemba	fd77533d-35a0-42f0-b664-87a0258e9f0e
d2a60e09-4b4a-4d8f-a986-9e95849507ca	t	Kabutozi	8f202e5d-cbb3-4d8a-a8ac-e0c81c200436
492597a1-422a-41b9-ae3f-149276b62569	t	Musenyi	8f202e5d-cbb3-4d8a-a8ac-e0c81c200436
86f8631b-5d6e-4fee-a312-beecc0fc7b48	t	Rwanika	8f202e5d-cbb3-4d8a-a8ac-e0c81c200436
7a103ddf-5d69-4891-9968-3278267a4f5a	t	Bihembe	d92ed8de-305d-400e-8fdd-96ec27ae336a
e19ab19c-35c1-4a36-b860-e35456d9a1d4	t	Kabuga	d92ed8de-305d-400e-8fdd-96ec27ae336a
1f80fb51-69b9-4d55-99cc-e42c3d04e27e	t	Mugwato	d92ed8de-305d-400e-8fdd-96ec27ae336a
67ba9538-59f7-43ef-9b1e-2171f1a3ca9b	t	Murikwa	d92ed8de-305d-400e-8fdd-96ec27ae336a
713cbe03-77a2-4198-8319-3858c8224d4b	t	Kamahoro	3fd9abe2-8d4f-4317-a9d0-65524bc101cf
a3b55322-da93-43ea-a363-201c824d13eb	t	Kazirankara	3fd9abe2-8d4f-4317-a9d0-65524bc101cf
57c5ee5e-1a94-4b68-961c-1b4094966f80	t	Kigabiro	3fd9abe2-8d4f-4317-a9d0-65524bc101cf
b84d692f-e358-44eb-bf03-a1a4b94e5316	t	Kabagabo	d23c20bd-d72a-4995-b5ea-0e6458e6121e
83391d92-c80d-47a7-84ee-901c46b8fb34	t	Kabuguzo	d23c20bd-d72a-4995-b5ea-0e6458e6121e
86558cbf-5b46-4348-9d5b-e086692f9044	t	Munanira	d23c20bd-d72a-4995-b5ea-0e6458e6121e
208b6f10-9683-4173-9d9d-070bbf1a0c83	t	Gacurabwenge	94237609-fbc8-4eb8-89d6-12877e0319fe
aae24110-ca25-46e6-9c2e-b956d4db14dd	t	Kagongo	94237609-fbc8-4eb8-89d6-12877e0319fe
18ece658-6eb6-4237-8fd5-0cd54eec68e6	t	Mukaka	94237609-fbc8-4eb8-89d6-12877e0319fe
21ac52ea-bf93-4c68-826d-f22c47450deb	t	Rwabahungu	94237609-fbc8-4eb8-89d6-12877e0319fe
b6618388-179f-4e14-a09f-76591dc26f40	t	Vunga	94237609-fbc8-4eb8-89d6-12877e0319fe
c1c4af72-bbc9-481a-8b27-11e93a9f7265	t	Kaziba	611f74a4-b9d8-4f80-ac72-b0ca1326a5a8
32b7d5e1-d331-445f-b4eb-d1ee294b30da	t	Gitega	b8c76a83-783b-4c7b-aea4-a3b17ad1645a
904e9aaa-b603-486d-86ee-d1ed7d4abcb6	t	Kabuga	b8c76a83-783b-4c7b-aea4-a3b17ad1645a
c63d581e-1e70-4e44-b866-abc496554bb2	t	Kiyovu	b8c76a83-783b-4c7b-aea4-a3b17ad1645a
951498c3-8851-462c-8461-03726b188576	t	Rutoyi	b8c76a83-783b-4c7b-aea4-a3b17ad1645a
d2469dcf-c0d1-483d-a0e3-b36efbae6964	t	Buhinga	fe3c3e87-ec07-44f8-b328-aa631ae9ddbe
09c40e1f-97f1-4f0e-aff0-bf82428ea3fa	t	Bushekeri	fe3c3e87-ec07-44f8-b328-aa631ae9ddbe
74a09e25-3fed-4d9b-89be-e378f50ff002	t	Gasebeya	fe3c3e87-ec07-44f8-b328-aa631ae9ddbe
e86c6ef7-8ecc-48eb-8032-f156bf6cd9b7	t	Mujabagiro	fe3c3e87-ec07-44f8-b328-aa631ae9ddbe
a0f7ddc6-496d-4a37-ab88-2253f339feae	t	Ruvumbu	fe3c3e87-ec07-44f8-b328-aa631ae9ddbe
fb775c11-2a75-4fd9-8bde-e0199494f11c	t	Rwumba	fe3c3e87-ec07-44f8-b328-aa631ae9ddbe
8d30032d-a358-4801-a985-82e07edb3b9e	t	Winkamba	fe3c3e87-ec07-44f8-b328-aa631ae9ddbe
3aac7048-73ff-4107-9023-52388579c5a7	t	Kinini	f37bc102-2ca0-40d5-96e7-60335886ba26
ccfad6b2-a4b8-4ac9-8e37-5af4260082ca	t	Mubuga	f37bc102-2ca0-40d5-96e7-60335886ba26
9dcb60aa-8d1e-4977-a211-4e6a0939b330	t	Nyanza	f37bc102-2ca0-40d5-96e7-60335886ba26
829ce882-434d-4290-9ff3-b1281793b5bc	t	Kamucyamo	c8f47213-cee0-4e88-8d89-adaaaf6b9fbf
64eb6092-f928-4a42-a7e4-fd2eb46cf1cc	t	Bushenge	601a6c2b-c97c-4004-bee5-7f90b7f3c777
5fcef143-63c6-4fc2-b3f3-a8ca2c5bbe9e	t	Gashirabwoba	676c88fe-0abb-40df-ac92-826645885e2b
32b1c708-575b-43d4-9aa0-55a6dca5fc71	t	Gatare	676c88fe-0abb-40df-ac92-826645885e2b
1a9194db-2af7-43a0-9c0d-6f48fa306c1a	t	Kagatamu	676c88fe-0abb-40df-ac92-826645885e2b
6523f7ab-0f4e-4466-9f9d-1ad8573d4e51	t	Karusimbi	0a434d0f-fadb-42b6-87d0-6fdeee734a24
2ed5e602-731c-4a6f-9039-2a769f3d1e05	t	Rwumuyaga	0a434d0f-fadb-42b6-87d0-6fdeee734a24
dcf3c307-7761-4570-8ce7-698dd8b1fa4a	t	Cyato	3d031c18-4e80-496e-8952-fa306c20c301
e26f2421-a17a-45b0-9352-f059eb1ab1e3	t	Kamonyi	3d031c18-4e80-496e-8952-fa306c20c301
e1b4590a-3983-4d33-b01e-21442255abd0	t	Muremure	3d031c18-4e80-496e-8952-fa306c20c301
9088132f-44a7-441c-a18b-edc17327346d	t	Yove	b3664ee6-7797-4fdc-bdda-229a1ee0848e
bcf58d98-1a08-47d7-9e19-793099bc1f90	t	Mbogo	bd47c359-a342-4bf3-9443-ae926cb4be8b
675b9b22-7c62-4de4-989e-d629a31782f9	t	Rwatsi	bd47c359-a342-4bf3-9443-ae926cb4be8b
7b8bcff4-f76e-4be7-a4fd-5d46bdb9edb3	t	Birehe	a9903b8e-513f-478e-9b26-dc0c3e6bff3c
8aeb3b7c-b363-4c23-8303-a8495f70d0c8	t	Kibirizi	a9516b92-a71d-43ce-bc82-25f7724ddf15
052e7c80-632d-46a8-bbf2-e06f508d45e5	t	Kigarama	0ce7e40b-5158-4635-80c6-58ec3964263a
da6415f4-d6c1-4b0e-9121-eb123a01aa19	t	Bungo	e767b78e-2eaa-4164-98b0-968595de4d6d
46fe4393-d589-4460-b911-8288d38b526b	t	Butembo	e767b78e-2eaa-4164-98b0-968595de4d6d
95bd2bc9-bbe8-4191-a6fd-803005e3bf06	t	Mubuga	e767b78e-2eaa-4164-98b0-968595de4d6d
c8c382b0-0aa4-44ce-9826-b5f8f7aabeb7	t	Muhavu	e767b78e-2eaa-4164-98b0-968595de4d6d
7a82d2f9-3101-4795-bcbe-f0c0f275906d	t	Ruhingo	e767b78e-2eaa-4164-98b0-968595de4d6d
adaaa68e-f4a2-4fb5-81b9-4117338ea1df	t	Gitwa	a4c6c532-209d-4e77-90ff-d760220395b1
70a24495-ced7-4787-896c-d5fbc44f596d	t	Kazibira	a4c6c532-209d-4e77-90ff-d760220395b1
ce2f1da1-b576-44ad-9c00-cf942547df1f	t	Remera	a4c6c532-209d-4e77-90ff-d760220395b1
afe078ce-814e-4cb3-93d4-635f2663916a	t	Buhuru	609c9180-2d39-4765-91cb-117d1481ee01
59d28aa2-f8dc-4918-a25c-e975071336af	t	Rushondi	a4c6c532-209d-4e77-90ff-d760220395b1
558b8f7e-ab1c-4bb8-8f8d-645508b8b2bb	t	Gikomero	1e7a9731-2e6b-413a-a2ca-9688fa4e6e67
2efdcfa3-359c-4bb0-ae92-2d031172f2b8	t	Kabagabo	1e7a9731-2e6b-413a-a2ca-9688fa4e6e67
80a301e2-6178-41e9-9d8b-6e0375702d28	t	Gikuyu	bd04897e-0f0d-479b-9c90-0bf7db780a9d
6e99a203-c894-49da-a84b-b9816131f023	t	Kavune	bd04897e-0f0d-479b-9c90-0bf7db780a9d
a7b72316-f6da-4227-85fa-e2756345894a	t	Mujabagiro	bd04897e-0f0d-479b-9c90-0bf7db780a9d
da346ede-7de8-4744-9f04-940fe8598488	t	Rugabano	bd04897e-0f0d-479b-9c90-0bf7db780a9d
96e14ce0-7fe4-4730-b73f-939f2836a8aa	t	Kijibamba	58dca7d0-9ab1-4c87-8792-80047528dd67
7d479f04-8ef3-4703-8d41-a339fd82dc32	t	Kirehe	58dca7d0-9ab1-4c87-8792-80047528dd67
65b442db-b34a-44ef-b0d1-e83a46c97aeb	t	Rwesero	58dca7d0-9ab1-4c87-8792-80047528dd67
61103c73-5007-4b94-9813-7478dc87f0cb	t	Gahumba	eced6135-4535-475c-b5e6-02ae59ba8050
738884cb-3828-4148-a55c-a62a31692102	t	Rambira	eced6135-4535-475c-b5e6-02ae59ba8050
c49eeed7-df1d-48a4-9e77-d15c91088701	t	Bizenga	b97d13f8-0046-4f52-b5b7-c45de6ecb37e
464915d9-2244-4f3e-ba98-6b02e795c2d7	t	Gataba	b97d13f8-0046-4f52-b5b7-c45de6ecb37e
c6af2cce-d6f9-4eaf-914f-6e155336a3fe	t	Kabuyaga	b97d13f8-0046-4f52-b5b7-c45de6ecb37e
983f16d7-9b47-471c-a52b-6be00adb9198	t	Kagarama	b97d13f8-0046-4f52-b5b7-c45de6ecb37e
123e9630-6efb-4536-8537-498f30cc7cf0	t	Kivugiza	b97d13f8-0046-4f52-b5b7-c45de6ecb37e
2edf3560-bebc-41d6-9c12-2fbf99df5211	t	Maseka	b97d13f8-0046-4f52-b5b7-c45de6ecb37e
d6fae37a-cfd6-43af-a2c2-c577ab009b8a	t	Nyarusange	b97d13f8-0046-4f52-b5b7-c45de6ecb37e
e8ab703b-0be2-4eb1-a449-88290eb4c4d2	t	Rwakagaju	b97d13f8-0046-4f52-b5b7-c45de6ecb37e
12657503-c1fc-4f8a-9bbb-2cec3769ed92	t	Gitwa	d4e85e5c-f39e-46f3-b48e-e8aa48d13fd2
d751d19e-5a9f-4178-bc46-829db5d16eb8	t	Karambi	d4e85e5c-f39e-46f3-b48e-e8aa48d13fd2
2a34df04-f6cb-4be9-a8bb-1c8ccc5f182a	t	Kigugu	4ff511e3-9c25-42dd-8ad0-32a01f2d0dbe
06cd46a3-64a3-4682-95a3-9e710423cd64	t	Museke	4ff511e3-9c25-42dd-8ad0-32a01f2d0dbe
2faa903c-ab98-4f3d-8a4c-30b69a2c665d	t	Ruganzu	4ff511e3-9c25-42dd-8ad0-32a01f2d0dbe
121c3448-d5ce-4eba-a4a7-103221a2b2b0	t	Musasa	183533f2-d963-450b-a8f0-42c3d2ff550e
4b8152df-0282-4378-9f0d-2352c1a85acd	t	Gakenke	5d77062e-9125-407e-b3dd-59b835a26e72
48385a80-a082-458d-9583-c73a16595d21	t	Kamuramira	5d77062e-9125-407e-b3dd-59b835a26e72
e59f4a0b-98d2-4807-b2a1-c0346d96055b	t	Ruganda	5d77062e-9125-407e-b3dd-59b835a26e72
e2bf4e60-84b5-449d-8b60-53c168e8010b	t	Bitare	00a80437-75fe-43aa-9c3b-8614be7da055
f239bd89-efd3-4a11-a60a-b92e58716dcc	t	Gikangaga	00a80437-75fe-43aa-9c3b-8614be7da055
f71ed4ce-c76a-4582-8e1e-32d07de392b9	t	Bugarama	5d108697-761c-439b-983b-cae735c65365
59e95a02-4c0d-4a14-ac00-607d5a3505fc	t	Gaseke	5d108697-761c-439b-983b-cae735c65365
0e924f20-0980-4359-9711-b281b8b8e341	t	Munini	5d108697-761c-439b-983b-cae735c65365
e006e109-c5bc-4257-ae70-12341f39f58c	t	Rugano	5d108697-761c-439b-983b-cae735c65365
d3c888d5-8b7a-4b67-bb67-8a8dea20d8dc	t	Gituntu	0ff77264-9fa1-499d-859e-684ea019e0f2
f2c12acd-26cf-4ffa-9af8-92c662089063	t	Misirimbo	0ff77264-9fa1-499d-859e-684ea019e0f2
ce428711-1559-4e62-bce8-6b1a36c0a8c5	t	Wibungo	0ff77264-9fa1-499d-859e-684ea019e0f2
531d0701-48e7-41a3-93d1-44cdb3d80a58	t	Rubyiruko	32e38a6e-dda0-4b06-9694-1d2f4e1ca62a
393f7776-e8b5-4bef-b85d-964a0db87744	t	Rwunamuka	32e38a6e-dda0-4b06-9694-1d2f4e1ca62a
bf827780-6eb9-4cf4-82ff-482c72af7917	t	Tyazo	32e38a6e-dda0-4b06-9694-1d2f4e1ca62a
7febea6a-2537-4f5c-9a45-52c685ef5da0	t	Gitwa	bc79cf8f-2af9-459c-80a9-47dd01e876ef
e78f2f75-cd22-4f87-addd-aec96208481f	t	Nyamugari	bc79cf8f-2af9-459c-80a9-47dd01e876ef
8e37d83e-15e0-4400-a361-eea0c1779048	t	Nyamurira	bc79cf8f-2af9-459c-80a9-47dd01e876ef
2f4dda75-04a1-4220-9160-32781ae11017	t	Rubona	bc79cf8f-2af9-459c-80a9-47dd01e876ef
0917246a-1d5f-4a73-9f9f-949853b6141e	t	Kabuye	f5edb227-9297-40fa-98c9-24ea604fefba
6b9dbc68-f1d0-4417-ba18-45655b22703f	t	Kanenge	f5edb227-9297-40fa-98c9-24ea604fefba
db220024-dc6c-4ae2-a2ff-ed2492c46cfb	t	Karangiro	f5edb227-9297-40fa-98c9-24ea604fefba
acb314a1-5006-4fe0-b181-e042475484ac	t	Gitunda	683ae5b0-b648-4136-a72e-f879a696ba3d
52d23787-ce24-4f45-94d8-06b0377b0b0f	t	Mpinga	683ae5b0-b648-4136-a72e-f879a696ba3d
08d6f4aa-1ef5-4a95-a35b-bc2ab8d8d0f9	t	Muhora	683ae5b0-b648-4136-a72e-f879a696ba3d
1d15cfca-b125-4c0e-ae91-29005ed7ad13	t	Rukunguri	683ae5b0-b648-4136-a72e-f879a696ba3d
75916216-19fc-4a1f-80a0-9d64cf1fbfe2	t	Kabisheshe	1cce383e-5e3d-4526-9598-65873fb79f2e
d197d07d-b9bb-4fb3-960b-fe644a2d3b3c	t	Nyagisozi	1cce383e-5e3d-4526-9598-65873fb79f2e
0f1b8b5e-ef21-4930-aedd-ecee78219a92	t	Gakeri	add2333c-f6ac-4741-91d0-8c5ad8156abd
cc0b2a23-2033-4097-ab56-7ab633b7cbbc	t	Nyagafunzo	add2333c-f6ac-4741-91d0-8c5ad8156abd
749037c4-d502-4118-a9c8-47dfd0777190	t	Nyagashikura	add2333c-f6ac-4741-91d0-8c5ad8156abd
37b05f2b-80c6-4019-aeb1-070c6847bc03	t	Katabaro	37585658-0b1f-4ee8-bcb1-346ee205efba
cb84a615-572a-41b7-969a-50824183708f	t	Rugeregere	37585658-0b1f-4ee8-bcb1-346ee205efba
be9afe73-ae92-4290-8697-db93baecdb88	t	Kabuga	6e36f2c6-d328-4adc-b5a0-0e08a1c2fc0e
55c61626-b1f2-4982-a945-0ce8e96314ae	t	Karambi	6e36f2c6-d328-4adc-b5a0-0e08a1c2fc0e
c9750a50-0fc2-42bc-8c78-877eeaac31e0	t	Bunyamanza	a75d72f9-4acd-4d66-9a7d-a0d2c78dcdcf
973a686f-b8e1-439b-9a27-8785280fe2b2	t	Gisheke	a75d72f9-4acd-4d66-9a7d-a0d2c78dcdcf
fa86cbd7-f4ca-45ab-992e-8cbae4f82a38	t	Gitsimbwe	a75d72f9-4acd-4d66-9a7d-a0d2c78dcdcf
45fa5fae-d1bc-4a6f-ad89-d7d7382b1944	t	Rubona	a75d72f9-4acd-4d66-9a7d-a0d2c78dcdcf
1024eac3-ac01-49bb-8d91-0ff8ade67ebc	t	Gaseke	b7940bb0-f13d-4ec8-b4f0-5e161b821b0d
b4f32c93-679e-4ae2-a564-5a3a37b9c4bd	t	Wimana	b7940bb0-f13d-4ec8-b4f0-5e161b821b0d
b0ad22bf-548c-45a9-ba95-0a6c2cad2d35	t	Wingabe	b7940bb0-f13d-4ec8-b4f0-5e161b821b0d
ab6253cd-9343-4f7c-88e9-f0e977c484bc	t	Rupango	61470d11-9d1e-4dca-973a-4c50960f908b
6876c692-7b9c-4efd-9ccc-967ac99bb0d0	t	Mataba	98024a17-44f3-4833-8185-1940e0388ebb
0ad4f7a5-4a83-4930-97ed-5f95bca33baf	t	Musumba	98024a17-44f3-4833-8185-1940e0388ebb
5108798e-32b6-4674-b390-ca077e1a16c3	t	Mwasa	98024a17-44f3-4833-8185-1940e0388ebb
de7ecfad-9033-486b-983f-128a2ba16b4d	t	Nyarunombe	98024a17-44f3-4833-8185-1940e0388ebb
6ea2b303-e3ee-405f-9743-2102d798c765	t	Rugote	98024a17-44f3-4833-8185-1940e0388ebb
83b5bbf4-d600-4ea9-b386-d53c1a564cb9	t	Rumamfu	98024a17-44f3-4833-8185-1940e0388ebb
6307f3ed-23ff-44bf-bb15-5d36982b7d57	t	Rwankuba	98024a17-44f3-4833-8185-1940e0388ebb
dac33de0-07dd-45fa-ab51-dcc8cb82df5b	t	Gatyazo	6340b9ed-b34b-4106-8017-bd69b5b168fc
cc5abdfd-4de5-456e-8dbd-c8e483a24571	t	Bizi	e31a4fd7-743f-45cc-a203-168dad4e6395
9576baf3-1881-4801-8aba-a7c3598655a6	t	Cyijima	e31a4fd7-743f-45cc-a203-168dad4e6395
ce05bf11-5372-4d18-a78c-364d583b2540	t	Nkuro	e31a4fd7-743f-45cc-a203-168dad4e6395
cfda6c17-3a28-402d-bede-7cbc307e8119	t	Nyarusange	e31a4fd7-743f-45cc-a203-168dad4e6395
e6d7d4d2-0b54-4e2b-9b66-3c59fae9c16f	t	Fumba	b4220075-5256-482b-8b6e-1f67b01a6e44
4f86ebf4-c3df-4bfb-a1da-164f294bc2b9	t	Nyabumera	b4220075-5256-482b-8b6e-1f67b01a6e44
18eb8767-50af-445a-8746-831fa26088bc	t	Gabiro	b38b1874-6b15-4b35-81f0-aaaa4816ad5e
7fa4e0ef-15b7-45d4-bc48-d72ed63d2873	t	Kigara	b38b1874-6b15-4b35-81f0-aaaa4816ad5e
b105e7dc-bd2a-4afb-b4f3-079484607fa0	t	Ruhanga	b38b1874-6b15-4b35-81f0-aaaa4816ad5e
84467c55-6e5e-41f8-a71d-bb2a9ad829b6	t	Rukaragata	b38b1874-6b15-4b35-81f0-aaaa4816ad5e
0a749ad4-0bbc-4cf4-8d70-2083d58d9cd2	t	Kizenga	e653d43b-7385-4d07-98fe-9e4e7cfd94b7
7904e521-f10d-438e-82c3-56daf1330fc9	t	Nyagahima	e653d43b-7385-4d07-98fe-9e4e7cfd94b7
30dd6f83-d110-4d00-9bf3-d0d54f826882	t	Bigali	803ad87b-3851-4afb-9861-1b29142fdafa
6e830991-cd75-4340-9789-8b87ba8003eb	t	Bisharara	803ad87b-3851-4afb-9861-1b29142fdafa
a08e02d1-a6a0-4b06-802d-b58c8a388e16	t	Cyinjira	803ad87b-3851-4afb-9861-1b29142fdafa
b2a851ff-a374-43fd-b39f-fe0217176a44	t	Gitwa	803ad87b-3851-4afb-9861-1b29142fdafa
526094f9-fa58-456e-9741-2cbc5e37f9ed	t	Nyarusiza	803ad87b-3851-4afb-9861-1b29142fdafa
2e9c84d6-e57b-4802-8c77-4721233a2bd5	t	Bunyenga	e9d27c59-17a8-4106-bd2f-ec9fc4f3558b
5b2a6e22-bb2a-4dfc-b16f-49fd78b68da5	t	Mariba	e9d27c59-17a8-4106-bd2f-ec9fc4f3558b
61188054-c6b8-438b-b7ca-a39f99dbd571	t	Ruginga	e9d27c59-17a8-4106-bd2f-ec9fc4f3558b
ca209b28-8813-465f-b72d-ae4f2e15de02	t	Gahwazi	b7372b90-ee30-4df7-bae0-6d57c9298b6d
e6eb48d2-5565-4df7-8d87-fcbba75728fe	t	Gasebeya	b7372b90-ee30-4df7-bae0-6d57c9298b6d
22adf944-612c-4932-a6ed-b87d2ba8e273	t	Kibanda	b7372b90-ee30-4df7-bae0-6d57c9298b6d
90796002-5f4b-48b1-ae1b-4be2b91e3d85	t	Mukarange	b7372b90-ee30-4df7-bae0-6d57c9298b6d
f2e7b44b-eb10-48eb-856e-bdded8a8047b	t	Gahuhezi	e30256a3-ae46-4623-a9a0-c17e2d8851fa
9628e088-00ad-421f-a6c3-957709ad1514	t	Kabacuzi	e30256a3-ae46-4623-a9a0-c17e2d8851fa
732a59b8-b1ae-4d28-94ac-a7e52376d32e	t	Buhokoro	f858803f-6f75-43c2-8c1c-997ce15d3f92
3eb4c83f-6e81-4c8f-9939-41bd9ef88133	t	Bugiga	b53c04c2-2091-4c5d-bbe4-e791a35b5e7b
2e5f3d9f-aa14-4722-9773-ceb5177efb49	t	Nyamirundi	b53c04c2-2091-4c5d-bbe4-e791a35b5e7b
cb86bf87-0407-4163-b432-85f0d37a77e7	t	Ruhonga	b53c04c2-2091-4c5d-bbe4-e791a35b5e7b
bf9fbb3a-8b06-43a0-afe7-e87f7fc660f3	t	Kaneke	d0e6e6ed-f7bd-4a5a-a9e0-5e2d0e580eb2
12e735a2-7645-4ee3-81b2-103febe91769	t	Rugomero	d0e6e6ed-f7bd-4a5a-a9e0-5e2d0e580eb2
d5fd329e-2cef-4945-a6e9-e16a592288c8	t	Murambi	b5912a28-9e3f-463c-9fd3-89781613b4cb
94210860-4048-4247-a4ed-af9b2536362b	t	Ryamashuri	63ae5c7d-3f0c-46e9-9b26-86abbc24182f
b042005d-d337-4fef-9389-d8baa80844b1	t	Kacyiru	112b0f94-debf-4622-837b-13acd0c710a6
d28babac-dba0-46b3-b5b7-1a6b572de49c	t	Kagarama	112b0f94-debf-4622-837b-13acd0c710a6
f5572198-71d8-40c7-b5f6-088a470a4f33	t	Kamabuye	112b0f94-debf-4622-837b-13acd0c710a6
25c53632-f018-4b3b-8b9a-952fac680637	t	Kamonyi	112b0f94-debf-4622-837b-13acd0c710a6
c48798dd-d988-42fd-a258-338a6c5e67a1	t	Bigutu	0e61c404-fd73-47ed-a8f6-0bb8e82774de
9d3ea93f-2909-4402-a1dd-098d83b1f3dc	t	Gihinga	0e61c404-fd73-47ed-a8f6-0bb8e82774de
1772ad10-10df-4f41-bb35-fe59c30197a4	t	Kanyovu	0e61c404-fd73-47ed-a8f6-0bb8e82774de
6509338d-9e22-48db-b4db-d7092be01f52	t	Nkomero	0e61c404-fd73-47ed-a8f6-0bb8e82774de
aff54eac-b766-406d-991d-31ca593d5d95	t	Nyamuhunga	0e61c404-fd73-47ed-a8f6-0bb8e82774de
b5bde90c-50e2-4d68-b3ea-6a824d38a112	t	Save	0e61c404-fd73-47ed-a8f6-0bb8e82774de
d521238b-20c9-4f49-a872-cc986723ddce	t	Gatanga	8f125b74-7e48-4f47-a441-d4935f800447
6992226c-9bea-4912-99c9-46dd953d5763	t	Ngoboka	8f125b74-7e48-4f47-a441-d4935f800447
7f663631-8610-489f-992f-484aba870b74	t	Rugabano	8f125b74-7e48-4f47-a441-d4935f800447
22be0849-a65c-4b15-b37d-e27769b94548	t	Ryangange	8f125b74-7e48-4f47-a441-d4935f800447
4fb91a77-2b92-4bfa-9395-8ad8876849c1	t	Rubayi	13f209f3-944a-4c60-b479-9d86510c2c22
210ab8e6-abc8-408e-8996-c11a7563a772	t	Gabiro	fd9f6cc5-f2b6-4443-84dd-b893de9e8a7f
d7111bf8-0b42-44d9-acbe-023e4330389e	t	Karuhigi	13007d5e-18a6-4560-b6b8-c9445427c261
f63a22b4-7329-483f-a9f1-988e816fd24c	t	Nyamateke	ad0b62d3-06ab-4504-b78d-5fc7b9c01aaa
8317bd06-9d64-4079-a08e-c073f4e9777b	t	Busasamana	625250ac-f81c-4910-a009-70b1014eb782
dd9c3d9c-b153-4734-8075-be808c8d31d2	t	Kabere	625250ac-f81c-4910-a009-70b1014eb782
cfdd23dc-bb3c-488a-9659-44cecf1c3e88	t	Bugeshi	f0aef44c-2614-4c18-95e8-f706587a49f9
ff47b091-4f3d-4e52-ac64-8f7b88ff1b2b	t	Buringo	f0aef44c-2614-4c18-95e8-f706587a49f9
68f5a254-c809-452e-957f-cd7edb5d16e6	t	Butaka	f0aef44c-2614-4c18-95e8-f706587a49f9
881ceac5-1611-4cb5-8b97-99b851f486bf	t	Gaharawe	f0aef44c-2614-4c18-95e8-f706587a49f9
af202ebd-d683-4986-a18a-2e9354ed834a	t	Gahira	f0aef44c-2614-4c18-95e8-f706587a49f9
e2dd26c5-834d-4c81-823f-9ce5827b8376	t	Jenda	f0aef44c-2614-4c18-95e8-f706587a49f9
c7948fe9-9e11-4560-ad30-bbdda4b7b5fa	t	Mutegengeri	f0aef44c-2614-4c18-95e8-f706587a49f9
78bdcd50-3022-4ce3-b473-94aad0e4cb28	t	Akabajara	ca12dcb3-bf11-491b-92d0-952fe15fd60d
e2185312-3e6e-428b-bdfe-ece7f425ad39	t	Akimitoni	ca12dcb3-bf11-491b-92d0-952fe15fd60d
3a68cd04-67ad-452f-973b-a02f5e57bc39	t	Gaheriheri	ca12dcb3-bf11-491b-92d0-952fe15fd60d
6900bec5-606e-413a-a4e1-436989229010	t	Kabingo	ca12dcb3-bf11-491b-92d0-952fe15fd60d
ecc578f9-2ebb-4d26-a81b-3d74f36cae08	t	Kinyamuhang	ca12dcb3-bf11-491b-92d0-952fe15fd60d
49145ca1-7725-4f07-ac63-bb7ef1b21206	t	Muremure	ca12dcb3-bf11-491b-92d0-952fe15fd60d
45c2a56d-b01c-4959-984b-bc867b06e3f0	t	Bereshi	d02a2295-4ee4-4717-b8a8-ad4191ff6311
6c376962-b147-466a-8469-d7cc8ae8870e	t	Bweramana	d02a2295-4ee4-4717-b8a8-ad4191ff6311
1beffe23-3012-457a-bbf8-81aadc5a6e4d	t	Gasizi	d02a2295-4ee4-4717-b8a8-ad4191ff6311
2905ebbb-3edf-4ad1-9f68-cc7b2f1d3276	t	Gitotoma	d02a2295-4ee4-4717-b8a8-ad4191ff6311
a1881553-fa7c-42ab-acc3-97fce564a588	t	Hangari	d02a2295-4ee4-4717-b8a8-ad4191ff6311
92968936-a8db-4f8f-9488-c2fb8a6c3478	t	Humure	d02a2295-4ee4-4717-b8a8-ad4191ff6311
97324c9a-9025-42c2-ba8c-4c306e0ce448	t	Kabeza	d02a2295-4ee4-4717-b8a8-ad4191ff6311
fe4f74a8-3afb-4d0f-8082-4f411f1ed9b1	t	Bonde	66e2291a-5583-467c-8eb1-bd96f5195d6d
6599e6c7-d070-4d85-bfe7-ceb3830cee1a	t	Bugeshi	66e2291a-5583-467c-8eb1-bd96f5195d6d
e73b4135-c8c0-4a20-91c8-0154534dc3e6	t	Gashaka	66e2291a-5583-467c-8eb1-bd96f5195d6d
8c8c0b14-3311-4d67-b5e7-b5586e75d56c	t	Gatovu	66e2291a-5583-467c-8eb1-bd96f5195d6d
f541a82e-4499-4d8f-b4ea-5d4c2efe653b	t	Gihira	66e2291a-5583-467c-8eb1-bd96f5195d6d
076fd576-42a8-4f07-9c6f-d339c7a8560e	t	Kabumba	66e2291a-5583-467c-8eb1-bd96f5195d6d
53f192a3-698c-4636-93bf-4e53dc55f98b	t	Mweya	66e2291a-5583-467c-8eb1-bd96f5195d6d
dfe2e55e-2b5c-4ae9-9f15-b16b1b00b126	t	Bigaragara	64737479-7b11-46dd-ab76-5e81de0b548a
c813f8d9-cb8c-4f3d-bbce-ea9c5bf849a2	t	Bugeshi	64737479-7b11-46dd-ab76-5e81de0b548a
642030de-726e-41ef-b1ce-c660fd7d1a79	t	Kabuhanga	64737479-7b11-46dd-ab76-5e81de0b548a
2ac0f77f-4320-4e9f-b2b8-17f790281295	t	Kimpongo	64737479-7b11-46dd-ab76-5e81de0b548a
5bb885e5-25b7-48d5-bb2c-ed80a7bb25ac	t	Mburamazi	64737479-7b11-46dd-ab76-5e81de0b548a
01b58131-eb33-45f3-b651-61c0cf77717d	t	Rindiro	64737479-7b11-46dd-ab76-5e81de0b548a
f9a03f69-7f68-400c-be44-4fdb00c06983	t	Vuna	64737479-7b11-46dd-ab76-5e81de0b548a
f0e0f64e-7a3d-4b22-88cf-8e157f61bbeb	t	Batikoti	3fe3107d-0849-4261-85b0-6efa3a6dadd2
f7798e01-aa07-4cfe-911e-f839fdf12ff6	t	Bipfura	3fe3107d-0849-4261-85b0-6efa3a6dadd2
a14a830c-82ca-4fc0-96e3-b19e2e5d1263	t	Bweza	3fe3107d-0849-4261-85b0-6efa3a6dadd2
73bf2c6f-916e-4211-a389-157552f30d5f	t	Cyumba	3fe3107d-0849-4261-85b0-6efa3a6dadd2
f1ed005c-c366-481c-86aa-38bbf8ade542	t	Gaheriheri	3fe3107d-0849-4261-85b0-6efa3a6dadd2
66ecaaed-7e5d-4c27-950c-d07258678c9c	t	Murangara	3fe3107d-0849-4261-85b0-6efa3a6dadd2
e141235b-9814-4761-b516-ae3c49f79575	t	Bihe	47a3d96c-412e-4bee-82f3-62666379dfa6
27238f70-fa92-4808-9d66-c79c0709e755	t	Bunjuri	47a3d96c-412e-4bee-82f3-62666379dfa6
96b27a74-f53a-4179-ba5d-065d26e5e05f	t	Ryarugamba	47a3d96c-412e-4bee-82f3-62666379dfa6
07807301-7b68-414d-bae7-47b14453e746	t	Biziguro	046b13ef-539f-4f5d-9bc2-13386043a6f8
5715e251-366c-41de-8acb-e6c816ca7d38	t	Busanganya	046b13ef-539f-4f5d-9bc2-13386043a6f8
f69e91bb-b4bb-4433-b88d-cdf92e2c62cf	t	Gakomero	046b13ef-539f-4f5d-9bc2-13386043a6f8
f3c72d00-a8b9-4936-b267-ef887cdfb775	t	Kamuyenzi	046b13ef-539f-4f5d-9bc2-13386043a6f8
7e5e254a-ced0-4b34-bb41-1c890cd6d1d9	t	Kanondo	046b13ef-539f-4f5d-9bc2-13386043a6f8
a0162396-a329-462d-8d16-d5f2b3eb3236	t	Kanyabijumba	046b13ef-539f-4f5d-9bc2-13386043a6f8
b1fa9f0b-2d05-43a2-ae2b-4a9243d53914	t	Nyarubuye	046b13ef-539f-4f5d-9bc2-13386043a6f8
8c11fd17-e081-471e-9441-8b71aa32eb39	t	Gisura	f50f84b7-bd30-426f-a701-2b7af50e5639
35c499bd-8580-4d83-abeb-dc3ad52c37b0	t	Kinyababa	f50f84b7-bd30-426f-a701-2b7af50e5639
b56d8adb-9c1f-486c-9aef-4ca6e0ddb201	t	Mashinga	f50f84b7-bd30-426f-a701-2b7af50e5639
6b9f39dd-521c-4775-9e9e-c22c2e5c3229	t	Munanira	f50f84b7-bd30-426f-a701-2b7af50e5639
65149190-7577-43c6-a409-64114d312852	t	Nyarunembwe	f50f84b7-bd30-426f-a701-2b7af50e5639
4d7dc1a2-52a2-4381-b1dc-efb698cbf20b	t	Marumba	f8620234-37f7-4d21-8a36-fb2d092ad3df
2a6d0925-4cb0-4c5c-994d-f2bae5e7231e	t	Mubona	f8620234-37f7-4d21-8a36-fb2d092ad3df
4e3641d6-6730-4bab-9522-1e55e1b99c16	t	Nyamyumba	f8620234-37f7-4d21-8a36-fb2d092ad3df
617de7ef-f795-4b44-b8de-5930d04d7695	t	Sabushengo	f8620234-37f7-4d21-8a36-fb2d092ad3df
f88edb3e-2413-4571-86d0-1cbeb9ed7440	t	Gasenyi	e1a360c0-b3db-4eb7-971c-03e22303e4f5
25fea668-276c-4653-aa10-137540d63214	t	Kigezi	e1a360c0-b3db-4eb7-971c-03e22303e4f5
ca19da67-b8f1-4ec5-ad06-0d657b9a66eb	t	Ruhara	e1a360c0-b3db-4eb7-971c-03e22303e4f5
e91d599d-d8c2-4044-a78a-818c37c1a01a	t	Rwamigega	e1a360c0-b3db-4eb7-971c-03e22303e4f5
4ce00b43-cd5c-4c6f-b18a-7fe0d95d407b	t	Gakuta	0b8be820-541c-4130-8f72-c4fa35a74636
7c831bb0-1f1a-48af-94b7-c58928a0754d	t	Kamuzamuzi	0b8be820-541c-4130-8f72-c4fa35a74636
11789099-ebd3-4907-bdc2-4948fd7cb525	t	Karambi	0b8be820-541c-4130-8f72-c4fa35a74636
b9e81443-6be3-4e43-8bf9-fb8a4d72b6e0	t	Kidadi	0b8be820-541c-4130-8f72-c4fa35a74636
0e8d8e60-db78-4bfe-b9c1-b04518c4c7b3	t	Cyanika	9549337f-64b3-457a-9c49-5f08194bbf96
ea2899a2-17da-41a6-9f99-b4ebb6f86ebf	t	Kitagabwa	9549337f-64b3-457a-9c49-5f08194bbf96
fc21d971-f7c0-4ed4-bd9d-71bd6eeee5d7	t	Cyamabuye	3944c94e-b7a8-4b47-9d09-ed915a6778c7
738c45ec-90bb-48b8-9ea8-5ac7ba31bcc0	t	Kabagoyi	3944c94e-b7a8-4b47-9d09-ed915a6778c7
b9b254bd-1db6-480d-aaae-db0689887556	t	Kageyo	3944c94e-b7a8-4b47-9d09-ed915a6778c7
69eb5c5d-1e4f-4ad0-933d-1ab39de5e5ef	t	Kambonyi	3944c94e-b7a8-4b47-9d09-ed915a6778c7
06c80940-0ab4-4b19-987e-fd02d20fd61f	t	Kamivumba	3944c94e-b7a8-4b47-9d09-ed915a6778c7
d2a5c412-56c3-4d22-b268-70fad07bac3f	t	Kinogo	3944c94e-b7a8-4b47-9d09-ed915a6778c7
b2ffc0fb-7e22-46e0-8ddf-a8f6a839ee1c	t	Munege	3944c94e-b7a8-4b47-9d09-ed915a6778c7
ed1ab02e-9661-4dd7-9306-6b68e6f421a4	t	Rebero	3944c94e-b7a8-4b47-9d09-ed915a6778c7
c4e7aeef-8c19-4816-85cf-75c6d2d01205	t	Bugu	b2516476-691c-4258-afa5-234c7aebd602
b8c2109d-bb1c-485e-babe-ca3ca7280f93	t	Butango	95d542e9-96ef-49e7-b876-50e670a42bf8
46b16d30-aad7-40d1-97d0-54f2f8c82a94	t	Cyanzarwe	95d542e9-96ef-49e7-b876-50e670a42bf8
a4bfd228-4f4f-4dd1-b4ed-e4954fa4dddc	t	Gasenyi	95d542e9-96ef-49e7-b876-50e670a42bf8
bb2e99f8-81cc-4c10-836c-48a528bbb8b5	t	Karangara	95d542e9-96ef-49e7-b876-50e670a42bf8
e15d05c9-a08f-40bc-97b4-dd660c853d00	t	Gora	0afb2c0e-0f47-4e89-bc00-2471d15c7a7b
7c4d64c9-1125-4834-bc5c-120bdd96e055	t	Kabere	0afb2c0e-0f47-4e89-bc00-2471d15c7a7b
365703b5-6cd0-404f-9abf-e16eb6b76156	t	Kanyentambi	a010d84d-2c98-424f-af42-2cfa3f69e788
34653303-48d7-4b91-a7d2-45e6f816dac1	t	Muhororo	a010d84d-2c98-424f-af42-2cfa3f69e788
220e82a5-8168-4732-b084-ab0e52096caf	t	Gashuha	8a497a5b-f961-4cf9-acf8-3266a7de403d
ac667391-29a7-4dfc-a481-169db2fd9270	t	Makurizo	8a497a5b-f961-4cf9-acf8-3266a7de403d
7d6c7974-0c0f-4213-8859-61c67482a751	t	Mukingo	8a497a5b-f961-4cf9-acf8-3266a7de403d
9f42d107-4d68-4603-9199-436bd17eba1f	t	Nyamugari	8a497a5b-f961-4cf9-acf8-3266a7de403d
48fe989d-3ca1-40dd-a245-e491e1b5a834	t	Ruhuranda	8a497a5b-f961-4cf9-acf8-3266a7de403d
1f87eaec-2279-4b74-ae97-41a701b5533e	t	Buramazi	51c8f2a9-982d-4702-a640-9b351b2e68b1
dee71677-50c3-417d-8d67-d8c1aeec1d79	t	Hanika	51c8f2a9-982d-4702-a640-9b351b2e68b1
c49923ce-e3ff-4279-bb91-765d126fd935	t	Muti	51c8f2a9-982d-4702-a640-9b351b2e68b1
079a6ac5-7f83-4e6e-b280-068c1c2365e0	t	Nyakabanda	51c8f2a9-982d-4702-a640-9b351b2e68b1
f14a0e07-0a0f-4a41-9c6c-fd6242c95cb5	t	Nyakabungo	51c8f2a9-982d-4702-a640-9b351b2e68b1
e0d3e4ce-5acf-4f46-9389-ac9cfe49a445	t	Kabirizi	cb44bf3a-17c5-4e11-a75d-c47eaf70a7f6
78c1d4f2-4fab-4f21-a60a-c4509cd31dcc	t	Karambi	cb44bf3a-17c5-4e11-a75d-c47eaf70a7f6
d3f8afff-1187-4bda-88a3-1409b536c1d1	t	Kinyamiyaga	cb44bf3a-17c5-4e11-a75d-c47eaf70a7f6
cf7651ba-dd4c-4294-8f49-ecb9c59daa08	t	Munaba	cb44bf3a-17c5-4e11-a75d-c47eaf70a7f6
366a36b5-6fe4-459f-81a1-302f2cf86f83	t	Rukorakore	cb44bf3a-17c5-4e11-a75d-c47eaf70a7f6
d647397a-5aa1-41b4-9b42-05407e9539a3	t	Burere	acf32b9b-c703-473b-ae0f-98b7b65e7e6d
0d6774c1-5c41-4399-81ba-a1d932f8754e	t	Kanyamagare	acf32b9b-c703-473b-ae0f-98b7b65e7e6d
7017de1c-8c39-4949-b8c4-b46594e93458	t	Musene	acf32b9b-c703-473b-ae0f-98b7b65e7e6d
0c63d1a0-d90e-432f-88a9-5e29f0850d13	t	Nganzo	acf32b9b-c703-473b-ae0f-98b7b65e7e6d
e02241bd-d18a-48b7-ad9b-dd5563afada8	t	Amahoro	07c29d23-6d19-41d1-bb9b-67c0ee5ebe69
c0ec2e25-19fc-4a19-a7fa-9bfdfb24425d	t	Kitagabwa	07c29d23-6d19-41d1-bb9b-67c0ee5ebe69
f7edbcbd-d16d-447f-a8ba-9d196879621b	t	Muhabura	07c29d23-6d19-41d1-bb9b-67c0ee5ebe69
c47127bd-877a-41da-899e-9308eb50dfdd	t	Murakazaneza	07c29d23-6d19-41d1-bb9b-67c0ee5ebe69
c45f01d4-1892-4f4a-9da7-43a0ca5afdb6	t	Umunezero	07c29d23-6d19-41d1-bb9b-67c0ee5ebe69
0d5275c6-9469-4be0-ba3a-085505abe43d	t	Amataba	bc7a7cdf-2430-458d-9287-d34a6424bd3b
a97153ce-77fe-4a89-adee-20a3c5817b95	t	Giraneza	bc7a7cdf-2430-458d-9287-d34a6424bd3b
dfa0eb6b-4e66-4cbf-b6c3-ad50c27b2900	t	Irakiza	bc7a7cdf-2430-458d-9287-d34a6424bd3b
df613612-4f36-4aed-8247-18ba0cc92a6d	t	Isangano	bc7a7cdf-2430-458d-9287-d34a6424bd3b
cae36a4e-4aef-4ef8-97c7-d492bcdf4f7a	t	Kaminuza	bc7a7cdf-2430-458d-9287-d34a6424bd3b
c467e57f-3418-49d4-a3c5-463638865016	t	Nyakabungo	bc7a7cdf-2430-458d-9287-d34a6424bd3b
a6f4eda2-eaf6-412e-aa2e-c05d19ace9da	t	Ubutabera	bc7a7cdf-2430-458d-9287-d34a6424bd3b
20d943dd-db5a-4b21-8612-399b0aefab76	t	Ubwiza	bc7a7cdf-2430-458d-9287-d34a6424bd3b
bb441a51-bdcc-481c-ba1d-6a0914e3d4f8	t	Giponda	17abf15e-f3c3-42cc-865e-f7ad96eff72b
09fb9fc5-1a79-40b2-8a51-87a3f2bd1d0f	t	Itangazamaku	17abf15e-f3c3-42cc-865e-f7ad96eff72b
4c470eba-f34b-4599-95b1-ec9ba72dd1ac	t	Karisimbi	17abf15e-f3c3-42cc-865e-f7ad96eff72b
40769f25-36a1-4653-87c9-3a663bc34404	t	Murisanga	17abf15e-f3c3-42cc-865e-f7ad96eff72b
bb80da28-d22a-4246-8fb5-f84f5782da0e	t	Ubukerarugen	17abf15e-f3c3-42cc-865e-f7ad96eff72b
edb8306c-595e-43a2-b1ab-4b7f2d96825b	t	Ubutabazi	17abf15e-f3c3-42cc-865e-f7ad96eff72b
90f4e663-1030-402e-8261-a30aa119568b	t	Umurava	17abf15e-f3c3-42cc-865e-f7ad96eff72b
8622d0a2-1049-4622-a5c2-1d299a5d229a	t	Urumuri	17abf15e-f3c3-42cc-865e-f7ad96eff72b
a6579d49-8d83-4bd0-b559-3cf5e62100b1	t	Amajyambere	05e3c14f-16ff-41b4-99ec-4dc454cb5078
a095c957-5f75-4638-b4b3-33fa8e089677	t	Gasutamo	05e3c14f-16ff-41b4-99ec-4dc454cb5078
5296fbc1-50be-4cbb-949d-5a18b3a21411	t	Icyinyambo	05e3c14f-16ff-41b4-99ec-4dc454cb5078
9ef8a3d2-c335-44b0-bcf6-1946c73ee6e3	t	Ikaze	05e3c14f-16ff-41b4-99ec-4dc454cb5078
ed04d219-1b52-407b-8ddc-4b852a4b72a4	t	Ikibuga	05e3c14f-16ff-41b4-99ec-4dc454cb5078
baa8cecd-a93c-4cb7-98ec-dc9b3a3b50c1	t	Inkurunziza	05e3c14f-16ff-41b4-99ec-4dc454cb5078
dddf197b-95a9-4368-81b6-ba60c8533a14	t	Rebero	05e3c14f-16ff-41b4-99ec-4dc454cb5078
cf1b0ff2-f33b-45ac-a414-323c5e4fdfd3	t	Uburezi	05e3c14f-16ff-41b4-99ec-4dc454cb5078
64f376cf-c2f2-4666-b24b-4f402532d0a3	t	Ubwiyunge	05e3c14f-16ff-41b4-99ec-4dc454cb5078
caf8885e-ec18-4243-a67f-a6839e362302	t	Umutekano	05e3c14f-16ff-41b4-99ec-4dc454cb5078
9cbbbb77-d86f-4820-9fee-517b643f33c6	t	Gacuba	19ac3dda-5423-48e2-b80b-0625761514b5
6255c516-e51c-42dc-8442-f5cb70daf5a4	t	Gikarani	19ac3dda-5423-48e2-b80b-0625761514b5
d350efc9-3547-4e7d-954b-946b5fe254a7	t	Kivu	19ac3dda-5423-48e2-b80b-0625761514b5
d5a0c5ae-7230-4398-b1f6-b364e76b84a7	t	Nyabagobe	19ac3dda-5423-48e2-b80b-0625761514b5
5cf4b5ec-ce23-4c03-8e2f-42fc652f26db	t	Nyaburanga	19ac3dda-5423-48e2-b80b-0625761514b5
ffecddf4-5451-4154-a7ec-3879153bdc8b	t	Ubucuruzi	19ac3dda-5423-48e2-b80b-0625761514b5
361a3b2e-1d58-464a-bc35-0b35ca42bae5	t	Urubyiruko	19ac3dda-5423-48e2-b80b-0625761514b5
6f854037-5f4a-49dc-bc51-95d620c4d3ed	t	Gahojo	1f168d3e-f4c2-4347-91b5-f4f48bb8d97d
f005a420-715e-4680-99a5-b441edc4978e	t	Kamayugi	1f168d3e-f4c2-4347-91b5-f4f48bb8d97d
60327599-7fb0-4bd8-b834-aa529e003423	t	Rubavu	1f168d3e-f4c2-4347-91b5-f4f48bb8d97d
b1c38f93-6422-494e-9dc9-0fb3f56b7599	t	Bonde	d984bf69-35ae-4c94-84ef-a8258b691b0e
5120fecb-1e73-45a9-9743-809121bbf731	t	Dukore	d984bf69-35ae-4c94-84ef-a8258b691b0e
cbf27a7e-0bdd-459c-b8df-663d0ab07c7b	t	Kabuga	d984bf69-35ae-4c94-84ef-a8258b691b0e
9b5bd7c8-8036-4b36-a688-45d1581d5720	t	Majengo	d984bf69-35ae-4c94-84ef-a8258b691b0e
d544c1db-f325-4e24-9995-224833fd78e6	t	Muhato	d984bf69-35ae-4c94-84ef-a8258b691b0e
a5099bfd-53ff-453d-9808-b7ee6856c13f	t	Umucyo	d984bf69-35ae-4c94-84ef-a8258b691b0e
44100f72-4b6f-4a46-8fcc-97a4c81f8cdc	t	Umuganda	d984bf69-35ae-4c94-84ef-a8258b691b0e
3f4dee17-ac1d-4917-892e-a06bc0479549	t	Umunyinya	d984bf69-35ae-4c94-84ef-a8258b691b0e
2f1e247a-722f-4bd7-bad4-9f40e2f94e13	t	Bambiro	cba7b5ad-b1f0-486d-921f-0760ae980df2
7414d6a3-bb4d-4971-8715-fe813fff7a7c	t	Kagarama	cba7b5ad-b1f0-486d-921f-0760ae980df2
0d0e7efe-d6f1-436d-bf50-fadb0d1f5e8f	t	Nyanshundura	cba7b5ad-b1f0-486d-921f-0760ae980df2
d50b519a-8eef-469c-b073-520ea27062e3	t	Rukoro	cba7b5ad-b1f0-486d-921f-0760ae980df2
6af4f8b5-18bb-47a5-a1fd-1bc76cb9bef1	t	Rwankomo	cba7b5ad-b1f0-486d-921f-0760ae980df2
f930fe81-9b22-47f2-8ea4-1b954352fb43	t	Ndongoshori	d3f31190-fd7e-4919-adfb-269adf9bc8b2
91dca6a4-dc61-4efc-a180-978fab29b380	t	Bikuka	fd14a4ea-49c3-493b-90ad-493384e229da
a5277366-42b1-40f4-aa52-0f72b060963e	t	Kabeza	fd14a4ea-49c3-493b-90ad-493384e229da
d65c2c0c-2b78-4cb7-bd45-4edac1bda606	t	Kabindi	fd14a4ea-49c3-493b-90ad-493384e229da
e0a51b65-fd60-44b1-ba7e-2191ee88a928	t	Kanama	fd14a4ea-49c3-493b-90ad-493384e229da
75671515-aad4-48d5-b36c-dc88bcb978f4	t	Kara	fd14a4ea-49c3-493b-90ad-493384e229da
f86c4e39-4075-4503-9941-e6651294944c	t	Mahoko	fd14a4ea-49c3-493b-90ad-493384e229da
6acbcc00-6384-4a0a-a0ed-f9f37d01eb6c	t	Nyagasozi	fd14a4ea-49c3-493b-90ad-493384e229da
85644d1c-6655-4f73-b691-07dbf4e1b95f	t	Nyamirambo	fd14a4ea-49c3-493b-90ad-493384e229da
c875a99f-0961-4ae7-8b4f-16e66cc00344	t	Nyamugari	fd14a4ea-49c3-493b-90ad-493384e229da
715c701b-d1ae-4a30-a8c1-92579aecdbef	t	Nyamuremure	fd14a4ea-49c3-493b-90ad-493384e229da
eb8f0aae-3599-4b2d-bee5-d04ffcfe51f9	t	Rubare	fd14a4ea-49c3-493b-90ad-493384e229da
090a6537-0842-4482-a715-def74c1ceb0a	t	Shusho	fd14a4ea-49c3-493b-90ad-493384e229da
8fd53dbb-4317-442c-9eed-2e7154e8546e	t	Kabingo	ec5be326-4da6-4d21-8199-df85b363de0a
50d98022-574c-44b4-8a59-af4168a9a199	t	Kagano	ec5be326-4da6-4d21-8199-df85b363de0a
b97bb5be-ca16-4c42-8b57-06251519bf3f	t	Nteranya	ec5be326-4da6-4d21-8199-df85b363de0a
d1eed283-9cb5-4479-a711-feb6a661518a	t	Nyakibande	ec5be326-4da6-4d21-8199-df85b363de0a
325a9189-d946-40cc-bd73-33332690c7a7	t	Gatsina	ce2c7d7f-e68e-4bd6-9e01-a08444791616
ba63b37c-e00b-4fa9-a02f-1aca73d08c95	t	Nyabishongo	ce2c7d7f-e68e-4bd6-9e01-a08444791616
8e89a55d-4a86-4b27-9d1c-ade8fb70cdbc	t	Rwanzuki	ce2c7d7f-e68e-4bd6-9e01-a08444791616
860f075c-73dc-4fbf-8ebd-7d85203e7274	t	Gihurizo	85218469-472d-475f-b589-128ef51f72a9
91fd542a-aeeb-434f-be4f-28535ce6c3a5	t	Kabere	85218469-472d-475f-b589-128ef51f72a9
f9e32cdc-6459-4520-b1cd-48b5ba78af72	t	Muvebwa	85218469-472d-475f-b589-128ef51f72a9
e54c8dd1-6de8-406e-af38-8b99165020b8	t	Gikomero	07777457-d44b-4128-9363-416b113e6a09
2e539a46-03be-4869-9631-9da848bd442e	t	Rugege	07777457-d44b-4128-9363-416b113e6a09
776f5be3-2393-4a4a-a265-c3e25e360311	t	Yungwe	07777457-d44b-4128-9363-416b113e6a09
bcc1d49e-a061-4150-a1c4-df8051df4bbe	t	Kabana	2e71e202-6e2b-4435-8fd1-fd0b2aa3e610
65677277-8c1f-48e6-b912-612455c752f7	t	Kirerema	19ea61a2-bea8-4799-94da-5551736b9a0e
46f1ea35-0c13-4e03-95fc-bbb056065d0d	t	Rushasho	19ea61a2-bea8-4799-94da-5551736b9a0e
d77f4ca4-e6cf-47c9-a79b-17edaccd6f8f	t	Cyivugiza	9076588e-549c-4e10-8196-cb88fdad79dc
0a88e219-24f8-419c-a87a-de3bb3d6bb06	t	Kabari	9076588e-549c-4e10-8196-cb88fdad79dc
a947b8fc-1bac-45e0-b08f-552e7cf122c7	t	Nyamikongi	9076588e-549c-4e10-8196-cb88fdad79dc
1e61a11e-c4fb-4e63-adef-da0c5e6702c5	t	Rwamikungu	9076588e-549c-4e10-8196-cb88fdad79dc
4e42c1b4-0178-4028-8a78-aa24d20438cf	t	Mizingo	eb5a6b5e-abc4-41f7-af22-531c3b2c85a0
5180bde1-351c-493c-a870-f5ff17420144	t	Kabere	3d322349-a72e-4e63-b2db-56ccaf5a038f
ff614d34-370f-412c-a871-16b3cc818467	t	Bivumu	f6c669d5-b65c-4fdf-abf7-d42bf3ef7a58
d213fd13-bdaf-4337-a648-767f185cb44b	t	Bunyove	f6c669d5-b65c-4fdf-abf7-d42bf3ef7a58
7bb67e73-37e8-484b-bffb-c27bc26c77dc	t	Mwirima	f6c669d5-b65c-4fdf-abf7-d42bf3ef7a58
a3a82f74-02ef-4cf5-b3eb-da6b06c5aa1e	t	Rukeri	f6c669d5-b65c-4fdf-abf7-d42bf3ef7a58
05bd5c05-0359-4c1d-b9c0-069d6d94a911	t	Gahanika	6f82bb92-0ce5-499f-8849-bf9e8e92863b
0b5190c0-c957-4231-bacf-fb67da17c9a9	t	Mugongo	6f82bb92-0ce5-499f-8849-bf9e8e92863b
992a821d-d7b2-46c3-a2f3-0061c626d95a	t	Murambi	6f82bb92-0ce5-499f-8849-bf9e8e92863b
b6594d77-eada-4cc4-8514-8be85d116938	t	Nyamirama	6f82bb92-0ce5-499f-8849-bf9e8e92863b
66180c78-902d-45cb-8a16-8fccccb8fb54	t	Gasiza	29a1a435-545d-4811-889d-63ae6ddd53ad
b77f13ea-a011-4ca1-b7a0-fee0965a8aca	t	Kanyamitura	29a1a435-545d-4811-889d-63ae6ddd53ad
9f431888-4822-40b7-b2b6-791f09841d28	t	Tetero	29a1a435-545d-4811-889d-63ae6ddd53ad
fc7f4355-3669-401a-a0c1-6b9807b815eb	t	Gasumba	cd9f5085-2fd5-4e0f-988c-3d1c0e715de5
5a3f2eef-a995-4afa-ba07-a0dfc96229b4	t	Mirindi	cd9f5085-2fd5-4e0f-988c-3d1c0e715de5
dc361c11-dade-4b12-9622-3d80cb763f55	t	Tamira	cd9f5085-2fd5-4e0f-988c-3d1c0e715de5
7d986be1-a04a-4bc9-98d4-d2ed807feee7	t	Gikuyu	c41d6fcd-ab21-4cd9-bfda-b339e353154a
ac1163fd-178d-4bef-ba22-1f98a1e8066b	t	Nyabishongo	c41d6fcd-ab21-4cd9-bfda-b339e353154a
b85d5de4-ba3e-4d98-8e1b-0bb6c7c23b74	t	Bihe	083ecedb-6826-4e3e-ae71-c15a91f37d8b
38d22125-515d-4bb8-9aad-1267c38825ff	t	Gahenerezo	083ecedb-6826-4e3e-ae71-c15a91f37d8b
8fb2935f-d7fd-4f86-8aa5-fbae6c467003	t	Rungu	083ecedb-6826-4e3e-ae71-c15a91f37d8b
a3663029-b2df-466d-aa2f-1c02b8d8c72d	t	Kabunoni	fb43a00e-e68c-4407-842d-d65f32a2feed
26552559-4abf-45a7-a6cc-33bc1b3c7d23	t	Muyange	fb43a00e-e68c-4407-842d-d65f32a2feed
edbe9f37-14a7-45cb-b8fd-957421e0ead1	t	Nangurubibi	fb43a00e-e68c-4407-842d-d65f32a2feed
34502f77-8876-49dd-9657-b71e0a25003c	t	Nyamugari	fb43a00e-e68c-4407-842d-d65f32a2feed
de0f91ef-0c3e-4dfe-b8ca-9971d383a8bd	t	Bweza	d2478036-0056-48c6-9475-c777552a12bc
1a0bad64-0a1e-4ff6-873c-8ac92004f67c	t	Gisangani	d2478036-0056-48c6-9475-c777552a12bc
e3274585-b9c1-41ac-af03-8a258b8cee60	t	Kamakinga	d2478036-0056-48c6-9475-c777552a12bc
42219ffe-b2f5-4275-8280-bdef1779993f	t	Mwumba	d2478036-0056-48c6-9475-c777552a12bc
9c79ff3e-6a28-4742-8d21-38516a4f48a2	t	Kitarimwa	994c0e51-8f0b-41a3-acd1-e5f10a275cec
77282a34-b4f4-4ad0-bae0-5ded778b021f	t	Nyabibuye	994c0e51-8f0b-41a3-acd1-e5f10a275cec
c0b8ff0d-d690-465f-988a-4a4d44b95ec1	t	Nyakibande	994c0e51-8f0b-41a3-acd1-e5f10a275cec
8634a4fc-d8a9-4e71-ac32-20a8c23e0863	t	Rugerero	994c0e51-8f0b-41a3-acd1-e5f10a275cec
938738f7-acaf-4e70-988b-018b4dc7aa38	t	Rushubi	994c0e51-8f0b-41a3-acd1-e5f10a275cec
df7516d8-70ec-4aff-b531-68601e0aacd4	t	Kiyovu	d3e40b7e-af43-427c-9aa8-475fca49efa8
9de31325-005b-40de-a0f0-38db9e0eb2ec	t	Muhira	d3e40b7e-af43-427c-9aa8-475fca49efa8
efba856c-1070-4512-9ebe-27205e43e040	t	Nyakabungo	d3e40b7e-af43-427c-9aa8-475fca49efa8
e1917ec0-92fa-457f-809f-5de71e415d2f	t	Rebero	d3e40b7e-af43-427c-9aa8-475fca49efa8
afe0586c-f3a1-4c91-9987-add4dfb2b67e	t	Rukoro	d3e40b7e-af43-427c-9aa8-475fca49efa8
4d352ff3-3103-4e4e-9e19-0992b0817eee	t	Bazirete	28b1dbd8-d6f6-426f-8655-213b8e418026
aae2de9d-601f-4cb7-91d2-816f2e034666	t	Kivumu	28b1dbd8-d6f6-426f-8655-213b8e418026
e17a5480-2142-4530-ae0b-19921f20feda	t	Makoro	28b1dbd8-d6f6-426f-8655-213b8e418026
f82299f6-be6c-461f-bab3-34b6389b0df4	t	Nyonirima	28b1dbd8-d6f6-426f-8655-213b8e418026
e2e7db68-3bc8-41cf-b575-8d8b3bdb83b7	t	Ruhangiro	28b1dbd8-d6f6-426f-8655-213b8e418026
dfed2009-7afe-49c6-b203-79c5a75fce25	t	Kaberamo	53c6c763-ec05-4b8c-9786-f86f06394fea
29ad5e9d-3451-4593-a79a-09abfc631cee	t	Kabuyekera	53c6c763-ec05-4b8c-9786-f86f06394fea
856ff52a-ff6b-4827-99a3-c190ced935b5	t	Karuvugiro	53c6c763-ec05-4b8c-9786-f86f06394fea
61446f11-1d0d-47b6-bb9f-ea705b168c21	t	Muhingo	53c6c763-ec05-4b8c-9786-f86f06394fea
bbfa10df-6831-47b5-8d40-aa94f21e94ed	t	Mutembe	53c6c763-ec05-4b8c-9786-f86f06394fea
0ccae0fa-3d26-4aba-81f5-9fc7402c02b0	t	Nganzo	53c6c763-ec05-4b8c-9786-f86f06394fea
24172fe1-5ad6-46c5-ab4b-66d0663630d4	t	Wintwari	53c6c763-ec05-4b8c-9786-f86f06394fea
2a237876-8cac-4a80-8a05-3ffdd0bc2ce2	t	Bujenje	03c8ba3d-4fff-4f95-9d3e-2bd0b03806f4
dfb5eada-6fa4-48fd-ba43-3ae3138edebc	t	Bushagi	03c8ba3d-4fff-4f95-9d3e-2bd0b03806f4
dc835a38-8456-4035-8712-ba2fe6514956	t	Kabushongo	03c8ba3d-4fff-4f95-9d3e-2bd0b03806f4
aad2e679-9725-4e2a-b9b2-b177bc82b1dd	t	Kanajana	03c8ba3d-4fff-4f95-9d3e-2bd0b03806f4
fe11006b-86a6-4ce8-9817-01ae9fdd19f7	t	Kiguri	03c8ba3d-4fff-4f95-9d3e-2bd0b03806f4
3a8a824a-0897-4266-8c60-dfa0ce7b6faf	t	Burevu	e0f1fe25-c33f-4083-9166-9f5930e5cd92
206c5044-60bc-4256-8f12-c0955b09ffc4	t	Byima	e0f1fe25-c33f-4083-9166-9f5930e5cd92
432a0995-4a94-425d-bf8e-e17caf282be3	t	Karambi	e0f1fe25-c33f-4083-9166-9f5930e5cd92
0a4c8f82-fafc-4860-9034-9d4a760fd862	t	Nyabisusa	e0f1fe25-c33f-4083-9166-9f5930e5cd92
4d68392b-70ac-4eac-b08c-22433c2d60a8	t	Nyamiko	e0f1fe25-c33f-4083-9166-9f5930e5cd92
1c784484-44cc-44d4-a91f-e964c7ce2c29	t	Pfunda	e0f1fe25-c33f-4083-9166-9f5930e5cd92
83624d27-53c5-4a24-bdf9-c6aa63575ae5	t	Buhogo	99ad7e71-4b25-4d4c-a4f2-d8d8003cfd5c
f20ac8fa-107b-4f58-8842-9da0a7ccdec8	t	Kigufi	99ad7e71-4b25-4d4c-a4f2-d8d8003cfd5c
a2da2208-51cb-4d57-9a98-0bafa4ed6fa9	t	Mukondo	99ad7e71-4b25-4d4c-a4f2-d8d8003cfd5c
01231a54-b939-4a58-8d3f-8aade92c952e	t	Rambo	99ad7e71-4b25-4d4c-a4f2-d8d8003cfd5c
20adec89-15b2-4c3f-a512-a5461daa3fd0	t	Kabakora	dce72dfd-b523-4494-8294-e632eeabb39e
9069e8cb-b9d3-4207-a71f-e69b9f731f39	t	Nyamirambo	dce72dfd-b523-4494-8294-e632eeabb39e
77dfda5d-7124-4cf7-b20a-ac2e9af3c4ff	t	Rebero	dce72dfd-b523-4494-8294-e632eeabb39e
668879f6-7128-4c0d-a2ef-ec40c7cece05	t	Shusho	dce72dfd-b523-4494-8294-e632eeabb39e
38327577-4a26-47ac-9e5c-49a06eee0c0a	t	Bugasha	8bdd1e92-bccb-4b4d-ad77-10a2544263f6
33def986-8827-4bcd-bcbe-d9b6deaf2c8a	t	Buharara	8bdd1e92-bccb-4b4d-ad77-10a2544263f6
996afde4-329b-48a4-972b-eafddaeddf7d	t	Bunyago	8bdd1e92-bccb-4b4d-ad77-10a2544263f6
d1ba6c86-33b2-4548-8c17-5322d7e07d9e	t	Burima	8bdd1e92-bccb-4b4d-ad77-10a2544263f6
787db662-8766-4f38-b110-a8da98dd5f3c	t	Butotori	8bdd1e92-bccb-4b4d-ad77-10a2544263f6
f9126183-0970-4866-93e9-be1349d670c7	t	Kabiza	8bdd1e92-bccb-4b4d-ad77-10a2544263f6
ffef69e1-d469-4108-a49b-ff787b02602e	t	Kabuyekera	8bdd1e92-bccb-4b4d-ad77-10a2544263f6
f0446b41-5c74-4cd1-b195-f2568782ba9a	t	Remera	8bdd1e92-bccb-4b4d-ad77-10a2544263f6
65605f7f-12ea-4e22-8f55-27e755e9b5a3	t	Rushagara	8bdd1e92-bccb-4b4d-ad77-10a2544263f6
84b70517-2b99-4d59-9f03-a221b0bbf249	t	Buhozi	e775cb07-a792-4652-a06e-439a31806b14
ae8dc64c-6f1c-4437-961c-8a038433cdd5	t	Gatuntu	e775cb07-a792-4652-a06e-439a31806b14
b130bd69-8122-49fc-a61a-cda35201a2c9	t	Kagera	e775cb07-a792-4652-a06e-439a31806b14
8e16b9bd-c247-432f-a37d-f674fc223dd0	t	Ngege	e775cb07-a792-4652-a06e-439a31806b14
0a40c3f7-d4bb-4d64-86b8-0b7c0d0fcc43	t	Rurembo	e775cb07-a792-4652-a06e-439a31806b14
17893619-119e-4e96-a696-d5e7581f8891	t	Budaha	50689146-b7a0-49ef-920b-caaacf5ce1f1
04cff15d-c5c8-4f66-bb27-c9d8c573d873	t	Busheru	50689146-b7a0-49ef-920b-caaacf5ce1f1
99574477-0e87-4a29-98d8-93a5703ff8f1	t	Cyima	50689146-b7a0-49ef-920b-caaacf5ce1f1
92d8016f-b47f-4ec2-a4f0-8ad461eb641b	t	Kanyahene	50689146-b7a0-49ef-920b-caaacf5ce1f1
cf2010e8-3fa4-4c86-931b-e26fbcaf27f5	t	Burambo	2f67b846-8cdb-4077-8f4b-8060117a7555
f4cfb909-3c6c-44fa-b3a5-f383e3293f26	t	Gitwa	2f67b846-8cdb-4077-8f4b-8060117a7555
9c5d3e83-bd48-41f8-8cce-ef39185017e4	t	Kinihira	2f67b846-8cdb-4077-8f4b-8060117a7555
f8cd7351-cea3-4d80-852c-a0029974ba37	t	Kinyendaro	2f67b846-8cdb-4077-8f4b-8060117a7555
b6bd0d3d-20a3-4171-b286-8ad0b84a19f2	t	Shonyi	2f67b846-8cdb-4077-8f4b-8060117a7555
2eb7de6c-ae31-4dc3-93a3-0c29969850a3	t	Busesa	7372b477-f7ef-45f9-93c7-7ffd03acbf5e
a760f721-e9d6-418d-98d1-6d2ca8711cb8	t	Kazabe	7372b477-f7ef-45f9-93c7-7ffd03acbf5e
a58837c1-d2a7-4568-9998-9590681ebc03	t	Mwali	7372b477-f7ef-45f9-93c7-7ffd03acbf5e
38f5a706-c245-426b-869f-4095663bb531	t	Ndamiye	7372b477-f7ef-45f9-93c7-7ffd03acbf5e
80022d62-efb9-4845-9a1e-da28bf8f5115	t	Rukore	7372b477-f7ef-45f9-93c7-7ffd03acbf5e
d23abc91-d4f6-426f-b074-ed4aae57e40e	t	Buroha	9abe4384-2581-4046-b777-30ca972fbbcb
8b4487bf-0498-43f4-932b-99e3e3f96087	t	Kabitongo	9abe4384-2581-4046-b777-30ca972fbbcb
418d3c92-a6b1-4fb8-ba1d-25467a897829	t	Kanyamisuku	9abe4384-2581-4046-b777-30ca972fbbcb
cc40d5f7-dc8e-4fef-8350-597693631d10	t	Nkora	9abe4384-2581-4046-b777-30ca972fbbcb
9def5d23-9409-45d8-9b8a-bfa19340de32	t	Remera	9abe4384-2581-4046-b777-30ca972fbbcb
71e30c83-7012-4c17-b9d8-53ad691f0222	t	Tanda	9abe4384-2581-4046-b777-30ca972fbbcb
b109d7a5-37ff-434c-8543-99c99cca0a6d	t	Huye	4b23c811-d320-476e-afbb-ed7c42d7b36c
3fdc33e6-1392-4eef-a8d9-93a8da9b4c11	t	Kayanza	4b23c811-d320-476e-afbb-ed7c42d7b36c
8229867a-81a9-4451-be5d-1a0ea6096784	t	Nyakagezi	4b23c811-d320-476e-afbb-ed7c42d7b36c
99f26842-2a38-4f92-b9b8-4fb35a5d3d1d	t	Gahama	5b1d1449-b5cc-4981-a29b-141abc85b85f
f48297c1-8782-4bf6-8368-9deb230949c2	t	Hanika	5b1d1449-b5cc-4981-a29b-141abc85b85f
ab7596a5-3965-4f74-a95e-9d93d8afbe96	t	Kanyamatembe	5b1d1449-b5cc-4981-a29b-141abc85b85f
875cf1c1-0a56-4567-a8ea-17b7cdb69721	t	Keya	5b1d1449-b5cc-4981-a29b-141abc85b85f
5d4a7e5c-ed4f-4dbc-80b1-259ee3214ee5	t	Nombe	5b1d1449-b5cc-4981-a29b-141abc85b85f
4742bdc3-7336-4f19-8138-7ffc0b6a02b5	t	Ruhango	5b1d1449-b5cc-4981-a29b-141abc85b85f
5d677f35-686f-4a60-a5be-eeeac2d9caa8	t	Terimbere	5b1d1449-b5cc-4981-a29b-141abc85b85f
8b60abe7-2371-486d-bd8f-3c2c807a9cd0	t	Gabiro	a240105f-2343-44d8-af07-30fa01de47e2
b6ac2dee-a477-4a96-a247-ed2ee95393c3	t	Murambi	a240105f-2343-44d8-af07-30fa01de47e2
eb391472-a0f0-4cef-9028-0d3c565a87c6	t	Akasengore	8fb5a8cf-7501-4412-9557-1000cb5dd969
470c44b0-a9c4-4449-8d0a-edb8ab241328	t	Gasenyi	8fb5a8cf-7501-4412-9557-1000cb5dd969
e36938ce-10ad-4713-895f-cdd7341984f5	t	Nyabantu	8fb5a8cf-7501-4412-9557-1000cb5dd969
2a17d71f-d843-46ef-9ea5-85946874ebe6	t	Nyamwinshi	8fb5a8cf-7501-4412-9557-1000cb5dd969
66b036a3-d306-4075-aa11-47036d34671b	t	Rwezamenyo	8fb5a8cf-7501-4412-9557-1000cb5dd969
97514c0c-6edc-4722-a304-dec564399acc	t	Isangano	609c9180-2d39-4765-91cb-117d1481ee01
4f940005-5eaa-4cd0-82b9-60efb54ef860	t	Mikingo	609c9180-2d39-4765-91cb-117d1481ee01
a7fbc3a8-4804-43c9-8eaf-269d4f174bf1	t	Ngugo	609c9180-2d39-4765-91cb-117d1481ee01
187b947f-d52d-472e-afc4-aa316f6ace7c	t	Rurembo	609c9180-2d39-4765-91cb-117d1481ee01
e387adb4-a061-42c1-871c-b5f3bfe2a9b3	t	Bambiro	9ac16377-66b4-40f8-a062-2df9e206e0c0
15b43ccf-f3a2-44b8-8567-f748db48d4d0	t	Bushengo I	9ac16377-66b4-40f8-a062-2df9e206e0c0
d7aaa261-4aa0-4e1b-94a7-dfb9a6652596	t	Gafuku	9ac16377-66b4-40f8-a062-2df9e206e0c0
7566520b-e96f-407b-8079-6835d3c8d6fa	t	Mubuga	9ac16377-66b4-40f8-a062-2df9e206e0c0
a68ccd3b-db91-4fe2-9c1c-b0225f7109e7	t	Rebero	9ac16377-66b4-40f8-a062-2df9e206e0c0
53483eab-1b40-4e12-be33-51cea99a4de8	t	Buzuta	bf15291c-2992-4366-b8dd-850395234022
0136e8a9-1e88-4dfb-b8ae-a802e69ad5d3	t	Bwiru	bf15291c-2992-4366-b8dd-850395234022
9f41e136-8874-42ee-8e9b-6b786644d036	t	Ruvumbu	bf15291c-2992-4366-b8dd-850395234022
cb9f7a40-c30a-405f-b5e7-9233370743d2	t	Rwangara	bf15291c-2992-4366-b8dd-850395234022
4f6f80bb-94dd-4fd9-9e62-85761c1052bf	t	Bugesera	14d35cd1-968c-4b11-a41f-ee1f40bc512e
3deb3d9d-1ab9-4c78-9fc1-170e1ae9f682	t	Kabere	14d35cd1-968c-4b11-a41f-ee1f40bc512e
64b27b32-0676-4f52-8436-e757f95b9e93	t	Bisizi	04ae368e-7a94-4d77-be33-6ef0809f73c0
5a2781f7-4e87-41e9-9123-0b4de50e0101	t	Isangano	04ae368e-7a94-4d77-be33-6ef0809f73c0
7d31e2c7-bbd0-4046-b6e3-e651bca603a5	t	Kitarimwa	04ae368e-7a94-4d77-be33-6ef0809f73c0
feb81758-91e0-44ff-86c9-68306ef88bdb	t	Rutagara	04ae368e-7a94-4d77-be33-6ef0809f73c0
6b908d78-a084-4a8a-b467-c56ddd3ced30	t	Buranga	95db6b75-8f30-4f20-ac21-06ab76886c4c
cf711a6e-6bde-462f-842d-d55925741955	t	Gahinga	95db6b75-8f30-4f20-ac21-06ab76886c4c
4da01982-01df-4b2e-ba70-e88afd2d06b5	t	Kanyukiro	95db6b75-8f30-4f20-ac21-06ab76886c4c
b38fa9be-ac0e-45e9-a71f-ed04c0e01bd9	t	Nyaruhengeri	95db6b75-8f30-4f20-ac21-06ab76886c4c
e4fa36c1-2ea7-4790-a284-608b7bab498a	t	Tagaza	95db6b75-8f30-4f20-ac21-06ab76886c4c
0433b537-0334-491e-b7c0-843a520147b9	t	Gatangare	9ee47418-1846-4895-bed9-f339f1f6fbac
9e598b80-6ab7-4d46-b405-218de4b824c7	t	Gihira	9ee47418-1846-4895-bed9-f339f1f6fbac
c2a15230-58fa-4a20-a7ec-685c256aa821	t	Gisa	9ee47418-1846-4895-bed9-f339f1f6fbac
46a9b5e9-aed8-4609-9e0b-fff781ef8f58	t	Kabashanja	9ee47418-1846-4895-bed9-f339f1f6fbac
36f450db-6a37-40bd-9081-27b78ac60004	t	Kaniga	9ee47418-1846-4895-bed9-f339f1f6fbac
184525e0-5f52-4f87-ae0c-82f7e203d135	t	Ndobogo	9ee47418-1846-4895-bed9-f339f1f6fbac
8ab5d956-cd87-48ca-98b6-1dcf4bdbd993	t	Rusongati	9ee47418-1846-4895-bed9-f339f1f6fbac
19b506fb-b1fd-403e-8c2b-7d6e66112b3d	t	Shwemu	9ee47418-1846-4895-bed9-f339f1f6fbac
9062fd8f-822b-4405-a347-d1ac609a6e64	t	Amahoro	00c4dd27-c15d-474a-940b-190f06f40202
e8766e43-c723-4dbc-94be-1ced638634e4	t	Gakoro	00c4dd27-c15d-474a-940b-190f06f40202
64b87b3c-485d-4064-bbe3-82c9c2022816	t	Nkama	00c4dd27-c15d-474a-940b-190f06f40202
2849c8dc-07b1-40cd-ad44-473ec76b588c	t	Nyamyiri	00c4dd27-c15d-474a-940b-190f06f40202
f7bac5db-82d3-4ccc-85f6-dbe2b905fa8f	t	Ruhangiro	00c4dd27-c15d-474a-940b-190f06f40202
15836c50-20de-451f-ae56-dd19b5a36324	t	Gatebe I	9a7548f6-f72d-4085-a8c1-67efa0585d28
29c3e0a3-83a9-4f89-8bfd-7661c8e30f3c	t	Gatebe Ii	9a7548f6-f72d-4085-a8c1-67efa0585d28
fec58bc0-5c0d-460a-b266-881f8f519166	t	Gitebe I	9a7548f6-f72d-4085-a8c1-67efa0585d28
7e604399-b098-4340-a628-184203faa18f	t	Kasonga	9a7548f6-f72d-4085-a8c1-67efa0585d28
6a459630-4841-4f74-94d2-be0b7b379f71	t	Kizi	9a7548f6-f72d-4085-a8c1-67efa0585d28
d3827bab-012f-4df6-a6ab-fc4d23fb7f64	t	Rusamaza	9a7548f6-f72d-4085-a8c1-67efa0585d28
13c3fb69-3739-4fde-b039-c9b25f551210	t	Kabarora	08847e4a-7966-42bf-9ede-caa0c2ae0d4e
800da130-9055-498d-9687-83e93be87299	t	Kibaya	08847e4a-7966-42bf-9ede-caa0c2ae0d4e
60aa772d-f8b3-4008-b1e1-bff8945b0fbb	t	Nyantomvu	08847e4a-7966-42bf-9ede-caa0c2ae0d4e
3bb42c9f-06b1-407f-b9c4-f4e5392fdcaa	t	Nyarurembo	08847e4a-7966-42bf-9ede-caa0c2ae0d4e
d14af1d5-a5c0-49bc-bd3c-26622af8f2ad	t	Rukingo	08847e4a-7966-42bf-9ede-caa0c2ae0d4e
5afd3b89-fa8d-4495-9731-6e029d7909f6	t	Ruranga	08847e4a-7966-42bf-9ede-caa0c2ae0d4e
57f7641c-87ad-47aa-89c8-267f0afc1bef	t	Busheke	301c0653-74d5-4339-b3c7-2ca4c7a3869f
ad087250-e228-43cd-882b-ebce616dae0d	t	Butangi	301c0653-74d5-4339-b3c7-2ca4c7a3869f
2891e67b-0120-4455-841f-5a7aca0897ff	t	Butumba	301c0653-74d5-4339-b3c7-2ca4c7a3869f
564adbad-26d3-4ce4-bf01-04d560e4653e	t	Kabashara	301c0653-74d5-4339-b3c7-2ca4c7a3869f
7a679a75-5a2b-4353-9117-6098f881b96a	t	Kazika	301c0653-74d5-4339-b3c7-2ca4c7a3869f
a3f9bad8-ed5e-457c-ac92-b41463935e53	t	Kimina	301c0653-74d5-4339-b3c7-2ca4c7a3869f
57373a35-5945-4003-80c4-d41e841f1a80	t	Byima	d05650e5-1d3b-49bd-af9b-66034f4041ac
dd7c6b9f-133b-4345-bce6-e635ced7afc7	t	Cyanika	d05650e5-1d3b-49bd-af9b-66034f4041ac
e12f4410-637a-4fcc-8488-13f0fc4275a9	t	Gashovu	d05650e5-1d3b-49bd-af9b-66034f4041ac
fd639455-0beb-4610-9b2c-2af743789084	t	Gateko	d05650e5-1d3b-49bd-af9b-66034f4041ac
b24b7748-c847-4bb3-95f0-218b75e5432c	t	Kiroji	d05650e5-1d3b-49bd-af9b-66034f4041ac
dbacfc24-6653-4f19-bc35-3d32fb479b05	t	Mushoko	d05650e5-1d3b-49bd-af9b-66034f4041ac
eaf1fee6-e550-4fa7-bb2e-996916b00fcd	t	Rebero	d05650e5-1d3b-49bd-af9b-66034f4041ac
5466fec0-ac46-4b8b-a827-8db67c7197e4	t	Rohero	d05650e5-1d3b-49bd-af9b-66034f4041ac
22f0d27e-9b6d-42bc-bf09-f74e9d3c0d13	t	Rucyamo	d05650e5-1d3b-49bd-af9b-66034f4041ac
1154a9fe-ff79-45c9-ad70-10963320529c	t	Rwaza	d05650e5-1d3b-49bd-af9b-66034f4041ac
a3aeae7c-8022-4426-a38a-0de9fbdd4020	t	CitΘ	bb7b6e4e-53ea-45c8-b9c9-94a1d4592b55
24aced0d-f808-4b4a-b2bd-2ee5cb4a872e	t	Gatebe	bb7b6e4e-53ea-45c8-b9c9-94a1d4592b55
44658a70-9082-4a5b-9f5c-35f611721cdf	t	Kabeza	bb7b6e4e-53ea-45c8-b9c9-94a1d4592b55
5e873368-521d-4cf3-ac6e-5e4edd4feb54	t	Mihabura	bb7b6e4e-53ea-45c8-b9c9-94a1d4592b55
db638a1d-98e6-4cb0-865c-ccd55c5fb03c	t	Mubogora	bb7b6e4e-53ea-45c8-b9c9-94a1d4592b55
6505b39f-3050-45ca-a07c-fc84cb14b45e	t	Munini	bb7b6e4e-53ea-45c8-b9c9-94a1d4592b55
291c1e16-f25a-4650-a89e-bd50f8e4fe3d	t	Nyange	bb7b6e4e-53ea-45c8-b9c9-94a1d4592b55
e1b37769-4200-4a32-84fe-2364ca6808e5	t	Rubumba	bb7b6e4e-53ea-45c8-b9c9-94a1d4592b55
2afec379-9e80-466d-b48d-15146c0b2fd5	t	Buhanga	a56f8700-1d62-4f2e-ba01-d6d407e51751
0fdd51c0-f1d2-40c9-88d3-a6df64ba9f4a	t	Kabuye	a56f8700-1d62-4f2e-ba01-d6d407e51751
3164ac94-ac7b-4472-979e-023882fcb6ac	t	Kiyovu	a56f8700-1d62-4f2e-ba01-d6d407e51751
3b7c0c5b-aca1-4c81-8e9f-f20617bf31dd	t	Murambi	a56f8700-1d62-4f2e-ba01-d6d407e51751
f85f4343-e1c3-417a-81f4-fa3a59ab79ee	t	Mwaro	a56f8700-1d62-4f2e-ba01-d6d407e51751
af421919-316e-40d2-acbf-3a2d2a48f3b2	t	Pera	a56f8700-1d62-4f2e-ba01-d6d407e51751
bc0cdaef-56b7-4542-b8b9-582748de126b	t	Gombaniro	b2ebee26-a2de-42f7-b812-857ad241a5b8
ee65eceb-e73a-41a6-a441-a21162db41b9	t	Kabuga	b2ebee26-a2de-42f7-b812-857ad241a5b8
8ba3fad7-cfa3-4582-8b08-7e06b81b6f9f	t	Kayenzi	b2ebee26-a2de-42f7-b812-857ad241a5b8
fcdc4111-2cda-4a11-9a9d-4ef9be8a8010	t	Mahoro	b2ebee26-a2de-42f7-b812-857ad241a5b8
71f18701-c710-4b35-afb2-81f7f8b3987c	t	Muyange	b2ebee26-a2de-42f7-b812-857ad241a5b8
6b12167e-67c2-4129-bc6d-cfce733ad8bc	t	Nyehonga	b2ebee26-a2de-42f7-b812-857ad241a5b8
1c4cab62-aa3d-4d1f-abc0-54bb8528f5ef	t	Rubyiro	b2ebee26-a2de-42f7-b812-857ad241a5b8
c3f56cd9-8882-4f5b-b09d-bfaf78a7c1ed	t	Rusizi	b2ebee26-a2de-42f7-b812-857ad241a5b8
7bcf9895-921b-44b0-a0c9-4cae7d5cd0d4	t	Buganzo	d3442f98-1aa8-4588-92ca-5dfb76e5482e
3e4a3a10-dbe5-4f78-aae9-c5db01d78994	t	Gasihe	d3442f98-1aa8-4588-92ca-5dfb76e5482e
ea8f0716-06b3-479c-838f-ad44aa75f275	t	Rugera	d3442f98-1aa8-4588-92ca-5dfb76e5482e
70000bf2-01d1-4225-b79e-9f4a5328cfb2	t	Rujagi	d3442f98-1aa8-4588-92ca-5dfb76e5482e
6fb49b1d-c5c8-481b-9708-71c8e4f1bc5c	t	Karama	b7c4c55e-6d30-4538-b4a8-3cc19e7386cb
ae7c6823-384b-496c-84fb-39d6aca2eac5	t	Kareba	b7c4c55e-6d30-4538-b4a8-3cc19e7386cb
c3920400-ee82-45ee-9a39-4fd83e9e6c56	t	Nyaburenge	b7c4c55e-6d30-4538-b4a8-3cc19e7386cb
4bf87afe-01bc-4b57-90d8-c8d9bf79b284	t	Nyakibanda	b7c4c55e-6d30-4538-b4a8-3cc19e7386cb
10a8660a-4092-41b3-9abe-6469d903a717	t	Ruhinga	b7c4c55e-6d30-4538-b4a8-3cc19e7386cb
d64a7646-65a5-4dc6-86d4-3af87701eca2	t	Rwibutso	b7c4c55e-6d30-4538-b4a8-3cc19e7386cb
daf295d9-e5b4-4376-9da6-38fc7752a9f9	t	Kirwano	ec9f4588-765e-43c4-858a-2a8548a011e8
59c8ff7a-81ac-4546-9d29-83ea017b4b50	t	Munkamba	ec9f4588-765e-43c4-858a-2a8548a011e8
92caba18-bfef-41e7-81f4-ae812f61a0e9	t	Mwimerere	ec9f4588-765e-43c4-858a-2a8548a011e8
758fbc3a-e542-42a0-9ff1-dc7e3de74484	t	Ndengerezi	ec9f4588-765e-43c4-858a-2a8548a011e8
fa90f918-0c12-4999-b93f-3f9bfd8ae98a	t	Rushwati	ec9f4588-765e-43c4-858a-2a8548a011e8
e7dc7609-95cd-42b1-b7ab-e0073b18cf9a	t	Bisengo	8fe3be73-f5a7-4170-8b8a-794e64fcecc7
8f6a7934-6e0c-48f6-9460-cf4d50a153cd	t	Byimana	8fe3be73-f5a7-4170-8b8a-794e64fcecc7
aebea51c-bca0-443d-9e3a-10f758211b7c	t	Gasumo	8fe3be73-f5a7-4170-8b8a-794e64fcecc7
07d00bd2-e63e-47be-8c13-dd10f4add6e4	t	Karambo	8fe3be73-f5a7-4170-8b8a-794e64fcecc7
6535f928-7415-4549-91a2-32a80afc6ec6	t	Kigarama	8fe3be73-f5a7-4170-8b8a-794e64fcecc7
0506fb9c-19a6-409f-bf9f-76e3386308e8	t	Nyaruteja	8fe3be73-f5a7-4170-8b8a-794e64fcecc7
0c60fe3c-b9b2-4ba8-9563-852549669eaa	t	Rutovu	8fe3be73-f5a7-4170-8b8a-794e64fcecc7
c5ca48d5-8783-4ce7-94db-c67decd81633	t	Kibonajoro	9961911b-a226-42b7-b13a-8ed406d7988a
b631bdc6-0f5b-4544-8add-15eab23a85ad	t	Rwamagare	9961911b-a226-42b7-b13a-8ed406d7988a
328be88e-b232-4116-93e2-f7dd2344a937	t	Matyazo	ec6d586b-a22a-4baf-be7c-60ff503baa1a
35155daf-7ade-4129-8c85-28a915fce2df	t	Mbisabasaba	ec6d586b-a22a-4baf-be7c-60ff503baa1a
452cc3d4-cdca-4f23-b3e9-02b6788b5b2c	t	Mudasomwa	ec6d586b-a22a-4baf-be7c-60ff503baa1a
746014f3-7a2f-44a3-a937-bc90420f43cc	t	Mutara	ec6d586b-a22a-4baf-be7c-60ff503baa1a
de961083-15be-497b-b8d0-96a205935666	t	Ruhondo	ec6d586b-a22a-4baf-be7c-60ff503baa1a
a8dbfd3c-f8c3-493e-a7cb-7a6ca07e25bd	t	Runege	ec6d586b-a22a-4baf-be7c-60ff503baa1a
fd7ba663-941c-4c0b-aa9f-b32a9e19f531	t	Rutobo	ec6d586b-a22a-4baf-be7c-60ff503baa1a
a07c4367-69d0-45ba-bc2e-987414574c2d	t	Muyebe	6279d3fc-1a27-4560-a442-69b66daafea2
6fb9cc56-9ac9-46dd-bb75-bacda1871255	t	Nyabigoma	6279d3fc-1a27-4560-a442-69b66daafea2
8443ef99-ad81-43bb-8941-f3db8cb8d44a	t	Gakopfo	0044600a-1bf1-4ebc-9bb5-df070006d9a0
4c25498f-ec30-4c2f-aaef-732e8bdfd053	t	Muhiza	0044600a-1bf1-4ebc-9bb5-df070006d9a0
1bd6a8cf-3f98-4dfd-928c-ac42878d5a3f	t	Rwamisave	0044600a-1bf1-4ebc-9bb5-df070006d9a0
e6818fee-d2ef-4765-a626-4996ad84fc5a	t	Banamba	8e97ffa5-026a-4fad-b74f-5f14bc21b04d
7b7ad213-d592-4018-8d2c-65333ec7b54a	t	Kabuga	8e97ffa5-026a-4fad-b74f-5f14bc21b04d
a650e687-138d-4f4d-be3e-178fb33e26cc	t	Nyamirambo	8e97ffa5-026a-4fad-b74f-5f14bc21b04d
e2d9531c-fe0c-4908-b2e1-40613eec4afe	t	Runyami	8e97ffa5-026a-4fad-b74f-5f14bc21b04d
42259c28-caa1-4ce3-afd6-ae419cb1828d	t	Runyovu	8e97ffa5-026a-4fad-b74f-5f14bc21b04d
edf375d5-3078-48ec-88b3-d9b40c4bc305	t	Mariba	b269f09c-2d61-4028-b72f-3e80d22994cb
c634c056-2f2e-460a-9413-c61337fa26f9	t	Burama	b269f09c-2d61-4028-b72f-3e80d22994cb
21d16464-2ec7-46f5-85ee-56cc2a877ee8	t	Ryagacece	7f901605-2ed7-44bb-bede-eba91541087a
330e0aec-86e9-4712-82f4-296dfdbfec12	t	Gatare	5045f2ee-f455-4051-ae89-44d790ed9327
9916337e-1134-429c-8d8a-19e3b5661927	t	Munini	5045f2ee-f455-4051-ae89-44d790ed9327
986aaa7d-2593-448b-ba2e-5bc71ef284bc	t	Rango	5045f2ee-f455-4051-ae89-44d790ed9327
50f3c9ca-d1a1-47bb-afe9-99c6253a013b	t	Mubuga	8a96eb3a-0df8-4f20-8016-4a0dfe5f18c0
bb6744ed-63d7-4c43-8dcd-17f67905c4ee	t	Mukaba	8a96eb3a-0df8-4f20-8016-4a0dfe5f18c0
2f83da97-aa57-4df1-bb3b-6858c47c4ab5	t	Rango	8a96eb3a-0df8-4f20-8016-4a0dfe5f18c0
e7f6c207-a767-4605-8102-5b519ecc3ffc	t	Torero	8a96eb3a-0df8-4f20-8016-4a0dfe5f18c0
c5d59c5f-cb03-4715-ae16-e937d7f1e24f	t	Gacyamo	a4d0fae6-c0b0-458e-94ff-19eba840a195
499fb9e8-1657-4823-8ecc-16a01c30985e	t	Kamonyi	a4d0fae6-c0b0-458e-94ff-19eba840a195
1208f089-58ff-4f07-b0de-5c7d4e27ebed	t	Mashya	a4d0fae6-c0b0-458e-94ff-19eba840a195
52df0123-53aa-4749-a93d-5e149dfaef5e	t	Nyabihanga	a4d0fae6-c0b0-458e-94ff-19eba840a195
e625501d-732c-4c7f-afad-3eab36fe9040	t	Rebero	a4d0fae6-c0b0-458e-94ff-19eba840a195
99fd571e-da3b-4a8b-b279-94d35ebd9ad5	t	Kagikongoro	d78897ea-87c2-4dec-b942-1dfabd029434
94c85210-f504-423f-ab78-438fa34974b2	t	Mibirizi	d78897ea-87c2-4dec-b942-1dfabd029434
bbe56266-1158-42dc-a862-8179feee51f5	t	Gakombe	a0cd7e69-682b-4bc7-b647-72443d9199ee
57baab38-faa6-4a1f-9596-54b5395beac3	t	Kabeza	a0cd7e69-682b-4bc7-b647-72443d9199ee
c2ab14c9-06a9-48d2-ac9d-e94ae6a3f4c8	t	Rugende	a0cd7e69-682b-4bc7-b647-72443d9199ee
dcb9b32b-e0ce-4a89-9c34-b97d6d79a92e	t	Kamuhana	1a820ecd-a0f6-458f-8e0a-692cf974fb27
ca276080-b7dd-46a7-9e2a-f634173585c4	t	Kiremereye	1a820ecd-a0f6-458f-8e0a-692cf974fb27
8519fe04-3435-4b73-9950-9b14debc634b	t	Misave	1a820ecd-a0f6-458f-8e0a-692cf974fb27
62d02c90-b5ef-4e57-8656-cd7b6057bcf0	t	Nyamutarama	1a820ecd-a0f6-458f-8e0a-692cf974fb27
ee93ebc3-4f10-4543-abbc-875c9cc0dd39	t	Ryagatebe	1a820ecd-a0f6-458f-8e0a-692cf974fb27
fe230835-e6b8-406d-af8c-fe011661a5b7	t	Burembo	b961fe67-bb1f-41a1-a101-e1e21970408c
7e88603a-7e29-4e4f-bd56-cfd7fb8bc66a	t	Kabeza	b961fe67-bb1f-41a1-a101-e1e21970408c
29ac2898-a50a-46b6-a47f-b8d0912693a5	t	Murinzi	b961fe67-bb1f-41a1-a101-e1e21970408c
704a3e01-770a-467a-94a3-f6318478f433	t	Buzi	a979f880-c762-4d18-95ea-ba5b7b093698
1fd78953-c6c5-44e5-b7af-806ff5170da8	t	Gacyamo	a979f880-c762-4d18-95ea-ba5b7b093698
d5c1267a-037f-4e51-ae35-584c1cb3bdd7	t	Kabuga	a979f880-c762-4d18-95ea-ba5b7b093698
138c65d8-2d1b-40c4-a027-f5b7e12d46a1	t	Kagarama	a979f880-c762-4d18-95ea-ba5b7b093698
c12e050c-3b1f-4b77-afe4-c438ca46d6e0	t	Ruvumbu	a979f880-c762-4d18-95ea-ba5b7b093698
1a87433a-a6c0-4123-8882-c4b48259868f	t	Murambi	1e572898-2ca3-4e6a-916a-0059aae96a16
120381f4-173d-4fd1-bf3e-11596329854b	t	Rwumvangom	1e572898-2ca3-4e6a-916a-0059aae96a16
57dd0d1c-6932-49d3-936b-13ef1aa03c5d	t	Wimana	1e572898-2ca3-4e6a-916a-0059aae96a16
a95e3859-1253-4829-82db-12edd7cf391f	t	Isha	57ed43a2-dc2b-4326-975e-4268f9d24fd1
0026fcc9-bbe7-43c2-a95c-5c7cc2983db5	t	Gahinga	5cb4f129-a4f7-40aa-822d-b81997bf54c3
f082f829-6f0b-4b39-9b12-e59126e49743	t	Gahurubuka	5cb4f129-a4f7-40aa-822d-b81997bf54c3
10d9fd7e-3aeb-470b-8899-8c77d9ea0faf	t	Rwamiko	5cb4f129-a4f7-40aa-822d-b81997bf54c3
4fd754c6-c7a8-4636-8bc5-8854153f27c1	t	Bubanga	950e8eb7-3114-47a6-97d3-f4ae0a5724bc
d0dd0515-ea45-44f2-b8c1-b53995cb01e5	t	Kabujyogoro	950e8eb7-3114-47a6-97d3-f4ae0a5724bc
b4bf192c-6c7c-4af1-82d7-80d9a05c7af4	t	Karambi	950e8eb7-3114-47a6-97d3-f4ae0a5724bc
d6bb875f-36cb-4544-9eb5-d03d0dbbf26e	t	Kigenge	950e8eb7-3114-47a6-97d3-f4ae0a5724bc
e0a0f4dc-4496-402c-88a0-17b1960261bd	t	Ntura	950e8eb7-3114-47a6-97d3-f4ae0a5724bc
fa7212d0-7ea3-44cb-aafe-d68e6ff9c895	t	Rebero	950e8eb7-3114-47a6-97d3-f4ae0a5724bc
673c6663-9c76-4f46-a9e7-191dae9bef3f	t	Kamuhoza	390db8f7-8c8d-4db2-8092-d29a4be8ae5a
616cf2a4-4298-4a91-b34d-0cc5d5ee6ed7	t	Munyove	390db8f7-8c8d-4db2-8092-d29a4be8ae5a
631b89aa-08d3-443e-8370-e6ad8cfabc2e	t	Cyapa	bccf2b9a-9365-4438-97d8-30528f9f636a
6cf2ef5d-8a3a-4b27-8d30-8adcec97127a	t	Gacamahemb	bccf2b9a-9365-4438-97d8-30528f9f636a
7b60ac56-5697-421d-80ae-73084d4e4557	t	Kamabuye	bccf2b9a-9365-4438-97d8-30528f9f636a
9cfe6ceb-b9e8-4dd6-92d8-d97952233211	t	Kanombe	bccf2b9a-9365-4438-97d8-30528f9f636a
4bc8dcdd-57fa-4aa3-bd33-c8ec5f1bfb6e	t	Karangiro	bccf2b9a-9365-4438-97d8-30528f9f636a
3d6dbf3b-7950-48a5-aaed-88af7e17ea4a	t	Karitasi	bccf2b9a-9365-4438-97d8-30528f9f636a
9f56c207-6394-493e-8b33-ac0d58aee3d2	t	Karushaririza	bccf2b9a-9365-4438-97d8-30528f9f636a
6a883b7a-d90c-4c97-aed6-f9dd28e6cf0d	t	Mpongora	6f1a4590-f41d-4250-802a-e0a5412eac2c
bc7ac00b-100b-4595-8478-9009f006cf2e	t	Tuwonane	6f1a4590-f41d-4250-802a-e0a5412eac2c
730d9569-f5a9-4507-9def-00f5eebdb733	t	Rubenga I	7f241109-05b0-4b08-84af-35044bffa1ea
86afcee9-abb3-4dde-a664-eb553d977f6e	t	Rubenga Ii	7f241109-05b0-4b08-84af-35044bffa1ea
d9fd0057-f0cf-4334-add6-ce3c75557dac	t	Cyinzovu	f25e3ea5-c283-4771-b77e-5c4d9bc6cd1a
ad4278ea-fcbf-4af4-99d8-24fabab8cb6e	t	Gahwazi	f25e3ea5-c283-4771-b77e-5c4d9bc6cd1a
23768c40-e0f5-4894-9d39-dece4e5dd2ad	t	Kamanyenga	f25e3ea5-c283-4771-b77e-5c4d9bc6cd1a
2a578651-8854-40d1-882a-abfbbd5c82cb	t	Muhari	f25e3ea5-c283-4771-b77e-5c4d9bc6cd1a
d3836b38-157b-4d2f-8cbd-3201b2cbf460	t	Munyana	f25e3ea5-c283-4771-b77e-5c4d9bc6cd1a
211f0d53-3cbe-4620-bb10-97295457bc44	t	Ngoma	f25e3ea5-c283-4771-b77e-5c4d9bc6cd1a
3a7acd6d-074e-4e34-902f-631d4bf51a8b	t	Bisanganira	f24b82d7-2eb4-4b52-b811-0fcdfb23e3b4
db9b6d40-c390-42b6-9640-615d418968d7	t	Gitwa	f24b82d7-2eb4-4b52-b811-0fcdfb23e3b4
f5b98ba0-74fe-4aa1-81d9-17d04fbc5a08	t	Kanoga	f24b82d7-2eb4-4b52-b811-0fcdfb23e3b4
89fffa17-06c2-41a1-be1e-cc92c2abd161	t	Nyagatare	f24b82d7-2eb4-4b52-b811-0fcdfb23e3b4
91fce040-dfdf-42fd-94bc-16c07d81872f	t	Shagasha	f24b82d7-2eb4-4b52-b811-0fcdfb23e3b4
4c3a420e-0ba4-496c-9ebd-2b412348305d	t	Gitambi	5c9d6080-4d34-4bc3-983b-52cf7f078008
660b82a2-a624-4e5f-97dc-30868d437b96	t	Hinduka	5c9d6080-4d34-4bc3-983b-52cf7f078008
fb5460e0-1965-4c18-b352-f43d8d402023	t	Ituze	5c9d6080-4d34-4bc3-983b-52cf7f078008
09ee6145-3f6a-419d-a281-e9d2699ca279	t	Kamabuye	5c9d6080-4d34-4bc3-983b-52cf7f078008
cf256cb5-85a5-424c-97db-f6e0aba146b4	t	Mubera	5c9d6080-4d34-4bc3-983b-52cf7f078008
3546cf98-f3b1-4401-a636-26150f9c0892	t	Mutonga	5c9d6080-4d34-4bc3-983b-52cf7f078008
484d55f0-6cf7-4c7c-8120-afaa9537afdb	t	Ruhango	5c9d6080-4d34-4bc3-983b-52cf7f078008
ef073681-dd72-4ed0-9850-5d46e2b58ce2	t	Rukuraza	5c9d6080-4d34-4bc3-983b-52cf7f078008
d3a14ad7-7696-4cd1-b600-a8254e37360b	t	Shanike	5c9d6080-4d34-4bc3-983b-52cf7f078008
918a6da3-d412-4413-8923-06eeec8bf236	t	Birindiro	bf74a90a-09d8-4580-ba31-92519a64a47d
9709a93e-a030-4ad0-9c50-dd1def5ca54e	t	Busarabuye	bf74a90a-09d8-4580-ba31-92519a64a47d
fafa65ab-e0bd-4e21-8396-3811ae15479c	t	Bushenge	bf74a90a-09d8-4580-ba31-92519a64a47d
cd3f45a8-b264-48d9-9e08-ccb9a7e430ec	t	Gihomba	bf74a90a-09d8-4580-ba31-92519a64a47d
37daca50-1af6-473e-91f7-96476374ce95	t	Kirume	bf74a90a-09d8-4580-ba31-92519a64a47d
b0244cd5-b4b0-4b25-808e-c7a71b087cf6	t	Matyazo	bf74a90a-09d8-4580-ba31-92519a64a47d
23697f7f-e694-484e-b11b-c7cb5edf4a32	t	Mpuzamahanga	bf74a90a-09d8-4580-ba31-92519a64a47d
21c59fb0-0f76-4d52-9009-fce50263a70a	t	Mubuga	bf74a90a-09d8-4580-ba31-92519a64a47d
2af2d49f-7a23-4d78-bd54-79b394a97505	t	Nyabihanga	bf74a90a-09d8-4580-ba31-92519a64a47d
a91bcfcb-9740-4db4-a4dc-9f873c98fce3	t	Rebero	bf74a90a-09d8-4580-ba31-92519a64a47d
0d70be2a-6b67-4c8d-8636-2cc2f30aafb9	t	Binyaburanga	66d07483-7a68-403d-932d-3f11c88ceebe
611a5c5b-cd4e-4588-977d-4a76186a3ee8	t	Buhinga	66d07483-7a68-403d-932d-3f11c88ceebe
752df77b-4cc6-4919-b891-4d5b429936fe	t	Bumaranyota	66d07483-7a68-403d-932d-3f11c88ceebe
a106d681-edad-477d-bdca-843349eddb98	t	Kabugarama	471654ec-d68e-4119-9b31-374707b67c1a
3e5d3540-bf5e-44a2-8acc-9f8aa30633ab	t	Mpinga	471654ec-d68e-4119-9b31-374707b67c1a
d88940f5-ca95-48df-bf53-489851ad6c36	t	Kamagaju	7301230b-a844-411e-ba96-f8700ed61469
da06228d-4f10-494b-8cad-1f2582675ce9	t	Njambwe	7301230b-a844-411e-ba96-f8700ed61469
10c36c92-d7ff-476c-ba38-09c4e2e4fe67	t	Nyakibingo	7301230b-a844-411e-ba96-f8700ed61469
feea1c76-041f-49f1-8e96-86b49da8e8e4	t	Nyamaganda	7301230b-a844-411e-ba96-f8700ed61469
923c0348-637a-4aec-9e76-d3e250a1321c	t	Nyantaba	7301230b-a844-411e-ba96-f8700ed61469
9a9d0556-8704-4ea7-89f1-5678e2560d55	t	Kabonabose	bef97db3-4977-4c6f-b9c5-1d2d5604e348
046d2328-255e-4252-9df5-688eaf5dc820	t	Karambo	bef97db3-4977-4c6f-b9c5-1d2d5604e348
b13d9df0-1b50-4018-825b-1c3e8da7d191	t	Kirehe	bef97db3-4977-4c6f-b9c5-1d2d5604e348
c5531388-4ef4-4bd8-a90b-e5e090ced839	t	Idaga	5831d6a9-b0d3-450d-bb2c-a9a1c0a05222
257efd89-bdb1-48c6-bbad-7306256d6d32	t	Kankuba	5831d6a9-b0d3-450d-bb2c-a9a1c0a05222
f881d346-74ed-497a-a8cf-b198d1dd50db	t	Nyakivomero	5831d6a9-b0d3-450d-bb2c-a9a1c0a05222
a057bf1b-c332-44e5-837c-b9658394e162	t	Gatovu	51dc72ca-7747-4344-967c-7dbd0387f236
3340a501-0fed-40ec-8782-4306c9025666	t	Karambo	51dc72ca-7747-4344-967c-7dbd0387f236
b444301a-b54a-4c50-8e12-269c3a4a4443	t	Karangiro	51dc72ca-7747-4344-967c-7dbd0387f236
cb7d9032-3289-43bd-a7fb-1cad43f1813a	t	Mont Cyangu	51dc72ca-7747-4344-967c-7dbd0387f236
750ce1ca-b47f-4e4a-bddb-b0b2d97237ef	t	Mundima	51dc72ca-7747-4344-967c-7dbd0387f236
8bf653b9-1a22-4e28-b69a-119e328d3912	t	Ngoma	51dc72ca-7747-4344-967c-7dbd0387f236
1a73d487-ad20-4e54-98e0-6f436b270062	t	Ntwari	51dc72ca-7747-4344-967c-7dbd0387f236
7b73dc5f-0366-4bdf-bb55-bcdc06f063b4	t	Batero	5d0a239f-5479-47a2-8f77-e15e84492aa1
429c97a3-4a8b-45e7-9d20-4b8cc82c18e4	t	Burunga	5d0a239f-5479-47a2-8f77-e15e84492aa1
db14448b-bed3-4e96-9ef9-e6e9195021a5	t	Kabeza	5d0a239f-5479-47a2-8f77-e15e84492aa1
e144ab29-8a3b-4308-9228-6ddd6fc2230d	t	Munyinya	5d0a239f-5479-47a2-8f77-e15e84492aa1
988fbee8-ebf3-4de9-ad18-f64c5d29bfdb	t	Murambi	5d0a239f-5479-47a2-8f77-e15e84492aa1
622f4657-76bb-41c9-835c-b41368b46f49	t	Amahoro	e867d99d-4b4c-4f1d-b3ed-c8c8aa6f5341
0a35a3c6-121b-4d3e-bd73-b0a510b5ea1b	t	Badura	e867d99d-4b4c-4f1d-b3ed-c8c8aa6f5341
f875eb0a-40c1-445f-82e6-da7204c13bbe	t	Kadasomwa	e867d99d-4b4c-4f1d-b3ed-c8c8aa6f5341
375e232f-c294-4cf2-9a7a-ec2687f8b0d3	t	Kannyogo	e867d99d-4b4c-4f1d-b3ed-c8c8aa6f5341
fc5e9abf-525c-44b4-b4a0-f41883f7468f	t	Mbagira	e867d99d-4b4c-4f1d-b3ed-c8c8aa6f5341
c4e22699-59c2-4043-b757-e805086f4003	t	Mucyamo	e867d99d-4b4c-4f1d-b3ed-c8c8aa6f5341
28c13c07-5589-47ab-a434-4df2f052358a	t	Ntemabiti	e867d99d-4b4c-4f1d-b3ed-c8c8aa6f5341
958f6316-34a5-4112-9166-4be335418bcb	t	Nyakayonga	e867d99d-4b4c-4f1d-b3ed-c8c8aa6f5341
253b653a-4f45-4ec8-8fd7-2c11ca4d7ff2	t	Rushakamba	e867d99d-4b4c-4f1d-b3ed-c8c8aa6f5341
05c4f1a0-aef2-4453-82dd-791d408d8f15	t	Umuganda	e867d99d-4b4c-4f1d-b3ed-c8c8aa6f5341
b05f326b-af2d-4993-9a94-27e8a425248c	t	Cyapa	c2fdf37d-de33-4993-a084-b6bed04f56da
d4c5fdd7-cb45-479b-8477-a93179f1b3c5	t	Gikombe	c2fdf37d-de33-4993-a084-b6bed04f56da
448574f4-3182-463a-92a9-fc1dc65abda3	t	Kamuhirwa	c2fdf37d-de33-4993-a084-b6bed04f56da
7b7c8bcd-2851-4f6b-adad-afd4781a8c11	t	Murangi	c2fdf37d-de33-4993-a084-b6bed04f56da
6c88002f-0048-4962-9d9d-2026f90cddfe	t	Kadashya	eec6a513-9fae-4ded-910b-486abca7ccb7
a8caf0c2-d305-4fa8-8d04-aec656ec0048	t	Kamubaji	eec6a513-9fae-4ded-910b-486abca7ccb7
6f4fcd37-5d62-4aea-9f16-1d62c41ad93a	t	Murindi	eec6a513-9fae-4ded-910b-486abca7ccb7
8d139e51-120e-46b0-be05-7ce0b4362d7e	t	Gashisha	74759906-5247-48c8-b00b-415eebdeee42
be1344f4-f084-45ba-95ac-3c926a336711	t	Kabamba	74759906-5247-48c8-b00b-415eebdeee42
1c7df4e4-9499-4be8-bb45-ee711a6f5247	t	Murira	74759906-5247-48c8-b00b-415eebdeee42
72cdad98-3115-4909-b198-bbbadc221219	t	Nyakagoma	74759906-5247-48c8-b00b-415eebdeee42
ab9d530e-3034-4bc7-8d6f-f77eacbbd027	t	Rubumba	74759906-5247-48c8-b00b-415eebdeee42
3afa5faa-a3d7-47e6-9e06-477486c08a17	t	Rungunga	74759906-5247-48c8-b00b-415eebdeee42
238c8381-e268-4939-9db0-12ac2111576d	t	Gatanga	dba6aa22-a8f5-410a-96b3-33b123dd8742
94e7ecc4-430f-4e45-abd2-2b6ef18cb1ad	t	Kiyovu	dba6aa22-a8f5-410a-96b3-33b123dd8742
d480046a-1fcf-49d9-bb78-35ac6b540116	t	Rugaragara	dba6aa22-a8f5-410a-96b3-33b123dd8742
4acc511b-1a9f-4616-a596-078827d89957	t	Busasamana	80900522-edee-4eed-8db5-06d0a8cff589
38501ad6-3aaa-4114-af0e-a8d1627ce958	t	Gakenke	80900522-edee-4eed-8db5-06d0a8cff589
5938df8e-15f8-499f-bc07-ac721281f628	t	Kabarore	80900522-edee-4eed-8db5-06d0a8cff589
0aca0c06-78fd-4bb7-808f-4f01829e2fe7	t	Kamabuye	80900522-edee-4eed-8db5-06d0a8cff589
bd7b30cd-5fef-4e51-baf8-96c9f642e85b	t	Murabyo	80900522-edee-4eed-8db5-06d0a8cff589
d14889bf-6e2b-4071-b487-dc64ea327646	t	Nyabishunju	80900522-edee-4eed-8db5-06d0a8cff589
f5d4a674-2ec8-45e4-9427-90164a19a1b3	t	Nyenyeri	80900522-edee-4eed-8db5-06d0a8cff589
60600259-f3e6-44b4-864c-ce72aa0e2173	t	Ramiro	80900522-edee-4eed-8db5-06d0a8cff589
92cfb846-0d2a-45f6-bfd4-d3a0718848f8	t	Rubeho	80900522-edee-4eed-8db5-06d0a8cff589
28f1dea5-a404-44bb-9969-dcf5a8801564	t	Buremera	7169f1c0-c5b1-49cd-9b2e-6167ab7846b3
41b473bc-e54d-4586-978e-ad0f554bf10b	t	Cyirabyo B	7169f1c0-c5b1-49cd-9b2e-6167ab7846b3
057a2669-68cc-4efa-946f-c350f5f1cc62	t	Gipfura	7169f1c0-c5b1-49cd-9b2e-6167ab7846b3
0af8be6c-8583-4052-adcd-b950a0ee85d6	t	Kamarebe	7169f1c0-c5b1-49cd-9b2e-6167ab7846b3
855ed294-e4a6-44c3-bae9-45ed443851f0	t	Kanunga	7169f1c0-c5b1-49cd-9b2e-6167ab7846b3
06e130df-217e-4c8f-8587-84a239aaacfc	t	Mutara	7169f1c0-c5b1-49cd-9b2e-6167ab7846b3
0fd0a677-88a0-4eb6-bb97-8e5d340874ce	t	Kabahire	f187391f-77a9-4ca8-adbb-ba39454ced96
6810b94f-4acf-4643-9e36-8060c87e3218	t	Winteko	f187391f-77a9-4ca8-adbb-ba39454ced96
70075cfd-f6c8-4070-bdc5-2d1ba2c57529	t	Bitongo	0aa5ba64-c805-4a2b-ada8-119c4d45940e
49a93acc-aa91-4c2e-9b56-64d3a2e0d58f	t	Cyete	54a9268b-a6e6-4995-960a-65c3d4ddf9be
a47f2fa5-38d9-46ec-8b8e-a3f9fb84048b	t	Gikungwe	54a9268b-a6e6-4995-960a-65c3d4ddf9be
c5a2fbd1-11d6-4e5b-89c4-c0ac641798df	t	Gitwa	54a9268b-a6e6-4995-960a-65c3d4ddf9be
4a912971-5bda-4df8-9834-54da414f6914	t	Kamatene	54a9268b-a6e6-4995-960a-65c3d4ddf9be
408d84ab-0d45-4f3f-ac95-e30836d5c4a5	t	Bugayi	da454de4-73cf-458d-9f32-aacb0ab28011
f3f3f61e-90b7-4980-a4a1-79dcdfa33564	t	Gihango	da454de4-73cf-458d-9f32-aacb0ab28011
df8d1dac-1ef9-4f37-977d-d1ea44db7713	t	Kagarama	da454de4-73cf-458d-9f32-aacb0ab28011
eb89cd87-f757-414b-b7c1-5257d19e45a9	t	Ruhimbi	7ea22e08-12f9-42d8-824f-5b1f9f1bf76a
5ca623e0-e8a9-423b-83a3-d07bf0e5a221	t	Byangoma	76cae6b4-ea3d-4e2f-a13a-4b4e9b22b7a8
08f547a5-ea8f-4a35-ad04-c16fd8c0e049	t	Cyandarama	76cae6b4-ea3d-4e2f-a13a-4b4e9b22b7a8
52c51827-dff3-45eb-b606-50f115c38f65	t	Gatimbwa	76cae6b4-ea3d-4e2f-a13a-4b4e9b22b7a8
79b74662-149d-4a3d-89cc-2c8da3d6ebb5	t	Kamutongo	76cae6b4-ea3d-4e2f-a13a-4b4e9b22b7a8
33475c6e-c564-4bc0-880f-05c9e68b470f	t	Karanjwa	76cae6b4-ea3d-4e2f-a13a-4b4e9b22b7a8
9f5189bb-5d52-4e67-8f23-f62cbc3e7def	t	Mukorazuba	76cae6b4-ea3d-4e2f-a13a-4b4e9b22b7a8
408ee0e5-6435-4975-bc6b-132f587aadff	t	Mutongo	76cae6b4-ea3d-4e2f-a13a-4b4e9b22b7a8
f05bd719-c283-4795-a784-048746a41604	t	Rugerero	76cae6b4-ea3d-4e2f-a13a-4b4e9b22b7a8
5270296f-3818-40bd-8bca-fc52e32b24e4	t	Burege	b9ede99c-2267-47a8-a8cd-6f3de41822bb
f077cca3-9dab-4c27-83cd-844348645b04	t	Kanyombya	b9ede99c-2267-47a8-a8cd-6f3de41822bb
6c00cf24-8fd8-4d47-a708-17b6006ca00c	t	Muhonga	b9ede99c-2267-47a8-a8cd-6f3de41822bb
a48c642b-8e73-479f-91be-efae69f06a2a	t	Rugarika	b9ede99c-2267-47a8-a8cd-6f3de41822bb
dd9ed193-789b-4414-8b9d-240a856a0536	t	Hepfo	ee8cc566-a8d1-4dc3-ae7e-0316744e10cd
56488dc4-6749-4f86-8b72-02d1593181c7	t	Gafoka	88fc687f-70d0-4d78-827a-5bb52a32852a
20024307-e155-4e8c-8cfd-b14f00f826ec	t	Rusunyu	88fc687f-70d0-4d78-827a-5bb52a32852a
3a92d6ba-2598-4cff-9d39-e880c03de9cc	t	Kabutimbiri	891866a4-4208-4dca-9c1e-4b935c026ab2
f486b0e5-ce86-4bf2-979e-1eb42897b76f	t	Kinyaga	891866a4-4208-4dca-9c1e-4b935c026ab2
ef431561-11b4-4cbc-8a27-508192e90b37	t	Rugaragara	891866a4-4208-4dca-9c1e-4b935c026ab2
affc935f-9de4-4f9b-9937-3f61576abc24	t	Sumoyamana	891866a4-4208-4dca-9c1e-4b935c026ab2
64ef2eaa-fa12-4578-8702-434a29fcb57e	t	Bitaba	69072db4-2615-436d-8863-18edb6b3493e
104240ff-15aa-4089-9926-7f4bd4be7aab	t	Kagarama	69072db4-2615-436d-8863-18edb6b3493e
f7ce0b2c-e7a5-49b1-b8af-173cf873ce6f	t	Kamahoro	69072db4-2615-436d-8863-18edb6b3493e
f512bad5-a46b-4bb4-a1c4-83bb31e3ebc4	t	Karambo	69072db4-2615-436d-8863-18edb6b3493e
fd4ace6a-2983-4c09-bf4a-6e7cfab166f0	t	Rebero	69072db4-2615-436d-8863-18edb6b3493e
51de9f2a-b70d-4884-8563-5ba6cb550a5b	t	Gisunyu	5874d3a1-e0bc-4e90-a73a-5d4bf7e722a2
dbf38ae0-e3ae-4971-8c64-5aec81dbf657	t	Giteme	5874d3a1-e0bc-4e90-a73a-5d4bf7e722a2
c00d81e5-4b0f-47e2-a0a3-516ab9cc04d7	t	Kabashinga	5874d3a1-e0bc-4e90-a73a-5d4bf7e722a2
fdcd5441-c23b-41cf-9ee7-9fafaebc5aeb	t	Ngoma	5874d3a1-e0bc-4e90-a73a-5d4bf7e722a2
3753eabe-8bb4-4943-8b03-5fc4c2505617	t	Nyawenya	5874d3a1-e0bc-4e90-a73a-5d4bf7e722a2
91cf92bb-4003-4cfb-857e-d2eecec9c8d2	t	Rebero	5874d3a1-e0bc-4e90-a73a-5d4bf7e722a2
c2a5a87c-e276-4acb-aa56-2f152798503c	t	Nyankumbira	1f320edd-86f5-4c85-b847-0084c899af5e
184d2094-ad0b-437d-9e34-323c8576a8e4	t	Biraro	13559db4-10a7-49cd-9056-31da26e8cb7b
ac45a4f3-cedf-4ea4-8da8-7a88fdb6c8c1	t	Kaboneke	13559db4-10a7-49cd-9056-31da26e8cb7b
d165403a-f2d1-4cbd-a178-34ee6c7f9052	t	Kabuga	13559db4-10a7-49cd-9056-31da26e8cb7b
20e677f1-2284-42a9-9650-616f60fd7d55	t	Mapfura	13559db4-10a7-49cd-9056-31da26e8cb7b
34e4a4c9-8f72-4c85-9f1a-4426551ee553	t	Gashara	ad95d60a-4269-4421-9795-82ea67705bb2
9d5bfaa2-4b06-4d22-9772-854e96aed98c	t	Kabuye	ad95d60a-4269-4421-9795-82ea67705bb2
af475b27-121f-4fe9-8aa3-36a43a873a08	t	Kanyinya	ad95d60a-4269-4421-9795-82ea67705bb2
eacdf713-63bf-4e2f-9a6f-b19253a986d4	t	Muhora	ad95d60a-4269-4421-9795-82ea67705bb2
09241034-6ef3-43b9-84e2-7c265bdfde01	t	Gituro	41f03953-3306-4838-ab4a-96de917024cb
2490b31d-0543-491d-a3a5-9814cde5726f	t	Nyabintare	41f03953-3306-4838-ab4a-96de917024cb
138c2033-2aa5-43a4-9c2f-b213830d4610	t	Rutarakiro	41f03953-3306-4838-ab4a-96de917024cb
2a94215d-4c15-459c-ba58-da264f3ef713	t	Cyandarama	4a1bc50c-ae4d-45de-8cad-123f8a597891
43678c89-d358-4427-b5b4-b1f95f91add7	t	Njambwe	4a1bc50c-ae4d-45de-8cad-123f8a597891
6379846a-184e-47a6-88d4-ab4685f70b0e	t	Rutegamatwi	4a1bc50c-ae4d-45de-8cad-123f8a597891
c4a5ab5a-e643-4525-8dd9-43c0a4981646	t	Byugaro	4335f50a-08c2-4bf4-95f0-04f6e4eb877c
02d887dc-0963-4c14-8aee-c6fae9409e3c	t	Gasarabuye	4335f50a-08c2-4bf4-95f0-04f6e4eb877c
bdade27c-20b2-4411-947d-d24b4a4c648c	t	Kabigohe	4335f50a-08c2-4bf4-95f0-04f6e4eb877c
6675edfc-730d-443e-9ca7-f274aec1bcfd	t	Kabuga	4335f50a-08c2-4bf4-95f0-04f6e4eb877c
fefc4d88-4b03-4510-a6e9-105b4c3bc8dc	t	Kabuganza	4335f50a-08c2-4bf4-95f0-04f6e4eb877c
c5c5450b-9261-4cac-b7b1-79ab71441c54	t	Kadashya	4335f50a-08c2-4bf4-95f0-04f6e4eb877c
c2f68edc-ff60-4893-b3db-db4c58a8b913	t	Karongoro	4335f50a-08c2-4bf4-95f0-04f6e4eb877c
5b5ba5e8-9831-4713-a76b-b7e2eca7eb68	t	Mpinga	4335f50a-08c2-4bf4-95f0-04f6e4eb877c
1cc51748-0fa5-4c48-b4c4-8d22f5e7f128	t	Rebero	4335f50a-08c2-4bf4-95f0-04f6e4eb877c
a475e895-2b82-41fe-8adb-ce0b74d66111	t	Gatondo	7ea5e250-55a3-4dd9-b9e7-082b80f95051
5e638692-c265-4f98-9560-ebe5e56666aa	t	Honga	7ea5e250-55a3-4dd9-b9e7-082b80f95051
c3ab8641-842e-4437-881c-78284199200c	t	Kabinyugwe	7ea5e250-55a3-4dd9-b9e7-082b80f95051
2e283192-00b7-4553-8268-13f41be2fe14	t	Kamajumba	7ea5e250-55a3-4dd9-b9e7-082b80f95051
a4fdebde-50d7-4578-921e-df6e2b40f429	t	Muhora	7ea5e250-55a3-4dd9-b9e7-082b80f95051
950e42f0-ddd7-4506-9e39-cd835aa44dbe	t	Gako	89a563d9-4cda-453a-b5ae-44c848de4d41
f71f52d6-50b5-4f21-8f39-a7bdeaeb2689	t	Gatarange	89a563d9-4cda-453a-b5ae-44c848de4d41
164ec0bb-faa6-4ed9-bc19-d54c999709ed	t	Kigurwe	89a563d9-4cda-453a-b5ae-44c848de4d41
0a7565f0-0e41-4a5d-a09d-4d052283191b	t	Kinanira	89a563d9-4cda-453a-b5ae-44c848de4d41
ea46e56d-9d92-4b4f-8f9e-eb9ec4af765f	t	Kiyanza	89a563d9-4cda-453a-b5ae-44c848de4d41
b03c257e-1f15-4850-bb23-6c8d122b9d82	t	Nyarushishi	89a563d9-4cda-453a-b5ae-44c848de4d41
d9af3a1c-762c-4ba5-8164-8d5252508f9b	t	Rugabe	89a563d9-4cda-453a-b5ae-44c848de4d41
12524418-3482-49e4-8dee-e89b5928e788	t	Gacyamo	ae5288ab-a14c-4735-bdcb-2165bc8504b3
aecc1b5c-517b-49c7-8ca2-f69d7c561992	t	Gahuna	ae5288ab-a14c-4735-bdcb-2165bc8504b3
ace1d16d-ed0f-4bdb-b505-79581292f6d7	t	Gashyuha	ae5288ab-a14c-4735-bdcb-2165bc8504b3
d2dbc977-a2fb-489c-9bc6-0941d63dfe6e	t	Kanoga	ae5288ab-a14c-4735-bdcb-2165bc8504b3
5658e199-e4ec-4f4d-b1b7-237960e139ca	t	Kaveya	ae5288ab-a14c-4735-bdcb-2165bc8504b3
447040c0-26ba-482b-8b1a-936adb217d83	t	Kagabiro	d37e1396-a3ed-4e5d-8ce6-74e26413a572
66d2c59b-3535-4c00-9f7d-4ee5cbb7c82f	t	Bugumya	20f8a10e-c2d5-4f80-a109-d30171e8fb98
c3025ae1-0e8d-48ef-967d-4bac99865c90	t	Gatare	20f8a10e-c2d5-4f80-a109-d30171e8fb98
8e2aacb4-2728-43c3-a22f-191ae12c1e4d	t	Kamusana	20f8a10e-c2d5-4f80-a109-d30171e8fb98
cbbc8ddb-f606-403b-89ff-6a0b33281c28	t	Mpoga	20f8a10e-c2d5-4f80-a109-d30171e8fb98
277cb451-41e2-4184-af0b-1872f6199797	t	Mukondo	20f8a10e-c2d5-4f80-a109-d30171e8fb98
3bdb5c49-aa93-4aee-9c47-457746bce178	t	Murambi	20f8a10e-c2d5-4f80-a109-d30171e8fb98
bed8eefa-5e8a-4d2a-acc7-ef9dd381fbef	t	Nyakagoma	20f8a10e-c2d5-4f80-a109-d30171e8fb98
15f3ebf6-fb96-4650-88ad-d0f75d3cb7ff	t	Nyeshati	20f8a10e-c2d5-4f80-a109-d30171e8fb98
12782c1d-3e21-42ae-abc1-b05f382275d1	t	Segege	20f8a10e-c2d5-4f80-a109-d30171e8fb98
a5646720-8cd8-41b8-b76c-d17d6c085614	t	Shaba	20f8a10e-c2d5-4f80-a109-d30171e8fb98
c62a486d-2768-4bb7-8eaf-3e1c9c6c944e	t	Site	20f8a10e-c2d5-4f80-a109-d30171e8fb98
9c9d14f0-c302-4ff0-bf3c-cef73d143738	t	Bunyereri	95400147-30c3-45f5-a6c3-f095af484194
bdf19f81-61a5-4daa-84d1-7e0199febe23	t	Nkanga	95400147-30c3-45f5-a6c3-f095af484194
5d621196-d4ed-432e-9a29-41047cd48b47	t	Ruhinga	95400147-30c3-45f5-a6c3-f095af484194
486d5e7e-ff21-4530-83a9-3ccf0cba34d2	t	Rwimbogo	95400147-30c3-45f5-a6c3-f095af484194
60532e25-4639-4752-9c0a-ee427f7cc977	t	Kibirizi	40924256-731f-43dc-9bfa-5ef7889b3134
04576349-9bae-4bb4-9e6f-c830b99e8004	t	Nyamaronko	40924256-731f-43dc-9bfa-5ef7889b3134
a24060dc-8c6c-4239-a26a-0142519ceeb5	t	Ruganzu	40924256-731f-43dc-9bfa-5ef7889b3134
a413c9ca-800a-4192-a4dd-337bc90e49ec	t	Barenga	675a18c9-62d4-43e7-ab7b-3dad8a1ec8ae
335534fa-9282-4e74-86cf-bf75b5227bb4	t	Gakungu	675a18c9-62d4-43e7-ab7b-3dad8a1ec8ae
b8c5a9ea-a76d-49d3-bc01-672eb455f3d1	t	Mabuye	675a18c9-62d4-43e7-ab7b-3dad8a1ec8ae
1a38bdb8-7628-4f32-84a8-f2a32f87f854	t	Mizibira	675a18c9-62d4-43e7-ab7b-3dad8a1ec8ae
28662a2d-5e61-4149-acae-da71c29180f9	t	Peru	675a18c9-62d4-43e7-ab7b-3dad8a1ec8ae
a581a04d-0a88-4707-a9a8-07f397ae487e	t	Ryarubaka	675a18c9-62d4-43e7-ab7b-3dad8a1ec8ae
7256a6db-45e7-4eaf-af20-8e3e14ff46d9	t	Bigando	8888249e-21de-4b8e-879b-b6f9042a97fb
80f2dcf4-1542-4946-b2c7-701b492db143	t	Bitaba	83d035b5-30a6-47d9-8ee0-52bb7dacfa56
305dfda4-ebd9-4861-b31b-4148510b5d3c	t	Karambi	83d035b5-30a6-47d9-8ee0-52bb7dacfa56
f984aedd-36cb-4ec3-a151-c24543ce2666	t	Nyamugari	83d035b5-30a6-47d9-8ee0-52bb7dacfa56
e95c4f6c-6210-45d7-a258-0076323a21d4	t	Bisenyi	cb53cd40-05c6-4b41-9f7b-6d3b533f738e
ef43acf9-5fd8-460f-ae12-70d570b86c9d	t	Mashya	cb53cd40-05c6-4b41-9f7b-6d3b533f738e
997e089d-a18b-4b88-a1ef-1adda3ca8b9b	t	Mugerero	cb53cd40-05c6-4b41-9f7b-6d3b533f738e
392c9093-0193-48b3-b5aa-418a04388e9e	t	Nyamagana	cb53cd40-05c6-4b41-9f7b-6d3b533f738e
e020a99a-48a1-4fa5-9894-0a73f89be5b0	t	Kamanura	a465811c-e2fc-48f2-86ba-841b1b14468b
04ff95da-ba5f-4be1-95f2-252ce44534ea	t	Kanyovu	a465811c-e2fc-48f2-86ba-841b1b14468b
1609b222-e14f-4958-b3f4-2cf394c42926	t	Cyimbogo	62d5472d-028b-4219-a8cb-4a50cc7f2fb5
1a85a3e7-7462-4aa4-aef3-e3e989a87d22	t	Gihusi	62d5472d-028b-4219-a8cb-4a50cc7f2fb5
3d4e1d76-969c-4a8a-b183-8ee2fd61bcb0	t	Gituza	62d5472d-028b-4219-a8cb-4a50cc7f2fb5
99ebc9b0-000b-4163-ad2a-1500e6c005de	t	Gisovu	2d02901e-b607-4f1d-a68b-9be4da86182f
3ac8d2a1-fd3d-435b-b447-01038ac69f70	t	Njambwe	2d02901e-b607-4f1d-a68b-9be4da86182f
bfd5a7a7-45a0-4901-8ca0-9bc4f0d4338e	t	Runyanzovu	2d02901e-b607-4f1d-a68b-9be4da86182f
3b265180-13b2-4419-b27e-bbb46b49e119	t	Gataramo	f23359a7-a922-4503-910a-bc476abf98c2
8d106f53-ce76-4571-a062-85e2938016cb	t	Mugongo	f23359a7-a922-4503-910a-bc476abf98c2
d209fd09-f90c-48b9-971a-cc778d46a66b	t	Rusambu	f23359a7-a922-4503-910a-bc476abf98c2
8d66d098-4441-43a3-a17e-06181aa04a0c	t	Karunyerera	4181f3ec-8347-42d4-84f8-36330f793ad9
6a18eb17-7bac-46b8-a013-d91c03e2220b	t	Gacuriro	4de5e66c-4c2a-47c8-87fb-888b56256fe6
577b0140-4909-493a-b483-e7814e0eddc9	t	Nyagasozi	4de5e66c-4c2a-47c8-87fb-888b56256fe6
8b493dd0-9aba-49af-84f0-ef8d16c83bc0	t	Ryagashyitsi	4de5e66c-4c2a-47c8-87fb-888b56256fe6
dafa9080-7d38-4f83-a9f8-3b839239a681	t	Gasave	94814656-fdd0-4627-9719-ac1255df8a1b
abb651ca-0c40-4e1f-871f-2f39dfafdbff	t	Gatanga	039e664b-5411-41a6-b664-5e5c46862a09
dcbf428f-0455-4ba5-b619-9ee89db4f0b3	t	Nyabihanga	039e664b-5411-41a6-b664-5e5c46862a09
f3f92210-6aa3-41e8-88af-61385d6643e4	t	Kamabuye	4feabf56-2a22-4d91-b523-5ffd578f1b76
5a060d7b-1e19-465c-9b92-5d08b4ec2d09	t	Ntenyi	3aa4579f-56e6-4fc8-b854-707dd7793060
c373d922-f6fc-488c-a2fa-a70061c8158e	t	Bugarura	9386b8a3-e848-4719-bd09-d5ae8c2b3c87
70ce695b-8f53-4edb-b49a-a07946bb6509	t	Kabirizi	9386b8a3-e848-4719-bd09-d5ae8c2b3c87
7023b91b-82d7-4261-9cdd-5472f2133034	t	Kinunu	9386b8a3-e848-4719-bd09-d5ae8c2b3c87
7d40209d-c9b6-41fa-a1ff-36cc01d6417a	t	Muramba	9386b8a3-e848-4719-bd09-d5ae8c2b3c87
5fc689be-7661-47f7-a30d-93c55b4d7efd	t	Rwimbogo	9386b8a3-e848-4719-bd09-d5ae8c2b3c87
642fed83-dfeb-4a0b-ab3e-4fc0c882beb8	t	Buhonongo	03d93a99-306e-4ff0-8843-97b39bfeadd8
e86fbd79-3bc4-4921-bc1a-ebd51fbd2aa9	t	Bweramana	03d93a99-306e-4ff0-8843-97b39bfeadd8
f2f5b309-d977-403b-8670-3cf4d83d9c45	t	Gashoko	03d93a99-306e-4ff0-8843-97b39bfeadd8
bc6aebfa-36d5-455b-a664-94b03f71d6f2	t	Kamuyaga	03d93a99-306e-4ff0-8843-97b39bfeadd8
4c10c8a3-2cc6-4f62-a199-25e77d6444a7	t	Rugamba	03d93a99-306e-4ff0-8843-97b39bfeadd8
ccf193aa-57bb-48db-8679-69ff08385eb1	t	Rwabisururu	03d93a99-306e-4ff0-8843-97b39bfeadd8
d734f6bd-afcf-4899-8725-5fbff7e05c99	t	Gisiza	c5602675-35cd-4abd-b652-025e11e57585
6f3bcd3f-a964-4ef5-b178-a8510f083748	t	Gisoro	c5602675-35cd-4abd-b652-025e11e57585
4faa27cc-73d0-4005-9dfd-3a450d88d6d9	t	Karukamba	c5602675-35cd-4abd-b652-025e11e57585
8fb95aac-f13f-45cf-a897-46e1474cdfab	t	Kigarama	c5602675-35cd-4abd-b652-025e11e57585
0e9064bf-4d2e-4f75-b306-9de358ba2658	t	Munanira	c5602675-35cd-4abd-b652-025e11e57585
1e8fed61-defb-4c16-8d7d-a3da874d0867	t	Murambi	c5602675-35cd-4abd-b652-025e11e57585
6b8e2f06-9844-4cb3-a3ba-78ef959941fd	t	Bigabiro	439f61d3-6904-4dcd-8780-79d633b65fc8
1686a257-aa52-4283-9499-82ee17196f10	t	Buhoro	439f61d3-6904-4dcd-8780-79d633b65fc8
1a5e9a51-8f4f-4b46-bdb3-9b6531cd8ce7	t	Kaganza	439f61d3-6904-4dcd-8780-79d633b65fc8
69bcf25f-c4c9-4c64-966d-ed5993e2b217	t	Kamuzigura	439f61d3-6904-4dcd-8780-79d633b65fc8
cf103e56-5a71-4bf9-8eab-686ac1183559	t	Muyange	439f61d3-6904-4dcd-8780-79d633b65fc8
bcb33e83-0cf5-4e41-9669-7ab1c42b113b	t	Gishushu	25637fae-624c-41d6-aa39-ab48bdf4b97c
64d2ebf2-81ed-417f-90d0-3e403a264e22	t	Gitarama	25637fae-624c-41d6-aa39-ab48bdf4b97c
64e6f6ec-ca15-483e-a899-0688df730761	t	Kagarama	25637fae-624c-41d6-aa39-ab48bdf4b97c
7b003496-b9ca-489f-a380-fc1bc7dcaea5	t	Karambi	25637fae-624c-41d6-aa39-ab48bdf4b97c
2d4570b3-f578-4422-84dd-54c1b0440d0e	t	Kandahura	b336470f-6d4c-4805-b099-4e6f03d739c7
ed49a623-c8f3-4631-bcd9-92eabd27b6d4	t	Kindoyi	b336470f-6d4c-4805-b099-4e6f03d739c7
112def85-2ef8-4544-b811-0c03fca2f0ce	t	Mukebera	b336470f-6d4c-4805-b099-4e6f03d739c7
52b64956-fde9-40b8-9c71-936e65864723	t	Nduba	b336470f-6d4c-4805-b099-4e6f03d739c7
41b9ed87-5df0-48b1-b7c7-bc25a8c4ed4d	t	Nkwiro	b336470f-6d4c-4805-b099-4e6f03d739c7
194ad6f0-593c-4838-a38c-cc6fb82f514e	t	Butare	facaaa94-ac35-4293-b3d1-9de2d14102f1
8cc5922f-cb96-43b2-8fce-5cf73c38eb70	t	Kamutambiro	facaaa94-ac35-4293-b3d1-9de2d14102f1
8098a3df-2261-4b2a-899a-98814ada8776	t	Terimbere	facaaa94-ac35-4293-b3d1-9de2d14102f1
428a21b4-deee-4405-8936-50b8e6d19321	t	Gatomvu	4f5ce870-f46e-40ef-9977-591733f22e77
6c87b875-19f7-4fdd-808b-871ae682dad9	t	Karugaju	4f5ce870-f46e-40ef-9977-591733f22e77
bb9a6d1d-d2a9-4309-bbaa-97bc851d5f65	t	Muhora	4f5ce870-f46e-40ef-9977-591733f22e77
90f9d91f-02cf-4ef5-84ab-5c13b91e4a5a	t	Gasharu	6829636f-67fe-4dd1-a521-c64d45801250
3fbdc6d2-bdab-4144-affa-30d617ed8990	t	Kabuga	6829636f-67fe-4dd1-a521-c64d45801250
68a01597-9cee-42f5-9d4a-cff0e681482d	t	Nyagahinga	6829636f-67fe-4dd1-a521-c64d45801250
95a930a5-9584-4cf2-87c9-875f7c02605a	t	Gisunzu	938c13a6-3ef7-47f1-a121-653ba8d3737b
83e3eb86-141c-4e4b-985d-67a85a78e925	t	Karongi	938c13a6-3ef7-47f1-a121-653ba8d3737b
62d45e48-f130-44c8-b28b-c44c97f65c13	t	Rugote	938c13a6-3ef7-47f1-a121-653ba8d3737b
f0849feb-28b0-4424-bd56-d86b2f1eafa3	t	Rwamiyaga	938c13a6-3ef7-47f1-a121-653ba8d3737b
f9fbcdcc-63ef-4122-9d51-a7ae4f18907c	t	Bweramana	ef63dfe3-6aad-40c7-a197-5293788ec352
9471168c-d5a2-4dc5-a03a-23604fe672c3	t	Gasave	ef63dfe3-6aad-40c7-a197-5293788ec352
fb467f3d-2ec7-4b15-8b48-47d3cf1c06d8	t	Gateja	ef63dfe3-6aad-40c7-a197-5293788ec352
bb1c979e-5461-44e1-9676-95f82699c303	t	Rasaniro	ef63dfe3-6aad-40c7-a197-5293788ec352
2c3728ac-651b-4cbd-a341-4b137c084cdf	t	Gisiza	91307fd4-0e85-4a55-be79-cc0600c7cfd9
388fcdf4-4474-49d5-a41b-7aaa92abf8b8	t	Nkamba	91307fd4-0e85-4a55-be79-cc0600c7cfd9
30caad55-9d3b-4168-a730-98c3338010ee	t	Nturo	91307fd4-0e85-4a55-be79-cc0600c7cfd9
5850b69d-4514-42e3-bc64-0cea8cdff2dc	t	Buhimba	9f8f7092-5a37-4a82-885c-c873d4bf8713
79ca108e-a54b-4dbe-ba43-8901fe150dad	t	Gahotora	9f8f7092-5a37-4a82-885c-c873d4bf8713
97c0d927-11d9-4544-ad3c-4cb43dd9450d	t	Gasagara	9f8f7092-5a37-4a82-885c-c873d4bf8713
2aaa91d1-5aef-4e5a-aa79-fb22aa5f15b6	t	Humiro	9f8f7092-5a37-4a82-885c-c873d4bf8713
a6df07db-7dc6-4b11-95d0-510b440df77d	t	Kabashyembe	9f8f7092-5a37-4a82-885c-c873d4bf8713
3cf7c148-8a6b-45b5-a8f0-33b7ffd5083c	t	Kanyirahweza	9f8f7092-5a37-4a82-885c-c873d4bf8713
2f90759f-f9ec-4098-885c-882af1d69110	t	Kigugu	9f8f7092-5a37-4a82-885c-c873d4bf8713
b8b43ab9-40c6-4ce9-a2f5-f76704262362	t	Rukundo	9f8f7092-5a37-4a82-885c-c873d4bf8713
ceee362b-7486-4b49-90e9-2485bfbf93ca	t	Kampi	aa500ba2-1d9a-4ce4-83b3-03eca944add4
f9ed9d74-5366-4efa-9e4f-ccee80115321	t	Rugabi	aa500ba2-1d9a-4ce4-83b3-03eca944add4
50e5c79d-7793-43b9-81a4-2bd63057836c	t	Rukombe	aa500ba2-1d9a-4ce4-83b3-03eca944add4
9c722d52-6f69-4e5d-867a-b8813fb3752a	t	Rupango	aa500ba2-1d9a-4ce4-83b3-03eca944add4
c05fa0b9-aaa1-4691-b340-06af260ae2aa	t	Rusisiro	aa500ba2-1d9a-4ce4-83b3-03eca944add4
039c63a5-ab16-401e-b49b-824c8fb99eb8	t	Ruvumu	aa500ba2-1d9a-4ce4-83b3-03eca944add4
b0255820-a154-49d0-a47e-c3353cee5f52	t	Gahunga	e2d47e05-ce7a-4374-9823-8e221b3e38bf
db6dbd91-78da-4883-8e51-8cbc77d3ae46	t	Kinihira	e2d47e05-ce7a-4374-9823-8e221b3e38bf
78332b0a-0cd1-4e47-a2db-3f44f594c023	t	Murambi	e2d47e05-ce7a-4374-9823-8e221b3e38bf
1fc12650-90fc-4e3d-a29b-99ef946d373e	t	Nganzo	e2d47e05-ce7a-4374-9823-8e221b3e38bf
77409a74-2157-4704-8fd2-5386a6a4fe3e	t	Rwamiyaga	e2d47e05-ce7a-4374-9823-8e221b3e38bf
028e14b2-e61b-4aad-9e71-989c3cf5e5c1	t	Tagaza	e2d47e05-ce7a-4374-9823-8e221b3e38bf
b4b25e43-8fac-439f-ace5-3e816f48ff2a	t	Bureke	d876c0da-6e35-4899-992d-20718b1aeaf3
f884a7f3-dca5-4f30-b0b7-0fc7eaf0f097	t	Gihari	d876c0da-6e35-4899-992d-20718b1aeaf3
94d33fb2-7f29-4b98-a609-56f587af4a30	t	Gitwa	d876c0da-6e35-4899-992d-20718b1aeaf3
92914632-4c12-446a-ad67-9a199f33054c	t	Kanyempanga	d876c0da-6e35-4899-992d-20718b1aeaf3
cf952f6b-a416-4792-9980-f608039e11e2	t	Nyarubuye	d876c0da-6e35-4899-992d-20718b1aeaf3
f5b03e90-c557-490a-ab2b-cd7f070885aa	t	Cyivugiza	4be2f1cc-ae26-4fce-bf8d-160479fff6b0
d9e0fb7e-8b55-4e92-a4b7-0aaa449981a8	t	Kamabuye	4be2f1cc-ae26-4fce-bf8d-160479fff6b0
98f046f7-f078-4449-b24b-8afb9f70f607	t	Karungu	4be2f1cc-ae26-4fce-bf8d-160479fff6b0
796bfd13-ff57-4e08-8d9d-3120728a9c47	t	Mpinga	4be2f1cc-ae26-4fce-bf8d-160479fff6b0
9f71edd4-c724-478e-b6f3-8c021a46c8cd	t	Rwamvura	4be2f1cc-ae26-4fce-bf8d-160479fff6b0
bca8ffd6-f435-4fad-b49e-0e19c10ffe72	t	Tarafiporo	4be2f1cc-ae26-4fce-bf8d-160479fff6b0
0f6f43c4-d07a-4dd7-bc9e-7de26023ec31	t	Burambo	88f3b3ca-7d3f-46bd-8fe4-ee9bd67f0c25
c9ef3eb8-94c6-4554-9bc8-5ac9e3d478dc	t	Burango	88f3b3ca-7d3f-46bd-8fe4-ee9bd67f0c25
726c722b-2ffe-4e7e-ab8c-747c52cea91b	t	Cyato	88f3b3ca-7d3f-46bd-8fe4-ee9bd67f0c25
dc62ca3e-f75a-4a96-91fe-a48b90c09491	t	Kabitara	88f3b3ca-7d3f-46bd-8fe4-ee9bd67f0c25
54b7fcc4-bfef-4ce3-bdba-50e8c37725ce	t	Kagera	88f3b3ca-7d3f-46bd-8fe4-ee9bd67f0c25
3b384196-2423-4222-ac7a-797f1c0b7056	t	Bitare	d6a4380d-76da-46eb-b090-a07aea58ebd6
b7b18065-c0a4-4baa-a97e-c3d84b25b9bb	t	Bukiro	b1fc0d3e-7389-4bd9-a702-c595a485fb1e
70455223-bc12-4a9e-9bd8-e865cf85cee8	t	Bukumba	b1fc0d3e-7389-4bd9-a702-c595a485fb1e
c2297e1a-8a93-45d1-9b45-786fb31eebd7	t	Buroha	b1fc0d3e-7389-4bd9-a702-c595a485fb1e
9a1c9e62-a227-446e-adc7-793d4d2ada47	t	Bushamba	b1fc0d3e-7389-4bd9-a702-c595a485fb1e
c951979e-8168-4045-931d-9fc360fc47df	t	Kabuga	b1fc0d3e-7389-4bd9-a702-c595a485fb1e
d62d985c-e603-4343-81da-aaa2a1def168	t	Nyundo	b1fc0d3e-7389-4bd9-a702-c595a485fb1e
cf645d1f-6da2-4776-8547-68fa2979ca0e	t	Rusumo	b1fc0d3e-7389-4bd9-a702-c595a485fb1e
9ebd8cc8-4acc-4b24-96db-7382d10782f2	t	Kamwimba	d1a8e075-3a52-4479-9048-a641368f0499
4819c9c2-96c7-4e03-aa93-d85b7e3740f4	t	Muramba	d1a8e075-3a52-4479-9048-a641368f0499
cb39d32b-d7dc-4338-997b-ebddb53593c1	t	Remera	d1a8e075-3a52-4479-9048-a641368f0499
1a1db217-2874-4523-9d24-a040aad93da1	t	Rwinyoni	d1a8e075-3a52-4479-9048-a641368f0499
e6443273-017e-4807-b5c1-87c04a44ae34	t	Tawuni	d1a8e075-3a52-4479-9048-a641368f0499
6d51d2e5-751d-4f83-af13-a3114e856e9f	t	Bitabaro	c4029e8a-3a79-4310-97e6-e6b9f8f02c76
17aa71b6-c558-4b49-baad-9617a480be4f	t	Gitwe	c4029e8a-3a79-4310-97e6-e6b9f8f02c76
8ee0ec12-2864-4f0d-956f-8f9691606a8b	t	Kivumu	c4029e8a-3a79-4310-97e6-e6b9f8f02c76
6aa01f65-de64-403c-9516-5f1a4c01c133	t	Kagarama	13e5ab56-1573-4b28-8b74-4ceee6058942
34affa54-5bb4-45d0-8649-12359195b25c	t	Kamishunguro	13e5ab56-1573-4b28-8b74-4ceee6058942
7e068338-3fc5-4de1-a390-07dd434a6dec	t	Kanama	13e5ab56-1573-4b28-8b74-4ceee6058942
61702c53-78c3-422a-b217-06ad687713db	t	Kimpongo	13e5ab56-1573-4b28-8b74-4ceee6058942
b26b4b8b-380d-40d6-ad60-19de8735b18a	t	Mujebeshi	13e5ab56-1573-4b28-8b74-4ceee6058942
4d9139cc-dd29-4ed0-8dca-b404ab7d26f3	t	Muyira	13e5ab56-1573-4b28-8b74-4ceee6058942
7261374a-30fd-425c-82b3-ecaeb9429282	t	Nyakarambi	13e5ab56-1573-4b28-8b74-4ceee6058942
7a7b7998-db44-4c50-ade6-e7188e1f8f0b	t	Rutare	13e5ab56-1573-4b28-8b74-4ceee6058942
504be89d-79b9-44e3-b8d4-01e841f1364a	t	Kanama	076e7033-1e35-48d9-af51-888d6d262ff6
1469e114-2076-4fd1-845f-e24e26469f18	t	Kabacuzi	49502fe0-540f-4483-a203-e601d04b0380
a409927c-9d70-4b87-8926-84970682da00	t	Kagano	49502fe0-540f-4483-a203-e601d04b0380
1a9448ca-0d32-4ac0-8713-cb6c773dfb9a	t	Kamonyi	49502fe0-540f-4483-a203-e601d04b0380
d345c67f-695e-4669-a206-b038bf2f27a5	t	Kazizi	49502fe0-540f-4483-a203-e601d04b0380
b6c79b50-5684-409b-b0dc-96ef8877056f	t	Kiriba	49502fe0-540f-4483-a203-e601d04b0380
3f2e1aff-69af-4b92-8945-4e8e357af3e4	t	Ntobo	49502fe0-540f-4483-a203-e601d04b0380
75200d68-0dc8-4591-a0fe-8b0f055da02f	t	Kigeyo	ec0172fd-a18c-428d-93ba-a08383f34064
ffa1c4ae-c2e0-4012-af4a-8b91c1dc3f32	t	Kimishishi	ec0172fd-a18c-428d-93ba-a08383f34064
902bdcab-97a9-4c48-8db6-d6e7c230fcb6	t	Site Mukura y	ec0172fd-a18c-428d-93ba-a08383f34064
e38db995-f9e0-476a-93cc-a5ef61777826	t	Dehero	4036fd79-8a44-486d-b0ec-cc4202f77178
d949ce63-90e0-4955-b41a-dd1f67c8716e	t	Gasambi	4036fd79-8a44-486d-b0ec-cc4202f77178
61abbe58-41d7-4e64-83b9-549caf3b9345	t	Karambo Ya 2	4036fd79-8a44-486d-b0ec-cc4202f77178
cd890cf4-9e76-494a-ae34-d76f7ae8bd10	t	Gafu	2bfce96b-5aa6-418a-aba1-dd4600c12b31
5bcde60e-2688-4711-ab90-d08243076b77	t	Gako	2bfce96b-5aa6-418a-aba1-dd4600c12b31
ddc66da7-1402-4b21-8706-0d2da99df4ae	t	Mataba	2bfce96b-5aa6-418a-aba1-dd4600c12b31
0ee17b71-037e-42f6-9910-497bfd471a6a	t	Nyarubande	2bfce96b-5aa6-418a-aba1-dd4600c12b31
8688ccb4-a06d-44be-9dc1-ee4d047233ce	t	Nyarusongati	2bfce96b-5aa6-418a-aba1-dd4600c12b31
47cc3076-8ba4-4442-8daa-f0d3b5627159	t	Gasasa	eec018f0-955c-41b5-877b-dd8ce81bbf28
302560ec-7dfc-478a-866c-155652162968	t	Karumbi	eec018f0-955c-41b5-877b-dd8ce81bbf28
f3e31322-4af0-48b8-8341-b0f2fc340aaf	t	Muremure	eec018f0-955c-41b5-877b-dd8ce81bbf28
2e591b85-0de3-4d6e-9c1d-a759a97d4b7a	t	Kamuhoza	e21c6362-b560-48fc-8f4b-d1fecfc2924b
190ec102-afcc-49c4-8db9-33dc99e86ac1	t	Murunda	e21c6362-b560-48fc-8f4b-d1fecfc2924b
a7fa5b48-adba-4bce-862e-67d69da6b773	t	Rurimba	e21c6362-b560-48fc-8f4b-d1fecfc2924b
94cf367e-e61f-4afd-9057-f00cb044e2b7	t	Kamusambi	d4021150-186f-4a8e-b0fa-626cc2909988
1235b3df-0772-4068-a625-4460933776db	t	Karambo	d4021150-186f-4a8e-b0fa-626cc2909988
a178c216-5c72-4f4f-b0a3-2e66e71a9e75	t	Musongati	d4021150-186f-4a8e-b0fa-626cc2909988
6d60448e-d3ba-4fff-9f2c-221548443337	t	Gatare	eae278e4-15e9-4338-9b16-28e9aca17250
59aafbe9-6cd0-41ff-8573-f9d71d0d714b	t	Rwanika	eae278e4-15e9-4338-9b16-28e9aca17250
51554b82-1cad-4457-ac97-163fe5e7af67	t	Rwoza	eae278e4-15e9-4338-9b16-28e9aca17250
ef725d8f-97bd-458e-80db-05835a41c910	t	Gabiro	06cb41e0-f0bf-43b1-80f3-6fb012a143fe
12a21c6a-7d72-4bd5-b7bc-5f21bf89fab7	t	Gitwa	06cb41e0-f0bf-43b1-80f3-6fb012a143fe
8eb95e87-ca4a-482e-994e-47bff30a8ee9	t	Murama	06cb41e0-f0bf-43b1-80f3-6fb012a143fe
cec712ba-aa85-4c9d-8a08-fa29711f4edf	t	Nyarugenge	06cb41e0-f0bf-43b1-80f3-6fb012a143fe
1bc75d87-e959-466b-a127-ec32d8985219	t	Rugarambiro	06cb41e0-f0bf-43b1-80f3-6fb012a143fe
a523ff6b-3478-441d-ab9d-8b0eae35df9a	t	Bweramana	6ba675a1-b3ee-475e-9f2d-fcc1dfa43ccb
e74afe4e-e551-4c62-a36c-a5d08a28d286	t	Gihinga	6ba675a1-b3ee-475e-9f2d-fcc1dfa43ccb
9b1508aa-9369-40cd-9be8-7da758fe4b80	t	Gisiza	6ba675a1-b3ee-475e-9f2d-fcc1dfa43ccb
7b263ad6-556b-4605-8908-5910bc70f338	t	Karambi	6ba675a1-b3ee-475e-9f2d-fcc1dfa43ccb
9e8e184b-c08d-400c-91a1-4bbe2a74d601	t	Ngoma	6ba675a1-b3ee-475e-9f2d-fcc1dfa43ccb
51390e82-774f-4028-9f88-e67125dd2546	t	Bunnyari	db1e308d-5e7f-472d-aaab-99a449a4f7ab
06783f51-c3f9-4a09-9cd0-fbc0b750e95d	t	Murambi	db1e308d-5e7f-472d-aaab-99a449a4f7ab
c90d1551-697d-427b-a534-6d4caa880a38	t	Mirambi	714a68f5-c53f-460b-97d3-79c84c3c29e1
50608f47-fa0d-48d6-8c50-d65aaa3e865d	t	Muhororo	714a68f5-c53f-460b-97d3-79c84c3c29e1
aefc67b7-5f61-4139-9c2e-5aacb6c48008	t	Rebero	714a68f5-c53f-460b-97d3-79c84c3c29e1
e86e3633-169e-42b0-83bc-7b9ad3dbcf0d	t	Buhunde	c7604c88-50e9-4003-93ad-90c7f75b1702
b663ed97-96e7-42bc-adf5-964cbf0b3774	t	Buzukira	c7604c88-50e9-4003-93ad-90c7f75b1702
4df5c29c-9fa5-45c9-97c1-3e39a6a4a2db	t	Kamaranzara	c7604c88-50e9-4003-93ad-90c7f75b1702
29d80351-20d2-48ab-bc73-3f216833bdfd	t	Karengera	c7604c88-50e9-4003-93ad-90c7f75b1702
332e3ac3-17a1-44e7-99a9-0297445af73e	t	Mugara	c7604c88-50e9-4003-93ad-90c7f75b1702
7d37214b-2406-44d9-8b31-de5a8b1be51b	t	Rurimba	c7604c88-50e9-4003-93ad-90c7f75b1702
7699ee8c-e7a8-4150-a881-e66fe46fbea3	t	Mubuga	d99fe649-66e7-415e-bc1a-dfd605f3adb6
23ebe98d-0947-4c68-9953-9691b2dc613e	t	Rugerero	d99fe649-66e7-415e-bc1a-dfd605f3adb6
684fbcec-469b-406b-b246-d16ae8e5107d	t	Ryarwasa	d99fe649-66e7-415e-bc1a-dfd605f3adb6
2d41d2e2-1ce2-4dac-a68a-80449cff60a6	t	Gasave	9b5e47b8-6082-4bf3-be77-c179f271bb8f
430aa336-eb3f-4e30-8859-baf47c7f8e1f	t	Kakibaba	9b5e47b8-6082-4bf3-be77-c179f271bb8f
1c7b3051-4dbc-44c0-995f-b17050d54db4	t	Kariba	9b5e47b8-6082-4bf3-be77-c179f271bb8f
42fb01b6-7bc5-4ca6-9cf4-1422e84b8da0	t	Nkomero	9b5e47b8-6082-4bf3-be77-c179f271bb8f
5abd5840-5d88-4dc4-b1be-e1ab76af1ccf	t	Ruyogoro	9b5e47b8-6082-4bf3-be77-c179f271bb8f
4c009973-719d-46f1-829e-a98d65d47224	t	Gasoro	7295729a-1383-4c51-9816-b5993ccf6648
77bb71f8-51df-4283-9e62-a45ffe9250b6	t	Kaboneye	7295729a-1383-4c51-9816-b5993ccf6648
92a93d2e-af31-4125-85d1-dce249bff9b6	t	Kagano	7295729a-1383-4c51-9816-b5993ccf6648
9bf370a9-706a-4928-b9bc-17177230c5d5	t	Kashishi	7295729a-1383-4c51-9816-b5993ccf6648
61e4ced8-90c7-4237-b422-49620e4ace84	t	Mukati	7295729a-1383-4c51-9816-b5993ccf6648
f6685236-b305-4520-bae8-5a979a454342	t	Ngunguru	7295729a-1383-4c51-9816-b5993ccf6648
17f35d30-323c-49ac-b7cd-675dd0ab08ce	t	Rugaragara	7295729a-1383-4c51-9816-b5993ccf6648
ca3e10d1-0089-4b46-8a95-66c4fa25a29f	t	Ruhengeri	7295729a-1383-4c51-9816-b5993ccf6648
2f1af783-6f04-4aa5-86d2-9adcdef19a7b	t	Bisyo	647da765-a878-41d5-9e94-bc3fd0660b64
bf6b32f9-036b-4b68-ba91-f7e35cf8d553	t	Kabiraho	647da765-a878-41d5-9e94-bc3fd0660b64
625af923-cacb-46ab-998e-c39d284d385f	t	Kamushozi	647da765-a878-41d5-9e94-bc3fd0660b64
f0523541-5782-4437-b61b-6f37895acd16	t	Karambi	647da765-a878-41d5-9e94-bc3fd0660b64
6c01dfb8-91ff-406b-b235-eece9e81c82e	t	Mataba	647da765-a878-41d5-9e94-bc3fd0660b64
047e6d90-9191-473c-82af-5d6f9f48155f	t	Ruhinga	647da765-a878-41d5-9e94-bc3fd0660b64
8ade8149-fed5-4f4a-b000-e390d08d9580	t	Kunini	778c162d-986f-4cc3-8aea-49f2414f9a18
797a9d6c-e9fb-40cd-abec-76e311bc80e4	t	Gakoma	b02ab216-0a3d-435e-adc0-8e962fe1393c
fe024119-4501-4a6b-81e7-3d1b35f1f561	t	Karambira	b02ab216-0a3d-435e-adc0-8e962fe1393c
a48cae69-a7df-4275-8ef2-0b1de110a6c2	t	Mugote	b02ab216-0a3d-435e-adc0-8e962fe1393c
438c71b0-5a8a-4803-ae4c-2164ff6ef75b	t	Rububa	b02ab216-0a3d-435e-adc0-8e962fe1393c
8609453c-6143-4609-a071-9156b6878b55	t	Ruhinga	b02ab216-0a3d-435e-adc0-8e962fe1393c
45324594-3160-4e54-85e6-df16f3744f37	t	Rwintore	b02ab216-0a3d-435e-adc0-8e962fe1393c
df85e728-e200-4d7c-bb88-04cb59e2e35a	t	Gitega	6acaf836-a392-4444-a764-78e61b9c8f35
b6e18df6-28ab-42dc-907c-600c6b73addc	t	Murambi	6acaf836-a392-4444-a764-78e61b9c8f35
d0d8d608-a7fb-40cf-b979-e4425d404a52	t	Nyarusange	6acaf836-a392-4444-a764-78e61b9c8f35
27bbaf04-df05-4f3f-9ce9-00f9aa9e8abb	t	Rushikiri	6acaf836-a392-4444-a764-78e61b9c8f35
6127db2e-0b00-43ab-a6e7-3671510a8058	t	Kabuga	a9df307e-4deb-451a-b0c5-0f1385d849f2
0dfc7613-8145-442a-a700-f449beb7ab4a	t	Kaduha	a9df307e-4deb-451a-b0c5-0f1385d849f2
44527987-a48a-402a-86da-b97deba4d4bc	t	Kagugu	a9df307e-4deb-451a-b0c5-0f1385d849f2
6e24aeee-1780-4827-9b59-74c6f5df1d41	t	Kanyinya	a9df307e-4deb-451a-b0c5-0f1385d849f2
2873c5f7-df1c-4658-bb71-0ed95915fbc4	t	Kivumu	a9df307e-4deb-451a-b0c5-0f1385d849f2
f9dd1108-79c0-4c49-b0b8-20f3dfc5cf93	t	Nyagahinga	a9df307e-4deb-451a-b0c5-0f1385d849f2
0d0c8cc7-572c-4d72-9694-f3acc7e99010	t	Nyamahuru	a9df307e-4deb-451a-b0c5-0f1385d849f2
0e9334da-c11e-497c-b4c8-25f2eacf9587	t	Busuku	dd77a42c-7bb9-44d0-8492-558ae59a29bf
5bc19873-2047-4c9e-87a8-a7af2e9cfc14	t	Busuti	dd77a42c-7bb9-44d0-8492-558ae59a29bf
f2458b32-580b-4e21-b7df-b00043118b46	t	Bwiza	dd77a42c-7bb9-44d0-8492-558ae59a29bf
5b56c578-0f70-4e04-9916-a66e43a5f927	t	Ngugo	dd77a42c-7bb9-44d0-8492-558ae59a29bf
71b4b319-5ebe-4bea-90e0-6c1a5ed68b9b	t	Nyakibande	dd77a42c-7bb9-44d0-8492-558ae59a29bf
7083181b-02be-4deb-ac61-f23d69d94fdd	t	Rwamigega	dd77a42c-7bb9-44d0-8492-558ae59a29bf
9bd32404-1081-425e-927f-18f4f54623a7	t	Torwe	dd77a42c-7bb9-44d0-8492-558ae59a29bf
4f1d5fbe-10bb-4ab6-8e5f-a0ab5633c4eb	t	Tsindiro	dd77a42c-7bb9-44d0-8492-558ae59a29bf
25014b86-0463-4846-ae29-7732c9eec93f	t	Gakumba	9403bcda-8ad4-4582-9421-9dedbd5246fe
f1e1438d-28b0-40ff-acaf-557ad93c553d	t	Kamananga	9403bcda-8ad4-4582-9421-9dedbd5246fe
7bff024a-1fad-47f9-bc12-275f87700bac	t	Nyabishongo	9403bcda-8ad4-4582-9421-9dedbd5246fe
cafcc090-d494-42f1-b4f5-3086b1f5961f	t	Rukomero	9403bcda-8ad4-4582-9421-9dedbd5246fe
e0b47d4f-49e1-45d2-b8e1-86bec892381b	t	Gashihe	f1fff4ef-03d8-41ea-9784-be96eed98d2f
09561b25-ff48-454d-92d2-630fc90e9374	t	Kaje	f1fff4ef-03d8-41ea-9784-be96eed98d2f
c6c43780-c90c-4347-b647-a0d0175da5f6	t	Kazo	f1fff4ef-03d8-41ea-9784-be96eed98d2f
47e2a93c-75ee-43b2-b8bf-5b6ae6023a59	t	Mpati	f1fff4ef-03d8-41ea-9784-be96eed98d2f
2b64cd56-c466-40b8-a18a-6dc497c095d7	t	Nkuna	f1fff4ef-03d8-41ea-9784-be96eed98d2f
691a1381-fe6b-424e-a141-af4513a88724	t	Gihinga	3860dc7a-8b6f-45b9-a0a5-fc17f90c1614
8562c381-939b-4da6-b8f8-2d61699fdfba	t	Kanombe	3860dc7a-8b6f-45b9-a0a5-fc17f90c1614
c0fad5c5-1274-4266-8576-68867a89aeda	t	Kasonga	3860dc7a-8b6f-45b9-a0a5-fc17f90c1614
797b9c38-796f-49a2-80ee-1facd5fa8d87	t	Kinyamavuta	3860dc7a-8b6f-45b9-a0a5-fc17f90c1614
9ac81ec8-1bb0-40fd-a2f7-03c58ab9e239	t	Negenero	3860dc7a-8b6f-45b9-a0a5-fc17f90c1614
5f8cadd3-982f-4088-a2c3-297a685819b3	t	Nyampengeri	3860dc7a-8b6f-45b9-a0a5-fc17f90c1614
b05daaf8-397f-484d-9eb8-590763bb263c	t	Ruraji	3860dc7a-8b6f-45b9-a0a5-fc17f90c1614
32384203-9ad6-4dfc-be2b-400f36782423	t	Rwangambuto	3860dc7a-8b6f-45b9-a0a5-fc17f90c1614
de73f9c0-2a89-494f-b5fe-39246486dce1	t	Ryanyiramuno	3860dc7a-8b6f-45b9-a0a5-fc17f90c1614
d2932c09-67b0-4e84-8c08-264aa92c0bf2	t	Gasovu	ad7eee21-d12e-43f0-8848-6077d15169a7
4e50c44f-ef85-40fe-b75b-e574c452a2c6	t	Kamuramira	ad7eee21-d12e-43f0-8848-6077d15169a7
acb49c03-5856-496d-88e1-a3f69af74a50	t	Mwurire	ad7eee21-d12e-43f0-8848-6077d15169a7
a4db4b76-2615-4171-b984-06d83847286e	t	Ruhimbi	ad7eee21-d12e-43f0-8848-6077d15169a7
91e51be1-0a9c-4441-83aa-dea046638302	t	Rukenesha	ad7eee21-d12e-43f0-8848-6077d15169a7
b2b4431c-d85b-49a9-ae99-94da3ab75a17	t	Bitenga	a8a60341-324b-4d99-8719-f10c9461bef1
8a9a3a90-fcdc-4813-bff7-ac2967e49f54	t	Busenda	a8a60341-324b-4d99-8719-f10c9461bef1
188e7ced-fb72-4013-b02b-acee54c1f967	t	Murambi	a8a60341-324b-4d99-8719-f10c9461bef1
89f8e0bb-54e7-4ea8-baae-2df4d08072c2	t	Tara	a8a60341-324b-4d99-8719-f10c9461bef1
e4e686f4-a5b4-49b2-8c21-d681c5a06fbf	t	Gakeri	a625e24f-3313-442e-9485-1d5ea6de3c63
a386b442-b1ec-4937-a531-6c1ee2f22c16	t	Gasasa	a625e24f-3313-442e-9485-1d5ea6de3c63
7ecd25f6-32fe-4540-b415-7151f4e79527	t	Gasunzu	a625e24f-3313-442e-9485-1d5ea6de3c63
208c9c61-7c42-4723-b9f8-d4cb51acbef0	t	Mubirizi	a625e24f-3313-442e-9485-1d5ea6de3c63
cb217559-cf5a-424b-afb2-080b27545772	t	Muhingo	a625e24f-3313-442e-9485-1d5ea6de3c63
e4a6d8c8-1785-4256-be1b-32431cdaa1b6	t	Nyundo	a625e24f-3313-442e-9485-1d5ea6de3c63
e802b2eb-2ba5-4f0f-b7dc-79e36aac5b72	t	Buzeyi	3bdab947-c466-45c7-b45f-de9351db6d78
5b321adb-99e2-45e1-b6a8-d94d8da922f7	t	Kabeza	3bdab947-c466-45c7-b45f-de9351db6d78
f4749fce-9eaa-4ccc-94fa-35ebc0ed5b56	t	Kayove	3bdab947-c466-45c7-b45f-de9351db6d78
6302b41e-c910-48df-a57c-424318519ee9	t	Mugali	3bdab947-c466-45c7-b45f-de9351db6d78
a7d535a5-5bed-43e8-b7d6-503fe28bb9e3	t	Kabitovu	cc0f5c48-0e9f-4b38-95cd-4291c36558f9
98f64dab-b7b7-4361-835b-3dabcc7fe8bd	t	Kaziga	af7657e3-3336-4a87-b898-da2b7157f557
e7441217-dd11-461b-b1c6-f8da5b8d91fe	t	Matyazo	af7657e3-3336-4a87-b898-da2b7157f557
2143bc56-77a7-4ac9-b251-3b88210754a6	t	Byiniro	56f98323-ec46-4517-a6f9-24a30632fbd2
5acf959e-c1a7-476f-89b4-e1776c22d1bd	t	Nyagasambu	56f98323-ec46-4517-a6f9-24a30632fbd2
88c21f80-f4dd-4134-acdb-27b262442ad4	t	Rwamvura	56f98323-ec46-4517-a6f9-24a30632fbd2
22e4c85a-9e59-4a81-8746-5f4dbd7f3b99	t	Gakeri	ed493ba4-255a-4f9a-b8d8-a46530211766
e703123b-abff-4d85-a3cc-7d3ba932a293	t	Gatenga	ed493ba4-255a-4f9a-b8d8-a46530211766
11da508a-ac4d-44f1-9972-360a076a098d	t	Kacyiru	ed493ba4-255a-4f9a-b8d8-a46530211766
04156335-89d4-43ea-a01f-d03b91d17e81	t	Marimba	ed493ba4-255a-4f9a-b8d8-a46530211766
7234e5f5-f89a-496e-9491-9a6381b95b63	t	Ruganda	ed493ba4-255a-4f9a-b8d8-a46530211766
75010188-19aa-4bb1-b65d-7f10862df5fa	t	Rurambo	c1dff4f9-9818-4f3f-b2fe-1f15593d8cdf
4c034241-4c07-4127-bfb7-cdcbaf8b7fc6	t	Shyembe	c1dff4f9-9818-4f3f-b2fe-1f15593d8cdf
003c7f24-00e5-4629-9b80-efde93ab27fb	t	Nyamibombwe	fc251c5b-4880-4262-98b9-5dfe6d971c72
2cec541f-e15c-4966-ad62-bec57c979418	t	Bungwe	027f77ea-0365-4864-b890-3dc496e26648
cfd5772a-634b-419e-b93c-3ca7d862c99d	t	Gakeri	027f77ea-0365-4864-b890-3dc496e26648
53bf4f6c-84bf-4fa7-b663-3d0c8ef8eeb4	t	Gatenga	027f77ea-0365-4864-b890-3dc496e26648
b05a3c48-9729-40c9-849d-ad6bcffd02cb	t	Nyabyondo	027f77ea-0365-4864-b890-3dc496e26648
83e89e57-269a-4b4c-a5af-19ba6a4f14bc	t	Gifumba	afb3564c-b207-4e26-b9ca-ac1c91897980
9de2a570-d612-42b5-81b3-11d797d70d48	t	Ryamayaya	afb3564c-b207-4e26-b9ca-ac1c91897980
9c0721b7-bb44-46fe-89c9-5e5eff2eec64	t	Mubuga	000addb1-63cb-4c03-9133-552e4c14b673
eda5f5c0-83d6-4747-a9a8-14bdbd5e62a3	t	Karwema	31984cbe-06dc-4980-b7e1-0e9a90fd6fe7
16d4d085-1546-478e-9970-eb15de242061	t	Mubuga	31984cbe-06dc-4980-b7e1-0e9a90fd6fe7
e880d240-6541-412c-b5a4-e04e4a1159d5	t	Murambo	31984cbe-06dc-4980-b7e1-0e9a90fd6fe7
a4d900fe-4b33-42a4-8cda-4c746a65e026	t	Mutungo	31984cbe-06dc-4980-b7e1-0e9a90fd6fe7
f1aebed6-3e66-4db0-b184-1c6c723522b6	t	Nama	31984cbe-06dc-4980-b7e1-0e9a90fd6fe7
79189e32-6d32-4424-a46c-8755c5b080c8	t	Gafumba	e019059a-1b77-4d5f-bac5-54c7416c115f
86b13b64-64ec-4c98-af78-aed68c3cc609	t	Gahuye	e019059a-1b77-4d5f-bac5-54c7416c115f
94e7d714-c98f-4f5b-8124-af8f9e3aabb9	t	Gasebeya	e019059a-1b77-4d5f-bac5-54c7416c115f
341da104-6b64-4841-a7ca-90a5c64dacda	t	Kadehero	e019059a-1b77-4d5f-bac5-54c7416c115f
9b9ba35e-cc71-4b1c-a078-8fae88b01b87	t	Kagano	e019059a-1b77-4d5f-bac5-54c7416c115f
6fd86945-5fdd-4451-a199-ffef5ab3531f	t	Kanyoni	e019059a-1b77-4d5f-bac5-54c7416c115f
8e4f4ea7-8448-46bf-8954-5a9ff82cf1e3	t	Kindoyi	e019059a-1b77-4d5f-bac5-54c7416c115f
edfb8de8-90c7-48b6-979e-4944326a40cb	t	Rubonobono	e019059a-1b77-4d5f-bac5-54c7416c115f
7dd2c3ee-78a2-45b5-b434-0e6b2d7b7ece	t	Biyove	2711bcc0-1427-4f7c-9fc5-0be202c637be
6a66d052-cba8-4143-9f70-d6604d9a7586	t	Bugeme	2711bcc0-1427-4f7c-9fc5-0be202c637be
4d390f69-cec3-47c1-8d7e-45bb2f8762a2	t	Kirwa	2711bcc0-1427-4f7c-9fc5-0be202c637be
6537823d-53a8-46e2-8d53-0d3b7380cbc5	t	Mulindi	2711bcc0-1427-4f7c-9fc5-0be202c637be
3cc0a5ff-1f0f-4c27-abdc-a94dbfe09a56	t	Murambi	2711bcc0-1427-4f7c-9fc5-0be202c637be
773650a6-93de-4d8b-b6f7-426ebedc0c4f	t	Musenyi	2711bcc0-1427-4f7c-9fc5-0be202c637be
7a9cc90a-073e-4c22-9f9c-7df0727ee697	t	Nyanamo	2711bcc0-1427-4f7c-9fc5-0be202c637be
000f1e73-993f-4799-860f-4937b19f0894	t	Rupangu	2711bcc0-1427-4f7c-9fc5-0be202c637be
44741594-5791-4460-a9f1-b47103deb3ba	t	Ryakagundu	2711bcc0-1427-4f7c-9fc5-0be202c637be
fa09f114-55f0-4eab-b567-351463895d6d	t	Ryanturege	2711bcc0-1427-4f7c-9fc5-0be202c637be
30a35291-0ab5-487f-b495-95332eb5ec3c	t	Bukaragata	22a7f001-029f-4124-a7d9-464e3cd682b5
524a4563-3753-4130-a4ad-4ebc327d1d43	t	Cyahera	22a7f001-029f-4124-a7d9-464e3cd682b5
37cd9166-151f-4298-a2f4-56ce934a4de5	t	Karambi	22a7f001-029f-4124-a7d9-464e3cd682b5
86906543-e005-42f9-a66d-02e67ca993bc	t	Kibande	22a7f001-029f-4124-a7d9-464e3cd682b5
58f1a28e-8eed-4604-97a4-38a918869b3f	t	Kindege	22a7f001-029f-4124-a7d9-464e3cd682b5
1a5321e9-9d6e-472b-bfc2-a34c9dfd64d4	t	Murambo	22a7f001-029f-4124-a7d9-464e3cd682b5
97605fc1-56ea-46ff-a49a-256a61d89b4a	t	Murwa	22a7f001-029f-4124-a7d9-464e3cd682b5
c717843a-b3d9-4977-a611-62f52a346bbe	t	Rugandu	22a7f001-029f-4124-a7d9-464e3cd682b5
bc8b03d0-d6e3-4bf2-a56e-8d2b4c749f86	t	Taba	22a7f001-029f-4124-a7d9-464e3cd682b5
04d4b333-164e-4464-9f8f-39670a35604c	t	Burambira	0c0a3921-c8d6-4345-ae45-384cca022745
e4e4fa7e-4e6c-4640-91a6-728b2f3bafa7	t	Gari	0c0a3921-c8d6-4345-ae45-384cca022745
687e6565-e72b-48a1-8513-4608c72680a6	t	Gasiza	0c0a3921-c8d6-4345-ae45-384cca022745
669ebab8-8202-46a8-b056-185875c788ec	t	Gitovu	0c0a3921-c8d6-4345-ae45-384cca022745
cf869da9-ab3f-4c47-8abd-798ac6d0b3a9	t	Kiringa	0c0a3921-c8d6-4345-ae45-384cca022745
f52106d7-cc9d-4bbb-a6ca-6463b7294161	t	Murwa	0c0a3921-c8d6-4345-ae45-384cca022745
334d360e-2bfa-4ab0-ac86-a906b48b64dc	t	Musama	0c0a3921-c8d6-4345-ae45-384cca022745
6fd95278-9a99-43bc-b1ad-19df10c3df1b	t	Nkururo	0c0a3921-c8d6-4345-ae45-384cca022745
3ea1135c-ff7f-43b7-a5a7-30768995f7dc	t	Nyamiyaga	0c0a3921-c8d6-4345-ae45-384cca022745
e069a6df-b33d-4bec-9708-c968f20af542	t	Rubaya	0c0a3921-c8d6-4345-ae45-384cca022745
65a56f01-ffc2-4982-ba96-026c78f8ba84	t	Butaro	e5dc8ce9-c24e-4ff1-818b-7ea58b65a07a
09d7f52f-51c5-4c85-b38c-4508c9fc7c5e	t	Buyanga	e5dc8ce9-c24e-4ff1-818b-7ea58b65a07a
45cd27c0-252c-4650-a19c-3b7fd0b8c6f7	t	Gitanda	e5dc8ce9-c24e-4ff1-818b-7ea58b65a07a
c86199e4-f215-4278-b719-a2fbf15b3d7a	t	Kabahura	e5dc8ce9-c24e-4ff1-818b-7ea58b65a07a
1d8b51b2-1b25-4a04-9ca8-db33e10e959c	t	Kanyesogo	e5dc8ce9-c24e-4ff1-818b-7ea58b65a07a
2cafe28e-c594-4a1a-acb9-19d54a071beb	t	Mugari	e5dc8ce9-c24e-4ff1-818b-7ea58b65a07a
38f6c14c-a8a4-455a-8b1e-19d31b198555	t	Mugera	e5dc8ce9-c24e-4ff1-818b-7ea58b65a07a
1d870414-11e0-44ef-8762-17ebbc6de6de	t	Mukeri	e5dc8ce9-c24e-4ff1-818b-7ea58b65a07a
fe53b014-2040-48e1-bf32-255a1a82f912	t	Gahirikiro	4dcb6c8e-89dd-4664-8c16-d3b3e9d16d1f
7ac48e96-b828-4663-85d2-68ba3588fca2	t	Kabona	4dcb6c8e-89dd-4664-8c16-d3b3e9d16d1f
86bc35bf-01fe-4fbe-a11f-cbc73d7c761d	t	Nyamiyaga	4dcb6c8e-89dd-4664-8c16-d3b3e9d16d1f
94c0b191-30ef-4a65-ab1d-e1293cb73979	t	Rwankongi	4dcb6c8e-89dd-4664-8c16-d3b3e9d16d1f
0dfb818d-182e-4f00-a626-300abcc3d48c	t	Gisovu	cfca5c1b-2dea-431e-8ddd-2df4a22df73e
da7dcb5e-41a0-488a-97f3-65de1edcc46c	t	Hanika	cfca5c1b-2dea-431e-8ddd-2df4a22df73e
2d0fbe56-4764-4a8b-b171-c039c5361836	t	Ruhimbi	cfca5c1b-2dea-431e-8ddd-2df4a22df73e
b7d542c0-a4ed-4404-98fc-116426809a1a	t	Samiro	cfca5c1b-2dea-431e-8ddd-2df4a22df73e
4e6702d3-6a7e-4745-9e00-3fd9d12287a1	t	Kabadari	6663c01b-acb2-4214-ae0e-be83d7d9e78f
dd8fcd15-c5f0-4461-8a99-9d9f2391c74a	t	Mbonabose	6663c01b-acb2-4214-ae0e-be83d7d9e78f
4a719699-98e3-40d5-92e0-1302c20f0f56	t	Mugarama	6663c01b-acb2-4214-ae0e-be83d7d9e78f
f9532457-c4ac-43e1-ba3f-3e31909915c7	t	Mugeshi	6663c01b-acb2-4214-ae0e-be83d7d9e78f
d9b93f11-62e6-444c-a9b1-f2e769d2eff0	t	Nkiriza	6663c01b-acb2-4214-ae0e-be83d7d9e78f
e241e1d8-24bf-496b-b2a1-1d5a0968cf44	t	Nyagisenyi	6663c01b-acb2-4214-ae0e-be83d7d9e78f
98a2bee5-50f0-49e7-b86c-e3ad7e2da097	t	Zindiro	6663c01b-acb2-4214-ae0e-be83d7d9e78f
90f99bab-00a6-42ef-add8-877ba5a5b53d	t	Gasebeya	f7b93e5a-8c3b-4384-82bf-5249fae4e9af
c08b1036-2961-48ee-ad7d-0f7610c6d1a2	t	Kabaya	f7b93e5a-8c3b-4384-82bf-5249fae4e9af
766a028b-5874-4aab-945c-db4c656ccb07	t	Kagerero	f7b93e5a-8c3b-4384-82bf-5249fae4e9af
f9228076-d522-4ff3-9525-99962850c175	t	Karambo	f7b93e5a-8c3b-4384-82bf-5249fae4e9af
ad7f8293-ff3b-42cc-907f-e9e6daf3a618	t	Kidaho	f7b93e5a-8c3b-4384-82bf-5249fae4e9af
38860457-13ec-4204-977b-bda36180e87c	t	Munini	f7b93e5a-8c3b-4384-82bf-5249fae4e9af
80c9e9c8-9ad3-4c69-bf9a-54ff8340b3c1	t	Ntarama	f7b93e5a-8c3b-4384-82bf-5249fae4e9af
9210f1ec-fe84-4738-a683-bcacabc71672	t	Sirwa	f7b93e5a-8c3b-4384-82bf-5249fae4e9af
c8a934be-e612-4e96-8412-de277069583e	t	Gasiza	30b3c500-e543-40b0-a356-b024162fc8ab
b106fe22-6e73-4e30-8001-d5b8c0665081	t	Gasovu	30b3c500-e543-40b0-a356-b024162fc8ab
3e58ebe6-c454-43ca-b982-14c7e4422b54	t	Kabira	30b3c500-e543-40b0-a356-b024162fc8ab
d55eb541-83ea-4f86-9c30-d3cd8a1ae0db	t	Kavunda	30b3c500-e543-40b0-a356-b024162fc8ab
57f12aa0-d1b1-48e4-b589-fc619aa6a1fe	t	Kibaya	30b3c500-e543-40b0-a356-b024162fc8ab
82c67d5c-31f8-4d53-b16e-4e6929c08f54	t	Majyambere	30b3c500-e543-40b0-a356-b024162fc8ab
fdb585e0-a0e2-4c45-8248-9178aff9ec80	t	Nyarutosho	30b3c500-e543-40b0-a356-b024162fc8ab
24c45ff3-4b09-4565-b527-d72cf6453f29	t	Runyenkanda	30b3c500-e543-40b0-a356-b024162fc8ab
56dfa8ed-3e66-418f-9b96-53ceb9b4bbac	t	Ryabiteyi	30b3c500-e543-40b0-a356-b024162fc8ab
490f5a4c-9326-4566-a590-b126c79ad9bb	t	Bisura	b877312e-2432-44b6-bfee-8f715fa3925a
854dff71-affa-4d8d-8b6c-79ff1109b360	t	Gahama	b877312e-2432-44b6-bfee-8f715fa3925a
65372534-680d-410c-b8e0-7d205fab621e	t	Gahonga	b877312e-2432-44b6-bfee-8f715fa3925a
c12d2401-0f37-4b4b-89dc-0592176dbc28	t	Gakenke	b877312e-2432-44b6-bfee-8f715fa3925a
c7871f6b-79e8-4143-8390-d0a6947119a7	t	Kabande	b877312e-2432-44b6-bfee-8f715fa3925a
a8a985c7-8e36-431e-88ee-c76945f6d942	t	Kabyimana	b877312e-2432-44b6-bfee-8f715fa3925a
904cd266-a52e-44b6-ba4f-a29936db02f2	t	Kanyabaranzi	b877312e-2432-44b6-bfee-8f715fa3925a
460a8e94-bf1b-4052-a2dd-ee3aef04c16a	t	Kebero	b877312e-2432-44b6-bfee-8f715fa3925a
e9c41a00-2935-476b-8bca-b3edce89f8fa	t	Mashango	b877312e-2432-44b6-bfee-8f715fa3925a
e396414b-fd56-4e27-a31e-49bda11cd4ed	t	Musave	b877312e-2432-44b6-bfee-8f715fa3925a
e2cbc66d-5149-4c67-b035-f400aa14888a	t	Ruko	b877312e-2432-44b6-bfee-8f715fa3925a
c921c9ed-f790-4e5b-8f51-f11786c4963c	t	Kamata	ac4e7e82-1011-460b-9d38-1f9e646e9485
56be55c8-1916-454a-b361-0757279cd191	t	Kabagenza	7032361f-c026-46a3-b550-88b745226f33
57eff2cb-36e7-40db-bf5c-710f6ec0f79a	t	Ntazi	7032361f-c026-46a3-b550-88b745226f33
88932355-0b98-4f0f-8525-f62ccc3e71ca	t	Nyagisozi	7032361f-c026-46a3-b550-88b745226f33
a58aae44-728f-45df-a792-0eacb58feec9	t	Rujanja	7032361f-c026-46a3-b550-88b745226f33
44ab4ebe-5455-4144-89b6-d8e19f354e84	t	Ryaruhirima	7032361f-c026-46a3-b550-88b745226f33
d6835bb1-bea4-475d-b4e6-1470bde6b5be	t	Burabwa	1b13b82d-c5ec-4e84-8254-1cb0409a146f
bca5ef46-c4d9-485c-a5f5-26bcc1614344	t	Kabaya	1b13b82d-c5ec-4e84-8254-1cb0409a146f
f63bd34e-4d98-4265-a884-d5910450035c	t	Gafatangwe	1fcaea69-5569-4fe0-84ba-be78714984e5
9b4e8187-7a42-483f-b686-c3b7ce03c277	t	Gasenyi	1fcaea69-5569-4fe0-84ba-be78714984e5
44ef45bb-0388-40f0-969d-153ea2423343	t	Kagoma	1fcaea69-5569-4fe0-84ba-be78714984e5
ec77965d-83e9-4988-b06c-e25c1e006491	t	Karuheshyi	1fcaea69-5569-4fe0-84ba-be78714984e5
152c12d0-4984-4f1f-a431-de11128520c1	t	Murambi	1fcaea69-5569-4fe0-84ba-be78714984e5
aa87e8fe-eecb-4e85-8f4c-14e2344a3efc	t	Musanzu	1fcaea69-5569-4fe0-84ba-be78714984e5
e9a47c7c-9607-46a9-a091-9d3823379366	t	Gisizi	3d8645e8-2f46-4842-b8a8-642254e390b3
6bc4bae0-8545-4824-9d5c-d8d20fbd83c2	t	Kabagabo	3d8645e8-2f46-4842-b8a8-642254e390b3
c307c3aa-a3bd-4a9f-a291-4f5049771b5b	t	Kanaba	3d8645e8-2f46-4842-b8a8-642254e390b3
7aa6b34c-401b-499f-9e88-61898c9f6ff9	t	Kigote	3d8645e8-2f46-4842-b8a8-642254e390b3
05b59a30-0413-4775-9bda-af9ae1dbe195	t	Nyagasozi	3d8645e8-2f46-4842-b8a8-642254e390b3
0df17a87-d505-471c-9c91-93e348095d77	t	Ruri	3d8645e8-2f46-4842-b8a8-642254e390b3
e47c1140-7840-4b59-9435-0ecd9ab09f2d	t	Bahenga	690d97b6-0716-40b5-8eac-ffcb81aaed16
c60f1080-50da-4abf-a2fe-f38e89887c25	t	Kabarima	690d97b6-0716-40b5-8eac-ffcb81aaed16
567ab938-b737-4b27-be1e-acc507b4c63e	t	Kabindi	690d97b6-0716-40b5-8eac-ffcb81aaed16
338b124f-3562-4929-ba34-a97a383ec9a0	t	Kajevuba	690d97b6-0716-40b5-8eac-ffcb81aaed16
fcca8898-7178-4b4e-b56a-78ce5c373270	t	Kangoma	690d97b6-0716-40b5-8eac-ffcb81aaed16
930bfb78-00e7-4c4d-9fbb-24fb84a45e08	t	Kanyendara	690d97b6-0716-40b5-8eac-ffcb81aaed16
4b4a44c7-d81e-40ce-be31-e84f2d8dbc75	t	Kidakama	690d97b6-0716-40b5-8eac-ffcb81aaed16
983bbacd-eb70-4542-99e9-43bc761be44b	t	Mubuga	690d97b6-0716-40b5-8eac-ffcb81aaed16
0c945c4e-cbd5-429d-a451-37237997fdbe	t	Nangimbibi	690d97b6-0716-40b5-8eac-ffcb81aaed16
5330af76-ba57-4989-adad-b0a4b1ac0833	t	Rusenyi	690d97b6-0716-40b5-8eac-ffcb81aaed16
9385ef26-bd3d-4c13-b942-e34bec293504	t	Songa	690d97b6-0716-40b5-8eac-ffcb81aaed16
8619e6c7-d361-4f68-bb4a-ac148a3ba56e	t	Bihanga	608f4c5d-4f07-44c0-8d08-a3a8b14557e4
8b74ce65-7273-4615-9156-32ad4bd40e17	t	Gasagara	608f4c5d-4f07-44c0-8d08-a3a8b14557e4
d2326c1e-a13f-40df-b726-1b7f76ad7124	t	Gikoro	608f4c5d-4f07-44c0-8d08-a3a8b14557e4
c6187285-d087-40dd-9c8b-627097e2de26	t	Kamatanda	608f4c5d-4f07-44c0-8d08-a3a8b14557e4
79a80ffb-9ee2-4c79-ad50-f963c3e7c7a8	t	Mubibi	608f4c5d-4f07-44c0-8d08-a3a8b14557e4
39f7076b-665f-4164-9b88-51d5c64654fe	t	Ntenyo	608f4c5d-4f07-44c0-8d08-a3a8b14557e4
eed194e3-902d-4cd0-8079-bbfda133bcc2	t	Nyangwe	608f4c5d-4f07-44c0-8d08-a3a8b14557e4
529d44b7-7c7d-4f18-8782-67ca70cdfce4	t	Remera	608f4c5d-4f07-44c0-8d08-a3a8b14557e4
6e645045-2826-4477-8e24-47837f720785	t	Kabanga	c8e6f7c8-8f36-4e42-a9d9-c5b0ee8ce607
151829de-4429-4305-9d3b-91b0bf9c2e7a	t	Kangoboka	c8e6f7c8-8f36-4e42-a9d9-c5b0ee8ce607
75be0a21-e676-412a-8236-7506abf1f254	t	Kanyiramusen	c8e6f7c8-8f36-4e42-a9d9-c5b0ee8ce607
685ec691-778f-4e9b-98e8-9be6bfc519ee	t	Nyangezi	c8e6f7c8-8f36-4e42-a9d9-c5b0ee8ce607
d50100d6-b25d-4356-b4ea-751eb5ad4ce6	t	Nyakabungo	b59798c4-84d2-4203-b126-1039ff23d381
f1720bf8-90be-4639-b86e-461caf8832ab	t	Ryaruyumbu	b59798c4-84d2-4203-b126-1039ff23d381
9f8c770e-bd84-4e17-a18e-24a02124ec30	t	Kabuga	76fcab97-9732-4c48-96eb-4e6d31652241
c37f232b-9f32-4906-8c52-0add2712e6f1	t	Mubuga	73c98605-70ea-4f71-ba0e-4fb9a98de833
9f66668f-c3aa-4286-9b78-2c2b40084a9f	t	Taba	73c98605-70ea-4f71-ba0e-4fb9a98de833
9716dec2-be0d-4fce-9950-555fe1918f23	t	Karambi	0987d2da-fe21-49c6-ab6a-8c39d519b69d
a556a605-6b71-49dc-9e3a-3197e70f8b43	t	Nganzo	0987d2da-fe21-49c6-ab6a-8c39d519b69d
63dc67bf-aee3-4a3f-b6ab-16b864cc83b6	t	Rutovu	0987d2da-fe21-49c6-ab6a-8c39d519b69d
49277300-06f0-4a01-a808-0feead13f825	t	Kiboga	b4d113b0-0973-4918-93d8-911f11888aed
2eaf7a62-dc28-4b00-b7af-7a538d1de2cc	t	Kibumbiro	616ef015-5789-4a07-bc66-04df8d0a7f98
c1985774-6292-4a27-9724-4dddbaa6e75c	t	Murore	616ef015-5789-4a07-bc66-04df8d0a7f98
d6940dae-79f2-4454-8141-686ccf09c728	t	Sina	616ef015-5789-4a07-bc66-04df8d0a7f98
2a4149d4-4330-402a-ad32-a16e2306a4c9	t	Gitwe	10136c49-0564-4014-8d4a-0f42fe90eb62
b69483fa-b97b-4588-a1c5-ec4b334f7bf3	t	Mubuga	10136c49-0564-4014-8d4a-0f42fe90eb62
3f172e8a-f73e-4404-836a-5aafacb73ecc	t	Butare	3ee21c0d-83af-4ed9-aedb-127ec0050ef2
d51f7521-a761-4f6f-85ef-ee497f720dee	t	Kanaba	3ee21c0d-83af-4ed9-aedb-127ec0050ef2
82140f1e-20c5-4067-979e-7c32e1fdbe31	t	Rukenke	3ee21c0d-83af-4ed9-aedb-127ec0050ef2
5bb0cdb6-e7c4-49e3-b67d-eab4c3ad3cfb	t	Kaguriro	7c3210ab-9cc4-41b8-85e2-3aa01b56202a
c7cdb1da-f28d-43ef-8c41-92e1cb791d84	t	Kiyira	7c3210ab-9cc4-41b8-85e2-3aa01b56202a
5fef9703-c838-4896-8453-8be94d40a19e	t	Rwitongo	7c3210ab-9cc4-41b8-85e2-3aa01b56202a
b7711205-687a-4a83-bde0-8bae64d96f5e	t	Gisanze	99ecd4ff-1afc-4b40-a298-cf8fa4041542
2aa4848f-89be-4995-bb38-4e5da7ba152b	t	Karambi	99ecd4ff-1afc-4b40-a298-cf8fa4041542
b1c50497-2599-464d-b5ad-3e0bae7b3aad	t	Kariba	99ecd4ff-1afc-4b40-a298-cf8fa4041542
0e632619-bd3f-47ea-ae4e-224ca9c4fd7f	t	Karombero	99ecd4ff-1afc-4b40-a298-cf8fa4041542
e4ea863f-32b7-45a3-be5c-7abdef4f3e15	t	Kigote	99ecd4ff-1afc-4b40-a298-cf8fa4041542
415fc14d-5549-4120-8ba6-ea4d4bbc0242	t	Musangabo	99ecd4ff-1afc-4b40-a298-cf8fa4041542
362fee3a-5952-461d-9e5b-04e32c449d58	t	Nyamuha	99ecd4ff-1afc-4b40-a298-cf8fa4041542
2b5d7e16-9933-4473-ae23-fd93628ea11a	t	Rusenyi	99ecd4ff-1afc-4b40-a298-cf8fa4041542
fcda984b-a03a-425b-88b3-4e37cab63007	t	Rwabageni	99ecd4ff-1afc-4b40-a298-cf8fa4041542
6a8fd17a-5243-4133-a8db-3a65d0dc4047	t	Ryangarama	99ecd4ff-1afc-4b40-a298-cf8fa4041542
015c26bc-b847-4bd2-b7ef-29bcdced7399	t	Gitare	1be28b7f-92cb-470f-9bd6-fd1dc323fa04
6b587300-4b84-4f10-87e8-fce5020c6e43	t	Kabana	1be28b7f-92cb-470f-9bd6-fd1dc323fa04
45518d34-1e41-4d34-910b-873e26e6d59f	t	Kikubo	1be28b7f-92cb-470f-9bd6-fd1dc323fa04
b9ee8180-674b-4041-b556-02464a146f77	t	Mfashe	1be28b7f-92cb-470f-9bd6-fd1dc323fa04
eb600d06-e9be-4f03-924c-fbbb735fb631	t	Musarara	1be28b7f-92cb-470f-9bd6-fd1dc323fa04
db139a5f-c276-41a1-8270-62faefe14736	t	Nyamabuye	1be28b7f-92cb-470f-9bd6-fd1dc323fa04
f49b35a7-63ab-4966-9862-7ccd7963e477	t	Nyarubuye	1be28b7f-92cb-470f-9bd6-fd1dc323fa04
0192b1b7-c91a-4512-9ddf-c9fe8617994b	t	Nyarugina	1be28b7f-92cb-470f-9bd6-fd1dc323fa04
cf5ef058-e3e3-49bb-81da-f57f78e93b49	t	Bugeyo	b6d89e42-a9cc-422a-a7c3-601afa839def
f4ac3864-b6f3-48be-8111-43f0e9f7b188	t	Kigugu	2a3219f8-4c8d-4dd2-9086-c2c4497cae5a
516195f8-c0a7-488a-baeb-de3bf6b876b4	t	Cyivugiza	36df21fb-34eb-4936-8149-8fa2940f353a
cf4ee88b-91e4-4bb4-a88a-c864bc63f08e	t	Karambo	36df21fb-34eb-4936-8149-8fa2940f353a
95a26d95-d75c-4c50-99d4-2930b7acae2b	t	Mbaya	36df21fb-34eb-4936-8149-8fa2940f353a
80737756-e3ef-4c1d-ab25-66bef97e2185	t	Mubuga	36df21fb-34eb-4936-8149-8fa2940f353a
5eac2eab-8c23-4a4a-ab4c-8da12fa0ee96	t	Mutabo	36df21fb-34eb-4936-8149-8fa2940f353a
a562b8ae-e352-4750-8e5f-fc32d36c6d28	t	Cyamabuye	263419cd-5744-45d5-8c32-7d24c4ac66b1
50c95b3b-4503-4db8-bfe6-1a16e70b7eb8	t	Gikoro	263419cd-5744-45d5-8c32-7d24c4ac66b1
b44db374-542d-4e2d-9ed5-c7fd9b47e4b3	t	Karuganda	263419cd-5744-45d5-8c32-7d24c4ac66b1
97a9ccf1-9cc6-433b-967e-4e2b4d09e53b	t	Nyabagenzi	263419cd-5744-45d5-8c32-7d24c4ac66b1
b43fb997-143e-4ace-ba49-9b4e2bdab759	t	Cyogo	62ea92ec-6177-4432-bc42-56fedd8796e9
b4a392ae-ec04-4e20-b842-f4c71b2e0dc9	t	Kabingo	62ea92ec-6177-4432-bc42-56fedd8796e9
b7d8aec2-eee8-4275-949c-35cbea219cab	t	Kirwa	62ea92ec-6177-4432-bc42-56fedd8796e9
814895f2-37db-4c28-8263-659c41a46344	t	Matyazo	62ea92ec-6177-4432-bc42-56fedd8796e9
044d1fa9-4db4-4dc7-8fee-f3fdd32fe11b	t	Ndabizi	62ea92ec-6177-4432-bc42-56fedd8796e9
ed7d54e9-d8c2-492b-8c96-f61629450433	t	Gisirwe	782937cb-aad3-411e-a2ac-320fe4b856f7
c3ff84c4-eba2-4483-9f32-f8ee8f0bdab1	t	Kiraro	782937cb-aad3-411e-a2ac-320fe4b856f7
fe8f9b51-cf22-45c5-ad71-bd55f8b6f9d4	t	Ruhinga	782937cb-aad3-411e-a2ac-320fe4b856f7
664589c3-b843-437b-93c9-b55f62ccc62d	t	Rusebeya	782937cb-aad3-411e-a2ac-320fe4b856f7
3c56e848-9a55-4c9e-94a4-58c9ace2bbe0	t	Gitoma	abacca77-f0a0-4d04-90cc-4aed4d526008
3ad2457e-a555-41fd-ae97-4fa9ae66390a	t	Kanyaminyiny	abacca77-f0a0-4d04-90cc-4aed4d526008
fe03c783-5d32-4d5f-b173-560aab22f114	t	Murambo	abacca77-f0a0-4d04-90cc-4aed4d526008
8984dbd3-a5bf-4dca-a546-f5408a8e0cfb	t	Rukaya	abacca77-f0a0-4d04-90cc-4aed4d526008
3a8f30d7-2371-41d4-b151-7680b03598ec	t	Gisiriri	5be684ee-db34-48f4-8157-24159ec15abe
9d00d62a-df81-4c50-ba3b-6ec39937a498	t	Kavumu	5be684ee-db34-48f4-8157-24159ec15abe
6725d17e-83e3-4fe4-9fdf-1ceefc5f9753	t	Musaga	5be684ee-db34-48f4-8157-24159ec15abe
1634b433-cc95-493e-9d37-b54b1cdf45db	t	Nyabizi Ii	5be684ee-db34-48f4-8157-24159ec15abe
92015e97-ad2d-4a02-a86f-666df111dd17	t	Nyabizi Iii	5be684ee-db34-48f4-8157-24159ec15abe
17362642-e555-4229-9f89-1a587f406720	t	Rubayu	5be684ee-db34-48f4-8157-24159ec15abe
30a02068-b431-4e6d-8ef1-f3dcbd9a3b6e	t	Buhita	abdf1509-400d-419f-817c-69609f7d46b4
590ea8e4-1058-4ba0-8c87-8d449fe27b71	t	Gitovu	abdf1509-400d-419f-817c-69609f7d46b4
7db35bba-355d-4066-a922-5a6e47815341	t	Murambo	abdf1509-400d-419f-817c-69609f7d46b4
fa3dcd56-71e8-4176-8396-94a534fb322d	t	Nyakira	abdf1509-400d-419f-817c-69609f7d46b4
14cb1d09-7712-4779-b538-5d4c19953d8b	t	Nyarutovu	abdf1509-400d-419f-817c-69609f7d46b4
3a6da628-ce9c-4152-8739-c40d12965ae9	t	Bitukura	b7be74f9-f972-4d8f-8e8b-43830ca50752
d9eed742-00cd-47f7-b722-bbabec289ade	t	Burango	b7be74f9-f972-4d8f-8e8b-43830ca50752
ae0e07d6-712a-4e5d-b10e-aaadfdda0ec4	t	Gafumba	b7be74f9-f972-4d8f-8e8b-43830ca50752
8928cfe5-e8e0-42e5-bdb8-abfbe7aa04cb	t	Gashiru	b7be74f9-f972-4d8f-8e8b-43830ca50752
ba11ee2b-17f7-4580-83b6-da81387164b2	t	Karambo	b7be74f9-f972-4d8f-8e8b-43830ca50752
1ef4f7be-d5c7-4b06-9a8b-5716ff19caaa	t	Nyakabungo	b7be74f9-f972-4d8f-8e8b-43830ca50752
9b8eae3f-6bd6-4bc4-95c5-b1fa83c2af42	t	Rugarambiro	b7be74f9-f972-4d8f-8e8b-43830ca50752
d0060c5c-6cb7-404c-bce2-c5e00760e0a8	t	Gasiza	5e6e8f3e-17c8-46a5-bda9-2a13764cfa23
c686fde8-1a37-40c3-9455-90117a41f289	t	Kabaya	5e6e8f3e-17c8-46a5-bda9-2a13764cfa23
8c7cb720-c7d8-4dde-926b-52219bbc36c5	t	Rucyamo	5e6e8f3e-17c8-46a5-bda9-2a13764cfa23
006c05e1-d966-46c7-bcc4-e975ee978ca7	t	Rusasa	5e6e8f3e-17c8-46a5-bda9-2a13764cfa23
e4ac57df-7911-420e-9551-319c4eb41b95	t	Vumage	5e6e8f3e-17c8-46a5-bda9-2a13764cfa23
b7bdf357-234e-4a93-b8bd-e0b1ac51d06f	t	Buganza	4e0f1fbe-003e-4d2f-a7de-ff79073225a1
3101749d-c4b5-478c-b2b3-a769159c6f07	t	Bukumbi	4e0f1fbe-003e-4d2f-a7de-ff79073225a1
13c27f90-0d8a-497d-bcc4-c72040552ec8	t	Kanyenzugi	4e0f1fbe-003e-4d2f-a7de-ff79073225a1
f09443fb-2e3d-4df2-b4c6-8db09b63e678	t	Mushunga	4e0f1fbe-003e-4d2f-a7de-ff79073225a1
b9d36409-0c8c-4ae3-a953-a8c936039f56	t	Gashushura	88d084b3-3163-49dc-9bc7-9a581cf31d37
33dbc9b1-5275-4667-9b16-4e76a35869cb	t	Mugano	88d084b3-3163-49dc-9bc7-9a581cf31d37
72f99dee-fa25-4763-b7d8-63683dbd5be2	t	Nyamusanze	88d084b3-3163-49dc-9bc7-9a581cf31d37
4624611a-3001-41e0-bf13-cd13800bd269	t	Cyabami	883e3fee-c8a8-4258-a1d0-86fadabc7436
18e22949-43cb-45d4-85b0-75736b704e33	t	Karyango	883e3fee-c8a8-4258-a1d0-86fadabc7436
9c29b3a2-be2d-4d6b-844d-75dafb47d37e	t	Nyagahondo	883e3fee-c8a8-4258-a1d0-86fadabc7436
ef0f0a1b-f3a3-4fe9-975d-f67fb1363a50	t	Nyiraruhuha	883e3fee-c8a8-4258-a1d0-86fadabc7436
98b302cc-2b8f-472a-b8a2-1812b8b381cc	t	Ryaruhirima	883e3fee-c8a8-4258-a1d0-86fadabc7436
838a7bf8-fea8-458d-b8b3-e88ec8cccab8	t	Bugarigari	6d63bd11-bfbd-47ee-8ea1-14fb3ba30115
108b966f-a71a-4c53-8abd-e535fdd7c6f3	t	Bukenyeye	6d63bd11-bfbd-47ee-8ea1-14fb3ba30115
bde8608b-e1c1-4458-9155-ae1d4d2fbaea	t	Cyabarenge	6d63bd11-bfbd-47ee-8ea1-14fb3ba30115
03be7627-cf96-4314-8928-4f8a62f405c5	t	Murandamo	6d63bd11-bfbd-47ee-8ea1-14fb3ba30115
2495a5f2-a0e6-40e9-96dd-c9c401d964d6	t	Ngongwe	6d63bd11-bfbd-47ee-8ea1-14fb3ba30115
9d8285c5-7eb4-495a-b4cc-493d71eb1c03	t	Rebero	6d63bd11-bfbd-47ee-8ea1-14fb3ba30115
3bb74901-951d-4573-9174-2c7587c42314	t	Bishingwe	a5f1afd6-9868-43fb-9b9d-53a42656ef21
19bf7bc4-252e-4c15-8a7a-37e66c8566a9	t	Cyave	a5f1afd6-9868-43fb-9b9d-53a42656ef21
f9ee41d4-fc19-4d50-88b6-641f77d9f547	t	Kagesera	a5f1afd6-9868-43fb-9b9d-53a42656ef21
92311c64-9839-4db4-b3e7-7ba0ae119ea7	t	Mugomero	a5f1afd6-9868-43fb-9b9d-53a42656ef21
31a3e33f-a089-4a1c-a587-b2056522971e	t	Nyabitare	a5f1afd6-9868-43fb-9b9d-53a42656ef21
df9679ce-fa9c-4329-ac94-aac49b42138a	t	Hanika	30eafe21-4720-4f10-9f1a-5f8dd53fe26a
aeecbf9c-d4c9-43cb-af15-7f69b4d8d61a	t	Nguri	30eafe21-4720-4f10-9f1a-5f8dd53fe26a
3dd50a68-61da-41f0-86c6-780272eb95f8	t	Nyabiho	30eafe21-4720-4f10-9f1a-5f8dd53fe26a
3c44bdff-8189-4e60-b9d6-ed82b3793a93	t	Rubeja	30eafe21-4720-4f10-9f1a-5f8dd53fe26a
7d0649ea-1c7b-47c3-88cd-f47bbe23c2e4	t	Bambiro	7c76f6e8-06ae-487a-9892-472ac30e277d
fae05266-b72d-44be-8905-10f276ff72c0	t	Gacyogo	7c76f6e8-06ae-487a-9892-472ac30e277d
50dfdeae-3ca1-408f-98df-54289e0d379c	t	Gahunga	7c76f6e8-06ae-487a-9892-472ac30e277d
de6de09f-5400-4851-9279-7ee785711bc9	t	Kabaya	7c76f6e8-06ae-487a-9892-472ac30e277d
769901be-3130-4a17-880d-ea850297d64e	t	Rugarama	7c76f6e8-06ae-487a-9892-472ac30e277d
ab481ef0-57da-4b90-a0c2-8ebfbe35b7d8	t	Rutamba	7c76f6e8-06ae-487a-9892-472ac30e277d
9aa6cb3a-3a62-446a-ae22-1abff4a280e6	t	Gahama	21619e7f-2ae8-472a-8c3e-e0346b72517e
a6c56c3a-a0a2-4a63-ade0-5b640fef63c7	t	Gasiza	21619e7f-2ae8-472a-8c3e-e0346b72517e
cd3fa54e-a5f3-41dc-82c2-dc7d369067dd	t	Kabaya	21619e7f-2ae8-472a-8c3e-e0346b72517e
543e240b-9509-405d-8edf-a19e8251664f	t	Maya	21619e7f-2ae8-472a-8c3e-e0346b72517e
32e51638-2937-4d2e-aa04-2578d99e178a	t	Muhabura	21619e7f-2ae8-472a-8c3e-e0346b72517e
ccdb66e5-56ff-4b7c-b92f-e7c028ff8cf4	t	Mpinga	7b01159d-b9ea-4a07-af4a-ee3302d02ff8
35008c8f-3bba-43a4-993f-cf3dd306f4c7	t	Nyakiriba	7b01159d-b9ea-4a07-af4a-ee3302d02ff8
944d3e69-ab94-4bae-b5a7-120ffa858d6d	t	Rwambeho	7b01159d-b9ea-4a07-af4a-ee3302d02ff8
db681c11-88f2-44f8-9e0a-00848aabc4b0	t	Rwinkuba	7b01159d-b9ea-4a07-af4a-ee3302d02ff8
9d6ea9b0-fb38-4c72-bf17-eda2eff0a5c6	t	Bushima	e5a157eb-a7ec-4818-952b-76564dbf5568
1907c193-87a2-4b44-a519-f383a50275ec	t	Cyogo	e5a157eb-a7ec-4818-952b-76564dbf5568
7799861c-326d-47a8-8f2e-2cc9403abd59	t	Murungu	e5a157eb-a7ec-4818-952b-76564dbf5568
4430f671-c691-486e-9d01-86f0042eac5a	t	Musheke	e5a157eb-a7ec-4818-952b-76564dbf5568
d79989e1-a448-4ad4-80ba-275e85411252	t	Taba	e5a157eb-a7ec-4818-952b-76564dbf5568
47bf0859-94b7-4309-a866-1bfdea5c2c59	t	Burago	b2a88ad9-7368-4157-a1b5-a16b0ae3e7e2
d889bd6e-afcd-4edb-81f5-97c1053ef2b2	t	Burande	b2a88ad9-7368-4157-a1b5-a16b0ae3e7e2
31a264b9-29d9-43b1-99a8-93dc63f115c0	t	Gahinga	b2a88ad9-7368-4157-a1b5-a16b0ae3e7e2
1fe98586-75a4-4031-b65a-a451c6bad9fa	t	Kamonyi	b2a88ad9-7368-4157-a1b5-a16b0ae3e7e2
101c3e46-6881-4156-a85d-6ce2ae80a078	t	Karubamba	b2a88ad9-7368-4157-a1b5-a16b0ae3e7e2
ef4a81c8-c86a-4256-9672-dfbf365641b7	t	Mugina	b2a88ad9-7368-4157-a1b5-a16b0ae3e7e2
e30859a4-b472-4c6a-a1a2-b947e68f9fdc	t	Nkoto	b2a88ad9-7368-4157-a1b5-a16b0ae3e7e2
795e4ebb-48bd-4638-82e1-c90e40471626	t	Nyabikungu	b2a88ad9-7368-4157-a1b5-a16b0ae3e7e2
c79902da-eb00-4e97-8a88-b67abdad720c	t	Rihiro	b2a88ad9-7368-4157-a1b5-a16b0ae3e7e2
6cdc8697-1b0c-4d67-b538-d9f45fd6a277	t	Bwenjeli	7c974f67-7f90-4e6a-b16d-1ddf410b3c39
fe693556-48c0-48a3-ab63-aacd35468378	t	Kabira	7c974f67-7f90-4e6a-b16d-1ddf410b3c39
03ebf956-adc0-41e9-a374-cca81a15d9dc	t	Kabukoko	7c974f67-7f90-4e6a-b16d-1ddf410b3c39
4ca7367a-6b9e-492b-837d-55c60d9f607d	t	Kabuyenge	7c974f67-7f90-4e6a-b16d-1ddf410b3c39
d3aa2547-3ad2-4030-89ed-ec8b602cb10a	t	Kamonyi	7c974f67-7f90-4e6a-b16d-1ddf410b3c39
76bd979c-37c5-46a3-915d-65fe7e4cedb3	t	Murambo	7c974f67-7f90-4e6a-b16d-1ddf410b3c39
10f670e1-6c39-4b1f-8819-161e8c09891f	t	Taba	7c974f67-7f90-4e6a-b16d-1ddf410b3c39
39d08cd0-36b1-42a8-9918-364d38faa1e3	t	Gatenga	4d9c242f-f574-4b2a-9365-5d80044fb933
4be32ed4-b7a2-4ab7-a904-1d0ceb1afb0b	t	Kinyefurwe	4d9c242f-f574-4b2a-9365-5d80044fb933
4c8f799a-8a78-4caf-89de-0d5ce8b7ddd3	t	Mubuga	4d9c242f-f574-4b2a-9365-5d80044fb933
26adcbfa-9588-4dc2-b44c-ddd5ae6bfec1	t	Ngoma	4d9c242f-f574-4b2a-9365-5d80044fb933
ee83d6ee-d5c4-49e7-a905-581a99810302	t	Remya	4d9c242f-f574-4b2a-9365-5d80044fb933
1f5f79d1-16eb-4900-8980-48a2fb969e3a	t	Rugandu	4d9c242f-f574-4b2a-9365-5d80044fb933
db2842a1-a69c-4e07-b807-a265b7c669ea	t	Seta	4d9c242f-f574-4b2a-9365-5d80044fb933
175950a4-f570-45f4-9c32-0b1b2aa9f410	t	Gahe	98f08225-e5b0-47eb-8d3b-ee0d15695343
0374b29d-ae0e-4c69-a4ce-5a27808578dc	t	Kanyoni	98f08225-e5b0-47eb-8d3b-ee0d15695343
1b535fab-ebdb-4f1c-b4fc-11528e4576e0	t	Kintobo	98f08225-e5b0-47eb-8d3b-ee0d15695343
36f1cee0-2f02-4a17-ae86-a8b5dea01339	t	Murambo	98f08225-e5b0-47eb-8d3b-ee0d15695343
690cee2a-f00f-4b8a-abbc-1b15b50212a9	t	Rukiniro	98f08225-e5b0-47eb-8d3b-ee0d15695343
a8040b94-7319-409c-87ec-d16ba27f1f4e	t	Rukwavu	98f08225-e5b0-47eb-8d3b-ee0d15695343
1a1a142b-31c6-43bb-8931-431683b4f1d0	t	Gashinge	e03018ae-a2b4-4349-ad7a-a32f11737785
0e41c07d-75e9-431f-9daf-0fee816e14f2	t	Gashishori	e03018ae-a2b4-4349-ad7a-a32f11737785
04280e63-6312-47fd-b989-6ec7c3b9b444	t	Gatete	e03018ae-a2b4-4349-ad7a-a32f11737785
f9371cbb-cf40-47c9-bc57-ec8a05845aad	t	Gitwe	e03018ae-a2b4-4349-ad7a-a32f11737785
845ebaa8-a320-4f5b-a6b0-84f232d2414f	t	Nganzo	e03018ae-a2b4-4349-ad7a-a32f11737785
8d9f3cdf-31b2-464f-9230-685fc5fdc294	t	Ruganda	e03018ae-a2b4-4349-ad7a-a32f11737785
ad54a568-b5cf-4b90-b6b0-b5a88ce87961	t	Rukingu	e03018ae-a2b4-4349-ad7a-a32f11737785
04af068b-dcb0-4911-b96e-84367a7d3f9a	t	Terimbere	e03018ae-a2b4-4349-ad7a-a32f11737785
246ddebf-48fb-4601-a27c-f010ddd2316a	t	Genda	d92f01fa-2eba-41a9-abef-3b2d8b19c9b0
f50ff645-247a-4460-b7e7-fa199bc8b767	t	Muremure	d92f01fa-2eba-41a9-abef-3b2d8b19c9b0
3b8e8bda-6b23-407a-8b01-48cdc6c10b85	t	Mweru	d92f01fa-2eba-41a9-abef-3b2d8b19c9b0
138e5293-4b36-4afd-8776-7e4e9669f7b5	t	Ngoma	d92f01fa-2eba-41a9-abef-3b2d8b19c9b0
12e3c289-56d2-4ce5-95d4-25c5ddb66f3f	t	Tetero	d92f01fa-2eba-41a9-abef-3b2d8b19c9b0
160380a2-5e81-4ca9-a189-7036cbd53562	t	Bugambanyon	477f8cf5-ef2e-4c59-9a0e-dc275a7b3f4c
f96b5b4e-a4af-4460-91c8-a7101c3b769f	t	Gasura	477f8cf5-ef2e-4c59-9a0e-dc275a7b3f4c
4204fe68-956c-48a2-9168-f24d38438806	t	Gatokezo	477f8cf5-ef2e-4c59-9a0e-dc275a7b3f4c
86c420d9-2509-4002-8525-45060819bf33	t	Matyazo	477f8cf5-ef2e-4c59-9a0e-dc275a7b3f4c
80cc4359-b383-4585-ac70-c56b219daf26	t	Rubyiniro	477f8cf5-ef2e-4c59-9a0e-dc275a7b3f4c
de3a36b5-a543-4d2c-a8ed-d7089d54169e	t	Rusenge	477f8cf5-ef2e-4c59-9a0e-dc275a7b3f4c
d59c2b77-a9a0-499e-8855-fece52ca49d3	t	Tarasi	477f8cf5-ef2e-4c59-9a0e-dc275a7b3f4c
4c7f1ddb-a244-4414-aea5-8f1b8272a562	t	Bucyaba	8f0714dd-da92-4d70-9628-23de582a172b
274b8113-59af-4c2c-bd11-3b0a9c43dcb7	t	Buzamuye	8f0714dd-da92-4d70-9628-23de582a172b
8d316b04-8841-42b1-a03f-80daec740d81	t	Gikore	8f0714dd-da92-4d70-9628-23de582a172b
6305bf38-c1d2-4d5c-bd81-6b8aede2d123	t	Ntagara	8f0714dd-da92-4d70-9628-23de582a172b
451b2320-264e-4091-81c4-3fb8c2843ad3	t	Burehe	62316bcf-5893-4fac-bb09-ab6277d7d524
82f9beb1-d62e-4a17-a6f4-b7fc71d94559	t	Gitovu	62316bcf-5893-4fac-bb09-ab6277d7d524
d8d364ef-374e-4081-88bf-04950e21836e	t	Kajerijeri	62316bcf-5893-4fac-bb09-ab6277d7d524
3f923357-e3f5-4d8a-8ca6-99a98823675f	t	Karorero	62316bcf-5893-4fac-bb09-ab6277d7d524
e454a5aa-39de-438a-8c67-84c975292e71	t	Kirambo	62316bcf-5893-4fac-bb09-ab6277d7d524
8034d28f-0425-4612-bb6a-1c2179aa51da	t	Ndago	62316bcf-5893-4fac-bb09-ab6277d7d524
26defc26-b540-47e1-9a47-fdbeaee8bd9e	t	Nyarungu	62316bcf-5893-4fac-bb09-ab6277d7d524
3179bf89-54a7-4fa8-afbf-65549f4bf104	t	Bumba	2362ca94-6ef8-4009-b9e0-b3cb53e8f2a5
5ea2c843-d250-4219-bdb8-88cefeb95e7c	t	Karuhanga	2362ca94-6ef8-4009-b9e0-b3cb53e8f2a5
5b707c3c-cccb-4975-a595-a0e96d68a832	t	Ruhurura Ii	2362ca94-6ef8-4009-b9e0-b3cb53e8f2a5
d9434ff5-804f-44a0-b9f1-ddcea004982e	t	Rutoro	2362ca94-6ef8-4009-b9e0-b3cb53e8f2a5
41075c02-a239-48ab-bab1-e72c80619bf4	t	Burindwa	d4a936e0-1bf3-4b50-a0c2-b6688810c777
01640dc9-8187-4f1c-95f0-d64464911014	t	Bisaga	e8de8ade-6d1a-4a98-9cfe-f098043eeaf1
e854d64a-1169-44f5-9ad5-c5054a6e02de	t	Gashoro	e8de8ade-6d1a-4a98-9cfe-f098043eeaf1
fee664ba-420b-47fa-a752-ef072bcb23b8	t	Kibuye	e8de8ade-6d1a-4a98-9cfe-f098043eeaf1
ffd76969-9122-4d44-a68e-de6831314dc3	t	Ngonya	e8de8ade-6d1a-4a98-9cfe-f098043eeaf1
6f0e0efb-da73-4f25-81d9-740a8ae1e4b3	t	Rugezi	e8de8ade-6d1a-4a98-9cfe-f098043eeaf1
dcd844bf-c326-4f43-8417-888f26457110	t	Rwerere	e8de8ade-6d1a-4a98-9cfe-f098043eeaf1
4114133f-dc0a-4cab-bbc3-a4d0e1c85c6c	t	Buhore	6d1d7118-6b92-49d0-b17d-e5950be2b984
7ec1e73e-7172-453d-8fd0-a1f0efd3f991	t	Gakenke	6d1d7118-6b92-49d0-b17d-e5950be2b984
b454fdc2-b550-4b4a-8b4b-5433f0fcb641	t	Kamatengu	6d1d7118-6b92-49d0-b17d-e5950be2b984
34c85898-b9b3-4e4c-8247-2b2f3da9d7d7	t	Kinkware	6d1d7118-6b92-49d0-b17d-e5950be2b984
72d79a87-148a-4110-b1c2-33c3d56d552a	t	Mugera	6d1d7118-6b92-49d0-b17d-e5950be2b984
27e9b249-e7d0-408d-b50b-d7473ef1356a	t	Ngoma	6d1d7118-6b92-49d0-b17d-e5950be2b984
708c4b35-1108-4771-9f33-29ff949cd27e	t	Ruconsho	6d1d7118-6b92-49d0-b17d-e5950be2b984
ef665da1-e0d4-41ba-be80-54c77db0fb3d	t	Gatovu	6befbb69-09aa-496b-b408-3109386a8dbc
268605f5-cadf-439c-9c10-0e30167da7a7	t	Mucaca	6befbb69-09aa-496b-b408-3109386a8dbc
d89f76c2-396d-4875-bdd1-1c826e2a0dae	t	Murambo	6befbb69-09aa-496b-b408-3109386a8dbc
f1b77d7b-dcd0-4350-b8f1-95c04683a865	t	Mushubi	6befbb69-09aa-496b-b408-3109386a8dbc
9515766c-8b32-4f06-aa06-496c9aa477b1	t	Tangata	6befbb69-09aa-496b-b408-3109386a8dbc
bf3f952f-a66b-4d1b-9923-1c5f39255a6d	t	Birambo	4b983608-2a46-4d29-ad62-dd2face05f9e
8de620d4-53c2-4896-87c5-bbefbc326fba	t	Kirwa	4b983608-2a46-4d29-ad62-dd2face05f9e
ac7ffa1c-d257-4612-b55d-a0f0dc231bd8	t	Nyarubande	4b983608-2a46-4d29-ad62-dd2face05f9e
5858aac4-b7c0-4b57-a1ac-4ca2d9529cf7	t	Butereri	d93f86cf-2124-4df2-9042-32cebcb043c0
d4f6c2ae-9229-4d7b-a80b-49f49b649d34	t	Rubaga	d93f86cf-2124-4df2-9042-32cebcb043c0
65fdbb0a-3289-47ac-b040-a2c8ed03756d	t	Rwinkuba	d93f86cf-2124-4df2-9042-32cebcb043c0
f6f8d4b3-af7f-4064-be72-49f508e988f3	t	Kajereri	fe65939b-f553-48b0-8c82-fc7ac10fd3dd
d22f8371-4d5a-4eda-b15b-2962ee3b3b23	t	Kamina	fe65939b-f553-48b0-8c82-fc7ac10fd3dd
914103b0-fd9f-467e-a6da-e5d27caebfdf	t	Mwendo	fe65939b-f553-48b0-8c82-fc7ac10fd3dd
3eb2d395-d763-4764-851e-a7127eff5240	t	Rusebeya	e1320956-542d-4297-aab1-0db0f158bd16
affb2699-232a-4aaf-ad81-d49355fb79fa	t	Mugunga	ed88ba87-58b7-47f6-ba32-75fecca347d5
5dfaebc3-11f5-4843-a82c-756bf1d4b1f7	t	Rutenga	ed88ba87-58b7-47f6-ba32-75fecca347d5
3025db60-ec5b-4920-854a-52d7fbbf0e40	t	Gashirwe	afb2ba7c-464b-416a-9352-543afe356e42
fe52401c-c39e-4611-ba10-6e87386e3730	t	Bukamba	80a011ea-84d9-481e-8afe-f5342b4c72fc
694b03b7-6e6a-4cff-942f-140415a246f1	t	Ntarabana	80a011ea-84d9-481e-8afe-f5342b4c72fc
0467dc96-a953-45ca-9cfe-e44eb7139551	t	Burengo	1f18ca93-dc94-4883-bb68-ad390e6416c7
d4d00243-3e3d-4d5d-a2f7-b7fbcc54aee9	t	Bushyama	1f18ca93-dc94-4883-bb68-ad390e6416c7
be8d4bac-ba84-442e-93a7-ce79c08eb27d	t	Matovu	1f18ca93-dc94-4883-bb68-ad390e6416c7
6c3de98e-f68c-4b78-a15f-627b0675d564	t	Rwahi	1f18ca93-dc94-4883-bb68-ad390e6416c7
6531ba34-4c15-4a84-a1f2-a6051acd7c56	t	Gaseke	fe6eb7d8-2abc-4b63-94fc-ffcf6c09982e
ab025108-2c94-41f9-870d-41726dab3d3b	t	Karambo	fe6eb7d8-2abc-4b63-94fc-ffcf6c09982e
861de512-572f-4854-8fc3-c56b4bef6b1b	t	Musasa	fe6eb7d8-2abc-4b63-94fc-ffcf6c09982e
3f09c358-77e7-41ad-8ef4-0ab1cd2f010b	t	Gikamba	43063249-0e1c-4d77-b0ab-3da651a2130a
3c68ca07-9136-45dc-a830-ec7daeb3f777	t	Gitaba	43063249-0e1c-4d77-b0ab-3da651a2130a
f98fc544-cd4f-45b5-958f-6b823278cb8d	t	Busoga	770219e9-8d7c-4311-ad1a-8d1f0c648f28
140821cb-633e-4a20-93f3-35bb0e9122d6	t	Karombero	770219e9-8d7c-4311-ad1a-8d1f0c648f28
ffc25212-19c2-4efc-b386-53a07f6da59d	t	Muhaza	770219e9-8d7c-4311-ad1a-8d1f0c648f28
776bedf2-7998-4fb4-9555-e31c273d4495	t	Mushirarungu	770219e9-8d7c-4311-ad1a-8d1f0c648f28
64d0ff55-bc74-451d-bc2a-5ad9295a61b6	t	Ntaraga	770219e9-8d7c-4311-ad1a-8d1f0c648f28
298aeca1-268d-4bf0-a4b7-825dcef8d9a6	t	Rutaramiro	770219e9-8d7c-4311-ad1a-8d1f0c648f28
dec0d4d4-a351-497b-9496-832a5ed6e2cc	t	Gatoki	22cfccb4-e290-40c6-9da2-8f6d2a856e54
bd757777-2e52-4375-8700-973d2b908938	t	Gatorero	22cfccb4-e290-40c6-9da2-8f6d2a856e54
09cb9fbb-0806-457c-ad0e-16ec2c6ca5fc	t	Karenge	22cfccb4-e290-40c6-9da2-8f6d2a856e54
dd45f903-427f-4109-b797-58e3f41994b5	t	Muhororo	22cfccb4-e290-40c6-9da2-8f6d2a856e54
dfd700f8-f9f2-485f-a921-c8c6c353d048	t	Musebeya	22cfccb4-e290-40c6-9da2-8f6d2a856e54
82fe6e25-09cd-4865-9f37-21d7750c4ab8	t	Tongoburo	22cfccb4-e290-40c6-9da2-8f6d2a856e54
2ba76a50-77b7-4cad-ae55-93dc08cfc3c4	t	Gahama	4ca65170-2d7e-48c8-a064-1cb45878406a
680eb17e-203a-4615-8536-697c3d6a8cd3	t	Musebeya	4ca65170-2d7e-48c8-a064-1cb45878406a
3c7b0a0d-7b8e-41a6-a758-ca4d7ef8b647	t	Rugaragara	4ca65170-2d7e-48c8-a064-1cb45878406a
af7d2479-fcef-4995-a61c-02fdae143189	t	Rwobe	4ca65170-2d7e-48c8-a064-1cb45878406a
cb7d0f2b-e527-420d-bd42-6605cfe4e9d2	t	Kambare	275a40c6-e9ff-480d-851e-8446df00f20a
c73f274d-3c04-4d6c-9145-ee28173a6b18	t	Kanyamukenk	275a40c6-e9ff-480d-851e-8446df00f20a
93d2f58d-8f02-4e1b-9053-57fa212694f3	t	Mutanda	275a40c6-e9ff-480d-851e-8446df00f20a
76b2e460-0570-4c25-b735-c29fc09f92f5	t	Nyabisika	93b9fa09-4ae6-400d-bfb8-bd76770f47f2
c72bee8e-c06f-4bf2-8750-dbc63339cbd3	t	Rukore	93b9fa09-4ae6-400d-bfb8-bd76770f47f2
d550105e-8e22-4576-ab27-6edcb405378f	t	Karorero	4a8f1cab-899b-4d57-8d87-e633fb713764
350b2bad-57db-446d-8208-dcfbf8b802bf	t	Kamatare	eeab8207-73e1-4bc7-bd49-4789de7349e7
63d462bb-00c3-4ebf-9186-aa5da39fe5b7	t	Musave	eeab8207-73e1-4bc7-bd49-4789de7349e7
5dab8be8-9052-49a3-b6d2-00dd4b69848f	t	Gishyinguro	b7eef486-0f59-4895-8d24-b8ec8dd0dcbb
ade3918f-d67b-41be-aab8-8f210634d623	t	Karuganda	b7eef486-0f59-4895-8d24-b8ec8dd0dcbb
1818cf19-766e-4390-9a4e-4f97acd234a3	t	Kabaya	cbbaf75e-ee69-4538-be60-b1086822f096
9b37b944-c3a6-4965-a8c2-7ff04bb3ec44	t	Sitwe	cbbaf75e-ee69-4538-be60-b1086822f096
9618f37a-7e0e-4b0a-9dfd-18fbf633d3b7	t	Umujyi Wa G	cbbaf75e-ee69-4538-be60-b1086822f096
866087e0-3755-4bdc-acd3-e2c1532e9adf	t	Mukira	3019db8f-4eb0-4076-8b0e-387a4f792115
7053f3b9-1202-4749-9107-89f7e6b4052b	t	Nyamure	3019db8f-4eb0-4076-8b0e-387a4f792115
463548e0-098f-43cd-9ccf-bd3cf72ce15f	t	Ruhore	3019db8f-4eb0-4076-8b0e-387a4f792115
8f7675ac-c5c1-46ee-abfd-2f14f1e4bd8a	t	Kirambo	6eabb731-78cd-4ce8-826a-b7ca263ed0fa
d2a53897-2013-41fc-929b-f7406567196d	t	Nyamataha	6eabb731-78cd-4ce8-826a-b7ca263ed0fa
d55e460c-3410-4f37-b881-8178859c4ce2	t	Kabugomba	f58745df-75ce-4788-b8d6-f51429c73722
50cd579f-6158-42a8-9582-aae53effd9bc	t	Murambo	f58745df-75ce-4788-b8d6-f51429c73722
d7018867-2b2f-4990-9006-ceff6db7b1f7	t	Busaro	14016797-ac5a-41bf-9863-e9feacbc6d3b
fbf2609f-c7b4-4273-9f3f-09bfb41b7b00	t	Bushita	14016797-ac5a-41bf-9863-e9feacbc6d3b
806bb012-7af6-4180-aa22-554cb4a78a17	t	Gihanga	14016797-ac5a-41bf-9863-e9feacbc6d3b
5ac8eded-7b39-48d6-bfb2-44a534d343b4	t	Kanteko	14016797-ac5a-41bf-9863-e9feacbc6d3b
c4e14fa8-a00e-4475-8e30-37aeaf075be3	t	Bukerera	c781a188-1297-41c9-bc1f-7d6dfbe50e3a
c1b7eee6-d581-4c46-9d0e-364f4fb54d42	t	Kibonwa	c781a188-1297-41c9-bc1f-7d6dfbe50e3a
176b36b6-394a-4b30-93e9-e8d33fa7d324	t	Gitega	15381976-08d5-4fcb-af33-43bfebe428d9
ca55e75b-ac61-4c85-8062-17074d6c25ee	t	Kinoko	15381976-08d5-4fcb-af33-43bfebe428d9
2a1f4d17-3a65-4dc9-b247-abab92f7275a	t	Rusasa	238c506f-8880-4528-bc99-34f797ad77d2
41e0fba3-34c3-4f00-b342-0ad5e8981584	t	Rutake	238c506f-8880-4528-bc99-34f797ad77d2
15223974-b2d6-4d0a-83b1-c6a590e12e74	t	Gitwe	ad6f8751-2e8d-4bdd-8d53-459b93af6e40
bacaa77b-4853-47c9-bb36-22e5644e3b63	t	Kabuye	ad6f8751-2e8d-4bdd-8d53-459b93af6e40
47f8992d-57b5-41e1-b0bb-9dec6e0b2144	t	Rugari	ad6f8751-2e8d-4bdd-8d53-459b93af6e40
da1a7856-c06a-4d1c-8a4c-98baadbd25a9	t	Bucyaba	1984ec2c-1b07-49bb-b9a7-e4cab66c6f10
0ae25bd4-873f-475c-9798-4b659cb904f5	t	Bugogo	1984ec2c-1b07-49bb-b9a7-e4cab66c6f10
2bedaa56-27b4-4b15-a1db-606873c4ccf8	t	Rutagara	1984ec2c-1b07-49bb-b9a7-e4cab66c6f10
bf6a2df1-2e3e-42f3-9074-83ded0eb2a84	t	Mbatabata	b05d2ef0-ece3-4301-9840-327c3920959c
9cf0e988-8bbb-4d11-b772-19da998bde40	t	Kabutwa	1a58b3a0-f3c8-417c-8b7b-b07ebf8b6b64
15143ade-58b1-4b53-845a-9efca66c79d8	t	Kabutare	46b2f50d-2287-4e5f-9634-30c7048b41cd
151971fc-2388-445e-a33a-7539604bf35c	t	Cyumba	553ef2a5-cfcb-4b35-9e3d-a1166fa8109b
8b0ead24-4fa3-4ac1-980f-461ea75de017	t	Bukondo	d694e50e-185c-4425-8008-284824cc7ebe
b143197a-0549-4fa1-a540-3e29cd27792e	t	Bukunga	d694e50e-185c-4425-8008-284824cc7ebe
5d0ec306-a33c-4ffc-aea6-e1bbdd666fab	t	Bigogwe	2c3e101b-b66b-4134-864c-c5b0c1384b39
ac60b3fe-c5dd-4b89-8ae8-193462eb4834	t	Nturo	3af8489a-fc66-4557-8f30-e91a1ba41272
34e90a8f-aa31-421a-80b8-18351da1f7bf	t	Mugali	f3001f02-ea92-43c8-b4d9-798c041530a6
6cafe7ba-e4ab-4c68-83f7-ff9780ebf460	t	Rurambo	f3001f02-ea92-43c8-b4d9-798c041530a6
5bacdb85-1d82-45db-8518-c0dfbf35261f	t	Rutamba	f3001f02-ea92-43c8-b4d9-798c041530a6
5b4dd77c-e0a8-471b-93b2-51ebf279b006	t	Rwamabare	f3001f02-ea92-43c8-b4d9-798c041530a6
1808ae43-06cf-49dd-a211-6e720372be35	t	Kivuruga	4349a211-413d-4e32-b75d-a817d644e7f4
dde6e80a-d9af-4791-be31-e9b9bc97bf4c	t	Nyamiyaga	ede7f785-9621-45a1-82df-77cc097db31b
0d6cf7fb-5f41-4658-b1d5-c3b61fc7d275	t	Muhororo	6214cb76-cc01-4ce9-8478-778ed4f0cb1f
5ab36208-3d56-48ec-a77d-e9105f186fa0	t	Munini	6214cb76-cc01-4ce9-8478-778ed4f0cb1f
28be6064-f9f3-4f50-a462-f444e2fe8b05	t	Ruhanga	6214cb76-cc01-4ce9-8478-778ed4f0cb1f
5ea4e009-1b7b-4aab-8d73-9ad2a7c360dc	t	Gihita	a9c48de0-bb09-4a70-8e49-7469191004c6
2f491a30-d1fe-4384-a37e-26ccf0905570	t	Karambi	a9c48de0-bb09-4a70-8e49-7469191004c6
653a230d-93eb-4a33-a9dd-c53a21f07a31	t	Mwanza	a9c48de0-bb09-4a70-8e49-7469191004c6
c1b12956-b897-4cca-806f-caaf5b69d576	t	Kigeyo	75531138-cc58-4605-9905-0d8527b29ebf
167dc8ac-6403-4dc2-9f32-adc4c73246fd	t	Kivuba	f232fc49-5421-4359-87a0-9b42c32f6543
aea5a0aa-705d-4ac6-ade7-ab0dcce720a8	t	Gisovu	11f69e85-f736-488a-aa2e-47cc986d0843
d3de446b-1b4a-483e-bdbc-632dff7fa8d8	t	Kabuga	11f69e85-f736-488a-aa2e-47cc986d0843
ccb81080-617f-47bf-b946-617fbfdd563e	t	Nyanza	11f69e85-f736-488a-aa2e-47cc986d0843
426c3967-2365-457b-ac49-32a855af1330	t	Gitaragwe	c7596155-6a94-41b8-9983-45d0d4b26c96
c4be9d2b-b732-4dd3-8b85-a4c87fb79382	t	Sarabuye	c7596155-6a94-41b8-9983-45d0d4b26c96
20b45638-d7e0-4ab4-8851-d8eba10e525f	t	Cyinama	fd6b0692-62ef-40b7-b239-e53f72c1df67
3311b282-b645-4631-9766-07929a9275c1	t	Giheta	fd6b0692-62ef-40b7-b239-e53f72c1df67
66ec1e43-9da9-4ff2-8dd5-1204f3f99ad0	t	Nyagahondo	fd6b0692-62ef-40b7-b239-e53f72c1df67
191a8f9b-f570-4d99-a7f5-f81d5b0feacc	t	Nyakagezi	fd6b0692-62ef-40b7-b239-e53f72c1df67
9c9bc1a9-f046-4d95-8832-36c9bb39d07a	t	Rwimpiri	fd6b0692-62ef-40b7-b239-e53f72c1df67
e2667be5-2652-495a-a73b-ce58eb290604	t	Cyarubayi	1779ba7d-0c56-4ff9-9aa8-441ec991bb0c
43455d1b-d3ed-4f0a-b60d-a831a58e964c	t	Karambi	1779ba7d-0c56-4ff9-9aa8-441ec991bb0c
0869c4a0-df51-4b72-9407-808dd56b4d95	t	Muhororo	1779ba7d-0c56-4ff9-9aa8-441ec991bb0c
6c7b53c0-6519-4ae3-87aa-40367a9d8962	t	Nturo	1779ba7d-0c56-4ff9-9aa8-441ec991bb0c
4045d691-a4c8-474e-a7fb-e1b6b3586f98	t	Rwezamenyo	1779ba7d-0c56-4ff9-9aa8-441ec991bb0c
446de6e8-b2f0-43b7-8bc2-e45c0a1650c4	t	Kabuga	0bc7fdb3-a73e-481e-89a4-581d2b4da194
8ccc6184-7f85-4f90-b732-d2a7d8ea56af	t	Kanaba	0bc7fdb3-a73e-481e-89a4-581d2b4da194
7bb8383d-7085-4e07-9b2f-6f51db4e8045	t	Rusebeya	0bc7fdb3-a73e-481e-89a4-581d2b4da194
e7d10eb4-cf28-4709-a4a3-8103985259a4	t	Gacemeri	eaa8326b-690d-4b5e-88bb-6c05277f58ec
626c3eca-72b0-452c-b827-6f0b18b1f6ae	t	Gatonde	eaa8326b-690d-4b5e-88bb-6c05277f58ec
aa71eaeb-67bb-44ca-b58d-3d8dede5f5ac	t	Muhororo	eaa8326b-690d-4b5e-88bb-6c05277f58ec
d4b052f2-25a7-40f7-ac7c-156e706f4420	t	Biraro	e4748691-f00c-44ad-9082-b376512f3d66
2489ea51-fdf9-4f93-bcbd-7abcc2cc600e	t	Bushoka	e4748691-f00c-44ad-9082-b376512f3d66
6e72d1a7-e94c-4b93-9b25-11e8548afee5	t	Gashubi	e4748691-f00c-44ad-9082-b376512f3d66
b73c74bb-0261-44c4-991c-bb6bed065260	t	Kanyinya	e4748691-f00c-44ad-9082-b376512f3d66
739f1575-a025-476e-8ed3-291fdcef9c90	t	Busake	d4155d30-233f-4b6d-87dd-c5f41172475c
6205b739-57bb-4f66-b09b-bc69922783cb	t	Gatare	527c4906-26d5-425e-b798-bdd4092bbb2e
a1a98e67-1e3d-4863-821e-f7d36673311e	t	Gahinga	e30aa655-4c5a-41d5-a63e-b255b3ec376d
d5f39a60-65ad-4965-bcd4-d28929a21b30	t	Taba	c13c1cba-c0e2-4ee8-bb7f-61dc87bf8c54
7f944a94-d17e-4a46-a09b-4eb4fe3cf4ce	t	Huro	84308b13-6498-44ff-a977-0d2d7556ffaf
cd80cad7-7e48-4fd1-b7f7-e8bbd1bed70f	t	Cyenda	c1971109-6aec-4cb0-ab53-af9536671811
79934bb1-50ef-43c8-bda3-76f89aa452c0	t	Buhinya	35ab2ca0-d41e-48c6-aff2-db43bc713c82
e58f0626-2e66-442a-89a6-2fd7c480925a	t	Mubuga	f8be8150-9adc-452a-bc53-55d6bf57558d
1dde0f86-534f-4faa-99c6-25e22686cffc	t	Bumba	a3dee1d7-776d-4de5-967b-3a7213e07869
6d34c0e6-b1f3-45bf-88b0-d5a8a9036973	t	Kabingo	d0e33319-ca2d-4d22-a18b-304e1fd525f7
1c02d206-3934-46f2-a7a2-0950c3254b0c	t	Sanzare	d0e33319-ca2d-4d22-a18b-304e1fd525f7
9da4e082-dce9-4a9f-a7a1-2338805d7c64	t	Muhororo	bab512f0-da47-4d54-a3ce-1c1ab72687cb
9843874c-1331-4605-8673-c0c4d9ff4b52	t	Nganzo	bab512f0-da47-4d54-a3ce-1c1ab72687cb
279ddefb-fe18-41ec-9ad7-33a8a164e1ff	t	Gitabi	5f049e8b-cdd2-4e64-b478-b031cd7855dd
5ea21c04-f24c-40c2-9571-b424b12004a6	t	Kasheshe	5f049e8b-cdd2-4e64-b478-b031cd7855dd
26998bec-99fa-4972-be45-284080c450b6	t	Mwirika	d8fdecb7-aa25-4164-9467-80a9203dbbac
194afabd-8071-4f4c-a393-324d7ce658be	t	Cyinturo	6236ee92-8166-464d-9c11-0f63eaa98350
2b7f2ebf-34e9-49c0-bd3f-aacb805c4de0	t	Buranga	1057368c-3c84-40b8-a709-5bef1d34c7b0
ad689d20-beae-41fe-838d-41c5754beeae	t	Bukurura	863ee5ef-7f08-49c0-b69e-a1846ec91127
b866b6ac-04e5-42dd-b228-e7667e593f16	t	Gisagara	486d8b80-ba4e-432a-9f8e-8d48772fb2f9
fcf2af18-b72e-43e4-be20-c5478a4719bf	t	Kabushara	486d8b80-ba4e-432a-9f8e-8d48772fb2f9
4950bfe1-1779-446c-a108-2f84ac7c0e80	t	Kanama	486d8b80-ba4e-432a-9f8e-8d48772fb2f9
567463d7-3f30-4c07-8275-616acc717b0d	t	Kanunga	486d8b80-ba4e-432a-9f8e-8d48772fb2f9
c5a41648-6e4e-4a4e-ab01-177217392bf4	t	Kirehe	486d8b80-ba4e-432a-9f8e-8d48772fb2f9
64d2e6c4-5a6d-4119-86ad-215f00dc89e9	t	Mushubi	486d8b80-ba4e-432a-9f8e-8d48772fb2f9
4eab4c45-e9b1-4d68-a485-ca3c126e8a50	t	Cyahafi	2d1b99b9-de80-4111-ba76-01d3d3b1245c
81917980-df77-40ea-8b42-f70e31772de2	t	Gatare	2d1b99b9-de80-4111-ba76-01d3d3b1245c
f3b82058-ce1e-4b5b-a3ca-7111827221bb	t	Kiruhura	2d1b99b9-de80-4111-ba76-01d3d3b1245c
0cf53458-c3c4-4007-9df1-577639cb31ed	t	Cyoganyoni	6a414e21-29fe-42ac-ae97-a0edd5e8cf64
8e77e62c-7d8c-436f-800e-55683a5a4467	t	Kabare	6a414e21-29fe-42ac-ae97-a0edd5e8cf64
9c1b5f52-8689-4c7f-b52f-0e08dd1fc00e	t	Rugaragara	6a414e21-29fe-42ac-ae97-a0edd5e8cf64
7c7ad9e5-cdd2-4b71-87b9-850e5566d363	t	Bushoka	8b6bb3ea-1b1e-422b-a622-aa0b974273b1
c7fefaa5-c0d9-4af8-a6a0-7d00748b002f	t	Karango	8b6bb3ea-1b1e-422b-a622-aa0b974273b1
e50054e3-886f-4906-8b43-82b4184b5835	t	Rumasa	8b6bb3ea-1b1e-422b-a622-aa0b974273b1
8ecf388a-158a-4813-842d-e8a11d68c005	t	Gatagara	577e50e0-81a7-495a-9389-e46bf54c2e1d
4e8db8e2-52f7-402b-a83a-36dc5bdc6d38	t	Gihura	577e50e0-81a7-495a-9389-e46bf54c2e1d
c5901fae-6af0-492c-a859-f9d879117f57	t	Gitonde	577e50e0-81a7-495a-9389-e46bf54c2e1d
bcfe015b-32db-434f-9c2a-c4ad8cc81810	t	Kinyonzo	577e50e0-81a7-495a-9389-e46bf54c2e1d
76376f7e-2657-4f0b-ab82-e5e57fb519ed	t	Mubuga	577e50e0-81a7-495a-9389-e46bf54c2e1d
22d8a40d-e482-4da4-88a7-04381844aca8	t	Murehe	577e50e0-81a7-495a-9389-e46bf54c2e1d
d67ec284-1dcc-41ba-be98-9bd52d63ec20	t	Bariza	0bd6943e-d4b6-41bc-8562-b6084fc29d6a
63bc4af2-2239-44d6-af85-4b39636a80b8	t	Gataba	0bd6943e-d4b6-41bc-8562-b6084fc29d6a
f468f39e-a174-4961-9fbf-0a5c893a1326	t	Gatare	01ccf2d5-0abd-4c28-b265-9538c0286dd3
97333433-4f2c-48e2-8f60-4dc88c91b48c	t	Mugwato	01ccf2d5-0abd-4c28-b265-9538c0286dd3
e70c850e-f80f-4f5b-8e51-1fc904351113	t	Gahama	9804a62e-89ec-4903-aaed-00ee76714c5e
ae47f19a-f037-4a5f-bc24-874a056709f7	t	Gataba	9804a62e-89ec-4903-aaed-00ee76714c5e
6ed3f283-3086-4dce-9b99-028d260850de	t	Kebero	9804a62e-89ec-4903-aaed-00ee76714c5e
337a9ad6-94cc-439c-8ae3-c746e5a1508c	t	Burinda	40b081f0-1997-4663-9ed4-068237ed475d
8826dd0c-d494-4f71-9fd6-e7dca9d09c81	t	Gakindo	40b081f0-1997-4663-9ed4-068237ed475d
a65f8cde-226d-49cf-98b6-a9cf19d8c25e	t	Gapfura	40b081f0-1997-4663-9ed4-068237ed475d
58f9c975-00fe-4b44-a4e6-90d5e02dc82a	t	Gitwe	40b081f0-1997-4663-9ed4-068237ed475d
0828fdc1-4564-44a5-bc2e-78dc0b6feb8c	t	Kidomo	40b081f0-1997-4663-9ed4-068237ed475d
9fd432ef-8fda-457f-a4f9-3491664aed45	t	Nyagahama	40b081f0-1997-4663-9ed4-068237ed475d
92ebdf28-75e5-45a9-ac43-2456fc30d3bb	t	Rurambi	40b081f0-1997-4663-9ed4-068237ed475d
e2b08107-480b-4276-a618-847841edcf10	t	Buharabuye	ebdb87b6-51f7-426d-8792-d8a71a2b52f3
53eb4f91-3858-40cc-a9c4-983a29587fc9	t	Karuhunge	ebdb87b6-51f7-426d-8792-d8a71a2b52f3
ba4dde1a-b3d2-4605-ad86-b55b4e318964	t	Kirehe	ebdb87b6-51f7-426d-8792-d8a71a2b52f3
95032172-0578-49d4-99b0-63c363416b8e	t	Nyange	ebdb87b6-51f7-426d-8792-d8a71a2b52f3
e66ca37f-8f3d-4e49-bbb1-e4101e23acaf	t	Gisovu	b1b07e27-f959-4607-a6d3-044845fc85cd
b1238c40-77ed-406c-8b01-9a6afe127c5e	t	Bukiza	e52388a6-2561-467e-9da0-2593a1747040
5006e4de-db9b-4fc7-b2d8-f541f536dc9f	t	Buyora	e52388a6-2561-467e-9da0-2593a1747040
8b77ea25-2c92-433d-a443-24e39030b524	t	Bwanamo	e52388a6-2561-467e-9da0-2593a1747040
7fc166b4-c70a-46be-a3fc-8748bc3425ce	t	Ninda	e52388a6-2561-467e-9da0-2593a1747040
6ba165c0-6f59-4c83-90f4-53a9b5e1de67	t	Kabuye	97cc1ec9-6508-4c88-a697-74a059a9d120
0be226fb-e313-47f9-b371-afb11e5d3bee	t	Gisiza	ef4d5d01-d5a3-42d2-9211-234f8fe03163
d29869c5-b3e9-46eb-8963-52eaa758e0a4	t	Nyagasozi	5ff50620-61ff-469e-a50c-b5d57754ce7c
d24713fd-0242-467f-a5f4-6a35039f88e5	t	Rugarama	5ff50620-61ff-469e-a50c-b5d57754ce7c
cc767054-6562-4384-bc99-96e88c01a32a	t	Kabeza	aaccd332-027e-431b-97a8-2256b476a68b
659dffc1-dc40-47cb-901b-36a13f839363	t	Nganzo	aaccd332-027e-431b-97a8-2256b476a68b
e524ef70-898b-4369-bc65-5f9e7f0ee97f	t	Gisanze	1d93d814-d565-4520-b1b1-ce18c0334278
f8106f19-f510-42d4-b49c-83a5bbe630af	t	Gikongoro	02b571c8-7495-45fc-90f0-a57782757449
129d1b80-0d23-47ae-a398-ec0e0ce379a5	t	Giheta	4ff566f7-ff2e-46ac-8343-fb8bec29a1a5
80d4c347-a221-4a81-800e-9dcfcb36cc90	t	Karushashi	4ff566f7-ff2e-46ac-8343-fb8bec29a1a5
2a5ca30c-392e-48d1-809f-dd093ced1fc9	t	Gihororo	f13bb61b-0a0f-40cf-8348-d75b7738ebbc
7c042859-e8b0-4486-81c9-0931ba5d7303	t	Murara	f13bb61b-0a0f-40cf-8348-d75b7738ebbc
49cc190f-d9a4-44fa-87b1-9d5231cc6637	t	Nyarutovu	969ba40f-1be3-42dd-a758-627f1809a122
f641ce5f-7b5b-4091-9757-5f9df5fd6e52	t	Rebero	969ba40f-1be3-42dd-a758-627f1809a122
261d38ba-06d2-4a79-99a9-4d9a2b56957a	t	Kanyogote	5651ce20-000e-470a-945d-7265dd2a6703
719836fb-3878-40fe-a181-8fbf8aec2f7f	t	Rugogwe	5651ce20-000e-470a-945d-7265dd2a6703
7f699229-58e0-4be6-a9cb-084524ea2b94	t	Rwarenga	5651ce20-000e-470a-945d-7265dd2a6703
37208eeb-8803-49c3-b8e7-537975cf9d38	t	Butare	f83a067b-f304-40ae-bdd1-17ad4a7fb192
67adff1c-f2c1-48bb-ac31-0de778c36da5	t	Karambo	f83a067b-f304-40ae-bdd1-17ad4a7fb192
91227c8e-5eb4-4c2b-b171-653662833bdf	t	Gicaca	06f9f747-138c-418a-a8c7-08a3db5679c7
0d6e44e8-4e2e-47e7-8146-9e1926ea4451	t	Mugorore	06f9f747-138c-418a-a8c7-08a3db5679c7
06cce30f-4054-48f0-81d0-87db55fef4f5	t	Ntarama	06f9f747-138c-418a-a8c7-08a3db5679c7
e0a35713-7ebc-4766-90ee-3c2a66832141	t	Kabuye	d8d96dea-c532-4bcf-8459-f36ff9c15a90
e83f9174-aa51-4bc3-b5ba-b37ed5c3a1e6	t	Kidandali	d8d96dea-c532-4bcf-8459-f36ff9c15a90
301f13af-550c-43bc-b27d-9505f89943fe	t	Nyarubuye	d8d96dea-c532-4bcf-8459-f36ff9c15a90
e67b8ca3-694c-4c8b-99bd-54b408b68477	t	Rutoma	d8d96dea-c532-4bcf-8459-f36ff9c15a90
a7710390-65c2-46f8-8fcb-5a641f267f35	t	Kumana	3cd56c2d-35c6-4062-aa62-34fbd6471dc8
ec788858-5351-4730-9a16-8b9a4c693594	t	Kumunini	3cd56c2d-35c6-4062-aa62-34fbd6471dc8
349bb655-0c3a-440b-9f84-f753e3902aab	t	Nyakagera	3cd56c2d-35c6-4062-aa62-34fbd6471dc8
2686028b-7d17-4ce3-a8d7-b9c481c3c770	t	Ndayabana	525b6d1e-2041-4782-82db-164477f8895f
d9ab780a-2d8d-4a80-956a-84688c007c5f	t	Gacurabwenge	9aa68b9c-d10b-4951-b9cb-bd3f5ee03202
ba74b413-c9ad-4697-9d5c-6c8e5b824430	t	Gisuna	5ffac60e-7953-4b5a-9640-f8d3c1f6b0bd
988463ba-9548-40f5-97a4-9ef57ba3783d	t	Rugarama	1c5ef23e-8987-43bd-953d-9310ab6d66f6
d345dccc-f875-4140-9dea-156d2edd9eb1	t	Kivugiza	346c17ee-f3b5-4973-8ce8-a1c0d71bfe9b
eb310284-9cbc-4023-8583-3e0eabf26ddf	t	Taba	f55929a6-b83b-45de-b758-0fae6206abf6
171d0b5d-876d-4986-bf1e-8abbefa55161	t	Kimirimo	ce006494-2dbb-4733-911b-8c30ebd3d986
3493bfc5-2f28-4592-9329-7bb63a6b08dc	t	Mugomero	c5a7f03d-9027-4dab-884d-f0723ca81187
caab8dba-1c5c-42af-bc74-9f4299d61665	t	Nyiragasuruba	c5a7f03d-9027-4dab-884d-f0723ca81187
76fff73b-ddc6-4cdb-b12b-05ce8b77166d	t	Mukeri	767132b4-d82e-4c18-9fcc-f60e70b993af
432fece0-68fa-449a-becf-afb778351969	t	Nyamiyaga	767132b4-d82e-4c18-9fcc-f60e70b993af
1edbf424-d4fb-4dde-89eb-1af412cafbe9	t	Nyarubande	767132b4-d82e-4c18-9fcc-f60e70b993af
df02cf93-2e3a-4011-a507-141e328afa54	t	Rugarama	767132b4-d82e-4c18-9fcc-f60e70b993af
4e5198b3-2db7-4a6c-a29d-47ef8920e7c6	t	Mubuga	f81387a7-21c0-4b04-b788-378d774f6281
fe09496d-e8da-44bb-a8af-d5def168f5e0	t	Nyamabare	fc6589f2-670f-435c-bfe9-1922083d4d1a
8e8cab52-e070-4405-94b4-a8dfb7014f58	t	Rugerero	fc6589f2-670f-435c-bfe9-1922083d4d1a
f97a88ec-9fa6-4db7-9100-3c9cbd23ffaa	t	Gashija	54f79320-3bd8-40ef-80f9-1053e3820689
8ef09ac6-f577-495d-ba07-047000ae289a	t	Kabare	54f79320-3bd8-40ef-80f9-1053e3820689
e145385e-810b-4d67-b8b6-7f70c7124425	t	Remera	54f79320-3bd8-40ef-80f9-1053e3820689
8dc52cd9-2d26-4198-85dc-70384ab15859	t	Ryaruhumba	54f79320-3bd8-40ef-80f9-1053e3820689
905d1647-bc10-4dee-a9c4-de087a955ec8	t	Burambira	38741ace-4d83-4fe7-ae8e-ccd2a5410356
ad83c243-80a1-4d26-b968-5786593e317b	t	Gipandi	38741ace-4d83-4fe7-ae8e-ccd2a5410356
cef8ab20-3369-4815-809a-280dcffadfae	t	Maya	3aa99b86-62af-4e50-a05d-f82591a5e1f5
d4bae05b-b289-42af-ae98-a36ef3260663	t	Murore	3aa99b86-62af-4e50-a05d-f82591a5e1f5
11e04c38-66d2-46a3-ba4c-d39b91111c3e	t	Rusambya	3aa99b86-62af-4e50-a05d-f82591a5e1f5
9f137e1f-759a-4abd-8ac3-8362779413b5	t	Gatuna	d4600111-7078-4de8-bbff-c36ce383d5ca
8c79c898-2fcd-4cb8-b271-960807361879	t	Kagera	d4600111-7078-4de8-bbff-c36ce383d5ca
94055fbb-ec07-42d8-8807-62c2166098b0	t	Rukizi	d4600111-7078-4de8-bbff-c36ce383d5ca
71c6738d-6cda-4632-86b2-6e8fb056018e	t	Kababito	7646ad1b-8f0c-4063-b098-1760d673ca88
bc36c445-f236-407b-8d55-0bf2bf10cd0f	t	Kabacuzi	7646ad1b-8f0c-4063-b098-1760d673ca88
446cb645-ce1e-4a15-b522-7afa1f4272b7	t	Bisika	762cc91b-9136-49e5-ab5b-c75a403a88ba
b3a6c5df-7052-4bb2-8695-5c8fa6d49665	t	Butare	762cc91b-9136-49e5-ab5b-c75a403a88ba
ddbc1d82-28dc-4b43-b0a4-9b51e108ded3	t	Cyamabano	762cc91b-9136-49e5-ab5b-c75a403a88ba
3f90569e-de43-4b8a-a257-f60e70501d86	t	Gatare	762cc91b-9136-49e5-ab5b-c75a403a88ba
25ba8b5a-ec9c-4198-b21a-303af3fb4a5c	t	Nyakabungo	5728ce62-09d6-44f4-89f2-bb1be43f82f6
8befeac3-60c4-4303-8b45-c8c792d0637b	t	Ruzizi	5728ce62-09d6-44f4-89f2-bb1be43f82f6
e51c8e0f-8b8f-483d-ba3e-f1539539930d	t	Tanda	5728ce62-09d6-44f4-89f2-bb1be43f82f6
099bd5a3-d908-4b0d-904e-95f71beaf867	t	Gitaba	fd577728-64ea-4e2d-b65b-2d7b708e6c8f
e57b44eb-d317-48d0-ad85-e129eb3621bb	t	Muyange	fd577728-64ea-4e2d-b65b-2d7b708e6c8f
f249e14b-98f4-43dd-bc1f-cf71931413d6	t	Kigoma	2bc0ffdd-9157-42df-8118-143d3671c60d
59b4fade-8aef-4b6b-b13f-895a8b74244c	t	Musetsa	2bc0ffdd-9157-42df-8118-143d3671c60d
2d44fe5d-3ecd-4738-a0a8-54c57df2f473	t	Nyirangoga	2bc0ffdd-9157-42df-8118-143d3671c60d
c834ff80-3482-497b-abb5-42be7a11cf2d	t	Gicumbi	b730cefe-2cec-4ff5-b2c4-a5f3630ace5e
152822ff-c8c9-43f3-8ccb-bd88ab4b90d9	t	Maya	b730cefe-2cec-4ff5-b2c4-a5f3630ace5e
f5a5b385-cfb2-4bf7-ac08-b0ac9527a53f	t	Mwange	522cfb61-9412-48ad-a8d4-67e4924dd11e
f371f7c4-30d9-4319-aa0b-d3af8b3d9070	t	Kabungo	fc2bde2b-428b-4c71-a595-e218dea7193d
000987bb-7155-481e-aee8-a6f94308d539	t	Nyaruhanga	fc2bde2b-428b-4c71-a595-e218dea7193d
342c0342-3420-46b4-bde8-824a06958d50	t	Rugarama	fc2bde2b-428b-4c71-a595-e218dea7193d
c96a22a4-4e42-49b1-aa5c-c9b67f475236	t	Ryakabanda	fc2bde2b-428b-4c71-a595-e218dea7193d
646161f4-5228-42cb-bdcc-07b5ed3221e0	t	Gashiru	331e4665-f41f-4620-bc6a-4baa65c86719
396b6ac8-a9a0-4f74-ad48-7bf150214b03	t	Kamabare	331e4665-f41f-4620-bc6a-4baa65c86719
f0ed8e7f-31ac-41b0-8147-a89068094dc1	t	Nyakara	331e4665-f41f-4620-bc6a-4baa65c86719
4bb583d5-d5d2-42dc-b818-913ec17d8e99	t	Centre Mulind	ea64961b-8427-439d-99fd-1bbdd58bb08a
f8d3381a-d798-4076-93ee-17e228489863	t	Nyakabungo	ea64961b-8427-439d-99fd-1bbdd58bb08a
e4a9dd8a-04c3-4e87-9ab4-1da822b4ee1a	t	Rugenda	ea64961b-8427-439d-99fd-1bbdd58bb08a
05759ecf-43e8-4344-9490-08648f4d2fc4	t	Ruhita	ea64961b-8427-439d-99fd-1bbdd58bb08a
e7a69ded-a23c-4b88-b904-d18425dadff2	t	Rukizi	ea64961b-8427-439d-99fd-1bbdd58bb08a
48697d24-5fec-4037-9467-5ed7dc1a3d4c	t	Runyinya	ea64961b-8427-439d-99fd-1bbdd58bb08a
302edf1a-e998-4797-8e4d-254053bbba71	t	Taba	ea64961b-8427-439d-99fd-1bbdd58bb08a
16b571fd-4228-4280-8bbb-9b37766ca8ff	t	Cyasaku	e2af9f11-fea0-4b15-a5a9-4557ded897f4
2ae8f818-fb89-49a1-9941-ea38360b234a	t	Kabeza	e2af9f11-fea0-4b15-a5a9-4557ded897f4
ac5e99ac-5d13-4f4c-80f0-687cabcc1e42	t	Kinnyogo	e2af9f11-fea0-4b15-a5a9-4557ded897f4
5de7a6ee-e63d-4689-9685-fe5ee5a88a79	t	Mushunga	e2af9f11-fea0-4b15-a5a9-4557ded897f4
8d6bef6e-8920-4142-8f2f-e628e3068bfb	t	Kamushure	a6dea50f-5162-43ab-8764-86682334b66a
d87374e5-e26f-4a51-a9e1-59a9d6717f2f	t	Karambo	a6dea50f-5162-43ab-8764-86682334b66a
baf1986c-e3a5-4b4f-a3a0-ca4bbc2043b5	t	Ngabira	a6dea50f-5162-43ab-8764-86682334b66a
86a6cb6e-dff7-485a-b076-55b8098f874d	t	Nyagatare	a6dea50f-5162-43ab-8764-86682334b66a
8462f38b-2043-40ec-b6f0-ef5387c67ad9	t	Gabiro	50717da0-e62b-4f7c-9a52-e07a87e7409e
22b04f38-5323-49bd-8517-806aca4a65db	t	Mugera	50717da0-e62b-4f7c-9a52-e07a87e7409e
18027b7a-8db8-42e6-9bb0-c70146778ab6	t	Mutara	50717da0-e62b-4f7c-9a52-e07a87e7409e
7b6bc7dc-e4cd-42b1-bff9-4181fc0dfc62	t	Gacyamo	4f50661a-b737-43bd-b420-3ec477306b47
06cfaf0d-a52b-489d-9c95-aac3ebd091b8	t	Kiyovu	4f50661a-b737-43bd-b420-3ec477306b47
23792a0d-7d3d-456f-824f-f0a76b060c7b	t	Murambo	4f50661a-b737-43bd-b420-3ec477306b47
ec32a8ef-de01-46d1-af05-572ba6c7cd7b	t	Rurambi	4f50661a-b737-43bd-b420-3ec477306b47
633e16e7-ac00-415b-b345-53a992932a17	t	Bugibwa	9754844c-db9e-4a0d-8b88-a63271b7e575
ad675b89-309a-4257-b4cc-37f957812136	t	Kajevuba	9754844c-db9e-4a0d-8b88-a63271b7e575
1215fa5d-5d9b-4e07-993c-32c6607b1c7b	t	Rurembo	9754844c-db9e-4a0d-8b88-a63271b7e575
6a886327-f5ae-4c0e-a736-484e68835965	t	Sangano	2aa45062-71d8-48b2-a0da-139dff0cda8c
c215bcb1-8143-4558-b96a-6a22634ab7cb	t	Kiyovu	de75e078-955a-41db-826c-e536149f52ae
5d587300-f3ba-4b56-83f4-40d2e9355e6f	t	Rebero	de75e078-955a-41db-826c-e536149f52ae
0618b972-7cb2-4fd9-af5a-336161346b48	t	Gatsyata	5b865088-721e-4227-986d-b6536cb39bf2
145992d0-953c-4ba5-b0c7-fb80a0987846	t	Muturirwa	5b865088-721e-4227-986d-b6536cb39bf2
9ce97be2-1d79-49d8-82a1-eb3282e36719	t	Rugasa	5b865088-721e-4227-986d-b6536cb39bf2
74fc298f-ab1b-4203-9a51-0031d1f6b284	t	Karwanira	c3337660-3a8d-4b64-8210-39c56bee22ca
6dad09a2-8010-4007-9d10-9192a36403a8	t	Nyarurambi	c3337660-3a8d-4b64-8210-39c56bee22ca
4c496b94-f196-49e3-a655-6e78de3e65c9	t	Murehe	785a1670-b396-4351-8f11-15d14a98e282
75201088-11d0-4efe-a15d-9cb2f2fd9cce	t	Kagote	37b4b330-3f8e-4895-aa0c-160c950566ed
ed44d2c7-5230-4abc-93e1-c75893b129e3	t	Kivumu	37b4b330-3f8e-4895-aa0c-160c950566ed
da3edb2d-4bc1-4dd2-99ab-5de4df6320a6	t	Ndarama	87642154-a3ac-4dfd-9570-3df064135dae
3470ec83-1ea0-4e3b-89ed-e71766afe0d2	t	Nyakabungo	87642154-a3ac-4dfd-9570-3df064135dae
9d9be286-dd24-4815-aaf7-fb50e3601d3d	t	Rugarama	87642154-a3ac-4dfd-9570-3df064135dae
752ce279-8939-4318-a0bf-946d7879f1e1	t	Mugina	bdc76189-6253-45b4-ae01-086fe10bfe40
55b2f813-5ff8-426e-bd73-5a6d8daf6c68	t	Nyange	bdc76189-6253-45b4-ae01-086fe10bfe40
3a5722b8-fea4-4f2d-aab5-aeb0d56a3608	t	Gacwamba	759b73dd-f263-4720-840f-dfe53850bc37
8ae4389d-cea5-4e53-b3b5-00d7a4a74e91	t	Kariba	759b73dd-f263-4720-840f-dfe53850bc37
9c09c818-509a-4482-9200-d9d844d1546d	t	Kaziba	a7842880-d1f6-4c92-8ef9-8c190c44723b
5ecebc20-b570-42cf-b522-4a1877527dd9	t	Mafumirwa	a7842880-d1f6-4c92-8ef9-8c190c44723b
0bf8b9ed-1c5c-4f11-a25a-adf2e07ed78d	t	Murara	a7842880-d1f6-4c92-8ef9-8c190c44723b
d6b17443-3276-4dd3-88ad-229694007531	t	Rugeshi	a7842880-d1f6-4c92-8ef9-8c190c44723b
90e9df33-af3e-48af-98dd-d9c00ec98a62	t	Gakizi	b16cfb48-e0cd-4137-b804-8d8ab8d82d5c
dd108ab8-66ee-4927-a654-b17aa29b6e21	t	Kagarama	b16cfb48-e0cd-4137-b804-8d8ab8d82d5c
71a8c819-ad7c-4bf9-979c-111990ea2ae1	t	Rurembo	b16cfb48-e0cd-4137-b804-8d8ab8d82d5c
5ca7eb21-9b69-4da8-bfdf-3966e29f89eb	t	Ruziku	b16cfb48-e0cd-4137-b804-8d8ab8d82d5c
63c74e5f-397b-47f3-8e2e-6a8cc5a3fac9	t	Rusambya	44604946-e538-4102-8a3e-d853f7f99022
5a09443b-acb7-4c32-9163-a2994cb36b7b	t	Ntonyanga	1c5bb7be-7f4a-4d53-adb6-71172a273ecf
d99114bb-c3cf-46e3-afb5-4609e45c2be6	t	Rukazire	1c5bb7be-7f4a-4d53-adb6-71172a273ecf
010bbcd3-be1a-498b-8652-ce76a9f5df10	t	Rwamitembe	1c5bb7be-7f4a-4d53-adb6-71172a273ecf
5bfa235f-e9ac-42d4-a1e3-44a525553be2	t	Gatobotobo	45f235d0-a8bc-4edd-8019-f7aaf73f4e6b
0fc4a0f4-49c8-4aca-a792-4e03ac8bbf5d	t	Karumuli	45f235d0-a8bc-4edd-8019-f7aaf73f4e6b
2f2409a3-8f34-4cd6-b5ce-c994333a112a	t	Ryarwoga	45f235d0-a8bc-4edd-8019-f7aaf73f4e6b
8becf1d3-e8e1-4b82-b89a-a133fe774296	t	Gikumba	eb06cb09-1f8b-4f6c-b0c6-de398aa93814
f3f958d0-32be-4626-9413-2f3f5e531f8a	t	Kirengo	eb06cb09-1f8b-4f6c-b0c6-de398aa93814
5b1f69ec-2e51-4f74-8226-f46f759b9f48	t	Kabare	77402a37-9dc1-4f65-a25e-81ae6ccc6233
5dc52e8a-68ae-49c9-9f6d-8ce73b7fc728	t	Karundi	9eba78f5-dcf1-467f-8592-50e70346a243
0d8b4545-2c16-46a7-8b6b-8e0702be93a0	t	Kirara	9eba78f5-dcf1-467f-8592-50e70346a243
1a149402-29e6-49f6-bdcd-c24c40e8d379	t	Gasharu	06878d59-0101-4c4e-8f4b-86a0fa1226cf
e658bbb4-0331-42f2-9f0b-95341d645720	t	Irasaniro	06878d59-0101-4c4e-8f4b-86a0fa1226cf
d8b20123-b30c-4d0b-8a0f-c28e5694bcb9	t	Ngando	06878d59-0101-4c4e-8f4b-86a0fa1226cf
bac48a3c-027f-43c3-9649-f07bfea7e6c3	t	Nyamiryango	06878d59-0101-4c4e-8f4b-86a0fa1226cf
c46e548c-b5f9-41e5-a44b-a585c21341df	t	Nyagasozi	f451f556-a4ef-402e-a02f-6eff12aeced0
cd3ecd55-04b2-482b-8bf3-b06c25267979	t	Karambi	166a0a08-a8f9-4782-8fce-4165f5c1b940
af7fda21-91aa-4813-9f5e-96af0148fb89	t	Kimisugi	166a0a08-a8f9-4782-8fce-4165f5c1b940
cbeb25af-df1a-47cb-acee-23f4dc8e5b25	t	Muhororo	166a0a08-a8f9-4782-8fce-4165f5c1b940
e7e46010-026b-430a-8166-53ef0263c157	t	Rukondo	166a0a08-a8f9-4782-8fce-4165f5c1b940
3233c40e-d73e-4479-bb4a-85377e82a0e0	t	Rurama	166a0a08-a8f9-4782-8fce-4165f5c1b940
5968f23b-4b74-4043-98c1-42190fadb02b	t	Gihangara	8907878d-92ab-4354-b222-f4b0a95f7ac1
ac893b7e-7b11-4f80-aa06-0ab129d45cc8	t	Karambi	8907878d-92ab-4354-b222-f4b0a95f7ac1
5c07355c-65ca-4ae2-ac46-dfda1b26bfe3	t	Nyarubande	8907878d-92ab-4354-b222-f4b0a95f7ac1
2bccd774-6af1-4b5d-8cb6-e4cdb21bb8b7	t	Kavumu	3bd3f01b-4426-49a0-bbb0-e5bef63e85c5
166c5796-aeec-48a4-9f78-0a46df3ba33f	t	Ruhondo	3bd3f01b-4426-49a0-bbb0-e5bef63e85c5
91e9b814-e9da-458b-8678-e89a7f1958ba	t	Rusumo	3bd3f01b-4426-49a0-bbb0-e5bef63e85c5
472d52d0-2eb7-467c-8f67-7e9aef5c94c5	t	Majyambere	1ebe7cbf-33c6-4ef5-a796-b59070741096
c008268e-37f6-4078-b46a-603fd3f86528	t	Rugarama	27b71d82-ed4f-4cd7-a88e-bc60c8c68e2d
5eb42d48-07d9-4e17-9597-f7ec33913a40	t	Karambo	f1a7bd8a-570f-475f-911c-22bd39925cfc
d63fc339-5f7b-4b20-9920-063216ecfd5a	t	Mugorore	f1a7bd8a-570f-475f-911c-22bd39925cfc
c768c035-a7ca-468a-aa09-1d22b28ef75c	t	Nyarubuye	3d883348-dd88-492f-8e89-a6402464c4f4
0befaccd-d35d-4c6b-860b-ddc5801ad81d	t	Gasave	a77a3434-082c-4d9d-8831-4b9220d530ca
adba89b4-3be7-4016-8b61-fe42e76b1b75	t	Karambi	a77a3434-082c-4d9d-8831-4b9220d530ca
43d11a96-d8ec-4512-a613-fe23ea8fca78	t	Nyirakagamba	a77a3434-082c-4d9d-8831-4b9220d530ca
cac4ad40-f24e-4682-9e6d-0f88e58ba7ed	t	Rugarama	d6f66521-2f19-485a-bc71-49d0c06eb2ed
cc3fc56e-f945-47d5-9e74-b8193f701908	t	Kabere	8ebc6ad3-3c46-4062-ac81-bcc7211fc993
0dc02d12-3b76-411d-953c-d89818facb2f	t	Ruhoho	46058a80-7d2b-4a63-a673-d5c050634958
afb993c3-6d38-406d-899d-20ef93dff438	t	Kabahura	d4697b70-5ccc-44c6-824b-4d02aec9ad64
06f70a6c-5c49-4bfa-9db8-6a35be916333	t	Nturo	36ed2922-ff0e-47b7-adc2-17429d75f7c9
72b2e0f5-4bb1-404b-800c-4cedf8798f53	t	Gomba	3e2016bc-23ee-4c26-919e-9269920ebac6
c3704a0a-eb77-467b-8847-bb75c03493ae	t	Kagugo	50574999-9ac9-4d9a-b10c-3b88b270d45d
1aaf9f97-701a-47e7-a7f5-41dc4db4f6ec	t	Mugote	50574999-9ac9-4d9a-b10c-3b88b270d45d
06087500-b9d4-4453-b2f5-d7ed6b5fad61	t	Nyakesha	50574999-9ac9-4d9a-b10c-3b88b270d45d
25b97398-1463-4986-bfef-be934b8237ce	t	Centre Rubay	3abfc4f0-dd77-4a83-bf60-0d73f490543a
3206c6ff-3b0b-47fa-874e-c1ecac507391	t	Ngange	3abfc4f0-dd77-4a83-bf60-0d73f490543a
17bf7657-efe3-49cd-93a7-f01dfb5419dd	t	Kabuga	d5b6cda6-d51a-4849-b80c-9470c15668d2
98e3a7bd-06c6-4e1c-b004-4bf33151cdc4	t	Kimiko	d5b6cda6-d51a-4849-b80c-9470c15668d2
e8e2416c-901d-477f-8e1f-cd0ba7dabd0e	t	Muhama	d5b6cda6-d51a-4849-b80c-9470c15668d2
67d6ec05-7d46-436f-a818-78a93983fc5c	t	Nyamutezi	d5b6cda6-d51a-4849-b80c-9470c15668d2
9114b82c-6e5e-4bcd-bfaa-2fe7e6979d5d	t	Sabiro	d5b6cda6-d51a-4849-b80c-9470c15668d2
2318dd1d-0d09-47c9-a7e9-990f3da7c7e5	t	Gatare	ec99c069-a266-4564-ab4d-b85aedceb8bd
f5c101fc-d44c-41a2-b6d2-a571d265b084	t	Gitaba	ec99c069-a266-4564-ab4d-b85aedceb8bd
31464406-e972-4f40-a0d7-0814f55eb107	t	Nyarubuye	ec99c069-a266-4564-ab4d-b85aedceb8bd
c01c90a6-3eda-4074-ada3-6db9cf9f494e	t	Rusumo	ec99c069-a266-4564-ab4d-b85aedceb8bd
a23cb7ed-3d02-4d34-ad01-77fb2cdc5191	t	Gahondo	aeeb9bf0-e4ac-4fc1-90c3-0e4e300c4520
2bfa187a-ed0d-4eb2-8caa-d2156cf58712	t	Kivugiza	aeeb9bf0-e4ac-4fc1-90c3-0e4e300c4520
4b98e63f-3846-48c2-b1b7-0b96ee3f6f17	t	Mburamazi	12a7db16-29f0-4e30-af74-a2ea9ed1d196
c2af0c5d-fe80-453f-80ac-4b6b29173983	t	Kabuga	936ccd99-f4e4-48d9-91af-0ea2885c5c9e
6f8e98b2-3a9f-4b02-a432-c781fb9223d8	t	Mataba	936ccd99-f4e4-48d9-91af-0ea2885c5c9e
6a99ad43-8158-4059-89e3-7d39ad7dbd6a	t	Rwamushumb	936ccd99-f4e4-48d9-91af-0ea2885c5c9e
e2b9a204-5540-4f02-be21-3812784f91d4	t	Gitega	258b0041-9b06-4110-973f-c530fd3cd7bf
23a08d38-a368-4283-9ca2-0bc73803e00c	t	Kabo	258b0041-9b06-4110-973f-c530fd3cd7bf
70d2f822-0409-4327-9ab9-3a988361da63	t	Karambo	258b0041-9b06-4110-973f-c530fd3cd7bf
fb25ee31-eb0a-4044-be1c-a64997955324	t	Kabuga	7d0f4a35-f46b-4e34-a73c-be93ed531674
41c5224f-8a5f-4a31-b95a-9f964d25e0ad	t	Kamutora	7d0f4a35-f46b-4e34-a73c-be93ed531674
b51bfb04-ace8-4516-b3ef-d89db6dcbe06	t	Mabare	7d0f4a35-f46b-4e34-a73c-be93ed531674
744dcfb0-90fe-481e-a97f-65d45320ad5b	t	Nkamba	7d0f4a35-f46b-4e34-a73c-be93ed531674
67122e19-837f-4082-b442-fe53fed4350e	t	Remera	7d0f4a35-f46b-4e34-a73c-be93ed531674
bdf41cd4-1880-4582-a7eb-e2179772bf16	t	C. Rushaki	50c264f9-35d1-49f2-be14-2ee926903896
bdcd1d65-0009-41f9-81b1-a794da356d03	t	Gatonde	50c264f9-35d1-49f2-be14-2ee926903896
c5b39750-c2ca-4516-88fa-8f08e19977d1	t	Izinga	50c264f9-35d1-49f2-be14-2ee926903896
c7413b1c-4093-45c3-b1f0-3f159938b5b5	t	Mbuga	50c264f9-35d1-49f2-be14-2ee926903896
aa4565e5-12cb-4766-b935-7c66db4efae4	t	Nyaruhanga	50c264f9-35d1-49f2-be14-2ee926903896
1f8bbea5-9260-407e-a004-4be907a2073e	t	Kintaganirwa	36f9866d-55c0-41b9-9480-5f0efd0db57b
1914d432-aa64-4d83-8fb4-d8181cbea8c8	t	Marembo	36f9866d-55c0-41b9-9480-5f0efd0db57b
d4cbe3f5-c425-4552-9abc-916347b50570	t	Matyazo	36f9866d-55c0-41b9-9480-5f0efd0db57b
c02694cc-eb12-4137-ab51-d069ecd0d2b4	t	Buyegero	55530ad5-3109-41fd-8ac0-ab3d6cb94b98
ef9c9e2e-2e28-4d1a-ab4c-6526d5fe71b6	t	Bureranyana	16fa3f6b-515c-48f2-988c-b5e6ebbaeb2a
530f5934-cd79-46f9-8953-454af78e0c33	t	Gashinya	16fa3f6b-515c-48f2-988c-b5e6ebbaeb2a
7c6e93f3-ba76-4ab4-9851-e96ebb166e22	t	Kabira	16fa3f6b-515c-48f2-988c-b5e6ebbaeb2a
2fc36ec1-f996-44fa-a602-790953a5cbfa	t	Kanaba	16fa3f6b-515c-48f2-988c-b5e6ebbaeb2a
47e64f66-955e-48d2-a0e6-b5bb6ac8e4a2	t	Rugarama	5a19ed33-0f94-47cd-a242-593ea0757920
57737852-34ba-424b-b392-342d08ca8e6c	t	Gasharu	42e09e9a-9304-4d7d-bbfa-3cff07a45290
a182434e-e026-4637-8ee4-9a1824777946	t	Kirwa	42e09e9a-9304-4d7d-bbfa-3cff07a45290
79185a6b-c47b-4667-9a2c-64d90d5e52cf	t	Nyagatoma	c966304c-442b-4e1b-bad4-6590bd056261
a70ae524-24b6-4be7-a4d6-4ca70e5c2d1f	t	Nyansenge	c966304c-442b-4e1b-bad4-6590bd056261
d1ac2ba8-d18b-4f6b-9ba9-c87e35e2063f	t	Karambo	8f05b81e-48a6-468e-9260-460cdee06123
4f0794a3-3f20-43dc-9a75-d5ba7c18303b	t	Rugarama	8f05b81e-48a6-468e-9260-460cdee06123
07e72b83-a369-4486-8b90-c9d946744b07	t	Mataba	9bb53cb1-3461-4790-ad3e-3d20901515be
9608b671-b714-433f-919b-6ef0f906edda	t	Nyamirama	9bb53cb1-3461-4790-ad3e-3d20901515be
ce495b47-fc35-41a8-a41d-e3db8259a724	t	Nyarubuye	f306f59c-fc3d-4485-9882-ce602af1dc92
692a3b9d-37f6-4434-99f9-cf56d0adfb0e	t	Remera	f306f59c-fc3d-4485-9882-ce602af1dc92
f46bf8a3-9dc5-462a-abbb-1fa878775122	t	Rugerero	f306f59c-fc3d-4485-9882-ce602af1dc92
b55f0d04-6123-4eff-b17a-f6421d0d3ce3	t	Murehe	c9692846-980c-4dc6-b6dc-7212cee63cb3
29e5e34d-f115-4b90-88ea-66fa2f783acc	t	Nyarusange	c9692846-980c-4dc6-b6dc-7212cee63cb3
08356cf1-e7b8-49a3-97d4-a012b8226a40	t	Taba	c9692846-980c-4dc6-b6dc-7212cee63cb3
cfb87497-17a0-4316-a353-6d4a79694309	t	Rwamiko	f4222de6-9cbb-4f70-bb4e-bca6671e3ae9
c99897d0-668c-475d-bed9-e961f6ee0149	t	Gatoki	42379f4c-7cec-4c77-9de8-9a9834ca6ead
9a35fc77-4752-4574-bbbc-c656a0ac4dd3	t	Mugorore	42379f4c-7cec-4c77-9de8-9a9834ca6ead
e6693c6b-a68e-425b-b167-d299ed746734	t	Nyakaju	42379f4c-7cec-4c77-9de8-9a9834ca6ead
c226d0a0-2746-4be9-92d4-dd92c689810e	t	Kamurenzi	72dd2c0a-9b48-430f-a24e-0ced20c007d5
ac80d390-dc13-4b11-a4a8-34c56efa7537	t	Kabira	ea727ffa-cca1-40d0-98f7-e0f7c46a6c0f
78561a0d-7fff-4820-9c8a-8eb925d64be9	t	Karangara	ea727ffa-cca1-40d0-98f7-e0f7c46a6c0f
447eac7f-dfa5-4804-b91e-1eaf017554e0	t	Mutambiko	ea727ffa-cca1-40d0-98f7-e0f7c46a6c0f
2f286e77-0144-49fe-b114-6a8046ef5050	t	Kabusunzu	1a0431b4-1b3d-4e1c-ae82-85c6728270a1
2b910418-b75f-4c81-bf19-391eb7f4af8b	t	Kigaga	1a0431b4-1b3d-4e1c-ae82-85c6728270a1
c61209a6-6efd-4ec9-b3b8-da548086d4ba	t	Ntaremba	1a0431b4-1b3d-4e1c-ae82-85c6728270a1
0b8e2d76-8291-4c17-bd75-1637c1276347	t	Bushara	ca4abb0f-ec2f-4a94-9923-2acc1eb73ef3
1578018b-592e-4530-b9f7-157b135f3719	t	Gasura	ca4abb0f-ec2f-4a94-9923-2acc1eb73ef3
a638887b-ac0c-4930-bec3-12939bff36d0	t	Ituze	04cec478-f7d1-42f2-89dc-aadf0dcc85e1
d95de6ff-8432-4641-bb5a-94799a9c4aae	t	Gahanga	5279c3bb-22e9-4e72-8333-56b62979230a
bcf394b7-022f-478b-a986-4dd3fb34ec47	t	Jabiro	5279c3bb-22e9-4e72-8333-56b62979230a
c72b6b04-92cb-4ffb-b339-8f8f749cddbc	t	Kabaya	5279c3bb-22e9-4e72-8333-56b62979230a
d009f0c3-827e-4d05-91ba-986a183d1088	t	Nengo	5279c3bb-22e9-4e72-8333-56b62979230a
fb01e56e-69e3-4d94-abe8-b6f5fec0232c	t	Nyarubuye	90cf4335-c6b1-475a-938e-e22ce046ce27
bcac0582-921e-44de-ab57-f8efec64e527	t	Nyiragaju	90cf4335-c6b1-475a-938e-e22ce046ce27
4ca9d85e-2112-4234-8d38-1e97b0fdd495	t	Rubaya	90cf4335-c6b1-475a-938e-e22ce046ce27
48b93bc7-b6ec-4522-b58a-8bc2118fb25c	t	Ryamukutsi	90cf4335-c6b1-475a-938e-e22ce046ce27
65ee61f6-3b5e-4dbd-a56e-1619cf145d85	t	Bubandu	7f94c380-5c1a-4b56-9d6a-bea2742ed23b
6c86a9a2-21ab-415d-a01d-c627f4fcc7c4	t	Murambi	7f94c380-5c1a-4b56-9d6a-bea2742ed23b
51ffbeca-9a30-4067-a4e9-f3a61aefce3a	t	Mwidagaduro	7f94c380-5c1a-4b56-9d6a-bea2742ed23b
b3070e50-08b8-4a71-9916-65881635b81a	t	Mwirongi	7f94c380-5c1a-4b56-9d6a-bea2742ed23b
583eb318-a366-4279-8144-f71520f92f61	t	Rugeshi	7f94c380-5c1a-4b56-9d6a-bea2742ed23b
721696a2-2fe8-4922-8651-d2828e51e2c8	t	Bazizana	d2a17279-d096-459f-bf0f-a6943b65a3ec
6be12be4-03e7-44ed-b26a-6d82569f53fc	t	Kabahama	d2a17279-d096-459f-bf0f-a6943b65a3ec
7b3704df-9ebe-49b8-bf39-37b18b6c2bf3	t	Kamenantare	d2a17279-d096-459f-bf0f-a6943b65a3ec
22cc0215-6721-4e26-8d8c-1037ef96abd3	t	Ruhindinka	d2a17279-d096-459f-bf0f-a6943b65a3ec
6276e8f6-af97-4545-8de8-027d2dce59da	t	Rutemba	d2a17279-d096-459f-bf0f-a6943b65a3ec
6a0bf340-3905-4cee-9a18-8549e5ea56e1	t	Ruvumu	d2a17279-d096-459f-bf0f-a6943b65a3ec
2b0f5a1d-591b-4e8d-8908-3471f2b96460	t	Kabaya	010279e4-6d4e-4e58-bc11-f798bb312775
4eee5312-a787-4454-9f08-d248ac0dbf2b	t	Karugabanya	010279e4-6d4e-4e58-bc11-f798bb312775
49db752c-254e-4d30-bf4b-d342e8d14f2e	t	Kayange	010279e4-6d4e-4e58-bc11-f798bb312775
09720c13-dc4a-43de-a322-4732b75c0fae	t	Kibande	010279e4-6d4e-4e58-bc11-f798bb312775
044581e8-edec-4542-919f-454a2189129a	t	Mubari	010279e4-6d4e-4e58-bc11-f798bb312775
1a6e956e-308f-4bad-b4a3-28136931d9b3	t	Mubuga	010279e4-6d4e-4e58-bc11-f798bb312775
7c64186f-fc4e-48af-ab8d-8394869afd32	t	Mugarama	010279e4-6d4e-4e58-bc11-f798bb312775
73ae931c-f0af-4e95-a1bf-1511edc3dc76	t	Rebero	010279e4-6d4e-4e58-bc11-f798bb312775
a83b062c-cac2-4df8-969d-67c1cad90cbd	t	Ruhehe	010279e4-6d4e-4e58-bc11-f798bb312775
18e1e1e6-f45f-4c7e-9968-0972631f3e5a	t	Bucuzi	87be187c-0066-4e02-b8b4-3e20e91e57ff
ce6e5dc5-de3d-4009-9a63-25820e232a00	t	Gashangiro	87be187c-0066-4e02-b8b4-3e20e91e57ff
b1f9e2aa-b05a-47d7-bde9-2e8f87bc1ff4	t	Karinzi	87be187c-0066-4e02-b8b4-3e20e91e57ff
c9b08348-6f1c-4e61-929e-523b7a6f5e08	t	Karunyura	87be187c-0066-4e02-b8b4-3e20e91e57ff
1c0d9504-a57f-4c0f-9728-b0a5519965d7	t	Kungo	87be187c-0066-4e02-b8b4-3e20e91e57ff
b42de24d-2898-42ca-859a-1146a3b60e25	t	Buremu	6845f4a8-8e10-4b6c-bb90-7742baa7e574
a73f0a9a-b5ed-44b2-ac35-9510babfc546	t	Gakenke	6845f4a8-8e10-4b6c-bb90-7742baa7e574
54257275-e693-4494-8cc2-4c2f7457d613	t	Kabaya	6845f4a8-8e10-4b6c-bb90-7742baa7e574
d97828a6-3b77-4342-b485-8af89be0a39b	t	Kamanga	6845f4a8-8e10-4b6c-bb90-7742baa7e574
99969e1f-5f28-4c45-99af-f0bb869be700	t	Kiviriza	6845f4a8-8e10-4b6c-bb90-7742baa7e574
016ae69c-979a-43ac-a45f-11242f30d6c0	t	Mugari	6845f4a8-8e10-4b6c-bb90-7742baa7e574
b3924cb1-1698-490c-bb4f-b0831094e7a5	t	Nyaruyaga	6845f4a8-8e10-4b6c-bb90-7742baa7e574
b2aefe57-96a7-4d4e-8120-8206d274349a	t	Rabika	6845f4a8-8e10-4b6c-bb90-7742baa7e574
3490c543-e201-4f96-91de-a2389a742541	t	Marantima	a4e16940-6e16-46d9-9f72-44fd68e5658f
abed823c-49a2-4d08-b80a-a9570ecedb5d	t	Nganzo	a4e16940-6e16-46d9-9f72-44fd68e5658f
8c0fd66f-906a-4f4c-b468-fcf0bcf0d85f	t	Nyarubande	a4e16940-6e16-46d9-9f72-44fd68e5658f
85bc6616-ad0f-4687-899b-5758bbbb4caf	t	Nyiraruhenge	a4e16940-6e16-46d9-9f72-44fd68e5658f
74d15c31-dcf5-44ca-8f48-dc8946a17a5d	t	Butunda	9987f54c-db38-41ea-a071-944e968ea52d
c0c493c7-9b70-4790-a841-8308f3aec0b9	t	Cyiri	9987f54c-db38-41ea-a071-944e968ea52d
8187cb4f-bce8-4897-8d16-1c0961f1397b	t	Gahama	9987f54c-db38-41ea-a071-944e968ea52d
58b00047-ea84-44dd-a72e-4c31f54a8e7c	t	Murora	9987f54c-db38-41ea-a071-944e968ea52d
b21de0d5-4207-44c9-b693-99fa9ff934ee	t	Murundo	9987f54c-db38-41ea-a071-944e968ea52d
32131be5-ccd0-4976-ae99-01619ea3610d	t	Nkomero	9987f54c-db38-41ea-a071-944e968ea52d
5fed2fe4-036c-462a-8e5a-d023755c0cae	t	Gasenyi	40896fb8-2158-4375-868c-d61166f46216
5bd12493-26bc-4923-8c15-d47538435b28	t	Nyamugari	40896fb8-2158-4375-868c-d61166f46216
9bc59517-26e6-48d6-9cf1-296f69c9c2fb	t	Ruhasa	40896fb8-2158-4375-868c-d61166f46216
4d393388-3c68-41ce-bbed-2d04971e7ebc	t	Rurambo	40896fb8-2158-4375-868c-d61166f46216
39de95dc-5f02-4ff2-bc7d-0d38682a406d	t	Gitovu	484c6724-3ef1-4410-a4d5-87ca2afaccc4
8d49adac-2da0-48ad-b074-d4b8b0d9f6ef	t	Kabushanda	484c6724-3ef1-4410-a4d5-87ca2afaccc4
c0e6af0b-0ef1-4ea1-989c-7cedc3dbf2c7	t	Kanama	484c6724-3ef1-4410-a4d5-87ca2afaccc4
2ef5714c-a2c5-42ed-b702-cb87b2fdeb9a	t	Karama	484c6724-3ef1-4410-a4d5-87ca2afaccc4
b8b45190-5dfb-42f1-a58a-0e4cb194a0d2	t	Mata	484c6724-3ef1-4410-a4d5-87ca2afaccc4
d13d3369-5fe1-47be-8d81-c7cc7e876308	t	Mukungwa	484c6724-3ef1-4410-a4d5-87ca2afaccc4
833ed841-738c-414d-95b7-5ff933b712cb	t	Rungu	484c6724-3ef1-4410-a4d5-87ca2afaccc4
50d638e5-dfba-48fc-b7ed-28aeb83fc000	t	Burengo	e30f0bd5-b5a9-4d48-a863-e2660086610f
7ca50c5a-85de-4f12-9b45-eeafba893149	t	Kabukende	e30f0bd5-b5a9-4d48-a863-e2660086610f
00ba858d-9512-4fb9-985b-b07a6c1c380e	t	Karambi	e30f0bd5-b5a9-4d48-a863-e2660086610f
e77115a7-af2f-445d-ab0b-a88c04fb0936	t	Kavumu	e30f0bd5-b5a9-4d48-a863-e2660086610f
d79d8fb4-6305-4e0b-a806-8ed7552def62	t	Sarazi	e30f0bd5-b5a9-4d48-a863-e2660086610f
8333bb29-cbf7-49a3-928e-a0aa9eec4b50	t	Kavumu	92a89d17-8490-40d9-845b-1ddc2cc6bd65
11d8b023-d64b-494a-a082-92a6ac29cb20	t	Musekera	92a89d17-8490-40d9-845b-1ddc2cc6bd65
9513079b-bf17-4ce0-af9f-3bca49650f01	t	Makara	2152f233-39cf-4b7f-992d-4142bf5c46e4
bc005fe5-bb1c-4785-bfe7-e15b9b99b6b3	t	Budiho	da2b15d7-2d1c-4f42-82e7-0f02190fa495
44c169a6-af25-41dd-8fa3-2c187f1c476e	t	Gatete	da2b15d7-2d1c-4f42-82e7-0f02190fa495
5c8ab4db-261b-488b-a51c-5cf3d9739359	t	Kamato	da2b15d7-2d1c-4f42-82e7-0f02190fa495
a50580d1-221f-43c3-8e39-30e7513c4df7	t	Kanzo	da2b15d7-2d1c-4f42-82e7-0f02190fa495
64bf27d5-9689-4477-b0b4-ff1ac32b0e1b	t	Ngambi	da2b15d7-2d1c-4f42-82e7-0f02190fa495
25f93f34-bb57-40a3-861e-76912644f887	t	Raro	da2b15d7-2d1c-4f42-82e7-0f02190fa495
394b0f2c-2919-4496-873e-49fd2b4a4287	t	Kibinyogote	6ec0f17d-59b0-4806-8b46-e4dbcbb07303
5acb0266-a73f-466b-a59d-55705a825b21	t	Mucaca	6ec0f17d-59b0-4806-8b46-e4dbcbb07303
1331910c-a47b-4f3f-859e-162a32754ae2	t	Murandi	6ec0f17d-59b0-4806-8b46-e4dbcbb07303
5c610210-7115-4b99-b992-cc1b7f88fda6	t	Kagongo	844fea57-b6e7-410d-be15-539e935d0c3e
3e2a4af0-0ecf-414f-b8f6-982aaee530cb	t	Rubaka	844fea57-b6e7-410d-be15-539e935d0c3e
8bd54c6e-5cc4-44f8-984a-49c8832b2518	t	Karurambi	ef6c887f-586e-417b-95c3-626bd730d68d
7a010635-db3e-4148-a3fa-8725a68af3fd	t	Manjari	ef6c887f-586e-417b-95c3-626bd730d68d
2e6cc75f-74ba-472e-82b0-26cb5bcb4b1a	t	Rukingo	ef6c887f-586e-417b-95c3-626bd730d68d
661c4e69-b445-49bf-b6d5-8b76214c54de	t	Rusambu	ef6c887f-586e-417b-95c3-626bd730d68d
c552bb5c-eb26-4963-bd16-643ec9e13a8a	t	Rwinzovu	ef6c887f-586e-417b-95c3-626bd730d68d
72876f95-fe5b-4586-a315-dde8a7c4e9a4	t	Gataraga	694373ca-f548-4427-967e-dc7cf8cb8f2f
0b4f10bf-17de-4fdc-bb67-61f347e61505	t	Kabaya	694373ca-f548-4427-967e-dc7cf8cb8f2f
434756ac-11bd-42e6-a89a-f622bd157b8e	t	Kaberege	694373ca-f548-4427-967e-dc7cf8cb8f2f
a5ba6a22-2f2c-4351-85fc-599a33529f33	t	Gahira	8fb0981a-68f4-4f16-bd6f-0ae76cf02449
4a95b6ba-7e80-4241-badd-55a9d4c54c11	t	Gatondori	8fb0981a-68f4-4f16-bd6f-0ae76cf02449
78bd5774-6b0a-4c5b-b415-86c3e4601055	t	Gatovu	8fb0981a-68f4-4f16-bd6f-0ae76cf02449
718352b9-2691-4952-ad33-81e4935e48df	t	Kampande	8fb0981a-68f4-4f16-bd6f-0ae76cf02449
95fd3b00-e725-404e-acd1-7c50541e88bc	t	Nyarubande	8fb0981a-68f4-4f16-bd6f-0ae76cf02449
023341f0-fae4-4606-8269-801913055b55	t	Kabagoyi	1caf3922-7c83-4e30-bbd2-3033d0823d5e
e39a6db7-6c75-4701-bb4f-dd940098d80a	t	Kamugeni	ff4449c9-a11c-4075-87d9-cd439dfbf55b
9fbbe1f2-5f9f-43e0-8924-d0e477caba3e	t	Nyiramuyenzi	ff4449c9-a11c-4075-87d9-cd439dfbf55b
297ef61e-8155-4820-bfbf-ef43cabbc023	t	Masoro	42837584-b0c0-42c6-b0e5-7ef7fa3c235c
f09fb1c9-a438-4d3c-b9f3-ba27cd964a0b	t	Muregeya	42837584-b0c0-42c6-b0e5-7ef7fa3c235c
99bc85ff-f49e-4827-aedc-39452b72a53d	t	Ndorahe	42837584-b0c0-42c6-b0e5-7ef7fa3c235c
89c57f4a-8cd5-4ab6-bdc9-2c1250ab68f1	t	Kabeza	897b0509-7051-4518-9d65-49fcffab3174
dcfb55ff-5909-4924-a1ab-c5cf9a93d661	t	Kaniga	897b0509-7051-4518-9d65-49fcffab3174
3e572bbb-2d73-4acb-9228-8849531727d3	t	Impano	897b0509-7051-4518-9d65-49fcffab3174
ec880bd2-2d68-40f0-9c20-a040b40c92f9	t	Rugeshi	897b0509-7051-4518-9d65-49fcffab3174
54eafec3-d906-4feb-b9ae-c401ed0fbf77	t	Ruginga	897b0509-7051-4518-9d65-49fcffab3174
8b76a212-1015-4287-ba8e-e055e05d8ff9	t	Rurembo	897b0509-7051-4518-9d65-49fcffab3174
fe132ad0-a821-4ba9-8a5e-5d0750138701	t	Kamakara	22e76f6b-65e5-46f4-933e-1c057572c07c
4eb0082b-ca12-4d59-853f-4a3de0e5e7f0	t	Muhe	22e76f6b-65e5-46f4-933e-1c057572c07c
f6b81321-b506-4094-a021-e3416c5d3d15	t	Nyarubande	22e76f6b-65e5-46f4-933e-1c057572c07c
0c3b58fe-a0f7-4a90-b0b8-d35c4122dccf	t	Nyejoro	22e76f6b-65e5-46f4-933e-1c057572c07c
a3f7fc48-0bec-40a6-96bc-557b719370bc	t	Rubara	22e76f6b-65e5-46f4-933e-1c057572c07c
33f1e273-ead9-48fa-8f3a-87ee792c8567	t	Rugi	22e76f6b-65e5-46f4-933e-1c057572c07c
8124d392-c38a-4bb5-8c6e-a6910a6b18e4	t	Rutindo	22e76f6b-65e5-46f4-933e-1c057572c07c
dd110eaf-a811-4ff5-9416-b77f33f57ee1	t	Mitobo	441aa91d-53a3-4c31-917c-bc6038dbae36
06782429-ea45-45bb-84fb-ee81db88af5f	t	Nyakagezi	441aa91d-53a3-4c31-917c-bc6038dbae36
8528f246-24cc-4273-95c0-60596be529ab	t	Bazizana	d2bd8a78-98ad-4119-800f-ad245f204478
a3fa29f9-2527-424a-b9e8-234fd5909ced	t	Butorwa I	d2bd8a78-98ad-4119-800f-ad245f204478
21099b96-cfa1-42dd-8125-7679c2deb819	t	Butorwa Ii	d2bd8a78-98ad-4119-800f-ad245f204478
07921fa1-098c-4c68-9d59-1c2ad6f193a9	t	Gahisi	d2bd8a78-98ad-4119-800f-ad245f204478
0dd6745c-7d0f-4c0c-9283-4929162996c1	t	Gasura	d2bd8a78-98ad-4119-800f-ad245f204478
c54678ef-223a-475b-a487-b3e9bd48b9ee	t	Kansoro	d2bd8a78-98ad-4119-800f-ad245f204478
153e8ec2-1d24-4d18-9c97-0eb7162a4373	t	Kanyampereri	d2bd8a78-98ad-4119-800f-ad245f204478
2a785dae-9768-41d9-8c61-a83792051af3	t	Nyagisenyi	d2bd8a78-98ad-4119-800f-ad245f204478
1b19dabc-38af-46bc-a77f-86795df82a49	t	Buhuye	f7bfe497-39af-4473-9ddd-99feb708183f
90431339-6ba1-428f-9a48-785e216eb0b3	t	Gasanze	f7bfe497-39af-4473-9ddd-99feb708183f
4fa9fb41-c0d1-4bad-85f2-4ecb2c5f5f65	t	Gatare	f7bfe497-39af-4473-9ddd-99feb708183f
5f1cf983-7526-4402-8ece-7e26a302742c	t	Gatorwa	f7bfe497-39af-4473-9ddd-99feb708183f
97495283-778c-4aa9-a15b-11adc5158308	t	Kabogobogo	f7bfe497-39af-4473-9ddd-99feb708183f
8f401c11-347e-4172-909e-b1ea6b7460e8	t	Yorodani	f7bfe497-39af-4473-9ddd-99feb708183f
e30bd44d-142d-49e9-9f10-21ce005cd706	t	Kavumu	6e4ed059-57e0-4a38-81d7-6a71a1b8c7e5
a7dd5197-5cc9-4f12-b4ff-b5926c7ced8d	t	Kiryi	6e4ed059-57e0-4a38-81d7-6a71a1b8c7e5
505a5d75-84af-4437-88c0-e1bb9356d280	t	Nyamagumba	6e4ed059-57e0-4a38-81d7-6a71a1b8c7e5
e82beb62-b8f8-4fd4-99c7-d0d125659097	t	Nyamuremure	6e4ed059-57e0-4a38-81d7-6a71a1b8c7e5
36fd0b67-b432-498a-a6a0-c95002959005	t	Rukereza	6e4ed059-57e0-4a38-81d7-6a71a1b8c7e5
559be6fd-ff0a-4ce0-b9e4-6465b293eace	t	Gikwege	75de8a78-fa55-4d7c-a5fc-1a143a0db32e
ea6b3c15-da27-45f0-9b26-a179c5286215	t	Giramahoro	75de8a78-fa55-4d7c-a5fc-1a143a0db32e
02a37c75-3f4a-4cbb-9036-0393e8c0d840	t	Mpenge	75de8a78-fa55-4d7c-a5fc-1a143a0db32e
264ab283-bcf9-4f6d-8d45-9d4571e5cbd0	t	Rukoro	75de8a78-fa55-4d7c-a5fc-1a143a0db32e
7069a3df-e5f7-4f90-88ed-4441d441291b	t	Rusagara	75de8a78-fa55-4d7c-a5fc-1a143a0db32e
3afc7d23-4138-4e3b-9fb4-d76113cce875	t	Buhoro	44b8db83-6a76-40e1-b724-9e50cb09e07b
3732feeb-0311-441c-a879-a628671a92b6	t	Burera	44b8db83-6a76-40e1-b724-9e50cb09e07b
ec921e1a-0cce-4f54-8cee-fa64b12b94e4	t	Bushozi	44b8db83-6a76-40e1-b724-9e50cb09e07b
8f78e98e-bcfb-459b-b8be-d693709d8402	t	Byimana	44b8db83-6a76-40e1-b724-9e50cb09e07b
116098ae-83bc-4863-a68f-4ffa91dbdca6	t	Kabaya	44b8db83-6a76-40e1-b724-9e50cb09e07b
3512c331-5dde-46d1-9430-b0fa159e5ba7	t	Muhe	44b8db83-6a76-40e1-b724-9e50cb09e07b
0c44f3ee-31d7-4268-994e-03ba7994eefe	t	Susa	44b8db83-6a76-40e1-b724-9e50cb09e07b
97f18ee3-5dd2-40df-8602-8649c42698b9	t	Nyiramuko	4143ade8-2fc5-42d6-b319-7340ddfe3224
c86ae708-5f2e-40af-8bd0-3183e16047b6	t	Kabere	10c60500-d4c7-48f3-a903-51fc432ffa2e
7ae17ad6-4038-4e0c-846b-e34dcc06060a	t	Kabindi	f2f7d079-0351-4257-84dd-44004c459a4f
c484291b-045c-4afb-b22c-429517deacb0	t	Musenyi	f2f7d079-0351-4257-84dd-44004c459a4f
c32f0fea-a18e-410d-b5e6-d676cfe769c2	t	Mwanganzara	f2f7d079-0351-4257-84dd-44004c459a4f
766ac285-1180-470b-919e-9663be5f09e4	t	Ngabane	f2f7d079-0351-4257-84dd-44004c459a4f
64871e2e-c399-4dbc-9ed6-4b66a91a7463	t	Ntindo	f2f7d079-0351-4257-84dd-44004c459a4f
20373515-c772-434a-9785-570a154fe92b	t	Bukane	fbb8894c-be6d-42dc-9916-7503fb6b7d99
bb556fcf-199d-40c3-832d-a969d9fc0fe5	t	Gaturo	fbb8894c-be6d-42dc-9916-7503fb6b7d99
3707d16e-83a9-4629-adb2-96964100c874	t	Gikeri	fbb8894c-be6d-42dc-9916-7503fb6b7d99
df0d3faf-a429-4bdc-bd88-80fed6849136	t	Kabaya	fbb8894c-be6d-42dc-9916-7503fb6b7d99
a8ac17ad-c8bb-42a3-bb6e-fd0dfba20f94	t	Kageyo	fbb8894c-be6d-42dc-9916-7503fb6b7d99
2b55d166-5ab6-4d98-9408-08f96b7a849d	t	Kiroba	fbb8894c-be6d-42dc-9916-7503fb6b7d99
569afab8-2d13-4b3f-958a-669432a85252	t	Rugeyo	fbb8894c-be6d-42dc-9916-7503fb6b7d99
6bae38b5-7e44-4db8-8545-aeed546a72e5	t	Ruvumu	fbb8894c-be6d-42dc-9916-7503fb6b7d99
3999f359-71b6-48dd-afbf-8e2affa9af6c	t	Cyanturo	2015cf52-9abf-467c-a2fa-cf520769d2f6
e5ed1eb6-d4e1-492a-8737-5be4bf91d404	t	Gacinyiro	2015cf52-9abf-467c-a2fa-cf520769d2f6
77883803-165b-446c-af81-8afe53fb4b16	t	Gapfuro	2015cf52-9abf-467c-a2fa-cf520769d2f6
063e8e5d-e82b-4ddf-be51-be05899fc654	t	Kanganwa	2015cf52-9abf-467c-a2fa-cf520769d2f6
0e1a8655-9886-4723-8218-504f50fbd613	t	Bihinga	cff8c68b-51ea-4f79-8618-5b110bbdbc5f
e33f77a4-abca-467f-b89b-9929da4409df	t	Kidendezi	cff8c68b-51ea-4f79-8618-5b110bbdbc5f
4594e9f4-f84e-4cdb-a9b0-47cdafe107a6	t	Mufukuro	cff8c68b-51ea-4f79-8618-5b110bbdbc5f
7f03eab1-de44-4254-a596-882bb391f294	t	Nyabageni	cff8c68b-51ea-4f79-8618-5b110bbdbc5f
a83a3cf3-eade-4e43-9232-8b21fcb5aeb9	t	Rucumu	cff8c68b-51ea-4f79-8618-5b110bbdbc5f
e3c3b450-fdbc-44f0-9b7f-1a472e3833cb	t	Rwunga	cff8c68b-51ea-4f79-8618-5b110bbdbc5f
088c05a8-4da0-4183-a219-fdaf61012c48	t	Bannyisuka	474bf0b0-b4f6-4453-96c1-841e48d64e80
0dc15f52-0400-4f22-9bf9-750f2ae3cfae	t	Kareba	474bf0b0-b4f6-4453-96c1-841e48d64e80
9aaccfcb-76fe-454f-968b-405ae6cf4edc	t	Kavumbu	474bf0b0-b4f6-4453-96c1-841e48d64e80
74ab226f-42d9-4236-9ef8-70adcc64481b	t	Murenzi	474bf0b0-b4f6-4453-96c1-841e48d64e80
e8e8b844-8dea-4500-9866-67f66c05ba94	t	Nturo	474bf0b0-b4f6-4453-96c1-841e48d64e80
b2799e51-9f67-4d89-8336-b0690af48b2e	t	Tero	474bf0b0-b4f6-4453-96c1-841e48d64e80
127e1256-4096-4d49-ada9-c4ffdfb3cbae	t	Buhunge	ec90d9c6-4cc5-42f1-8c95-876f0a6a8827
21dea8f3-1056-4986-9f11-5718eb58bdfe	t	Kirerema	ec90d9c6-4cc5-42f1-8c95-876f0a6a8827
f8ba0666-a896-43af-82e6-845abfb25189	t	Nyarubande	ec90d9c6-4cc5-42f1-8c95-876f0a6a8827
2de19072-ec5c-4fd5-b7d3-aef8cde8ee0d	t	Runyangwe	ec90d9c6-4cc5-42f1-8c95-876f0a6a8827
0d779412-0437-49d9-b270-1757cccf27b9	t	Rwunga	ec90d9c6-4cc5-42f1-8c95-876f0a6a8827
2fb83428-a709-40db-b197-a90443fafca8	t	Barizo	bedb3d64-605b-4fd9-9e36-a6e7da7985f1
577f97ed-9bf8-45d1-a40c-884e48b466d3	t	Karambi	bedb3d64-605b-4fd9-9e36-a6e7da7985f1
fec6bfb3-4cd2-4076-8dac-507837e10537	t	Kinkware	bedb3d64-605b-4fd9-9e36-a6e7da7985f1
fabdefca-f479-4464-96a0-35b2f067b6cf	t	Gasoroza	541b5196-4042-4ac6-83cd-7b26ae51957b
d0b39cc7-786f-4e45-862f-03012d8392c9	t	Kagano	541b5196-4042-4ac6-83cd-7b26ae51957b
8c930147-b330-4b94-8c31-c413924b94e3	t	Muhe	541b5196-4042-4ac6-83cd-7b26ae51957b
5cdf471f-8052-4eea-af4f-3f0f9f18ef70	t	Rugarama	541b5196-4042-4ac6-83cd-7b26ae51957b
7380e164-755d-4db5-b019-61bfed37966b	t	Terimbere	541b5196-4042-4ac6-83cd-7b26ae51957b
99bac3f7-63a7-4d6f-8ee0-86af2ddff4c1	t	Gahama	ee4c3eaf-c420-439b-823f-6890f0078cb1
288f7b2b-a783-4504-9f24-a05decb02196	t	Kansoro	ee4c3eaf-c420-439b-823f-6890f0078cb1
6a3066b5-fe72-43b2-a448-dfe0a8a13421	t	Kibingo	ee4c3eaf-c420-439b-823f-6890f0078cb1
576fc45b-4272-4ab5-ae83-1c25ca2ea693	t	Ntamiziro	ee4c3eaf-c420-439b-823f-6890f0078cb1
737224c9-8d31-4748-8a78-ff04409b493e	t	Nyarubuye	ee4c3eaf-c420-439b-823f-6890f0078cb1
f13917c4-6394-4190-abad-c82df424d734	t	Rwebeya	ee4c3eaf-c420-439b-823f-6890f0078cb1
97c2d9c8-ba90-4a71-806e-f885fb396838	t	Kabaya	5f3e945e-dcb6-4631-af1c-ce1b092a8a7a
3d11396f-651c-4454-b874-0eb0b5d9d81b	t	Kamajaga	5f3e945e-dcb6-4631-af1c-ce1b092a8a7a
026fac2a-a2c9-47f0-a83d-0783cea35305	t	Kamicaca	5f3e945e-dcb6-4631-af1c-ce1b092a8a7a
a44ba99a-2ae2-40a1-80a3-99dc802b42a0	t	Musenyi	5f3e945e-dcb6-4631-af1c-ce1b092a8a7a
84e9d3a9-f063-485e-af9f-3dada8c06765	t	Rugari	5f3e945e-dcb6-4631-af1c-ce1b092a8a7a
751b64d3-6255-45b1-8f40-9e7b7bebe287	t	Bazizana	91b5c68e-77b3-4d6d-aabf-a82dd41b0d3c
1f5a2755-2e3d-4e32-93af-c6f2a4ee3c70	t	Bihinga	91b5c68e-77b3-4d6d-aabf-a82dd41b0d3c
ea3542e2-003b-4dc9-88d7-86b4139f0c05	t	Bukingo	91b5c68e-77b3-4d6d-aabf-a82dd41b0d3c
b0f374bf-533d-4438-9983-f580826dd19b	t	Buramba	91b5c68e-77b3-4d6d-aabf-a82dd41b0d3c
5450edc6-dbb1-458d-8b4b-8f2dcb7a4966	t	Jite	91b5c68e-77b3-4d6d-aabf-a82dd41b0d3c
f4a7f625-5676-4376-91cd-402ad5425434	t	Micaca	91b5c68e-77b3-4d6d-aabf-a82dd41b0d3c
966e18c5-90d9-4305-b5d2-6483d8599131	t	Nkogote	91b5c68e-77b3-4d6d-aabf-a82dd41b0d3c
471712f7-22f4-442a-8c8b-1a42aad71724	t	Ntarama	91b5c68e-77b3-4d6d-aabf-a82dd41b0d3c
aca14e69-3a8b-49cb-9fb9-6e7cd1917281	t	Ntebe	91b5c68e-77b3-4d6d-aabf-a82dd41b0d3c
fd0241c6-7a5a-454a-9f3b-30c9f517dddc	t	Rugwiro	91b5c68e-77b3-4d6d-aabf-a82dd41b0d3c
49bb565c-c7d6-4161-a848-8d82c66192ba	t	Garuka	604daecb-b76d-4400-b8cb-817e6ab533a8
d6faaa08-7f05-483e-a4ad-9871a25cfa89	t	Gisigwa	604daecb-b76d-4400-b8cb-817e6ab533a8
bc6cbd40-5286-4343-ab29-b3c5ce5350e9	t	Kabagorozi	604daecb-b76d-4400-b8cb-817e6ab533a8
8b82a614-9ca4-4ea1-9287-c612b14e7d5c	t	Kareba	604daecb-b76d-4400-b8cb-817e6ab533a8
66c65ae6-6e6b-4296-ac9a-a4fd4b6bc750	t	Nkiriza	604daecb-b76d-4400-b8cb-817e6ab533a8
034b9c99-a401-4a4b-9d8f-03c76923b4e9	t	Bukara	27e3c200-efbb-483b-a5e6-2365b2f1dda3
76f2b38e-8706-4b3e-a774-fdca1a7349e1	t	Gitega	27e3c200-efbb-483b-a5e6-2365b2f1dda3
dd505a3e-663f-4d29-a016-0dd4d87f3908	t	Nyakibande	27e3c200-efbb-483b-a5e6-2365b2f1dda3
80e55698-8e48-4b92-aab2-6ffe2bcbc275	t	Rususa	27e3c200-efbb-483b-a5e6-2365b2f1dda3
260bf9f6-d512-4b71-9120-69a3d31ef026	t	Kabara	ca5c4f82-f5c2-443f-b250-7f445db9b1c7
7469a00a-396d-442e-9692-58f032cb52d7	t	Mikamo	ca5c4f82-f5c2-443f-b250-7f445db9b1c7
d84d9a86-2e61-47e7-9a7c-ab9c9b35373e	t	Buhogo	0bf3e6dd-b6ce-4a57-b4e4-f9b7910a49b9
3efd76b5-e371-4dd7-87a4-9f21d265f8af	t	Kabagora	0bf3e6dd-b6ce-4a57-b4e4-f9b7910a49b9
409b6aec-f82c-464b-a4c6-d0e0e181e218	t	Karuruma	0bf3e6dd-b6ce-4a57-b4e4-f9b7910a49b9
e12317ae-f1ce-4fa3-8528-10605c06c758	t	Muganda	0bf3e6dd-b6ce-4a57-b4e4-f9b7910a49b9
3e55a8fc-6eaf-4a7f-9825-c5299ae5189a	t	Nyirabisekuro	0bf3e6dd-b6ce-4a57-b4e4-f9b7910a49b9
7dfee6d1-0e70-4f10-b2a5-82ac983e283c	t	Gitwa	35c431bd-507c-49ab-8102-6e3ea0e7c605
12de8a60-1eff-49c9-a098-aaeab7e59458	t	Kabashima	35c431bd-507c-49ab-8102-6e3ea0e7c605
002a5704-ff08-4c8a-ad73-6f5c449e7d01	t	Kamanga	35c431bd-507c-49ab-8102-6e3ea0e7c605
9b736bb0-0875-49a1-9fcc-73f588886949	t	Mwiyandiro	35c431bd-507c-49ab-8102-6e3ea0e7c605
4375b86b-e6a7-407a-97ab-0f9e8618640f	t	Ngenzi	35c431bd-507c-49ab-8102-6e3ea0e7c605
6f75d918-a0e8-4199-85a9-e3c848257766	t	Bitsibo	0ed845be-f15d-4b69-9725-b4272107c78e
1e494afb-a898-4512-9860-90592c93abc6	t	Kabusozo	0ed845be-f15d-4b69-9725-b4272107c78e
68f1cfb4-35d3-4c82-9834-3cfbc246eea6	t	Muheta	beb7b5a6-2f43-4043-a8f0-838b7bed28da
5ea32564-5741-447e-8071-728dfa13e9d4	t	Busana	c502e37e-fb67-43d2-8696-b173f8848293
edb77776-5210-47b0-894d-c8643e38e3f8	t	Kabuga	c502e37e-fb67-43d2-8696-b173f8848293
c909c389-c3ff-48df-8cdb-d6f3151750fc	t	Nyagisozi	c502e37e-fb67-43d2-8696-b173f8848293
873831be-045c-42f5-9c83-4bea76e13e8e	t	Nyarugando	c502e37e-fb67-43d2-8696-b173f8848293
a73532d3-4ce9-4577-acda-fce6095b504d	t	Rwamigimbu	c502e37e-fb67-43d2-8696-b173f8848293
bc9f8854-7abd-4ae9-b198-530f8c1a643e	t	Mutara	a7e96b34-4ff0-4072-8f15-1e0d7922b7e6
82a2e2d7-2d62-469f-bc36-b2df90c8000f	t	Nyakarambi I	a7e96b34-4ff0-4072-8f15-1e0d7922b7e6
85ca5000-3ec1-4f56-80aa-b027f14e4970	t	Gakenke	b35546ea-9434-4386-93cf-94c3466d9cc9
f87767a1-7225-478b-8c11-a228e5388fbd	t	Mugogo	b35546ea-9434-4386-93cf-94c3466d9cc9
36cdf76a-e37d-4dee-87b3-c41a14c8a8a7	t	Rubabi	b35546ea-9434-4386-93cf-94c3466d9cc9
1a65857d-9f04-4def-a73a-43a97617e193	t	Rugari	b35546ea-9434-4386-93cf-94c3466d9cc9
d57a78c5-7ada-44dd-b35c-9f8f4282e8f5	t	Ruvumu	b35546ea-9434-4386-93cf-94c3466d9cc9
95b823e6-f12b-4315-a6de-11b28896483a	t	Ngege	712e5a31-8747-4aca-9855-c946f869c8c1
53bfb4ff-b94f-44b4-b6ce-0e8333248281	t	Bwamazi	6bb18c52-c483-44c5-8549-b9dbe5a69c0e
daa67ad6-afb4-4570-a1c1-094f2492b7cc	t	Gasura	6bb18c52-c483-44c5-8549-b9dbe5a69c0e
e1c65a8b-dc03-4845-8412-07ce2d32689c	t	Kabeza	6bb18c52-c483-44c5-8549-b9dbe5a69c0e
317496de-a039-433e-a050-0cb3d96d4f1c	t	Kadahenda	6bb18c52-c483-44c5-8549-b9dbe5a69c0e
e697026f-d255-4390-ad21-167a184de8ce	t	Karwesero	6bb18c52-c483-44c5-8549-b9dbe5a69c0e
c857f91d-5939-4527-9dc2-2d63225a43d0	t	Mutuzo	6bb18c52-c483-44c5-8549-b9dbe5a69c0e
f90994c3-d181-4347-b1e6-d54a98242867	t	Ryambungira	6bb18c52-c483-44c5-8549-b9dbe5a69c0e
ba9d8719-ca55-4c3c-922e-0984dee677a0	t	Byimana	b4b03b28-178c-428d-9f47-07f11e9e4b3f
5055c35d-74e9-4c68-b9c2-c3e6bea216dd	t	Cyimbazi	b4b03b28-178c-428d-9f47-07f11e9e4b3f
353eeabe-3f92-4210-a012-d41393681570	t	Mutuzo	b4b03b28-178c-428d-9f47-07f11e9e4b3f
12a14708-3ba6-40d3-864a-4e0dbd8feb3e	t	Nyundo	b4b03b28-178c-428d-9f47-07f11e9e4b3f
db0c8667-9d60-4566-9f4b-39326a7292a6	t	Rwinuma	b4b03b28-178c-428d-9f47-07f11e9e4b3f
7383ddd3-19d2-4a97-ac17-927711e3afe7	t	Nyamiyaga	eb1baa76-7f64-4f67-942b-80903510f37e
4bd0731a-4f1f-4455-b10b-fa29632b2b9c	t	Gihemba	4166203a-99ba-47a4-a867-dbce63b5dd72
6db6a5c8-332d-4739-8620-8735febae8f5	t	Kabingo	4166203a-99ba-47a4-a867-dbce63b5dd72
53b8d715-1bed-487c-bea1-656d931516b6	t	Mushongi	4166203a-99ba-47a4-a867-dbce63b5dd72
ba060972-bc73-4ad2-a313-33ac22fd5ffa	t	Gatete	38d11c6d-7c70-46e0-8800-f9b7a3b7eb25
734e78d7-922f-42bd-b97a-34beef12a58c	t	Mugenda I	38d11c6d-7c70-46e0-8800-f9b7a3b7eb25
2170845e-1e60-4411-8b61-765d7379125c	t	Base	0c85251a-a4c7-4fd9-8557-c995ff71f47f
ef0558e0-ebc2-489b-87a6-ce2dfce3f487	t	Cyondo	0c85251a-a4c7-4fd9-8557-c995ff71f47f
ac553730-a1fa-4a8f-ae75-86f8122c65ba	t	Kiruli	0c85251a-a4c7-4fd9-8557-c995ff71f47f
5bf0b027-dbb0-474c-ba59-2c8e8fb241e2	t	Gacyamo	4bf71803-f6b8-40b0-8e5e-802511e3cccb
a949a470-3626-41ab-b30a-dda4767d80c3	t	Mataba	77e41bb8-be61-4766-bbaa-25de2b1d4359
8f82167f-6b7f-489d-b495-09a163db526d	t	Ryinzovu	05ca1fe4-5b7e-4095-99da-a83471b771bb
6cf470e1-27b8-417b-886e-d114ecd1ae25	t	Remera	c7c9fc9d-3c31-430f-826b-48f057c49494
5565b129-6897-4eca-8361-1395114b374f	t	Rulindo	c7c9fc9d-3c31-430f-826b-48f057c49494
283127d2-05c2-44dc-9d1d-fedf75e18f4e	t	Cyiri	29b422eb-d42c-4ec6-be7b-cd00de5ea043
28c40d68-7fd7-455c-b871-53d3f91a9743	t	Gashiru	29b422eb-d42c-4ec6-be7b-cd00de5ea043
fc5ef57c-9702-4614-85a5-21a5b4ed023d	t	Kivomo	29b422eb-d42c-4ec6-be7b-cd00de5ea043
267e32a4-a87e-40a6-9101-496776dabe4a	t	Rebero	9fed2a9d-f360-434c-9ef6-dd8468811c8b
ef092a08-ad82-48b4-83e7-88d5a64858df	t	Rwanzu	9fed2a9d-f360-434c-9ef6-dd8468811c8b
7daa99b3-3681-44ef-91a1-f198ac21e769	t	Gatare	2f0b2860-dded-4018-a12d-095f70b97ed7
b32f7f0b-9cf8-4604-b446-f90eab7d121e	t	Muko	2f0b2860-dded-4018-a12d-095f70b97ed7
b9d92d62-9932-420d-b37b-7224fdcfecf9	t	Mukoto	2f0b2860-dded-4018-a12d-095f70b97ed7
56abc84d-e72a-403d-9a10-0bd774a7ec04	t	Bubiro	3381232b-fef6-4114-a482-f022af5988e8
10f8d32e-3a0a-4b15-8a45-96e4b9d0ae7e	t	Nyirangarama	3381232b-fef6-4114-a482-f022af5988e8
f675783c-74e7-4542-a0da-490fb2dfb01d	t	Remera	3381232b-fef6-4114-a482-f022af5988e8
7dd580e6-1dbe-4a58-a53e-129aa72f8a74	t	Tare	3381232b-fef6-4114-a482-f022af5988e8
9b9db5c2-640f-408d-9fb0-404ec6c83177	t	Rugarama	cfa5678c-7e3d-4f8d-9aeb-fe5c657c10c3
c15bbff7-53e1-4b11-ba4b-f79b2ae76711	t	Kankanga	6a7325a6-6ea1-4299-9ad4-7489501f130e
a7cd2ee3-7c8b-4ad0-b9b7-6175b12b675e	t	Bunyana	1414838e-80d6-4738-bde2-dd59ca79d1f7
8bedfdf7-765e-4f6c-9987-afebf45015aa	t	Gipfundo	1414838e-80d6-4738-bde2-dd59ca79d1f7
a0d35b06-a762-4b73-bf94-0cbb43264e08	t	Munini	a68c540b-e1f7-400c-9527-8d6ef6046cf7
9e66aa02-f624-46db-8176-0ddf907dbb44	t	Rutabo	a68c540b-e1f7-400c-9527-8d6ef6046cf7
9763d037-e3ca-4a94-98ee-1da6ac4add94	t	Cyasenge	e352e57a-d9b8-4948-b9db-b30e8e5dbfdd
b1147566-6355-474f-b36c-0a2b5a5bda05	t	Karambo	e352e57a-d9b8-4948-b9db-b30e8e5dbfdd
1196eec3-f23b-41f5-bda3-5ca62485fde3	t	Kigarama	e352e57a-d9b8-4948-b9db-b30e8e5dbfdd
fd5f2c40-01b8-44c0-9924-340e7011a356	t	Mataba	689e06f6-6367-4a71-b88c-7652a0861866
962ded5f-94c4-4907-a1a3-a468e3e17899	t	Kamatongo	183f5b01-7946-40e4-b4ba-12f1b734f4e9
d6a053fa-91e7-40f2-b014-ca0c0e4ba1d2	t	Gitabage	5bd4c108-a6eb-4b65-9bb0-175caf157d83
a83e3f61-671f-4a67-b982-23a970d3140f	t	Karambo	5bd4c108-a6eb-4b65-9bb0-175caf157d83
33af96b4-ed09-49d9-8c14-a85a7c62b7c8	t	Marembo	5bd4c108-a6eb-4b65-9bb0-175caf157d83
7db9116e-23df-4e73-9339-0381b3f9986d	t	Nyamugali	5bd4c108-a6eb-4b65-9bb0-175caf157d83
4e77c659-047b-445c-8a5d-83795972727e	t	Remera	5bd4c108-a6eb-4b65-9bb0-175caf157d83
aa845b4c-3aaf-49c4-914e-6358f0ca8f7e	t	Gasekabuye	565bdd72-71bc-435a-b263-362a182a792a
bcb6638b-f57c-4c4f-8659-9f052ca79032	t	Kibogora	4a53b407-e8fc-4b2c-a32b-9916e54fb380
400417a7-73c2-4ddc-807a-7b3b07b6f81e	t	Nyagatovu	4a53b407-e8fc-4b2c-a32b-9916e54fb380
9fe3a0d5-a895-446f-bc4d-4898868e31af	t	Buyaga	6badbe13-8938-4287-b9aa-1812c3a8fd20
19419573-4f20-42dd-b7f1-e34f7672867e	t	Gahinga	6badbe13-8938-4287-b9aa-1812c3a8fd20
58b02276-7908-4e3b-a8ab-55e87c0b7ebe	t	Kibuye	6badbe13-8938-4287-b9aa-1812c3a8fd20
23844bd9-773c-4bf5-a34f-186daa1095d5	t	Kidomo	6badbe13-8938-4287-b9aa-1812c3a8fd20
c3dfdfb6-6306-48d5-822d-db58b2776248	t	Murambo	6badbe13-8938-4287-b9aa-1812c3a8fd20
a7a4ffd1-772e-4613-ae15-235ef1f4b5bf	t	Rusayu	6badbe13-8938-4287-b9aa-1812c3a8fd20
bbf98c88-c126-43f8-adc8-193c64cc193a	t	Karambi	20d576a3-daa7-4b04-a9d0-8146938a4eda
19c91736-b616-4904-89d8-368e609148d2	t	Nturo	20d576a3-daa7-4b04-a9d0-8146938a4eda
354dab7b-a8b7-44c2-b5af-c974a7ec98c3	t	Sakara	20d576a3-daa7-4b04-a9d0-8146938a4eda
384b41c1-92a8-4e15-a9d8-b17bef6336c1	t	Akamiyove	b5eaa4ee-e6ce-439d-a95e-e0e459a8fb6e
9574ef57-4380-4752-ba8f-94b9fe35e2cc	t	Kinihira	b5eaa4ee-e6ce-439d-a95e-e0e459a8fb6e
4a92df81-96c5-40f9-bac5-a241c2da3cc6	t	Bwishya	9fb0920e-b3d6-4d01-9a35-4b7b37ca71b6
806de1b9-571a-4d7b-8279-9700539f6003	t	Gatembe	9fb0920e-b3d6-4d01-9a35-4b7b37ca71b6
97ed14a3-f866-44e0-a697-b3198c7b2e67	t	Kigali	3d613313-9886-4e3f-9d27-cb1b22dbdf29
912660b2-f5b8-44ec-8979-fb3e4c9b290e	t	Kabuga	98943a91-5819-4813-af44-7a7afead6575
19fde873-cce2-419d-a586-8ecb78f413d2	t	Gakenke	d71a462f-e0db-4077-a396-1ff724405285
39f24fbe-67cf-4b33-9d23-c6acfd4c0f47	t	Gasharu	3c672005-39ff-4afd-add7-9fe6d0f56021
61743213-4368-48ad-9c23-c62f7bb5caa5	t	Runyinya	3c672005-39ff-4afd-add7-9fe6d0f56021
9fd9a40b-8099-468e-a9c9-ae36fc63f4a4	t	Kirenge	d132f66e-c258-4022-967b-01504e18a6bd
7cd699b8-5fc6-4184-a875-692d0491f04a	t	Nyakarekare	d132f66e-c258-4022-967b-01504e18a6bd
0adc1bcc-b55f-46f6-933c-d3612bfcfb75	t	Akamanama	5edd5baa-bc35-432c-93d4-a740b41d2108
6a7f4b26-7ee3-488d-bbd5-a0e670d2bd15	t	Gishinge	5edd5baa-bc35-432c-93d4-a740b41d2108
a5b5bafa-43a0-4602-962f-9004a4dd90b3	t	Kibingwe	5edd5baa-bc35-432c-93d4-a740b41d2108
dd9da1f8-88f9-4f90-92f3-adf22a8152db	t	Mugomero	5edd5baa-bc35-432c-93d4-a740b41d2108
39f6dbbf-57be-4c38-98b8-dddad13aafc9	t	Cyasuri	d0f4f482-32c4-4536-bb26-d518342c5c74
ac57f920-d398-44c4-a96a-4c17b1722b52	t	Rusongati	d0f4f482-32c4-4536-bb26-d518342c5c74
dea31fad-5e3b-4952-940a-4942ec372e27	t	Gisiza	6e53d6e7-fb75-4680-ba4e-ce2e8db8cb3d
9e6bd8ba-f5c2-4b91-a425-5ec38bacd427	t	Kanunga	6e53d6e7-fb75-4680-ba4e-ce2e8db8cb3d
abc7b456-dbe3-4f53-af01-a155f113f333	t	Kigarama	6e53d6e7-fb75-4680-ba4e-ce2e8db8cb3d
0d3960aa-a0b8-41cb-914d-032ff074620c	t	Nyakibande	6e53d6e7-fb75-4680-ba4e-ce2e8db8cb3d
c9f916ae-cef0-4df0-b77c-168beb6762c6	t	Nyakizu	6e53d6e7-fb75-4680-ba4e-ce2e8db8cb3d
56069914-2955-42da-bc2b-646e25a5c80a	t	Rubaya	6e53d6e7-fb75-4680-ba4e-ce2e8db8cb3d
875de4e8-48c1-414a-a83f-012ec100ddc7	t	Gacyamo	58187818-902b-409e-93b0-c81a5b0cd12e
c6ed5bfc-5c4d-43b7-b971-b266c6118368	t	Marenge	58187818-902b-409e-93b0-c81a5b0cd12e
8a971a41-9f3b-41ff-9628-a8c46c8c5e79	t	Nyakabungo	58187818-902b-409e-93b0-c81a5b0cd12e
896a313f-4974-4dee-9f6b-bd2ebe9fe3b5	t	Rukurazo	58187818-902b-409e-93b0-c81a5b0cd12e
c39d3271-4d69-414b-82dd-408dd1e7f8b9	t	Nyarurembo	cedd8bca-f4fb-445e-90dc-9b877efff046
4aea1a0e-754a-444a-954d-cfee9ec927f4	t	Rebero	cedd8bca-f4fb-445e-90dc-9b877efff046
8e000607-4158-4f6c-a5a4-c0aa0b46d6f6	t	Kabeza	f203b56d-e06c-4f47-b310-2ca2f4c3a54a
daca84bb-2934-4f14-8e92-83559577d83f	t	Kabuga	f203b56d-e06c-4f47-b310-2ca2f4c3a54a
5f25c39b-6aba-4ec4-9fe0-e3702e05deef	t	Kigomwa	f203b56d-e06c-4f47-b310-2ca2f4c3a54a
5f9c61b8-ec02-40ea-9bed-3a785b5fc8b5	t	Marembo	f203b56d-e06c-4f47-b310-2ca2f4c3a54a
6bc88618-b5af-4fff-9669-fcff88c53a5d	t	Amataba	4d2e3f95-6213-4eb7-9846-58fe2631026e
8ca44072-17f8-4f0c-8c34-c5fbcf642662	t	Umubuga	4d2e3f95-6213-4eb7-9846-58fe2631026e
67bf66d1-da7d-42a0-8639-4ea74a544ee2	t	Buhira	12d8088b-4444-47f3-afa0-6b7e0d82b3ee
527ffa99-7316-4e0e-a04c-153e824e6da2	t	Gasama	12d8088b-4444-47f3-afa0-6b7e0d82b3ee
7fe5b204-4126-42bc-a0e1-efb97b7587c1	t	Kibaya	12d8088b-4444-47f3-afa0-6b7e0d82b3ee
ee25a35f-adb5-4425-9d05-205386bcdf19	t	Bukongi	c409fa2b-6a67-41b6-b1ff-e5bfe3f3d9d9
f98ebb68-2bb4-4d74-b849-1cb82c51f5b9	t	Buraro	c409fa2b-6a67-41b6-b1ff-e5bfe3f3d9d9
3bcf16db-7bfe-4a31-b452-d55799fc8372	t	Gikombe	868029ac-39d4-43f4-9a49-30f0467a56f3
63fd633b-227b-4ee7-8578-af43fdc1252f	t	Gisha	868029ac-39d4-43f4-9a49-30f0467a56f3
35adc488-f9da-44b1-b62d-968a5a8e931a	t	Muhora	868029ac-39d4-43f4-9a49-30f0467a56f3
8dc1de03-6c7f-4f69-acbc-dd902f5004b6	t	Gicumbi	95f6c8ab-fdcb-4637-8b2f-79db1155a4d4
740e366f-4765-418c-9f95-9017bd26856c	t	Karambo	43088db0-3e83-4118-9c04-c3b015130efd
08166a46-ee97-4901-a6e1-fb155db6db58	t	Karwa	43088db0-3e83-4118-9c04-c3b015130efd
a33764d5-3402-4a64-a0ba-066046b54ccd	t	Mayange	43088db0-3e83-4118-9c04-c3b015130efd
f6bf62ff-3f49-4d62-8fe4-7eab5196b0e5	t	Nyagisozi	43088db0-3e83-4118-9c04-c3b015130efd
6dbe3b88-ae98-47b0-9c50-035325ec17ce	t	Taba	43088db0-3e83-4118-9c04-c3b015130efd
03575851-32da-415b-9c26-f2b5058ff30a	t	Akarambi	b7c608f9-d61c-4238-9ce7-898b81ab39f8
3bf78084-5189-4221-980b-3c5c511c8b35	t	Nyarurembo	f54f7db8-33ae-4e4e-9028-59a4bca25a10
a740381f-f7fd-43f2-904f-7b445b57139b	t	Ruri	f54f7db8-33ae-4e4e-9028-59a4bca25a10
f8162317-bc3b-42d8-87a8-8a73593c8ca0	t	Munyinya	507505ed-52b3-4ea7-a551-ae189e8847d0
f68b3c82-6d08-461e-a01c-7b579d8756db	t	Rurama	507505ed-52b3-4ea7-a551-ae189e8847d0
3fb6a03e-a887-46e3-af77-6153cf3145b6	t	Nyabuko	e6456dcd-fdc1-4e5a-975e-106705c8bc8d
66fcfb25-59f7-4c91-9a28-7d2538acbef1	t	Butare	42c95346-8f42-400e-b817-0a686bd5a557
364189ac-1e7e-4344-bb4b-d2d3277bec06	t	Jyambere	42c95346-8f42-400e-b817-0a686bd5a557
b3cdf2af-70cc-4b1a-a372-0b61845960a2	t	Kagwa	42c95346-8f42-400e-b817-0a686bd5a557
75d5c04b-c216-411d-b3c0-362be18fc032	t	Karambi	42c95346-8f42-400e-b817-0a686bd5a557
f98c8023-8528-41eb-a888-3bb2f5419588	t	Mwishya	1b1a7266-7238-4777-9649-59d891363a96
24975d31-c2ef-4260-9155-4ac3ccc72c0a	t	Riryi	1b1a7266-7238-4777-9649-59d891363a96
9bfa8f01-f891-40b5-b9eb-313f388fd2d0	t	Sakara	1b1a7266-7238-4777-9649-59d891363a96
33f7eb1a-b560-4d51-b109-49ec4521b4a9	t	Kirungu	d4eaab27-157a-475d-ac13-bd330a013d27
83fa6f8b-0941-4b04-8304-7337d4f59926	t	Nyaruvumu	d4eaab27-157a-475d-ac13-bd330a013d27
13a3f0cb-86c0-42e9-bca5-7403b9524404	t	Rushayu	d4eaab27-157a-475d-ac13-bd330a013d27
5f4141ac-bd01-463d-b7e5-94264f350418	t	Bikamba	30c3f72f-e0f9-4af4-b3cd-d1055ce65055
808154a4-250c-4b90-b195-1fd6336df8a8	t	Cyamutara	30c3f72f-e0f9-4af4-b3cd-d1055ce65055
fbaa6e1c-05f6-4f7c-8d25-f71cb824dd54	t	Gitambi	30c3f72f-e0f9-4af4-b3cd-d1055ce65055
c619edb8-2b3b-48d6-9690-820fa6929c24	t	Kazi	30c3f72f-e0f9-4af4-b3cd-d1055ce65055
32eb7a35-7c31-4914-b7b8-e18661b956e4	t	Nyakambu	30c3f72f-e0f9-4af4-b3cd-d1055ce65055
a81ac3cd-73c5-4e91-aa9d-84000e460c73	t	Nyarubuye	30c3f72f-e0f9-4af4-b3cd-d1055ce65055
237f107a-1bad-4d09-9e7a-865d4711b69a	t	Rukore	30c3f72f-e0f9-4af4-b3cd-d1055ce65055
b20606ec-517a-4a5c-95c9-2ab06444801d	t	Rusasa	30c3f72f-e0f9-4af4-b3cd-d1055ce65055
0181f65c-5a4d-4673-9b1e-18a2be836910	t	Kabirizi	011a2ef0-1c3c-4244-aacc-78a471eb21a9
4d3b93a0-3f3b-41ea-a7e7-9b5f57b51781	t	Nyagisozi	011a2ef0-1c3c-4244-aacc-78a471eb21a9
f19c11aa-1d2e-4d37-9ee4-34a617cfffae	t	Burambi	77bd2c78-eabe-4aee-bbc8-726b7bcb706d
a8b5c75d-8025-4169-9372-62d1dc7cbbf2	t	Karera	77bd2c78-eabe-4aee-bbc8-726b7bcb706d
d0164b17-1692-49a0-b461-6ad7bd1f40a1	t	Rusekabuye	77bd2c78-eabe-4aee-bbc8-726b7bcb706d
88578dab-023f-462a-9fda-1db8a9d855ab	t	Rukingu	ef02abea-0e61-4221-946d-64cca10c9fd6
6d2d9ac5-e7ad-4a73-ad23-01214d8d5736	t	Shyondwe	ef02abea-0e61-4221-946d-64cca10c9fd6
9d8ed74b-0aea-43e3-8480-a38fd7470f0f	t	Gatwa	e1324e40-d184-4a62-86cd-855c5c7efd17
88c45fd4-b383-4150-bccd-1d0df87e6879	t	Kadendegeri	e1324e40-d184-4a62-86cd-855c5c7efd17
1bb904cd-0602-4377-adb8-59e99e323b52	t	Gahwazi	5b7365b1-eade-40be-9648-7fbc4bf7728f
cd90448a-7b5c-4197-9da0-8d0024a51e50	t	Gakubo	5b7365b1-eade-40be-9648-7fbc4bf7728f
fb179154-b088-4f87-8491-32093c6442f6	t	Mataba	5b7365b1-eade-40be-9648-7fbc4bf7728f
c8a83186-faf9-44a1-b2d5-8d38720614e3	t	Kibare	b2524828-ae85-4ff2-ae79-10bebebc1bca
d483ab2c-5eff-41c2-af67-ca249769a2b1	t	Mujebe	b2524828-ae85-4ff2-ae79-10bebebc1bca
64f7dbbb-a08c-4e3d-9fef-52f124005b05	t	Kabunigu	8e825355-5fe0-4086-9a63-1266673a4079
9a63b24e-588d-460a-9973-11e1e841f67e	t	Nkanga	8e825355-5fe0-4086-9a63-1266673a4079
7ab3b7d1-a5f3-4413-a76b-57ea7831d2cd	t	Rwintare	8e825355-5fe0-4086-9a63-1266673a4079
87ca0834-8f5e-4e2b-baf3-4afc440d73f1	t	Kigarama	1115052f-123e-450b-83ba-18caafb3279b
722cb197-7317-4273-bdad-00da70fc3b50	t	Kinini-rusiga	1115052f-123e-450b-83ba-18caafb3279b
e8cf2d84-28da-4500-ae43-547d5efa9e48	t	Bitare	5f7dd11c-bd65-4bd8-bcb1-6aa8f17fd087
07b45271-e631-4491-a06b-1556ca7f0f02	t	Nyakarama	5f7dd11c-bd65-4bd8-bcb1-6aa8f17fd087
923e3be8-cae6-4472-8dc5-950dd13d08b4	t	Gatimba	8e8e72b0-1487-47ff-a94d-851467f85bd1
0c1154cf-95ca-48e0-8db4-b2b17845a320	t	Gatwa	8e8e72b0-1487-47ff-a94d-851467f85bd1
ef513ab9-0ae2-49c6-95c8-bd2c63506016	t	Gisiza	8e8e72b0-1487-47ff-a94d-851467f85bd1
307dd198-ab31-4238-8b67-46756f6a1618	t	Kabaraza	8e8e72b0-1487-47ff-a94d-851467f85bd1
c11cbda6-1a87-453e-9484-09aa26686c5e	t	Kiziranyenzi	8e8e72b0-1487-47ff-a94d-851467f85bd1
bff68112-d39a-4741-812d-97eaad38ac97	t	Nyarushinya	8e8e72b0-1487-47ff-a94d-851467f85bd1
51fcebd7-ecda-4b96-87f3-94a3aa45c22f	t	Gaseke	35199414-34b9-4b97-b0da-e3a7900ca4a7
9a872850-8ebd-4024-b342-7d1ff3c84964	t	Kabagabaga	35199414-34b9-4b97-b0da-e3a7900ca4a7
aa5ea957-6074-4499-9ef9-55b21a84e2ea	t	Kivili	d538357f-bb46-463b-a114-65fea6e79a8b
24f0e948-87eb-4a8d-8cad-bda92ee2d7fb	t	Muvumu	d538357f-bb46-463b-a114-65fea6e79a8b
a063340f-255e-4c92-8027-d966babaa356	t	Rwahi	eb6de0f3-1e91-4543-bf58-64cdbcf48e88
5e69c7bf-955d-4479-8f1b-5edccb2b292e	t	Bugarura	f845b1c2-e9f3-4457-995b-09141eeacc17
215fbb47-8751-4115-892f-423b73c6e7e1	t	Mwagiro	f845b1c2-e9f3-4457-995b-09141eeacc17
0ec7f09c-9cdf-4e21-ad14-d94703f650fb	t	Ngendo	f845b1c2-e9f3-4457-995b-09141eeacc17
3d4157c8-2c92-4af1-837c-2afd90cfe27b	t	Nyabisindu	f845b1c2-e9f3-4457-995b-09141eeacc17
66c9f163-ca4c-48d3-9c49-23c93b833116	t	Nyabyondo	f845b1c2-e9f3-4457-995b-09141eeacc17
18dce035-114b-45dc-8454-aecffa8f0417	t	Nyamirembe	f845b1c2-e9f3-4457-995b-09141eeacc17
df486c15-fbea-4e65-a916-3dac8d1dd604	t	Rweya	f845b1c2-e9f3-4457-995b-09141eeacc17
8f64232a-cf1d-418e-b48a-7d10e341cb60	t	Gaseke	f074c9ae-f281-4b72-88c0-9266f38e312a
1e8e3984-ddb7-4eb8-89a6-7b81de788749	t	Karambi	f074c9ae-f281-4b72-88c0-9266f38e312a
82b6d891-e6cd-40d4-aacd-2fadff412d33	t	Rukore	f074c9ae-f281-4b72-88c0-9266f38e312a
90843719-1f0d-4af4-ab2d-e3e0a185212c	t	Mafene	bbe75d05-9ca9-408d-8ffa-87db7ae24fb4
95a56c20-d405-4b90-9dcd-2ca39dcccd81	t	Kanaba	a0f1a14a-ce80-4644-b226-0fbac7ef039c
23089dd2-ada5-4469-b0eb-b4e300680b95	t	Misezero	a0f1a14a-ce80-4644-b226-0fbac7ef039c
fc2418c2-cf4e-479c-bdbd-12c85c5fe4ee	t	Bukinga	04dd0fbe-3bfd-4d42-b2c3-eb8c51d740c3
882e5e79-12f7-48de-9cd9-937d99c5bd8f	t	Murambi	04dd0fbe-3bfd-4d42-b2c3-eb8c51d740c3
96611e8e-c619-4a4e-8929-0e0f242b4a36	t	Kamuragi	b12ca72a-227a-401a-aeba-985790fc38e1
072632e3-69f6-4299-a895-116d98e9eaad	t	Nyirambuga	b12ca72a-227a-401a-aeba-985790fc38e1
afe0279a-df33-4c9c-8b23-00555f72d50e	t	Ruvumba	b12ca72a-227a-401a-aeba-985790fc38e1
\.


--
-- Data for Name: wishlist_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wishlist_items (id, created_at, created_by, updated_at, updated_by, product_id, user_id) FROM stdin;
\.


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: banners banners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_pkey PRIMARY KEY (id);


--
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (id);


--
-- Name: carts carts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: cells cells_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cells
    ADD CONSTRAINT cells_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: chat_sessions chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: communication_logs communication_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_logs
    ADD CONSTRAINT communication_logs_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: customer_addresses customer_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_addresses
    ADD CONSTRAINT customer_addresses_pkey PRIMARY KEY (id);


--
-- Name: customer_metrics customer_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_metrics
    ADD CONSTRAINT customer_metrics_pkey PRIMARY KEY (id);


--
-- Name: customer_profiles customer_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_profiles
    ADD CONSTRAINT customer_profiles_pkey PRIMARY KEY (id);


--
-- Name: customer_segments customer_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_segments
    ADD CONSTRAINT customer_segments_pkey PRIMARY KEY (id);


--
-- Name: discounts discounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discounts
    ADD CONSTRAINT discounts_pkey PRIMARY KEY (id);


--
-- Name: districts districts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT districts_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: faq_articles faq_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faq_articles
    ADD CONSTRAINT faq_articles_pkey PRIMARY KEY (id);


--
-- Name: feedbacks feedbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT feedbacks_pkey PRIMARY KEY (id);


--
-- Name: financial_reports financial_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_reports
    ADD CONSTRAINT financial_reports_pkey PRIMARY KEY (id);


--
-- Name: fulfillment_orders fulfillment_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_orders
    ADD CONSTRAINT fulfillment_orders_pkey PRIMARY KEY (id);


--
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- Name: kpi_records kpi_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_records
    ADD CONSTRAINT kpi_records_pkey PRIMARY KEY (id);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (id);


--
-- Name: mfa_otps mfa_otps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_otps
    ADD CONSTRAINT mfa_otps_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: order_tracking_events order_tracking_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_tracking_events
    ADD CONSTRAINT order_tracking_events_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: payment_transactions payment_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_pkey PRIMARY KEY (id);


--
-- Name: procurement_orders procurement_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_orders
    ADD CONSTRAINT procurement_orders_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_reviews product_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reviews
    ADD CONSTRAINT product_reviews_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: provinces provinces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provinces
    ADD CONSTRAINT provinces_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: return_requests return_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_requests
    ADD CONSTRAINT return_requests_pkey PRIMARY KEY (id);


--
-- Name: revenues revenues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revenues
    ADD CONSTRAINT revenues_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sales_reports sales_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_reports
    ADD CONSTRAINT sales_reports_pkey PRIMARY KEY (id);


--
-- Name: satisfaction_surveys satisfaction_surveys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.satisfaction_surveys
    ADD CONSTRAINT satisfaction_surveys_pkey PRIMARY KEY (id);


--
-- Name: sectors sectors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectors
    ADD CONSTRAINT sectors_pkey PRIMARY KEY (id);


--
-- Name: security_settings security_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_settings
    ADD CONSTRAINT security_settings_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: support_messages support_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: system_backups system_backups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_backups
    ADD CONSTRAINT system_backups_pkey PRIMARY KEY (id);


--
-- Name: system_configurations system_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_configurations
    ADD CONSTRAINT system_configurations_pkey PRIMARY KEY (id);


--
-- Name: tax_rates tax_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT tax_rates_pkey PRIMARY KEY (id);


--
-- Name: tax_records tax_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_records
    ADD CONSTRAINT tax_records_pkey PRIMARY KEY (id);


--
-- Name: products uk61hq67yr3nuuwvx80rbr95r4s; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT uk61hq67yr3nuuwvx80rbr95r4s UNIQUE (inventory_item_id);


--
-- Name: carts uk64t7ox312pqal3p7fg9o503c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT uk64t7ox312pqal3p7fg9o503c2 UNIQUE (user_id);


--
-- Name: users uk6dotkott2kjsp8vw4d0m25fb7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk6dotkott2kjsp8vw4d0m25fb7 UNIQUE (email);


--
-- Name: password_reset_tokens uk71lqwbwtklmljk3qlsugr1mig; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT uk71lqwbwtklmljk3qlsugr1mig UNIQUE (token);


--
-- Name: refresh_tokens uk7tdcd6ab5wsgoudnvj7xf1b7l; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT uk7tdcd6ab5wsgoudnvj7xf1b7l UNIQUE (user_id);


--
-- Name: system_configurations uk867jsfttn43kaegq3c6c24b7r; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_configurations
    ADD CONSTRAINT uk867jsfttn43kaegq3c6c24b7r UNIQUE (config_key);


--
-- Name: tax_rates uk88nhapcsosjsuypf5wedngqgk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT uk88nhapcsosjsuypf5wedngqgk UNIQUE (code);


--
-- Name: customer_segments uk9v933bm211015c3i1vh4qg1iq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_segments
    ADD CONSTRAINT uk9v933bm211015c3i1vh4qg1iq UNIQUE (name);


--
-- Name: cells uk_cell_sector_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cells
    ADD CONSTRAINT uk_cell_sector_name UNIQUE (sector_id, name);


--
-- Name: districts uk_district_province_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT uk_district_province_name UNIQUE (province_id, name);


--
-- Name: sectors uk_sector_district_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectors
    ADD CONSTRAINT uk_sector_district_name UNIQUE (district_id, name);


--
-- Name: villages uk_village_cell_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.villages
    ADD CONSTRAINT uk_village_cell_name UNIQUE (cell_id, name);


--
-- Name: coupons ukeplt0kkm9yf2of2lnx6c1oy9b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT ukeplt0kkm9yf2of2lnx6c1oy9b UNIQUE (code);


--
-- Name: refresh_tokens ukghpmfn23vmxfu3spu3lfg4r2d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT ukghpmfn23vmxfu3spu3lfg4r2d UNIQUE (token);


--
-- Name: shipments ukhrhy2yghr8dampg1jtecuekvp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT ukhrhy2yghr8dampg1jtecuekvp UNIQUE (order_id);


--
-- Name: customer_metrics ukhuf800pbo311daueruwtpgd4w; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_metrics
    ADD CONSTRAINT ukhuf800pbo311daueruwtpgd4w UNIQUE (customer_id);


--
-- Name: mfa_otps ukicfpxf4f0hvk8up1epwolbe29; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_otps
    ADD CONSTRAINT ukicfpxf4f0hvk8up1epwolbe29 UNIQUE (mfa_token);


--
-- Name: customer_profiles ukjoftwv6r96fq3bdnu7q00hq1w; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_profiles
    ADD CONSTRAINT ukjoftwv6r96fq3bdnu7q00hq1w UNIQUE (customer_id);


--
-- Name: provinces ukl256wnwfdobq071mcq7rckr9y; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provinces
    ADD CONSTRAINT ukl256wnwfdobq071mcq7rckr9y UNIQUE (name);


--
-- Name: return_requests ukmlyu5yxuty6xy4bndr5rrnfr0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_requests
    ADD CONSTRAINT ukmlyu5yxuty6xy4bndr5rrnfr0 UNIQUE (order_id);


--
-- Name: fulfillment_orders ukng3qc69pwbil0dalh7vkmueod; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_orders
    ADD CONSTRAINT ukng3qc69pwbil0dalh7vkmueod UNIQUE (order_id);


--
-- Name: orders uknthkiu7pgmnqnu86i2jyoe2v7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT uknthkiu7pgmnqnu86i2jyoe2v7 UNIQUE (order_number);


--
-- Name: roles ukofx66keruapi6vyqpv6f2or37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT ukofx66keruapi6vyqpv6f2or37 UNIQUE (name);


--
-- Name: inventory_items ukp0mih1lkha7t38jh46r3uu0eg; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT ukp0mih1lkha7t38jh46r3uu0eg UNIQUE (sku);


--
-- Name: satisfaction_surveys ukpv41e93d5s8qmc9eq8ws0hawj; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.satisfaction_surveys
    ADD CONSTRAINT ukpv41e93d5s8qmc9eq8ws0hawj UNIQUE (ticket_id);


--
-- Name: fulfillment_orders ukrkhys3qm94etm6t863ifw77t0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_orders
    ADD CONSTRAINT ukrkhys3qm94etm6t863ifw77t0 UNIQUE (shipment_id);


--
-- Name: categories ukt8o6pivur7nn124jehx7cygw5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT ukt8o6pivur7nn124jehx7cygw5 UNIQUE (name);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: villages villages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.villages
    ADD CONSTRAINT villages_pkey PRIMARY KEY (id);


--
-- Name: wishlist_items wishlist_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist_items
    ADD CONSTRAINT wishlist_items_pkey PRIMARY KEY (id);


--
-- Name: idx_cell_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cell_name ON public.cells USING btree (name);


--
-- Name: idx_cell_sector; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cell_sector ON public.cells USING btree (sector_id);


--
-- Name: idx_district_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_district_name ON public.districts USING btree (name);


--
-- Name: idx_district_province; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_district_province ON public.districts USING btree (province_id);


--
-- Name: idx_province_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_province_name ON public.provinces USING btree (name);


--
-- Name: idx_sector_district; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sector_district ON public.sectors USING btree (district_id);


--
-- Name: idx_sector_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sector_name ON public.sectors USING btree (name);


--
-- Name: idx_village_cell; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_village_cell ON public.villages USING btree (cell_id);


--
-- Name: idx_village_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_village_name ON public.villages USING btree (name);


--
-- Name: refresh_tokens fk1lih5y2npsf8u5o3vhdb9y0os; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT fk1lih5y2npsf8u5o3vhdb9y0os FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cart_items fk1re40cjegsfvw58xrkdp6bac6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT fk1re40cjegsfvw58xrkdp6bac6 FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: support_tickets fk1tmbsselat6ceyejefrvdeis9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT fk1tmbsselat6ceyejefrvdeis9 FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: product_reviews fk35kxxqe2g9r4mww80w9e3tnw9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reviews
    ADD CONSTRAINT fk35kxxqe2g9r4mww80w9e3tnw9 FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: chat_messages fk3cpkdtwdxndrjhrx3gt9q5ux9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT fk3cpkdtwdxndrjhrx3gt9q5ux9 FOREIGN KEY (session_id) REFERENCES public.chat_sessions(id);


--
-- Name: cells fk3dykl3bvacycgrefqn0kwl7kx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cells
    ADD CONSTRAINT fk3dykl3bvacycgrefqn0kwl7kx FOREIGN KEY (sector_id) REFERENCES public.sectors(id);


--
-- Name: products fk4b4af0ov0jw6r9xtq3tabt5a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk4b4af0ov0jw6r9xtq3tabt5a FOREIGN KEY (tax_rate_id) REFERENCES public.tax_rates(id);


--
-- Name: product_reviews fk58i39bhws2hss3tbcvdmrm60f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reviews
    ADD CONSTRAINT fk58i39bhws2hss3tbcvdmrm60f FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: products fk5cyj7v7fvm60i2ubciqfo2wxm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk5cyj7v7fvm60i2ubciqfo2wxm FOREIGN KEY (discount_id) REFERENCES public.discounts(id);


--
-- Name: products fk5u9vbactm63h16y9fj00t798f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk5u9vbactm63h16y9fj00t798f FOREIGN KEY (inventory_item_id) REFERENCES public.inventory_items(id);


--
-- Name: chat_sessions fk6acn2awn3clx0yvpn8htd70be; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT fk6acn2awn3clx0yvpn8htd70be FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: communication_logs fk81wbm56ml5kl04lda12gxhrxs; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_logs
    ADD CONSTRAINT fk81wbm56ml5kl04lda12gxhrxs FOREIGN KEY (handled_by_id) REFERENCES public.users(id);


--
-- Name: districts fk82doq1t64jhly7a546lpvnu2c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT fk82doq1t64jhly7a546lpvnu2c FOREIGN KEY (province_id) REFERENCES public.provinces(id);


--
-- Name: feedbacks fk8kw5agn6ypgg4lkjrbc54wk0c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT fk8kw5agn6ypgg4lkjrbc54wk0c FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: customer_profiles fk9b8jyctrw1rowxsyiwmvh3gae; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_profiles
    ADD CONSTRAINT fk9b8jyctrw1rowxsyiwmvh3gae FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: fulfillment_orders fk9r0ufkesaxvhurv9q8fch75ka; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_orders
    ADD CONSTRAINT fk9r0ufkesaxvhurv9q8fch75ka FOREIGN KEY (shipment_id) REFERENCES public.shipments(id);


--
-- Name: customer_profiles fk9u9qbkn57pxecpxjstd68deti; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_profiles
    ADD CONSTRAINT fk9u9qbkn57pxecpxjstd68deti FOREIGN KEY (segment_id) REFERENCES public.customer_segments(id);


--
-- Name: notifications fk9y21adhxn0ayjhfocscqox7bh; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk9y21adhxn0ayjhfocscqox7bh FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: villages fkancrfdwvkb9r5d743uydn9ocf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.villages
    ADD CONSTRAINT fkancrfdwvkb9r5d743uydn9ocf FOREIGN KEY (cell_id) REFERENCES public.cells(id);


--
-- Name: chat_sessions fkao4yreakip07aurht94h7lo6r; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT fkao4yreakip07aurht94h7lo6r FOREIGN KEY (agent_id) REFERENCES public.users(id);


--
-- Name: carts fkb5o626f86h46m4s7ms6ginnop; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT fkb5o626f86h46m4s7ms6ginnop FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: order_items fkbioxgbv59vetrxe0ejfubep1w; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fkbioxgbv59vetrxe0ejfubep1w FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: return_requests fkbski88d6kewx0cbj5pk7nes01; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_requests
    ADD CONSTRAINT fkbski88d6kewx0cbj5pk7nes01 FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: procurement_orders fkbvdwa0a0j4xip16ocu2twj4bk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_orders
    ADD CONSTRAINT fkbvdwa0a0j4xip16ocu2twj4bk FOREIGN KEY (inventory_item_id) REFERENCES public.inventory_items(id);


--
-- Name: procurement_orders fke1ykrunqgqpagtdqorh0ea8l; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_orders
    ADD CONSTRAINT fke1ykrunqgqpagtdqorh0ea8l FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: support_messages fkejv4umpsfsqv4amvnjrmni3xi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT fkejv4umpsfsqv4amvnjrmni3xi FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- Name: orders fkg3485uyc54ym22haggn1lwumx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fkg3485uyc54ym22haggn1lwumx FOREIGN KEY (shipping_address_id) REFERENCES public.customer_addresses(id);


--
-- Name: chat_messages fkgiqeap8ays4lf684x7m0r2729; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT fkgiqeap8ays4lf684x7m0r2729 FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: communication_logs fkgk9474pf5rnu0c37mekk9gap9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_logs
    ADD CONSTRAINT fkgk9474pf5rnu0c37mekk9gap9 FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: user_roles fkh8ciramu9cc9q3qcqiv4ue8a6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fkh8ciramu9cc9q3qcqiv4ue8a6 FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: user_roles fkhfh9dx7w3ubf1co1vdev94g3f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fkhfh9dx7w3ubf1co1vdev94g3f FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: password_reset_tokens fkk3ndxg5xp6v7wd4gjyusp15gq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT fkk3ndxg5xp6v7wd4gjyusp15gq FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sectors fklj3sbd4y976qcn545xkiptog6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectors
    ADD CONSTRAINT fklj3sbd4y976qcn545xkiptog6 FOREIGN KEY (district_id) REFERENCES public.districts(id);


--
-- Name: fulfillment_orders fklqmme8l6wu2wdx6m5pdg5kvc6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_orders
    ADD CONSTRAINT fklqmme8l6wu2wdx6m5pdg5kvc6 FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: mfa_otps fkm4pfhtf6c4ov8if1v97yfrpy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_otps
    ADD CONSTRAINT fkm4pfhtf6c4ov8if1v97yfrpy FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: orders fkmb88e3a35geg9rxiefr1qma88; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fkmb88e3a35geg9rxiefr1qma88 FOREIGN KEY (cashier_id) REFERENCES public.users(id);


--
-- Name: wishlist_items fkmmj2k1i459yu449k3h1vx5abp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist_items
    ADD CONSTRAINT fkmmj2k1i459yu449k3h1vx5abp FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payment_transactions fknsous9qyrjv5ss8que6o6617; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT fknsous9qyrjv5ss8que6o6617 FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: support_tickets fko9o82krkf7cg9ic4r5froc83v; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT fko9o82krkf7cg9ic4r5froc83v FOREIGN KEY (assigned_agent_id) REFERENCES public.users(id);


--
-- Name: order_items fkocimc7dtr037rh4ls4l95nlfi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fkocimc7dtr037rh4ls4l95nlfi FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: products fkog2rp4qthbtt2lfyhfo32lsw9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fkog2rp4qthbtt2lfyhfo32lsw9 FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: cart_items fkpcttvuq4mxppo8sxggjtn5i2c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT fkpcttvuq4mxppo8sxggjtn5i2c FOREIGN KEY (cart_id) REFERENCES public.carts(id);


--
-- Name: order_tracking_events fkpiysrnkv9a30xirabwtyd0poj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_tracking_events
    ADD CONSTRAINT fkpiysrnkv9a30xirabwtyd0poj FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: customer_metrics fkqj2ewu7pf91h6a56jvd05l6s; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_metrics
    ADD CONSTRAINT fkqj2ewu7pf91h6a56jvd05l6s FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: product_images fkqnq71xsohugpqwf3c9gxmsuy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT fkqnq71xsohugpqwf3c9gxmsuy FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: customer_addresses fkqptcrpu3x8qle4pawfritva6o; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_addresses
    ADD CONSTRAINT fkqptcrpu3x8qle4pawfritva6o FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: wishlist_items fkqxj7lncd242b59fb78rqegyxj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist_items
    ADD CONSTRAINT fkqxj7lncd242b59fb78rqegyxj FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: satisfaction_surveys fkrivxx8qmqpjxdli4nwquxol58; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.satisfaction_surveys
    ADD CONSTRAINT fkrivxx8qmqpjxdli4nwquxol58 FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- Name: shipments fkrnt4wht95lxxplspltrg9681s; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT fkrnt4wht95lxxplspltrg9681s FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: categories fksaok720gsu4u2wrgbk10b5n8d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT fksaok720gsu4u2wrgbk10b5n8d FOREIGN KEY (parent_id) REFERENCES public.categories(id);


--
-- Name: stock_movements fksf8xqne4s20910sgk48jvyx4u; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT fksf8xqne4s20910sgk48jvyx4u FOREIGN KEY (inventory_item_id) REFERENCES public.inventory_items(id);


--
-- Name: orders fksjfs85qf6vmcurlx43cnc16gy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fksjfs85qf6vmcurlx43cnc16gy FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: support_messages fkt3x5f2qc7d89medr0xxslx982; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT fkt3x5f2qc7d89medr0xxslx982 FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: procurement_orders fkthjya06tx4ktno1tw72q1vogf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_orders
    ADD CONSTRAINT fkthjya06tx4ktno1tw72q1vogf FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- PostgreSQL database dump complete
--

